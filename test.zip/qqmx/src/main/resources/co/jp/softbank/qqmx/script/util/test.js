_log.info( 'This is util test logic!!!' );
var testPhases = _db.querys("test_phases.getTestPhasesForCmb");
for ( var i = 0; i < testPhases.size(); i++) {
	var data = testPhases.get(i);
	_log.info( 'data = {}', data );
}