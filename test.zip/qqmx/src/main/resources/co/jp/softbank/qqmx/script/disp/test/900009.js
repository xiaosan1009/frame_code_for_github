function test() {
	_log.info( 'This is test logic!!!' );
	var list = Lists.newArrayList( '456' );
	list.add( '123' );
	_log.info( 'list = {}',list );
	_log.info( 'boolean = {}', _util.isEmpty( '' ) );
}