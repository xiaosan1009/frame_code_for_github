package co.jp.softbank.qqmx.logic.bean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class Param {

	public String dispCode;

	public String cmdCode;

	public String clientType;

	public int projectId;

	public String pageRowNumber;

	public String currentPage;

	public String pageOrders;
	
	public String engineTest;

	private Map<String, String[]> reqTable = new HashMap<String, String[]>();

	@SuppressWarnings("deprecation")
	public void pickParameters(ServletRequest request) {
		copyParameters(request);
		this.dispCode = get(ConstantsUtil.Param.DISP);
		this.cmdCode = get(ConstantsUtil.Param.CMD);
		this.clientType = get(ConstantsUtil.Param.TYPE);
		this.engineTest = get(ConstantsUtil.Param.Test.ENGINE);
		if (StringUtils.isNotEmpty(get(ConstantsUtil.Param.PRO_ID))) {
			this.projectId = Integer.parseInt(get(ConstantsUtil.Param.PRO_ID));
		}
		this.pageRowNumber = get(ConstantsUtil.Param.PAGE_ROW_NUMBER);
		this.currentPage = get(ConstantsUtil.Param.CURRENT_PAGE);
		this.pageOrders = get(ConstantsUtil.Param.PAGE_ORDERS);
		if (reqTable.containsKey("gantt_filter") && StringUtils.isNotEmpty(get("gantt_filter")) && request instanceof HttpServletRequest) {
			HttpServletRequest req = (HttpServletRequest) request;
			req.setAttribute("gantt_filter", get("gantt_filter"));
		}
//		if (reqTable.containsKey("gantt_filter") && StringUtils.isNotEmpty(get("gantt_filter")) && request instanceof HttpServletRequest) {
//			try {
//				HttpServletRequest req = (HttpServletRequest) request;
//				String filterStr = new String(req.getParameter("gantt_filter").getBytes("ISO-8859-1"), ConstantsUtil.Frame.ENCODING);
//				req.setAttribute("gantt_filter", filterStr);
//				reqTable.put("gantt_filter", new String[]{filterStr});
//			} catch (UnsupportedEncodingException e) {
//				e.printStackTrace();
//			}
//		}
	}

	public String get(String key) {
		final String[] value = reqTable.get(key);

		if (StringUtils.isEmpty(value)) {
			return null;
		}

		return value[0];
	}

	public void set(String key, String val) {
		if (reqTable.containsKey(key)) {
			List<String> valList = Lists.newArrayList(reqTable.get(key));
			valList.add(val);
			reqTable.put(key, valList.toArray(new String[0]));
		} else {
			reqTable.put(key, new String[]{val});
		}
	}

	public String[] getList(String key) {
		return reqTable.get(key);
	}

	public Map<String, String> getParamerterMap() {
		Map<String, String> paramerterMap = Maps.newHashMap();
		for (String key : reqTable.keySet()) {
			paramerterMap.put(key, get(key));
		}
		return paramerterMap;
	}

	public void each(EachFilter filter) throws SoftbankException {
		for (String key : reqTable.keySet()) {
			filter.filter(key, get(key));
		}
	}

	private void copyParameters(ServletRequest request) {
		this.reqTable.putAll(request.getParameterMap());
	}

	public interface EachFilter {
		void filter(String key, String value) throws SoftbankException;
	}
	
	public boolean isEngineTest() {
		return ConstantsUtil.Param.Test.DO_ENGINE_TEST_VAL.equals(engineTest);
	}
	
	public Map<String, String[]> getRequestMap() {
		return reqTable;
	}

}
