package co.jp.softbank.qqmx.logic.application.project.bean;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class TicketBean {
	
	private Map<String, Object> issuesData; 
	
	private Map<Integer, Object> customValues;
	
	private Map<String, Object> oldIssueValues;
	
	private List<Map<String, Object>> oldCustomValues;
	
	private List<Map<String, Object>> customUpdateList = Lists.newArrayList();
	
	private List<Map<String, Object>> customInsertList = Lists.newArrayList();
	
	private List<Map<String, Object>> customDeleteList = Lists.newArrayList();
	
	private List<Map<String, Object>> changeList = Lists.newArrayList();
	
	private UpdateTicketBean updateTicketBean;
	
	private boolean isPortal;
	
	private String notes;

	public Map<String, Object> getIssuesData() {
		return issuesData;
	}

	public void setIssuesData(Map<String, Object> issuesData) {
		this.issuesData = issuesData;
	}

	public Map<Integer, Object> getCustomValues() {
		return customValues;
	}

	public void setCustomValues(Map<Integer, Object> customValues) {
		this.customValues = customValues;
	}

	public Map<String, Object> getOldIssueValues() {
		return oldIssueValues;
	}

	public void setOldIssueValues(Map<String, Object> oldIssueValues) {
		this.oldIssueValues = oldIssueValues;
	}

	public List<Map<String, Object>> getOldCustomValues() {
		return oldCustomValues;
	}

	public void setOldCustomValues(List<Map<String, Object>> oldCustomValues) {
		this.oldCustomValues = oldCustomValues;
	}

	public List<Map<String, Object>> getCustomUpdateList() {
		return customUpdateList;
	}

	public void setCustomUpdateList(List<Map<String, Object>> customUpdateList) {
		this.customUpdateList = customUpdateList;
	}

	public List<Map<String, Object>> getCustomInsertList() {
		return customInsertList;
	}

	public void setCustomInsertList(List<Map<String, Object>> customInsertList) {
		this.customInsertList = customInsertList;
	}

	public List<Map<String, Object>> getCustomDeleteList() {
		return customDeleteList;
	}

	public void setCustomDeleteList(List<Map<String, Object>> customDeleteList) {
		this.customDeleteList = customDeleteList;
	}

	public List<Map<String, Object>> getChangeList() {
		return changeList;
	}

	public void setChangeList(List<Map<String, Object>> changeList) {
		this.changeList = changeList;
	}

	public boolean isPortal() {
		return isPortal;
	}

	public void setPortal(boolean isPortal) {
		this.isPortal = isPortal;
	}
	
	public int getIssueId() {
		Map<String, Object> issueValues = getIssuesData();
		int issueId = StringUtils.toInt(issueValues.get(IssueKey.ISSUE_ID.KEY));
		return issueId;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public UpdateTicketBean getUpdateTicketBean() {
		return updateTicketBean;
	}

	public void setUpdateTicketBean(UpdateTicketBean updateTicketBean) {
		this.updateTicketBean = updateTicketBean;
	}

}
