package co.jp.softbank.qqmx.dao.common;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.common.bean.HolidaysBean;
import co.jp.softbank.qqmx.dao.common.bean.PluginInfoBean;
import co.jp.softbank.qqmx.dao.roles.RolesDao;
import co.jp.softbank.qqmx.dao.roles.bean.RolesBaseBean;

public class CommonDaoService implements CommonDao {
	
	@Autowired
	private CommonDao commonDao;
	
	@Autowired
	private RolesDao rolesDao;
	
	public List<HolidaysBean> selectHolidaysInfo() {
		return commonDao.selectHolidaysInfo();
	}

	@Override
	public List<PluginInfoBean> selectPluginInfo() {
		return commonDao.selectPluginInfo();
	}

	@Override
	public List<RolesBaseBean> selectAllRolesBaseInfo() {
		return rolesDao.selectAllRolesBaseInfo();
	}

	@Override
	public Map<String, Long> executeSqlForPageCount(Map<String, Object> conditions) {
		return null;
	}

	@Override
	public List<Map<String, Object>> executeSqlForPage(Map<String, Object> conditions) {
		return null;
	}

	@Override
	public List<Map<String, Object>> getEnabledScmInfos() {
		return commonDao.getEnabledScmInfos();
	}

}
