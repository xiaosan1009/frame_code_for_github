package co.jp.softbank.qqmx.dao.project.help;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.project.help.bean.HelpQuestionBean;
import co.jp.softbank.qqmx.dao.project.help.bean.HelpQuestionCategoryBean;

public interface HelpDao {
	
	List<HelpQuestionCategoryBean> getQuestionsCategory();
	
	List<HelpQuestionBean> getQuestions(Map<String, Object> conditions);
	
	void addQuestionHistory(Map<String, Object> conditions);

	List<HelpQuestionBean> getQuestionHistoryByUser(Map<String, Object> conditions);
	
	void addQuestion(Map<String, Object> conditions);
	
	List<HelpQuestionBean> getQuestionsByKeyword(Map<String, Object> conditions);

	List<HelpQuestionCategoryBean> getLatestQuestion();

	List<HelpQuestionCategoryBean> getOftenSeeQuestion();
	
	List<Map<String, Object>> getNews();
	
	List<Map<String, Object>> getQuestionsById(Map<String, Object> conditions);
	
	List<Map<String, Object>> updateQuestionById(Map<String, Object> conditions);
	
	Map<String, Object> getUserAddressByUserId(Map<String, Object> conditions);

}
