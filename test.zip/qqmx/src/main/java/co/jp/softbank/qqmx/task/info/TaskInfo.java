package co.jp.softbank.qqmx.task.info;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.task.face.IReader;
import co.jp.softbank.qqmx.task.face.ITask;
import co.jp.softbank.qqmx.util.ObjectUtils;

public class TaskInfo {
	
	private ITask task;

	private Class<?> inputType;
	
	private TaskInfo pre;
	
	private TaskInfo next;
	
	private int numOfThreads;
	
	private IReader<? extends Object> reader;
	
	public TaskInfo(ITask<?> task) throws SoftbankException {
		try {
			this.task = task;
			numOfThreads = task.numOfThreads();
			reader = task.getReader();
			Class<?>[] args = ObjectUtils.getActualTypeArguments(task);
			if (args == null) {
				throw new SoftbankException(SoftbankExceptionType.TaskHasNoInputType);
			}
			inputType = args[0] != null ? args[0] : String.class;
		} catch (Exception e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SystemException, e);
		}
	}

	public <V> ITask<V> getTask() {
		return task;
	}

	public void setTask(ITask<?> task) {
		this.task = task;
	}

	public Class<?> getInputType() {
		return inputType;
	}

	public void setInputType(Class<?> inputType) {
		this.inputType = inputType;
	}

	public TaskInfo getPre() {
		return pre;
	}

	public void setPre(TaskInfo pre) {
		this.pre = pre;
	}

	public TaskInfo getNext() {
		return next;
	}

	public void setNext(TaskInfo next) {
		this.next = next;
	}
	
	public boolean isFirst() {
        return pre == null;
    }

    public boolean isLast() {
        return next == null;
    }
	
    public int numOfThreads() {
        return numOfThreads;
    }

	public IReader<? extends Object> getReader() {
		return reader;
	}
    
}
