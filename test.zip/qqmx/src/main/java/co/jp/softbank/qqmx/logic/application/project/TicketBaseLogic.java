package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONArray;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.application.project.bean.TicketBean;
import co.jp.softbank.qqmx.logic.application.project.bean.UpdateTicketBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

public class TicketBaseLogic extends AbstractBaseLogic {
	
	protected Map<String, Object> getTicketById(int issueId, int projectId) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("issue_id", issueId);
		List<Map<String, Object>> customFields = db.querys("issues.getCustomFieldsForOldByIssueId", conditions);
		conditions.put("customFields", customFields);
		return db.query("issues.getTicketAllInfoById", conditions);
	}
	
	protected void updateTicket(final int issueId) throws SoftbankException {
		
		final Map<String, Object> issueValues = Maps.newHashMap();
		final Map<Integer, Object> customValues = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("tracker_id", Integer.parseInt(context.getParam().get("issue_tracker_id")));
		List<Map<String, Object>> boolList = db.querys("issues.getBoolDate", conditions);
		for (int i = 0; i < boolList.size(); i++) {
			customValues.put(StringUtils.toInt(boolList.get(i).get("id")), "0");
		}
		
		context.getParam().each(new Param.EachFilter() {
			@Override
			public void filter(String key, String value) {
				if (key.startsWith("issue_custom_field_values_")) {
					customValues.put(StringUtils.toInt(key.substring("issue_custom_field_values_".length())), value);
				} else if (key.startsWith("issue_")) {
					if (!"".equals(value)){
						issueValues.put(key.substring("issue_".length()), value);
					}
				}
			}
		});
		
		issueValues.put("issue_id", issueId);
		issueValues.put("lock_version", context.getParam().get("lock_version"));
		// データ変更前のROOTID取得する。
		int rootIdBak = selectRootIdInfo(issueId);
		
		TicketBean ticketBean = new TicketBean();
		ticketBean.setIssuesData(issueValues);
		ticketBean.setCustomValues(customValues);
		ticketBean.setNotes(context.getParam().get("notes"));
		
		List<String> watcherUserIds = Lists.newArrayList();
		if (context.getParam().getList("watcher_user_ids") != null) {
			watcherUserIds = Lists.newArrayList(context.getParam().getList("watcher_user_ids"));
		}
		
		updateWatcherInfo(issueId, watcherUserIds);

		updateTicket(ticketBean);
		
		//　データ変更後のPARENTID。
		Object strIssueId = ticketBean.getIssuesData().get("parent_id");
		if (issueId == rootIdBak){
			if (!"".equals(strIssueId)){
				int rootIdNew = selectRootIdInfo(StringUtils.toInt(strIssueId));
				if (rootIdNew != 0){
					// rootIdNew TODO 共通LFT更新機能
					
				}
			}
		} else {
			if ("".equals(strIssueId)){
				// rootIdBak
			} else {
				int rootIdNew = selectRootIdInfo(StringUtils.toInt(strIssueId));
				if (rootIdBak == rootIdNew){
					
				} else {
					
				}
			}
		}
	}
	
	private void updateWatcherInfo(final int issueId, List<String> watcherUserIds) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		List<Map<String, Object>> oldWatchers = db.querys("issues.getIssueWatchers", conditions);

		List<String> watcherDeleteList = Lists.newArrayList();
		for (Map<String, Object> watcher_old : oldWatchers) {
			if (watcherUserIds.contains(watcher_old.get("user_id").toString())) {
				watcherUserIds.remove(watcher_old.get("user_id").toString());
			} else {
				watcherDeleteList.add(watcher_old.get("user_id").toString());
			}
		}
		
		if (watcherDeleteList != null && watcherDeleteList.size() > 0) {
			for (String watcherDelete : watcherDeleteList) {
				conditions.put("watchable_id", issueId);
				conditions.put("user_id", Integer.parseInt(watcherDelete));
				db.delete("issues.deleteWatchers", conditions);
			}
		}

		if (watcherUserIds != null && watcherUserIds.size() > 0) {
			for (String issue_watcher_user_id : watcherUserIds) {
				conditions.put("watchable_id", issueId);
				conditions.put("user_id", Integer.parseInt(issue_watcher_user_id));
				db.insert("issues.insertWatchers", conditions);
			}
		}
	}
	
	protected boolean updateTicket(final Map<String, Object> issuesData, Map<Integer, Object> customValues) throws SoftbankException {
		return updateTicket(issuesData, customValues, null);
	}
	
	protected boolean updateTicket(final Map<String, Object> issuesData, Map<Integer, Object> customValues, UpdateTicketBean updateTicketBean) throws SoftbankException {
		TicketBean ticketBean = new TicketBean();
		ticketBean.setIssuesData(issuesData);
		ticketBean.setCustomValues(customValues);
		ticketBean.setUpdateTicketBean(updateTicketBean);
		ticketBean.setNotes(StringUtils.toString(issuesData.get(IssueKey.PROCESS.NOTES)));
		boolean result = updateTicket(ticketBean);
		if (result) {
			if (StringUtils.isNotEmpty(issuesData.get(IssueKey.PROCESS.WATCHER_USER_IDS))) {
				int issueId = ticketBean.getIssueId();
				String watcherUserIdstr = StringUtils.toString(issuesData.get(IssueKey.PROCESS.WATCHER_USER_IDS));
				List<String> watcherUserIds = Lists.newArrayList();
				if (!"empty".equals(watcherUserIdstr)) {
					JSONArray watcherArray = JSONArray.fromObject(watcherUserIdstr);
					if (watcherArray.size() > 0) {
						for (int i = 0; i < watcherArray.size(); i++) {
							watcherUserIds.add(watcherArray.getString(i));
						}
					}
				}
				updateWatcherInfo(issueId, watcherUserIds);
			}
		}
		return result;
	}
	
	protected boolean updatePortalTicket(final Map<String, Object> issuesData) throws SoftbankException {
		TicketBean ticketBean = new TicketBean();
		ticketBean.setPortal(true);
		ticketBean.setIssuesData(issuesData);
		return updateTicket(ticketBean);
	}
	
	protected boolean updateTicket(TicketBean ticketBean) throws SoftbankException {
		Map<String, Object> issueValues = ticketBean.getIssuesData();
		int issueId = ticketBean.getIssueId();
		if (issueValues.containsKey(IssueKey.PROCESS.ONLY_ORDER_CHANGED)) {
			db.update("issues.updateIssuesOrderById", issueValues);
			return true;
		}
		Map<String, Object> conditions = Maps.newHashMap();
		Map<String, Object> oldIssueValues = getOldIssueValues(ticketBean, issueId);
		ticketBean.setOldIssueValues(oldIssueValues);
		
		if (oldIssueValues == null || StringUtils.toInt(oldIssueValues.get(IssueKey.LOCK_VERSION.KEY)) != StringUtils.toInt(issueValues.get(IssueKey.LOCK_VERSION.KEY))) {
			return false;
		}
		
		Map<Integer, Object> customValues = ticketBean.getCustomValues();
		
		for (Map.Entry<String, Object> issueValue : issueValues.entrySet()) {
			String key = issueValue.getKey();
			Object old_value = oldIssueValues.get(key);
			String value = StringUtils.toString(issueValue.getValue());
			if (IssueKey.PROCESS.NOT_CHANGED.equals(value)) {
				continue;
			}
			if (!IssueKey.LFT.KEY.equals(key)
					&& !IssueKey.ISSUE_ID.KEY.equals(key)
					&& !IssueKey.ROOT_ID.KEY.equals(key)
					&& !IssueKey.ROOT_SEQ.KEY.equals(key)
					&& !IssueKey.PROCESS.FLOOR_ID.equals(key)
					&& !IssueKey.PROCESS.ADDFLG.equals(key)
					&& !IssueKey.PROCESS.ISDELETE.equals(key)
					&& !IssueKey.PROCESS.ISUPDATE.equals(key)
					&& !IssueKey.PROCESS.ISPARENT.equals(key)
					&& !IssueKey.PROCESS.WATCHER_USER_IDS.equals(key)
					&& !IssueKey.PROCESS.NOTES.equals(key)
					&& !IssueKey.CUSTOMVALUES.KEY.equals(key)
					&& !IssueKey.LOCK_VERSION.KEY.equals(key)
					&& !"added".equals(key)
					&& !IssueKey.RGT.KEY.equals(key) 
					&& isChanged(old_value, value)) {
				Map<String, Object> changes = Maps.newHashMap();
				changes.put("property", "attr");
				changes.put("prop_key", key);
				if (IssueKey.ASSIGNED_TO_ID.KEY.equals(key) || IssueKey.FIXED_VERSION_ID.KEY.equals(key)) {
					if (StringUtils.isEmpty(old_value)) {
						old_value = null;
					}
					if (StringUtils.isEmpty(value)) {
						value = null;
					}
				}
				changes.put("old_value", old_value);
				changes.put("value", value);
				ticketBean.getChangeList().add(changes);
			}
		}
		
		if (customValues != null && customValues.size() > 0) {
			conditions.put("issue_id", issueId);
			conditions.put("project_id", oldIssueValues.get("project_id"));
			conditions.put("tracker_id", oldIssueValues.get("tracker_id"));
			List<Map<String, Object>> oldCustomValues = null;
			if (ticketBean.getUpdateTicketBean() != null) {
				oldCustomValues = ticketBean.getUpdateTicketBean().getIssuesCustomValues(issueId);
			} else {
				oldCustomValues = db.querys("issues.selectIssueCustomFieldsAndValues", conditions);
			}
//			List<Map<String, Object>> oldCustomValues = db.querys("issues.selectIssueCustomFieldsAndValues", conditions);
			if (oldCustomValues != null) {
				ticketBean.setOldCustomValues(oldCustomValues);
				for (Map<String, Object> customValue_old : oldCustomValues) {
					if (StringUtils.isEmpty(customValue_old.get("custom_values_id"))) {
						continue;
					}
					if (customValues.containsKey(customValue_old.get("id"))) {
						Object old_value = customValue_old.get("value");
						String value = StringUtils.toString(customValues.get(customValue_old.get("id")));
						if (isChanged(old_value, value)) {
							Map<String, Object> customUpdate = Maps.newHashMap();
							customUpdate.put("custom_values_id", customValue_old.get("custom_values_id"));
							customUpdate.put("property", "cf");
							customUpdate.put("prop_key", customValue_old.get("id").toString());
							customUpdate.put("old_value", old_value);
							customUpdate.put("value", value);
							ticketBean.getCustomUpdateList().add(customUpdate);
							ticketBean.getChangeList().add(customUpdate);
						}
						customValues.remove(customValue_old.get("id"));
					} else {
						Map<String, Object> customUpdate = Maps.newHashMap();
						customUpdate.put("custom_values_id", customValue_old.get("custom_values_id"));
						if (ticketBean.getUpdateTicketBean() != null) {
							ticketBean.getUpdateTicketBean().addDeleteCustomValueId(customUpdate);
						} else {
							ticketBean.getCustomDeleteList().add(customUpdate);
						}
					}
				}
			}
			
			for (Map.Entry<Integer, Object> customValue : customValues.entrySet()) {
				Map<String, Object> customValueInfo = Maps.newHashMap();
				customValueInfo.put("customized_id", issueId);
				customValueInfo.put("custom_field_id", customValue.getKey());
				customValueInfo.put("value", customValue.getValue());
				if (StringUtils.isNotEmpty(customValue.getValue())) {
					customValueInfo.put("property", "cf");
					customValueInfo.put("prop_key", customValue.getKey());
					customValueInfo.put("old_value", "");
					ticketBean.getChangeList().add(customValueInfo);
				}
				ticketBean.getCustomInsertList().add(customValueInfo);
			}
		}
		if (ticketBean.isPortal()) {
			db.update("issues.updateIssuesInfoForPortal", issueValues);
		} else {
			if (ticketBean.getUpdateTicketBean() != null) {
				ticketBean.getUpdateTicketBean().addUpdateIssueValue(issueValues);
			} else {
				db.update("issues.updateIssuesById", issueValues);
			}
		}
		
		if (ticketBean.getCustomUpdateList().size() > 0) {
			for (Map<String, Object> customUpdate : ticketBean.getCustomUpdateList()) {
				if (customUpdate.get("custom_values_id") != null){
					db.update("issues.updateCustomValuesById", customUpdate);
				}
			}
		}
		
		if (ticketBean.getCustomInsertList().size() > 0) {
			Map<String, Object> map = Maps.newHashMap();
			map.put("customValues", ticketBean.getCustomInsertList());
			db.insert("issues.insertIssueCustomValues", map);
		}
		
		if (ticketBean.getCustomDeleteList().size() > 0) {
			for (Map<String, Object> customDelete : ticketBean.getCustomDeleteList()) {
				db.delete("issues.deleteCustomValuesById", customDelete);
			}
		}
		
		if (ticketBean.getChangeList().size() > 0 || StringUtils.isNotEmpty(ticketBean.getNotes()) ) {
			conditions = Maps.newHashMap();
			conditions.put("journalized_id", issueId);
			conditions.put("user_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
			conditions.put("notes", ticketBean.getNotes());
			if (ticketBean.getUpdateTicketBean() != null) {
				ticketBean.getUpdateTicketBean().addJournalizedList(conditions, ticketBean.getChangeList());
			} else {
				db.insert("issues.insertJournals", conditions);
				if (!ControlSettingMap.getInstance().getBoolean(ControlSettingMap.SettingKey.DEBUG_MODEL)) {
					sendMailSync(StringUtils.toString(conditions.get("id")), "edit");
				}
				for (Map<String, Object> changeItem : ticketBean.getChangeList()) {
					changeItem.put("journal_id", conditions.get("id"));
					db.insert("issues.insertJournalDetails", changeItem);
				}
			}
		}
		return true;
	}

	private Map<String, Object> getOldIssueValues(TicketBean ticketBean, int issueId) throws SoftbankException {
		if (ticketBean.getUpdateTicketBean() != null) {
			return ticketBean.getUpdateTicketBean().getOldIssueData(issueId);
		}
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		Map<String, Object> oldIssueValues = db.query("issues.selectIssueById", conditions);
		return oldIssueValues;
	}
	
	protected List<Map<String, Object>> updateIssueWithParent(Map<String, Object> issueData) throws SoftbankException {
		return updateIssueWithParent(Lists.newArrayList(issueData));
	}
	
	protected List<Map<String, Object>> updateIssueWithParent(List<Map<String, Object>> issueDatas) throws SoftbankException {
		return updateIssueWithParent(issueDatas, false);
	}
	
	protected List<Map<String, Object>> updateIssueWithParent(List<Map<String, Object>> issueDatas, boolean isPortal) throws SoftbankException {
		List<Map<String, Object>> conflicts = Lists.newArrayList();
		Set<Integer> set = Sets.newHashSet(); 
		for (int i = 0; i < issueDatas.size(); i++) {
			Map<String, Object> data = issueDatas.get(i);
			String tid = StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY));
			if (!tid.equals(StringUtils.toString(data.get(IssueKey.ROOT_ID.KEY)))) {
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("issue_id", tid);
				List<Map<String, Object>> parentList = db.querys("issues.getTicketParentInfo", conditions);
				for (int j = 0; j < parentList.size(); j++) {
					int parentId = StringUtils.toInt(parentList.get(j).get("id"));
					if (!set.contains(parentId)) {
						set.add(parentId);
					}
				}
			}
			boolean isConfilict = false;
			if (isPortal) {
				int progress = StringUtils.toInt(data.get(IssueKey.DONE_RATIO.KEY));
				int status_id = 2;
				switch (progress) {
				case 0:
					status_id = 1;
					break;
				case 100:
					status_id = 3;
					break;

				default:
					break;
				}
				data.put(IssueKey.STATUS_ID.KEY, status_id);
				isConfilict = !updatePortalTicket(data);
			} else {
				isConfilict = !updateTicket(data, (Map<Integer, Object>)data.get(IssueKey.CUSTOMVALUES.KEY));
			}
			if (isConfilict) {
				conflicts.add(data);
			}
		}
		for (Integer tid : set) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issue_id", tid);
			db.update("issues.updateIssueParentInfo", conditions);
		}
		return conflicts;
	}
	
	@SuppressWarnings("unchecked")
	protected void insertIssue(Map<String, Object> data, List<Map<String, Object>> customFieldList, int issueId) throws SoftbankException {
//		db.insert("issues.insertIssueInfoForGantt", data);
//		sendMailSync(StringUtils.toString(issueId), "add");
		insertCustomValues(data, issueId, customFieldList);
	}

	@SuppressWarnings("unchecked")
	private void insertCustomValues(Map<String, Object> data, final int issueId, List<Map<String, Object>> customFieldList)
			throws SoftbankException {
		Map<Integer, Object> customValues = (Map<Integer, Object>)data.get(IssueKey.CUSTOMVALUES.KEY);
		final List<Map<String, Object>> customValuesList = Lists.newArrayList();
		for (Map.Entry<Integer, Object> customValue : customValues.entrySet()) {
			if (StringUtils.isEmpty(customValue.getValue())) {
				continue;
			}
			Map<String, Object> customValueInfo = Maps.newHashMap();
			customValueInfo.put("customized_id", issueId);
			customValueInfo.put("custom_field_id", customValue.getKey());
			customValueInfo.put("value", customValue.getValue());
			customValuesList.add(customValueInfo);
		}
		if (customValuesList != null && customValuesList.size() > 0) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("customValues", customValuesList);
			customFieldList.add(conditions);
		}
	}
	
	private void sendMail(String id, String event) throws SoftbankException {
		log.info("sendMail start! id = {}, event = {}", id, event);
		Map<String, String> params = Maps.newHashMap();
		params.put("id", id);
		params.put("type", "issue");
		params.put("event", event);
		externalHttpServer.post("send_mail_by_api", params);
		log.info("sendMail end!");
	}
	
	protected void sendMailSync(final String id, final String event) {
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					sendMail(id, event);
				} catch (SoftbankException e) {
					e.printStackTrace();
					log.error(e.getErrorMsg(), e);
				}
			}
		});
		t.start();
	}

	public int selectRootIdInfo(int issueId) throws SoftbankException {
		int rootId = 0;
		if (!"null".equals(issueId)){
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issueId", issueId);
			List<Map<String, Object>> rootIdList = db.querys("issues.selectIssueRootId", conditions);
			if (rootIdList.size() > 0){
				rootId = Integer.parseInt(String.valueOf(rootIdList.get(0)));
			}
		}
		return rootId;
	}
	
	private static boolean isChanged(Object oldValue, String value) {
		boolean isChanged = false;
		if (StringUtils.isEmpty(oldValue)) {
			if (StringUtils.isNotEmpty(value)) {
				isChanged = true;
			}
		} else {
			if (StringUtils.isEmpty(value)) {
				isChanged = true;
			} else {
				try {
					if (Double.parseDouble(value) != Double.parseDouble(StringUtils.toString(oldValue))) {
						isChanged = true;
					}
				} catch (NumberFormatException e) {
					if (!org.apache.commons.lang.StringUtils.equals(value, oldValue.toString())) {
						isChanged = true;
					}
				}
			}
		}
		return isChanged;
	}
	
	protected void deleteTicketById(final int issue_id) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issue_id);
		db.delete("issues.deleteIssueRelationsByIssueId", conditions);
		db.delete("issues.deleteWatchersByIssueId", conditions);
		db.delete("issues.deleteJournalDetailsByIssueId", conditions);
		db.delete("issues.deleteJournalsByIssueId", conditions);
		db.delete("issues.deleteCustomValuesByIssueId", conditions);
		db.delete("issues.deleteIssuesById", conditions);
	}
	
	protected void deleteTicketOnlyById(final int issue_id) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issue_id);
		db.delete("issues.deleteIssueRelationsOnlyByIssueId", conditions);
		db.delete("issues.deleteWatchersOnlyByIssueId", conditions);
		db.delete("issues.deleteJournalDetailsOnlyByIssueId", conditions);
		db.delete("issues.deleteJournalsOnlyByIssueId", conditions);
		db.delete("issues.deleteCustomValuesOnlyByIssueId", conditions);
		db.delete("issues.deleteIssuesOnlyById", conditions);
	}

}
