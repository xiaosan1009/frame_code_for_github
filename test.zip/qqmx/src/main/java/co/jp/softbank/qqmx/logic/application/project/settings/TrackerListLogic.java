package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.TrackerListDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class TrackerListLogic extends AbstractBaseLogic {

	@Autowired
	private TrackerListDao trackerListDao;

	public void getTrackerListInfo() throws SoftbankException {
		PageListBean pageListBean = pageList(trackerListDao, "getTrackerListInfo");
		context.getResultBean().setData(pageListBean);
	}

	public void delTrackerListId() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("tracker_id", Integer.parseInt(context.getParam().get("tracker_id")));
		trackerListDao.delWorkflows(conditions);

		List<Map<String, Object>> trackerListIdList = trackerListDao.getTrackerListIdInfo(conditions);
		conditions.put("position_id", Integer.parseInt(String.valueOf(trackerListIdList.get(0).get("position"))));
		trackerListDao.updataTrackers(conditions);
		trackerListDao.delCustomFieldsTrackers(conditions);
		trackerListDao.delProjectsTrackers(conditions);
		trackerListDao.delTrackerListId(conditions);
	}
	
	public void saveTracker() throws SoftbankException {
		
		String[] customFieldsIds = context.getParam().getList("custom_fields_ids");
		String[] projectIds = context.getParam().getList("project_ids");
		Map<String, Object> conditions = Maps.newHashMap();
		String name = context.getParam().get("name");
		conditions.put("name", name);
		conditions.put("is_in_roadmap", "true".equals(context.getParam().get("tracker_is_in_roadmap")) ? true : false);
		conditions.put("is_in_chlog", false);
		
		int trackerId = 0;
		if ( "0".equals(context.getParam().get("up_flg"))){
			trackerListDao.insertTrackers(conditions);
			trackerId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		}else{
			trackerId = Integer.parseInt(context.getParam().get("up_flg"));
			conditions.put("tracker_id", trackerId);
			trackerListDao.updateTrackers(conditions);
		}
		
		Map<String, Object> conditionProjectsTracker = Maps.newHashMap();
		conditionProjectsTracker.put("tracker_id", trackerId);
		trackerListDao.delProjectsTrackers(conditionProjectsTracker);
		for (int i=0; i<projectIds.length; i++ ){
			conditionProjectsTracker.put("project_id", Integer.parseInt(projectIds[i]));	
			trackerListDao.insertProjectsTrackers(conditionProjectsTracker);	
		}
		
		Map<String, Object> conditionCustomFieldsTrackers = Maps.newHashMap();
		conditionCustomFieldsTrackers.put("tracker_id", trackerId);
		trackerListDao.delCustomFieldsTrackers(conditionCustomFieldsTrackers);
		for (int i=0; i<customFieldsIds.length; i++ ){
			conditionCustomFieldsTrackers.put("custom_field_id", Integer.parseInt(customFieldsIds[i]));
			trackerListDao.insertCustomFieldsTrackers(conditionCustomFieldsTrackers);
		}

		String strWorkflow = context.getParam().get("copy_tracker_workflow_from");
		if (strWorkflow != ""){
			int bakTrackerId = Integer.parseInt(strWorkflow);
			List<Map<String, Object>> selectRolesList = trackerListDao.selectRoles();
			for (int i = 0; i < selectRolesList.size(); i++) {
				Map<String, Object> workflowsMap = Maps.newHashMap();
				String role_id = String.valueOf(selectRolesList.get(i).get("id"));
				workflowsMap.put("new_tracker_id", trackerId);
				workflowsMap.put("bak_tracker_id", bakTrackerId);
				workflowsMap.put("role_id", Integer.parseInt(role_id));
				trackerListDao.deleteWorkflows(workflowsMap);
				trackerListDao.inserWorkflows(workflowsMap);
			}
		}
	}
	
	public LogicBean getTrackerListCustomFields() throws SoftbankException {
		LogicBean trackerBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("input_date"));
		trackerBean.setData(trackerListDao.getTrackerListCustomFields(conditions));
		return trackerBean;
	}
	
	public LogicBean getWorkflows() throws SoftbankException {
		LogicBean trackerBean = new LogicBean();
		trackerBean.setData(trackerListDao.getTrackerListInfo());
		return trackerBean;
	}
	
	public LogicBean getTrackerListId() throws SoftbankException {
		LogicBean trackerBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("tracker_id", Integer.parseInt(context.getParam().get("tracker_id")));
		trackerBean.setData(trackerListDao.getTrackerListIdInfo(conditions));
		return trackerBean;
	}
	
	public LogicBean getTrackerListProjects() throws SoftbankException {
		LogicBean trackerBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("input_date"));
		trackerBean.setData(trackerListDao.getTrackerListProjects(conditions));
		return trackerBean;
	}
	
	public void upTrackerSort() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		List<Map<String, Object>> trackerListEndIdList = trackerListDao.getTrackerListInfo();
		String str_end_position = String.valueOf(trackerListEndIdList.get(Integer.parseInt(context.getParam().get("end_pos"))).get("position"));
		
		conditions.put("tracker_id", Integer.parseInt(context.getParam().get("tracker_id")));
		List<Map<String, Object>> trackerListIdList = trackerListDao.getTrackerListIdInfo(conditions);
		if (Integer.parseInt(str_end_position) > Integer.parseInt(String.valueOf(trackerListIdList.get(0).get("position")))){
			conditions.put("end_pos", Integer.parseInt(str_end_position));
			conditions.put("start_pos", Integer.parseInt(String.valueOf(trackerListIdList.get(0).get("position"))));
			trackerListDao.upCommonMSort(conditions);
		}else{
			conditions.put("end_pos", Integer.parseInt(String.valueOf(trackerListIdList.get(0).get("position"))));
			conditions.put("start_pos", Integer.parseInt(str_end_position));
			trackerListDao.upCommonPSort(conditions);
		}
		Map<String, Object> conditionSort = Maps.newHashMap();
		conditionSort.put("tracker_id", Integer.parseInt(context.getParam().get("tracker_id")));
		conditionSort.put("end_pos", Integer.parseInt(str_end_position));
		trackerListDao.upCommonSort(conditionSort);

	}
	
}
