package co.jp.softbank.qqmx.logic.application.dasmain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.dasmain.DasmainDao;
import co.jp.softbank.qqmx.dao.project.ProjectDao;
import co.jp.softbank.qqmx.dao.project.bean.ProjectInfoBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.server.ExternalHttpServer;
import co.jp.softbank.qqmx.util.StringUtils;

public class DasmainLogic extends AbstractBaseLogic {
	
	@Autowired
	private DasmainDao dasmainDao;
	
	@Autowired
	private ProjectDao projectDao;
	
	@Override
	public void init() throws SoftbankException {
		if (StringUtils.isNotEmpty(context.getParam().projectId) && context.getParam().projectId != 0) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("project_id", context.getParam().projectId);
			context.getSessionData().set(ProjectInfoBean.PROJECT_INFO_KEY, projectDao.getProjectInfosById(conditions));
		}
	}
	
	public LogicBean getUserInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		Map<String, Object> data = Maps.newHashMap();
		data.put("userLogin", userInfoData.getLogin());
		data.put("userName", userInfoData.getName());
		logicBean.setData(data);
		return logicBean;
	}
	
	public void getUserInformationById() throws SoftbankException {
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		Map<String, Object> informationMap = Maps.newHashMap();
		List<Map<String, Object>> informationListMap = Lists.newArrayList();
		Map<String, Object> informationDataMap = Maps.newHashMap();
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("id", userInfoData.getId());
		
		List<Map<String, Object>> information1 = dasmainDao.getUserInformationById(data);
		List<Map<String, Object>> information2 = dasmainDao.getUserInformation1ById(data);
		List<Map<String, Object>> information3 = dasmainDao.getUserInformation2ById(data);
		
		informationDataMap.put("information1", information1);
		informationDataMap.put("information2", information2);
		informationDataMap.put("information3", information3);
		informationListMap.add(informationDataMap);
		
		informationMap.put("information", informationListMap);
		
		context.getResultBean().setData(informationMap);
	}
	
	public void getUserTicketPlanById() throws SoftbankException {
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("id", userInfoData.getId());
		context.getResultBean().setData(dasmainDao.getUserTicketPlanById(data));
	}
	
	
	public void getUserMonthInfoById() throws SoftbankException {
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("id", userInfoData.getId());
		context.getResultBean().setData(dasmainDao.getUserMonthInfoById(data));
	}
	
	public void getUserDelayInfoById() throws SoftbankException {
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("id", userInfoData.getId());
		context.getResultBean().setData(dasmainDao.getUserDelayInfoById(data));
	}
	
	public void getUserTaskInfoById() throws SoftbankException {
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("id", userInfoData.getId());
		context.getResultBean().setData(dasmainDao.getUserTaskInfoById(data));
	}
	
	public void getUserNewsInfoById() throws SoftbankException {
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("id", userInfoData.getId());
		context.getResultBean().setData(dasmainDao.getUserNewsInfoById(data));
	}
	
	@SuppressWarnings("unchecked")
	public LogicBean getProjectInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		logicBean.setData(dasmainDao.getProjectInfos());
		return logicBean;
	}
	
	@Override
	protected IDaoInterface getDao() {
		return null;
	}

}
