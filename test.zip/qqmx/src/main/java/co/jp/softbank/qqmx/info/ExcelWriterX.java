package co.jp.softbank.qqmx.info;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFDrawing;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.face.IExcelWriter;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.bean.ExportFileInfo;
import co.jp.softbank.qqmx.util.StringUtils;

public class ExcelWriterX extends ExcelWriterBase implements IExcelWriter {
	
	private static final int MAX_ROW_ACCESS = 100;
	
	protected SXSSFWorkbook wb;
	
	private int templateRowNumber;
	
	private List<String> templateHeaderList;
	
	private Map<String, CellStyle> cellStyleMap = Maps.newHashMap();
	
	private CellStyle errorStyle;

	public ExcelWriterX(HttpContext context) throws SoftbankException {
		super(context);
		wb = new SXSSFWorkbook(MAX_ROW_ACCESS);
	}
	
	public ExcelWriterX(HttpContext context, CreateFileName createFileName) throws SoftbankException {
		super(context, createFileName);
		wb = new SXSSFWorkbook(MAX_ROW_ACCESS);
	}
	
	public ExcelWriterX(HttpContext context, Map<String, Object> templateMap, CreateFileName createFileName) throws SoftbankException {
		super(context, createFileName);
		File templateFile = new File(StringUtils.toString(templateMap.get("description")));
		XSSFWorkbook wbt = null;
		try {
			wbt = new XSSFWorkbook(templateFile);
			Sheet sheet = wbt.getSheet("チケット");
			int headerRow = StringUtils.toInt(templateMap.get("header_row"));
			Row row = sheet.getRow(headerRow - 1);
			templateRowNumber = row.getPhysicalNumberOfCells();
			
			templateHeaderList = Lists.newArrayList();
			for (int i = 0; i < templateRowNumber; i++) {
				templateHeaderList.add(StringUtils.toString(row.getCell(i)));
			}
			
			wb = new SXSSFWorkbook(wbt, MAX_ROW_ACCESS);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
	}

	@Override
	public ExportFileInfo create(List<Map<String, Object>> headerColumns, List<Map<String, Object>> datas) throws SoftbankException {
		try {
			Sheet sheet = wb.createSheet("チケット");
			SXSSFDrawing patriarch = (SXSSFDrawing)sheet.createDrawingPatriarch();
			createHeaderRow(headerColumns, sheet);
			for (int i = 1; i <= datas.size(); i++) {
				Map<String, Object> data = datas.get(i - 1);
				Row row = sheet.createRow(i);
				for (int j = 0; j < headerColumns.size(); j++) {
					Map<String, Object> column = headerColumns.get(j);
					String key = StringUtils.toString(column.get("value"));
					Cell cell = row.createCell(j);
					String cellValue = "";
					if (data.containsKey(key)) {
						cellValue = StringUtils.toString(data.get(key));
					}
					if (cellAnalysis != null) {
						cellAnalysis.analysis(cell, data, key, cellValue, j);
					} else {
						cell.setCellValue(cellValue);
					}
					if (cellFormat != null) {
						if (cellStyleMap.containsKey(key)) {
							CellStyle style = cellStyleMap.get(key);
							cell.setCellStyle(style);
						} else {
							CellStyle style = cellFormat.format(wb, cell, data, key, null);
							if (style != null) {
								cellStyleMap.put(key, style);
							}
						}
					}
					if (cellErrorStyle != null) {
						errorStyle = cellErrorStyle.format(wb, patriarch, cell, data, key, errorStyle, i, j);
					}
				}
				if (i % MAX_ROW_ACCESS == 0) {
					((SXSSFSheet)sheet).flushRows();
				}
			}
//			((SXSSFSheet)sheet).flushRows();
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
		try {
			FileOutputStream output = new FileOutputStream(fileInfo.getFile());
			wb.write(output);
			output.flush();
			return fileInfo;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.FileNotFoundException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
	}
	
	public ExportFileInfo getExport(Map<String, String> optMap, List<Map<String, Object>> datas, Map<String, Object> templateMap) throws SoftbankException {
		int headerCol = 0;
		int headerRow = 0;
		if (!templateMap.isEmpty()) {
			headerCol = StringUtils.toInt(templateMap.get("header_col"));
			headerRow = StringUtils.toInt(templateMap.get("header_row"));
		}
		
		Sheet sheet = wb.getSheet("チケット");
		
		try {
			
			for (int i = headerRow; i < datas.size() + headerRow; i++) {

				Map<String, Object> data = datas.get(i - headerRow);
				Row row = sheet.createRow(i);
				int d = 0;
				for (int j = 0; j < templateRowNumber - headerCol; j++) {
					String value = String.valueOf(templateHeaderList.get(j));
					String key = StringUtils.toString(optMap.get(value));
					Cell cell = row.createCell(j);
					String cellValue = "";
					if (data.containsKey(key)) {
						cellValue = StringUtils.toString(data.get(key));
					}
					if (cellAnalysis != null) {
						if (IssueKey.SUBJECT.KEY_JSON.equals(key)) {
							cellAnalysis.analysis(cell, data, key, cellValue, d);
							d += 1;
						} else {
							cellAnalysis.analysis(cell, data, key, cellValue, j);
						}
					} else {
						cell.setCellValue(cellValue);
					}
					if (cellFormat != null) {
						if (cellStyleMap.containsKey(key)) {
							CellStyle style = cellStyleMap.get(key);
							cell.setCellStyle(style);
						} else {
							CellStyle style = cellFormat.format(wb, cell, data, key, null);
							if (style != null) {
								cellStyleMap.put(key, style);
							}
						}
					}
				}
				
				if (i % MAX_ROW_ACCESS == 0) {
					((SXSSFSheet)sheet).flushRows();
				}
			}
			
			FileOutputStream output = new FileOutputStream(fileInfo.getFile());
			wb.write(output);
			output.flush();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.FileNotFoundException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} finally {
			if (wb != null) {
				try {
					wb.close();
				} catch (IOException e) {
					// TODO 自動生成された catch ブロック
					e.printStackTrace();
				}
			}
		}
		return fileInfo;
	}

	private void createHeaderRow(List<Map<String, Object>> headerColumns,
			Sheet sheet) {
		Row headerRow = sheet.createRow(0);
		for (int i = 0; i < headerColumns.size(); i++) {
			Map<String, Object> column = headerColumns.get(i);
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(StringUtils.toString(column.get("label")));
		}
	}

}
