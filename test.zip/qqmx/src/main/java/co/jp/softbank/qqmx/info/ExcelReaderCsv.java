package co.jp.softbank.qqmx.info;

import java.io.File;
import java.io.InputStream;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.DiffAnalizy;
import co.jp.softbank.qqmx.info.face.IExcelReader;

public class ExcelReaderCsv implements IExcelReader {
	
	private XLSXCovertCSVReader xlsx2csv;
	
	public ExcelReaderCsv(InputStream is) throws SoftbankException {
		xlsx2csv = new XLSXCovertCSVReader(is);
	}
	
	public ExcelReaderCsv(File file) throws SoftbankException {
		xlsx2csv = new XLSXCovertCSVReader(file);
	}
	
	public ExcelInfoBean getSheetInfos() throws SoftbankException {
		return xlsx2csv.getSheetInfos();
	}
	
	public ExcelInfoBean getSheetFirstRowInfos(String sheetName) throws SoftbankException {
		return xlsx2csv.getSheetFirstRowInfos(sheetName, null, 0);
	}
	
	public ExcelInfoBean getSheetFirstRowInfos(String sheetName, DiffAnalizy diff, int headerRow) throws SoftbankException {
		return xlsx2csv.getSheetFirstRowInfos(sheetName, diff, headerRow);
	}
	
	@Override
	public ExcelInfoBean getSheetFirstRowInfos(int sheetIndex, DiffAnalizy diff, int headerRow) throws SoftbankException {
		return xlsx2csv.getSheetFirstRowInfos(sheetIndex, diff, headerRow);
	}
	
	public ExcelInfoBean getAllCellInfos(String sheetName) throws SoftbankException {
		return getAllCellInfos(sheetName, false, 0);
	}
	public ExcelInfoBean getAllCellInfos(String sheetName, boolean referFirst, int startRow) throws SoftbankException {
		return xlsx2csv.getAllCellInfos(sheetName, referFirst, startRow);
	}
	public ExcelInfoBean getAllCellInfos(int sheetIndex, boolean referFirst, int startRow) throws SoftbankException {
		return xlsx2csv.getAllCellInfos(sheetIndex, referFirst, startRow);
	}
	
	
}
