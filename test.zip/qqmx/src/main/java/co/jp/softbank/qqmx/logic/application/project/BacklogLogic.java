package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.JSONObject;

public class BacklogLogic extends AbstractBaseLogic {
	
	@SuppressWarnings("unchecked")
	public void getStoryInfos() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> backlogSett = db.query("backlog_settings.selectSettingInfosForProject");
		String settValue = StringUtils.toString(backlogSett.get("story_trackers"));
		String points = StringUtils.toString(backlogSett.get("story_points"));
		String[] story_trackers = settValue.split(ConstantsUtil.Str.COMMA);
		String[] story_points = points.split(ConstantsUtil.Str.COMMA);
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("story_trackers", story_trackers);
		List<Map<String, Object>> backlogs = db.querys("backlogs.selectBacklogInfosForProject", conditions);
		
		List<Map<String, Object>> sprints = db.querys("versions.selectVersionInfosForProject");
		
		List<Map<String, Object>> releases = db.querys("releases.selectReleasesInfosForProject");
		
		resultMap.put("backlogs", backlogs);
		resultMap.put("sprints", sprints);
		resultMap.put("releases", releases);
		
		Map<String, Object> backlogSettings = Maps.newHashMap();
		List<Map<String, Object>> storyTrackers = db.querys("trackers.selectTrackersInfoForCmb", conditions);
		backlogSettings.put("story_trackers", storyTrackers);
		backlogSettings.put("story_points", story_points);
		backlogSettings.put("issue_statuses", getIssueStatuses());
		
		resultMap.put("backlogSettings", backlogSettings);
		
		context.getResultBean().setData(resultMap);
	}
	
	public void stroyUpdate() throws SoftbankException {
		String changeData = context.getParam().get("update");
		if (StringUtils.isEmpty(changeData)) {
			return;
		}
		JSONObject dataJson = JSONObject.fromObject(changeData);
		JSONArray positions = dataJson.getJSONArray("pd");
		JSONObject properties = dataJson.getJSONObject("p");
		updatePositionData(positions);
		if (!properties.isEmpty()) {
			db.update("backlogs.updateStoryInfoById", createIssueMap(properties));
		}
	}

	private void updatePositionData(JSONArray positions) throws SoftbankException {
		if (!positions.isEmpty()) {
			List<Integer> delids = Lists.newArrayList();
			List<Map<String, Object>> positionList = Lists.newArrayList();
			for (int i = 0; i < positions.size(); i++) {
				Map<String, Object> posMap = Maps.newHashMap();
				JSONObject pos = positions.getJSONObject(i);
				delids.add(pos.getInt("id"));
				posMap.put("issue_id", pos.getInt("id"));
				posMap.put("position", pos.getInt("position"));
				positionList.add(posMap);
			}
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("delids", delids);
			conditions.put("positions", positionList);
			db.delete("backlog_position.deleteBacklogPositionByIssueId", conditions);
			db.insert("backlog_position.insertBacklogPositionInfos", conditions);
		}
	}
	
	public void addSprintInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("sprint_name", context.getParam().get("sprint_name"));
		conditions.put("effective_date", context.getParam().get("effective_date"));
		conditions.put("sprint_start_date", context.getParam().get("sprint_start_date"));
		db.insert("versions.addVersionInfo", conditions);
		context.getResultBean().setData(conditions.get("id"));
	}
	
	public void addStoryInfo() throws SoftbankException {
		String insertData = context.getParam().get("insert");
		if (StringUtils.isEmpty(insertData)) {
			return;
		}
		JSONObject dataJson = JSONObject.fromObject(insertData);
		int maxPosition = dataJson.getInt("pd");
		JSONObject properties = dataJson.getJSONObject("p");
		int maxRootSeq = db.queryo("issues.selectMaxRootSeqByProjectId");
		Map<String, Object> conditions = createIssueMap(properties);
		conditions.put("root_seq", (maxRootSeq + 1));
		db.insert("backlogs.addStoryInfo", conditions);
		Map<String, Object> resultMap = Maps.newHashMap();
		resultMap.put("issue_id", conditions.get("id"));
		resultMap.put("position", (maxPosition + 1));
		
		db.insert("backlog_position.insertBacklogPositionInfo", resultMap);
		context.getResultBean().setData(resultMap);
	}
	
	public void updateSprintInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", context.getParam().get("id"));
		conditions.put("sprint_name", context.getParam().get("sprint_name"));
		conditions.put("effective_date", context.getParam().get("effective_date"));
		conditions.put("sprint_start_date", context.getParam().get("sprint_start_date"));
		db.update("versions.updateVersionInfo", conditions);
	}
	
	public void removeSprintInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("version_id", context.getParam().get("sprint_id"));
		List<Map<String, Object>> issues = db.querys("versions.hasIssuesInVersion", conditions);
		if (issues != null && issues.size() > 0) {
			throw new SoftbankException("removeSprintInfoError");
		}
		db.delete("versions.deleteVersionInfoById", conditions);
	}
	
	public void closeSprint() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("version_id", context.getParam().get("sprint_id"));
		List<Map<String, Object>> issues = db.querys("versions.hasNotFinishedIssuesInVersion", conditions);
		if (issues != null && issues.size() > 0) {
			throw new SoftbankException("closeSprintInfoError");
		}
		db.delete("versions.closeVersion", conditions);
	}
	
	public void openSprint() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("version_id", context.getParam().get("sprint_id"));
		db.delete("versions.openVersion", conditions);
	}
	
	private Map<String, Object> createIssueMap(JSONObject properties) {
		Map<String, Object> issueMap = Maps.newHashMap();
		for (Object key : properties.keySet()) {
			String ks = StringUtils.toString(key);
			Object val = properties.get(key);
			if (val instanceof JSONNull) {
				val = null;
			}
			
			issueMap.put(ks, val);
		}
		return issueMap;
	}
	
	private Map<String, Map<String, List<Map<String, Object>>>> getIssueStatuses() throws SoftbankException {
		List<Map<String, Object>> issueStatuses = db.querys("issue_statuses.getIssueStatuses");

		Map<String, Map<String, List<Map<String, Object>>>> issueStatusMap = Maps.newHashMap();

		for (int i = 0; i < issueStatuses.size(); i++) {
			Map<String, Object> data = issueStatuses.get(i);
			String trackerId = String.valueOf(data.get("tracker_id"));
			String trackerName = String.valueOf(data.get("tracker_name"));
			String oldStatusId = String.valueOf(data.get("old_status_id"));
			String oldStatusName = String.valueOf(data.get("old_status_name"));
			String oldStatusPosition = String.valueOf(data.get("old_status_position"));
			if (!issueStatusMap.containsKey(trackerId)) {
				Map<String, List<Map<String, Object>>> oldStatusMap = Maps.newHashMap();
				issueStatusMap.put(trackerId, oldStatusMap);
			}
			if (!issueStatusMap.get(trackerId).containsKey(oldStatusId)) {
				List<Map<String, Object>> newStatusList = Lists.newArrayList();
				Map<String, Object> newStatusMap = Maps.newHashMap();
				newStatusMap.put("value", oldStatusId);
				newStatusMap.put("label", oldStatusName);
				newStatusMap.put("position", oldStatusPosition);
				newStatusList.add(newStatusMap);
				issueStatusMap.get(trackerId).put(oldStatusId, newStatusList);
			}
			issueStatusMap.get(trackerId).get(oldStatusId).add(makeStatusOptionMap(data));
		}
		return issueStatusMap;
	}
	
	private Map<String, Object> makeStatusOptionMap(Map<String, Object> data) {
		Map<String, Object> newStatusMap = Maps.newHashMap();
		String newStatusId = String.valueOf(data.get("new_status_id"));
		String newStatusName = String.valueOf(data.get("new_status_name"));
		String newStatusPosition = String.valueOf(data.get("new_status_position"));
		newStatusMap.put("value", newStatusId);
		newStatusMap.put("label", newStatusName);
		newStatusMap.put("position", newStatusPosition);
		return newStatusMap;
	}

}
