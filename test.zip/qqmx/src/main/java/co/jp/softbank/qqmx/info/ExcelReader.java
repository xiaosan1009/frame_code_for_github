package co.jp.softbank.qqmx.info;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.CellType;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.CellInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.DiffAnalizy;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.RowInfoBean;
import co.jp.softbank.qqmx.info.face.IExcelReader;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class ExcelReader implements IExcelReader {
	
	private POIFSFileSystem fs;
	
	private HSSFWorkbook wb;
	
	public ExcelReader(InputStream is) throws SoftbankException {
		try {
			fs = new POIFSFileSystem(is);
			wb = new HSSFWorkbook(fs);
		} catch (IOException e) {
			e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
	}
	
	public ExcelReader(File file) throws SoftbankException {
		try {
			fs = new POIFSFileSystem(file);
			wb = new HSSFWorkbook(fs);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
	}
	
	public ExcelInfoBean getSheetInfos() {
		ExcelInfoBean infoBean = new ExcelInfoBean();
		for (int i = 0; i < wb.getNumberOfSheets(); i++) {
			HSSFSheet sheet = wb.getSheetAt(i);
			infoBean.addSheetName(i + ConstantsUtil.Str.COLON + sheet.getSheetName());
		}
		return infoBean;
	}
	
	public ExcelInfoBean getSheetFirstRowInfos(String sheetName) {
		return getSheetFirstRowInfos(sheetName, null, 0);
	}
	
	public ExcelInfoBean getSheetFirstRowInfos(String sheetName, DiffAnalizy diff, int headerRow) {
		HSSFSheet sheet = wb.getSheet(sheetName);
		return getSheetFirstRowInfos(sheet, diff, headerRow);
	}
	
	@Override
	public ExcelInfoBean getSheetFirstRowInfos(int sheetIndex, DiffAnalizy diff, int headerRow)
			throws SoftbankException {
		HSSFSheet sheet = wb.getSheetAt(sheetIndex);
		return getSheetFirstRowInfos(sheet, diff, headerRow);
	}
	
	private ExcelInfoBean getSheetFirstRowInfos(HSSFSheet sheet, DiffAnalizy diff, int headerRow) {
		ExcelInfoBean infoBean = new ExcelInfoBean();
		if (sheet == null ) {
			return infoBean;
		}
		HSSFRow row = sheet.getRow(headerRow);
		if (row == null) {
			return infoBean;
		}
		for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
			HSSFCell cell = row.getCell(i);
			if (cell != null) {
				infoBean.addFirstRowCellName(cell.getStringCellValue(), i, diff);
			}
		}
		return infoBean;
	}
	
	public ExcelInfoBean getAllCellInfos(String sheetName) {
		return getAllCellInfos(sheetName, false, 0);
	}
	public ExcelInfoBean getAllCellInfos(String sheetName, boolean referFirst, int startRow) {
		HSSFSheet sheet = wb.getSheet(sheetName);
		return getAllCellInfos(sheet, referFirst, startRow);
	}
	public ExcelInfoBean getAllCellInfos(int sheetIndex, boolean referFirst, int startRow) {
		HSSFSheet sheet = wb.getSheetAt(sheetIndex);
		return getAllCellInfos(sheet, referFirst, startRow);
	}
	private ExcelInfoBean getAllCellInfos(HSSFSheet sheet, boolean referFirst, int startRow) {
		ExcelInfoBean infoBean = new ExcelInfoBean();
		if (sheet == null ) {
			return infoBean;
		}
		int cellNumber = 0;
		for (int i = 0; i <= sheet.getLastRowNum(); i++) {
			HSSFRow row = sheet.getRow(i);
			if (row != null) {
				RowInfoBean rowInfo = new RowInfoBean(i);
				infoBean.addRow(rowInfo);
				if (referFirst) {
					if (i == 0) {
						cellNumber = row.getLastCellNum();
					}
				} else {
					cellNumber = row.getLastCellNum();
				}
				for (int j = 0; j <= cellNumber; j++) {
					HSSFCell cell = row.getCell(j);
					CellInfoBean cellInfo = new CellInfoBean(j);
					rowInfo.addCell(cellInfo);
					if (cell != null) {
						getCellValue(cell, cellInfo);
					}
				}
			}
		}
		return infoBean;
	}
	
	private void getCellValue(HSSFCell cell, CellInfoBean cellInfo) {
		String content = "";
		if (CellType.BOOLEAN.equals(cell.getCellTypeEnum())) {
			content = StringUtils.toString(cell.getBooleanCellValue());
		} else if (CellType.ERROR.equals(cell.getCellTypeEnum())) {
			content = StringUtils.toString(cell);
		} else if (CellType.NUMERIC.equals(cell.getCellTypeEnum())) {
			if (cell.getDateCellValue() != null) {
				cellInfo.setDate(cell.getDateCellValue());
			}
			content = StringUtils.toString(cell.getNumericCellValue());
		} else {
			content = cell.getStringCellValue();
		}
		cellInfo.setContent(content);
	}

}
