package co.jp.softbank.qqmx.task.info;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class CollectorThreadFactory implements ThreadFactory {
	
	static final AtomicInteger poolNumber = new AtomicInteger(1);

    public static final String COLLECTOR_THREAD_NAME_PREFIX = "CollectorThreadFactory";

    public static final String COLLECTOR_THREAD_NAME_SEPARATOR = "-";

    public static final String COLLECTOR_THREAD_NAME_MIDDLE = "thread";

    final ThreadGroup group;

    final AtomicInteger threadNumber = new AtomicInteger(1);

    final String namePrefix;

    public CollectorThreadFactory() {
        SecurityManager s = System.getSecurityManager();
        group = (s != null) ? s.getThreadGroup() : Thread.currentThread().getThreadGroup();

        StringBuilder prefixSb = new StringBuilder();
        prefixSb.append(COLLECTOR_THREAD_NAME_PREFIX);
        prefixSb.append(COLLECTOR_THREAD_NAME_SEPARATOR);
        prefixSb.append(poolNumber.getAndIncrement());
        prefixSb.append(COLLECTOR_THREAD_NAME_SEPARATOR);
        prefixSb.append(COLLECTOR_THREAD_NAME_MIDDLE);
        prefixSb.append(COLLECTOR_THREAD_NAME_SEPARATOR);
        namePrefix = prefixSb.toString();
    }

    public Thread newThread(Runnable runnable) {
        StringBuilder nameSb = new StringBuilder();
        nameSb.append(namePrefix);
        nameSb.append(threadNumber.getAndIncrement());

        Thread t = new Thread(group, runnable, nameSb.toString(), 0);
        if (t.isDaemon()) {
            t.setDaemon(false);
        }
        if (t.getPriority() != Thread.NORM_PRIORITY) {
            t.setPriority(Thread.NORM_PRIORITY);
        }
        return t;
    }
}
