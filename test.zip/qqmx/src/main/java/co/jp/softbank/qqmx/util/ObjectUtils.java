package co.jp.softbank.qqmx.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.aop.support.AopUtils;

public class ObjectUtils {
	
	public static <T> Class<T>[] getActualTypeArguments(Object obj) {
        if (obj == null) {
            return null;
        }
        Class<?> target = null;
        if (AopUtils.isAopProxy(obj)) {
            target = AopUtils.getTargetClass(obj);
        } else {
            target = obj.getClass();
        }
        return (Class<T>[]) getActualTypeArguments(target);
    }
	
	public static <T> Class<T>[] getActualTypeArguments(Class<?> cls) {
        Class<?>[] classes = null;
        while (cls != null && cls != Object.class) {
            Type type = cls.getGenericSuperclass();
            Type[] types = cls.getGenericInterfaces();
            classes = getActualTypeArguments(type, types);
            if (classes != null) {
                break;
            }
            cls = cls.getSuperclass();
        };

        return (Class<T>[]) classes;
    }
	
	protected static <T> Class<T>[] getActualTypeArguments(Type type, Type...types) {
        Type[] ts = new Type[types.length + 1];
        ts[0] = type;
        if (0 < types.length) {
            System.arraycopy(types, 0, ts, 1, types.length);
        }

        List<Class<?>> temp = new ArrayList<Class<?>>();
        for (Type t : ts) {
            if (t instanceof ParameterizedType) {
                Type[] actTypes = ((ParameterizedType) t).getActualTypeArguments();
                for (int i = 0; i < actTypes.length; i++) {
                    if (actTypes[i] instanceof TypeVariable) {
                        temp.add(null);
                    } else if (actTypes[i] instanceof ParameterizedType) {
                        Type[] t1 = ((ParameterizedType) actTypes[i]).getActualTypeArguments();
                        if (t1[0] instanceof TypeVariable) {
                            temp.add(null);
                        } else {
                            temp.add((Class<?>) t1[i]);
                        }
                    } else {
                        temp.add((Class<?>) actTypes[i]);
                    }
                }
            }
        }
        return temp.isEmpty() ? null : temp.toArray(new Class[]{});
    }

}
