package co.jp.softbank.qqmx.info;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;

import com.google.common.collect.Lists;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlSettingMap.SettingKey;
import co.jp.softbank.qqmx.info.bean.DbRequestData;
import co.jp.softbank.qqmx.info.bean.DispRequestData;
import co.jp.softbank.qqmx.info.bean.FilterRequestData;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class ControlRequestMap {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	private static ControlRequestMap me;
	
	private static final String DEFAULT_PATH = "WEB-INF" + File.separator + "xml" + File.separator + "request";
	
	private static String path;
	
	private Map<String, DispRequestData> requestMap;
	
	private ControlRequestMap() throws SoftbankException {
		super();
		RequestMapReader reader = new RequestMapReader(path);
		requestMap = reader.read();
	}
	
	public static ControlRequestMap getInstance() throws SoftbankException {
		synchronized (ControlRequestMap.class) {
			if (me == null) {
				me = new ControlRequestMap();
			}
		}
		return me;
	}
	
	public String getLogic(Param param) {
		return requestMap.get(param.dispCode).getLogic();
	}
	
	public String getJsp(Param param) {
		if ("0".equals(param.cmdCode)) {
			return requestMap.get(param.dispCode).getJsp();
		}
		return requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).getJsp();
	}
	
	public String getMethod(Param param) {
		if ("0".equals(param.cmdCode)) {
			return "init";
		}
		return requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).getMethod();
	}
	
	public List<DbRequestData> getDbExecuteList(Param param) {
		return requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).getDbList();
	}
	
	public List<FilterRequestData> getFilterList(Param param) {
		if ("0".equals(param.cmdCode)) {
			return requestMap.get(param.dispCode).getFilterList();
		}
		return null;
	}
	
	public boolean isAutoLogout(Param param) {
		if ("0".equals(param.cmdCode)) {
			return "0".equals(requestMap.get(param.dispCode).getLogout());
		}
		return "0".equals(requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).getLogout());
	}
	
	public boolean isEaction(Param param) throws SoftbankException {
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.USE_EACTION)) {
			return true;
		}
		boolean isEaction = requestMap.get(param.dispCode).isEaction();
		log.debug("dispCode = {}, isEaction = {}", Lists.newArrayList(param.dispCode, isEaction).toArray());
		return isEaction;
	}
	
	public boolean isCheck(Param param) {
		if (requestMap.get(param.dispCode) == null || requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode) == null) {
			return false;
		}
		return "1".equals(requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).getCheck());
	}
	
	public boolean isIgnoreRole(Param param) {
		if (requestMap.get(param.dispCode) == null || requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode) == null) {
			return false;
		}
		return requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).isIgnoreRole();
	}
	
	public boolean isIgnoreAccessLog(Param param) {
		if (requestMap.get(param.dispCode) == null || requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode) == null) {
			return false;
		}
		return requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).isIgnoreAccessLog();
	}
	
	public String getSuccess(Param param) {
		if (requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode) == null) {
			return null;
		}
		return requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).getSuccess();
	}
	
	public boolean hasMessage(Param param, String code) {
		if (requestMap.get(param.dispCode) == null || requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode) == null) {
			return false;
		}
		return requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).getMessageMap().containsKey(code);
	}
	
	public String getMessage(Param param, String code) {
		if (!hasMessage(param, code)) {
			return null;
		}
		return requestMap.get(param.dispCode).getCmdMap().get(param.cmdCode).getMessageMap().get(code).getValue();
	}
	
	public static void setPath(String path) {
		ControlRequestMap.path = path + DEFAULT_PATH;
	}

}
