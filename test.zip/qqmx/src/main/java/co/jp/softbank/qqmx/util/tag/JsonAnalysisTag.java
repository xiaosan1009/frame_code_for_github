package co.jp.softbank.qqmx.util.tag;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.jsp.JspException;

import com.google.gson.JsonObject;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;


public class JsonAnalysisTag extends BodyTagSupportBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private StringBuilder outerPrint;
	
	@Override
	public int doStartTag() throws JspException {
		log.debug("--------------- start -----------------");
		outerPrint = new StringBuilder();
		final LogicBean logicBean = (LogicBean)pageContext.getRequest().getAttribute(LogicBean.RESPONSE_DATA);
		if (logicBean != null) {
			if (logicBean.isNotAnalysis()) {
				outerPrint.append(analysisLogicBeanGjson(logicBean).toString());
			} else {
				outerPrint.append(analysisLogicBean(logicBean).toString());
			}
		}
		log.debug("--------------- end -----------------");
		return SKIP_BODY;
	}
	
	@Override
	public int doEndTag() throws JspException {
		try {
			pageContext.getOut().print(outerPrint.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
	
	private JsonObject analysisLogicBeanGjson(LogicBean logicBean) {
		JsonObject result = new JsonObject();
		result.addProperty("flg", logicBean.isResultFlg());
		result.addProperty("resultCode", logicBean.getResultCode());
		result.addProperty("resultMsg", logicBean.getResultMsg());
		result.addProperty("showPanel", logicBean.isShowPanel());
		Object data = logicBean.getData();
		result.addProperty("str", StringUtils.toString(data));
		return result;
	}
	
	private JSONObject analysisLogicBean(LogicBean logicBean) {
		JSONObject result = new JSONObject();
		result.put("flg", logicBean.isResultFlg());
		result.put("resultCode", logicBean.getResultCode());
		result.put("resultMsg", logicBean.getResultMsg());
		result.put("showPanel", logicBean.isShowPanel());
		Object data = logicBean.getData();
		judgeType(result, data);
		return result;
	}
	
	private void analysisMap(Map<Object, Object> dataMap, JSONObject datasObj) {
		for (Object key : dataMap.keySet()) {
			Object data = dataMap.get(key);
			judgeType(datasObj, data, key);
		}
		
	}

	private void judgeType(JSONObject datasObj, Object data) {
		judgeType(datasObj, data, null);
	}
	
	private void judgeType(JSONObject datasObj, Object data, Object key) {
		if (data instanceof Map) {
			JSONObject dataObj = new JSONObject();
			if (StringUtils.isEmpty(key)) {
				key = "tab";
			}
			if ("from-list".equals(key)) {
				analysisMap((Map<Object, Object>)data, datasObj);
			} else {
				analysisMap((Map<Object, Object>)data, dataObj);
				datasObj.put(key, dataObj);
			}
		} else if (data instanceof List) {
//			JSONArray datasArr = new JSONArray();
			if (StringUtils.isEmpty(key)) {
				key = "list";
			}
//			analysisList((List<Object>)data, datasArr);
			datasObj.put(key, JSONArray.fromObject(data));
		} else if (data instanceof DaoBeanInterface) {
			if ("from-list".equals(key)) {
				((DaoBeanInterface)data).toJson(datasObj);
			} else {
				if (StringUtils.isEmpty(key)) {
					key = "tab";
				}
				JSONObject dataObj = new JSONObject();
				((DaoBeanInterface)data).toJson(dataObj);
				datasObj.put(key, dataObj);
			}
		} else if (data instanceof PageListBean) {
			PageListBean pageData = (PageListBean)data;
			datasObj.put("allRows", pageData.getAllRows());
			datasObj.put("currentPage", pageData.getCurrentPage());
			datasObj.put("allPage", pageData.getAllPage());
			datasObj.put("pageRowNumber", pageData.getPageRowNumber());
			judgeType(datasObj, pageData.getDatas(), "pageDatas");
			if (pageData.getDataMap() != null && pageData.getDataMap().size() > 0) {
				judgeType(datasObj, pageData.getDataMap(), "pageDataMap");
			}
		} else {
			if (StringUtils.isEmpty(key)) {
				key = "str";
			}
			datasObj.put(key, data);
		}
	}
	
	private void analysisList(List<Object> dataList, JSONArray datasArr) {
		for (int i = 0; i < dataList.size(); i++) {
			JSONObject dataObj = new JSONObject();
			Object data = dataList.get(i);
			if (data instanceof String) {
				datasArr.add(data);
			} else {
				judgeType(dataObj, data, "from-list");
				datasArr.add(dataObj);
			}
		}
	}

}
