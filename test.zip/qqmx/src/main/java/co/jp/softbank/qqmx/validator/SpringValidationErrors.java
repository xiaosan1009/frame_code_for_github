package co.jp.softbank.qqmx.validator;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.ValidatorAction;
import org.slf4j.Logger;
import org.springframework.validation.Errors;
import org.springmodules.validation.commons.MessageUtils;

import co.jp.softbank.qqmx.util.LogUtil;

public class SpringValidationErrors implements IValidationErrors {
    
	private Logger log = new LogUtil(this.getClass()).getLog();
    
    private Errors errors = null;
    
    public void setErrors(Errors errors) {
        this.errors = errors;
    }

    public Errors getErrors() {
        return errors;
    }
    
    public void addError(Object bean, Field field, ValidatorAction va) {
        String fieldCode = field.getKey();
        String errorCode = MessageUtils.getMessageKey(va, field);
        Object[] args = MessageUtils.getArgs(va, field);

        log.debug("Rejecting value [field='" + fieldCode + "', errorCode='" + errorCode + "']");

        errors.rejectValue(fieldCode, errorCode, args, errorCode);
    }
    
    public void addError(Object bean, Field field, ValidatorAction va, Object[] args) {
    	String fieldCode = field.getKey();
    	String errorCode = MessageUtils.getMessageKey(va, field);
    	
    	errors.rejectValue(fieldCode, errorCode, args, errorCode);
    }
}
