package co.jp.softbank.qqmx.task.face;

import java.util.Map;

import co.jp.softbank.qqmx.application.bean.HttpContext;

public interface ITaskContext extends Cloneable {
	
	<V> void setCollector(IOutputCollector<V> collector);
	
	<V> IOutputCollector<V> getCollector();
	
	<T extends ITaskContext> T copy();
	
	void setHttpContext(HttpContext httpContext);
	
	HttpContext getHttpContext();
	
	Map<String, Object> getParam();
	
	String READER_COLLECTOR_CONFIG = "READER_COLLECTOR_CONFIG";

}
