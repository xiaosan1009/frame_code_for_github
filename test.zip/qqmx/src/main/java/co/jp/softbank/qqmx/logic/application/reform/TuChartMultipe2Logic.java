package co.jp.softbank.qqmx.logic.application.reform;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.util.StringUtils;

public class TuChartMultipe2Logic extends TuLogicBase {
	private static final Map<String, String> listMap;

	static {
		listMap = new HashMap<String, String>();
		listMap.put("1801", "1701");
		listMap.put("1802", "1702");
		listMap.put("1803", "1703");
		listMap.put("1901", "1801");
		listMap.put("1902", "1802");
		listMap.put("1903", "1803");
	};
	private static final String ARTIFICIALNUMBER = "人工数";
	
	private static final String JINKOU = "人工";
	private static final String SEISYAIN = "正社員";
	private static final String MONEY = "金額";
	private static final String MILLION = "金額(百万)";
	private static final String GYOUITAKU = "業務委託";

	private static final String ARTIFICIAL = "artificial";
	private static final String BUDGET = "budget";
	private static final String DEFAULTVALUE = "9898";

	// private static final String AC_ARTIFICIAL = "ac_artificial";
	// private static final String AC_BUDGET = "ac_budget";
	//
	// private static final String PLAN_ARTIFICIAL = "plan_artificial";
	// private static final String PLAN_BUDGET = "plan_budget";

	private static final String NI = "N/I";
	
	private static final String LABEL = "label";
	
	private static final String SENGETU = "num1";
	private static final String KONGETU = "num2";

	public void getSisakuRituanInfor() throws SoftbankException, UnsupportedEncodingException, ParseException {
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"), "utf-8");
		}

		if (StringUtils.isEmpty(statusId) || ARTIFICIALNUMBER.equals(statusId)) {
			getResouceTransitionSuiiInfor(ARTIFICIAL);
		} else if (MONEY.equals(statusId)) {
			getResouceTransitionSuiiInfor(BUDGET);
		}
	}
	public void setChartMultipeInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//全従業員/社員/業託
		String dispartch = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = "";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		//保存履歴
		String study = "";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		String jsonDate = context.getParam().get("jsonDate");
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 3);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);
		context.getResultBean().setData(db.delete("tuchartSisakuRituan.delChartMultipeInfo", conditions));
		
		conditions.put("json_date", jsonDate);
		context.getResultBean().setData(db.insert("tuchartSisakuRituan.setChartMultipeInfo", conditions));
	}
	public void delChartMultipeInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//全従業員/社員/業託
		String dispartch = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		//保存履歴
		String study = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 3);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);

		context.getResultBean().setData(db.delete("tuchartSisakuRituan.delChartMultipeInfo", conditions));
	}
	
	private void getResouceTransitionSuiiInfor(String statusflg)
			throws SoftbankException, UnsupportedEncodingException, ParseException {

		Map<String, Object> conditions = Maps.newHashMap();

		// 統括
		String headquartersId = DEFAULTVALUE;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = DEFAULTVALUE;
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = DEFAULTVALUE;
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = DEFAULTVALUE;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = DEFAULTVALUE;
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = DEFAULTVALUE;
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 全従業員/社員/業託
		String dispartch = DEFAULTVALUE;
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"), "utf-8");
		}
		// 新規/既存
		String category = DEFAULTVALUE;
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"), "utf-8");
		}

		// 人工数/金額/施策数
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"), "utf-8");
		}
	
		Map<String, Object> listResult = Maps.newHashMap();
		String study = null;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		conditions.put("study", study);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		if ("".equals(statusId) || statusId == null || ARTIFICIALNUMBER.equals(statusId)) {
			statusId = ARTIFICIALNUMBER;
			conditions.put("artificial_unit", JINKOU);
		}
		conditions.put("status", statusId);
		String lastMonthTemp = study.substring(0, 8);
		String headNowTitle = study.substring(4, 6) + "月末";
		if (headNowTitle.startsWith("0")) {
			headNowTitle = headNowTitle.replace("0", "");
		}
		listResult.put("headNowTitle", headNowTitle);

		String lastMonth = getLastMonth(lastMonthTemp);
		String keyMonth = lastMonth.substring(2, 6);
		String headLastTitle = lastMonth.substring(4, 6) + "月末";
		if (headLastTitle.startsWith("0")) {
			headLastTitle = headLastTitle.replace("0", "");
		}
		listResult.put("headLastTitle", headLastTitle);

		if (listMap.containsKey(keyMonth)) {
			keyMonth = listMap.get(keyMonth);
		}

		conditions.put("lastMonth", "TU50経営会議" + keyMonth);
		conditions.put("id", 3);
		Map<String, Object> graph = db.query("tuchartGyoumuitaku.getChartMultipeInfo", conditions);
		listResult.put("graph", graph);
		List<Map<String, Object>> kongetuTotal = db.querys("tuchartSisakuRituan.getResouceKongetuTotalInfor",
				conditions);
		BigDecimal kogetuTotal1704 = BigDecimal.ZERO;
		BigDecimal kogetuTukekaeTotal1704 = BigDecimal.ZERO;
		
		BigDecimal[] tukekae = new BigDecimal[2];
		bigDecimalArrayInit(tukekae);
		
		for (int i = 0; i < kongetuTotal.size(); i++) {
			Map<String, Object> element = kongetuTotal.get(i);
			if("1".equals(element.get("level").toString())){
				kogetuTotal1704 = (objectToBigDecimal(element.get("sum_plan_" + statusflg + "17")));
			}else if("2".equals(element.get("level").toString())) {
				kogetuTukekaeTotal1704 = (objectToBigDecimal(element.get("sum_plan_" + statusflg + "17")));
			}
		}
		
		tukekae[1] = kogetuTukekaeTotal1704 ;
		listResult.put("kogetuTotal1704", kogetuTotal1704);
		listResult.put("kogetuTukekaeTotal1704", kogetuTukekaeTotal1704);

		List<Map<String, Object>> sengetuTotalInfo = db.querys("tuchartSisakuRituan.getResouceSengetuTotalInfor",
				conditions);
		System.out.println(1);
		BigDecimal sengetuTotal1704 = BigDecimal.ZERO;
		BigDecimal sengetuTukekaeTotal1704 = BigDecimal.ZERO;

		for (int i = 0; i < sengetuTotalInfo.size(); i++) {
			Map<String, Object> element = sengetuTotalInfo.get(i);
			if("1".equals(element.get("level").toString())){
				sengetuTotal1704 = (objectToBigDecimal( sengetuTotalInfo.get(0).get("sum_plan_" + statusflg + "17")));
			}else if("2".equals(element.get("level").toString())) {
				sengetuTukekaeTotal1704 = (objectToBigDecimal( sengetuTotalInfo.get(1).get("sum_plan_" + statusflg + "17")));
			}
		}
		tukekae[0] = sengetuTukekaeTotal1704 ;
		
		listResult.put("sengetuTotal1704", sengetuTotal1704);
		listResult.put("sengetuTukekaeTotal1704", sengetuTukekaeTotal1704);
		List<Map<String, Object>> kongetuInfor = db.querys("tuchartSisakuRituan.getResouceInfor", conditions);

		
		List<Map<String,Object>> resultList = Lists.newArrayList();
		Map<String,Object> totalData = Maps.newHashMap();
		
		
		totalData.put(LABEL, new String[]{"17年当初"}) ;
		totalData.put(SENGETU, sengetuTotal1704) ;
		totalData.put(KONGETU, kogetuTotal1704) ;
		resultList.add(totalData) ;
		
		BigDecimal value19 = kogetuTotal1704 ;
		BigDecimal nandi = BigDecimal.ZERO ;
		BigDecimal value19NI = BigDecimal.ZERO ;
		
		BigDecimal sengetuValue19 = sengetuTotal1704;
		BigDecimal sengetuNI = BigDecimal.ZERO;
		BigDecimal sengetuValue19NI = BigDecimal.ZERO;
		for (Map<String, Object> map : kongetuInfor) {
			Map<String,Object> resultMap = Maps.newHashMap();
			String key = (String) map.get("tu_category") ;
			BigDecimal value = (objectToBigDecimal( map.get("kon_plan_" + statusflg + "_effect1719")));
			BigDecimal zen_value = (objectToBigDecimal( map.get("zen_plan_" + statusflg + "_effect1719")));
			if(NI.equals(key)){
				nandi = value ;
				sengetuNI = zen_value ;
				continue ;
			}
			if(key.length() > 5){
				resultMap.put(LABEL, new String[]{key.substring(0, 5),key.substring(5, key.length())});
			}else{
				resultMap.put(LABEL, new String[]{key});	
			}
		
			resultMap.put(KONGETU, value);
			resultMap.put(SENGETU, zen_value);
			value19 = value19.subtract(value);
			sengetuValue19 = sengetuValue19.subtract(zen_value);
			resultList.add(resultMap) ;
			
		}
		
		value19NI = value19.subtract(nandi);
		
		sengetuValue19NI = sengetuValue19.subtract(sengetuNI);
		
		
		totalData = Maps.newHashMap();
		totalData.put(LABEL, new String[]{"19年着地"});
		totalData.put(KONGETU, value19);
		totalData.put(SENGETU, sengetuValue19);
		resultList.add(totalData) ;
		
		totalData = Maps.newHashMap();
		totalData.put(LABEL, new String[]{NI});
		totalData.put(KONGETU, nandi);
		totalData.put(SENGETU, sengetuNI);
		resultList.add(totalData) ;

		
		totalData = Maps.newHashMap();
		totalData.put(LABEL, new String[]{"19年着地", "(N/I含む)"});
		totalData.put(KONGETU, value19NI);
		totalData.put(SENGETU, sengetuValue19NI);
		resultList.add(totalData) ;
		
		listResult.put("resultList", resultList) ;
		
		String titleDispartch = !"9898".equals(dispartch) ? dispartch : "社員＋業託";

		String titleCategory = !"9898".equals(category) ? category : "新規＋既存";

		String titleStatusId = StringUtils.isNotEmpty(statusId)
				? SEISYAIN.equals(titleDispartch) ? ARTIFICIALNUMBER : MONEY.equals(statusId) ? MILLION : statusId
				: SEISYAIN.equals(titleDispartch) ? ARTIFICIALNUMBER : "人工数＋金額";

		titleDispartch = MILLION.equals(titleStatusId) ? GYOUITAKU : titleDispartch;

		String title = titleStatusId + "(" + titleCategory + "," + titleDispartch + ")";
		Map<String,Object> resultMapReturn = Maps.newHashMap();	
		resultMapReturn.put("headLastTitle", headLastTitle);
		resultMapReturn.put("headNowTitle", headNowTitle);
		resultMapReturn.put("graph", graph);
		resultMapReturn.put("title", title);
		resultMapReturn.put("chartData", resultList);
		resultMapReturn.put("extra", tukekae);
		context.getResultBean().setData(resultMapReturn);
	}

	private String getLastMonth(String lastMonthTemp) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date dt = sdf.parse(lastMonthTemp);

		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.MONTH, -1);
		Date lastMonthDt = cal.getTime();
		return sdf.format(lastMonthDt);
	}
	private BigDecimal objectToBigDecimal(Object obj){
		return new BigDecimal(StringUtils.toString(obj));
	}
	private void bigDecimalArrayInit(BigDecimal[] array){
		for (int i = 0; i < array.length; i++) {
			array[i] = BigDecimal.ZERO ;
		}
	}
}
