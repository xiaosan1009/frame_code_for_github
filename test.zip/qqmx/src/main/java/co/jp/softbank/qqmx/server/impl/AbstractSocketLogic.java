package co.jp.softbank.qqmx.server.impl;

import co.jp.softbank.qqmx.util.SocketClientManager;
import net.sf.json.JSONObject;

public class AbstractSocketLogic {
	
	protected SocketClientManager manager = SocketClientManager.getInstance();
	
	protected String getResultData(String type, Object data) {
		JSONObject result = new JSONObject();
		result.put("type", type);
		result.put("data", data);
		return result.toString();
	}

}
