package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

import com.google.common.collect.Maps;

public class NewsLogic extends AbstractBaseLogic {
	public void getNewsListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		List<Map<String, Object>> attachments = db.querys("newsAdd.selectNews", conditions);
		context.getResultBean().setData(attachments);
	}
}
