package co.jp.softbank.qqmx.logic.application.watchable;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

public class GitGraphLogic extends AbstractBaseLogic {
	
	private static final String GIT_IP = "http://10.229.17.11";
	
	private static final String GIT_URL = "/service-develop/CorelisCareClient/";
	
	private static final String QQMX_URL = "/qqmx/qqmx.mx?dispCode=600003&cmdCode=0";
	
	private static final String TOKEN = "M2tm-iLkE6okYpTZ_pz8";
	
	@Override
		public void init() throws SoftbankException {
			String method = context.getParam().get("method");
			if (StringUtils.isEmpty(method)) {
				method = "contributors";
			}
			
			String gitGraph = "";
			String ref = context.getParam().get("ref");
			String ps = context.getParam().get("ps");
			if (StringUtils.isEmpty(ps)) {
				if (context.getSessionData().containsKey("git_ps")) {
					ps = context.getSessionData().getString("git_ps");
				} else {
					ps = GIT_URL;
				}
			}
			context.getSessionData().set("git_ps", ps);
			if (StringUtils.isEmpty(ref)) {
				ref = "master";
			}
			if (ref.startsWith("#")) {
				ref = ref.replaceAll("#", "%23");
			}
			if (ref.startsWith("/")) {
				ref = ref.replaceAll("/", "%2F");
			}
			if ("contributors".equals(method)) {
				gitGraph = externalHttpServer.getStrUrl(GIT_IP + ps + "graphs/" + ref + "?private_token=" + TOKEN);
	//			gitGraph = gitGraph.replaceAll("success: function \\(data\\) \\{", "success: function \\(data\\) \\{alert\\(data\\)");
			} else if ("commits".equals(method)) {
				gitGraph = externalHttpServer.getStrUrl(GIT_IP + ps + "graphs/" + ref + "/commits?private_token=" + TOKEN);
			} else if ("languages".equals(method)) {
				gitGraph = externalHttpServer.getStrUrl(GIT_IP + ps + "graphs/" + ref + "/languages?private_token=" + TOKEN);
			} else if ("ci".equals(method)) {
				gitGraph = externalHttpServer.getStrUrl(GIT_IP + ps + "graphs/" + ref + "/ci?private_token=" + TOKEN);
			}
			gitGraph = gitGraph.replaceAll("type: \"GET\",\n\\s*url: \".*graphs/.*\\?format=json\",\n\\s*dataType: \"json\",", "type: \"POST\",\nurl: \"gitLabServlet?action="+ref+"&ps="+ps+"\",\ndataType: \"json\",");
			gitGraph = gitGraph.replaceAll("\"" + ps + "refs\"", "\"/qqmx/gitLabServlet?ps="+ps+"\"");
			gitGraph = gitGraph.replaceAll("\"" + ps + "refs/switch\"", "\"" + QQMX_URL + "&method="+method+"&ps="+ps+"\"");
			gitGraph = gitGraph.replaceAll("<script src=\"/assets/application-47cb3bfaca0e92332b3d895606b64288bf2bd391ea48a4e2ad2df5e991d1888c.js\"></script>", "");
			gitGraph = gitGraph.replaceAll("<a href=\".*graphs/.*\">Contributors</a>", "<a href=\"" + QQMX_URL + "&method=contributors&ref="+ref+"&ps="+ps+"\">Contributors<\\/a>");
			gitGraph = gitGraph.replaceAll("<a href=\".*graphs/.*/commits\">Commits</a>", "<a href=\"" + QQMX_URL + "&method=commits&ref="+ref+"&ps="+ps+"\">Commits</a>");
			gitGraph = gitGraph.replaceAll("<a href=\".*graphs/.*/languages\">Languages</a>", "<a href=\"" + QQMX_URL + "&method=languages&ref="+ref+"&ps="+ps+"\">Languages</a>");
			gitGraph = gitGraph.replaceAll("<a href=\".*graphs/.*/ci\">Continuous Integration", "<a href=\"" + QQMX_URL + "&method=ci&ref="+ref+"&ps="+ps+"\">Continuous Integration");
			//<a href="/Jedi-Proto-UI/ui-service-proto/graphs/feature-PSSOL%2FITTest/ci">Continuous Integration</a>
			context.getRequest().setAttribute("gitGraph", gitGraph);
			context.getResultBean().setData(gitGraph);
		}
//http://10.229.17.11/service-develop/CorelisCareClient/refs?ref=master	
	public void showGitGraph() throws SoftbankException {}
	
	public static void main(String[] args) {
		String a = "<a href=\"/Jedi-Proto-UI/ui-service-proto/graphs/feature-PSSOL%2FITTest/ci\">Continuous Integration</a>";
		System.out.println(a.replaceAll("<a href=\".*graphs/.*/ci\">Continuous Integration.*</a>", "<a href=\"" + QQMX_URL + "&method=ci&ref=&ps=\">Continuous Integration</a>"));
	}
}
