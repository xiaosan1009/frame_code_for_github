package co.jp.softbank.qqmx.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.springframework.context.ApplicationContext;

import co.jp.softbank.qqmx.application.CustomLoaderListener;

public class ProxyBaseFilter implements Filter {
	
	private Filter proxy;

	@Override
	public void init(FilterConfig config) throws ServletException {
		String filterName = config.getInitParameter("filterName");
		final ApplicationContext wac = CustomLoaderListener.getApplicationContext();
		this.proxy = (Filter) wac.getBean(filterName);
		this.proxy.init(config);
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		this.proxy.doFilter(arg0, arg1, arg2);
	}

	@Override
	public void destroy() {
		this.proxy.destroy();
	}
}
