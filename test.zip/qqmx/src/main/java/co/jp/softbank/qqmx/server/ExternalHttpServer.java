package co.jp.softbank.qqmx.server;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.http.NameValuePair;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.cookie.Cookie;
import org.apache.http.cookie.CookieSpecProvider;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.impl.cookie.BestMatchSpecFactory;
import org.apache.http.impl.cookie.BrowserCompatSpecFactory;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ExternalHttpServer {
	
	private static Logger log = new LogUtil(ExternalHttpServer.class).getLog();
	
	private HttpContext context;
	
	private HttpClientContext httpContext;
	
	private static CookieStore cookieStore;
	
	public ExternalHttpServer(HttpContext context) {
		this.context = context;
		httpContext = HttpClientContext.create();
		Registry<CookieSpecProvider> registry = RegistryBuilder.<CookieSpecProvider> create().register(CookieSpecs.BEST_MATCH, new BestMatchSpecFactory()).register(CookieSpecs.BROWSER_COMPATIBILITY, new BrowserCompatSpecFactory()).build();
		httpContext.setCookieSpecRegistry(registry);
	}
	
	public static void main(String[] args) throws ClientProtocolException, IOException, URISyntaxException {
		Map<String, String> params = Maps.newHashMap();
		params.put("username", "os62");
		params.put("password", "ohohoh");
//		(new ExternalHttpServer()).post("login.json", params);
//		clientCustom("login.json?username=os62&password=ohohoh");
	}
	
	public void defaultClient() throws IOException, SoftbankException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			HttpGet httpget = new HttpGet(ControlSettingMap.getInstance().getString("REDMINE_API_URL"));
			
			System.out.println("Executing request " + httpget.getURI());
			CloseableHttpResponse response = httpclient.execute(httpget);
			try {
				System.out.println("----------------------------------------");
				System.out.println(response.getStatusLine());
				System.out.println(response.toString());
				System.out.println(EntityUtils.toString(response.getEntity()));
				httpget.abort();
			} finally {
				response.close();
			}
		} finally {
			httpclient.close();
		}
		
	}
	
	public void clientCustom(String url) throws ClientProtocolException, IOException, SoftbankException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
        try {
            // Create a local instance of cookie store
//            CookieStore cookieStore = new BasicCookieStore();

            // Create local HTTP context
            HttpClientContext localContext = HttpClientContext.create();
            // Bind custom cookie store to the local context
//            BasicClientCookie cookie = new BasicClientCookie("_redmine_session", "8abb0818a4a395df476637c74a44ca56");
//            cookie.setVersion(0);
//            cookie.setDomain("10.172.17.62");
//            cookieStore.addCookie(cookie);
//            localContext.setCookieStore(cookieStore);

            HttpGet httpget = new HttpGet(ControlSettingMap.getInstance().getString("REDMINE_API_URL") + url);
            System.out.println("Executing request " + httpget.getRequestLine());

            // Pass local context as a parameter
            CloseableHttpResponse response = httpclient.execute(httpget, localContext);
            try {
                System.out.println("----------------------------------------");
                System.out.println(EntityUtils.toString(response.getEntity()));
            } finally {
                response.close();
            }
        } finally {
            httpclient.close();
        }
	}
	
	public Map<String, String> get(String url) throws SoftbankException {
		return get(url, null);
	}
	
	public Map<String, String> get(String url, Map<String, String> params) throws SoftbankException {
		log.info("-------------- start ------------------");
		Map<String, String> result = Maps.newHashMap();
		String resultStr = getStr(url, params);
		if (StringUtils.isEmpty(resultStr)) {
			return null;
		}
		log.info("resultStr end!");
		JSONObject resultJson = JSONObject.fromObject(resultStr);
		log.info("resultJson end!");
		if (resultJson == null || resultJson.isNullObject() || resultJson.isEmpty()) {
			return null;
		}
		for (Object key : resultJson.keySet()) {
			String keyStr = StringUtils.toString(key);
			result.put(keyStr, resultJson.getString(keyStr));
		}
		log.info("-------------- end ------------------");
		return result;
	}
	
	public String getStr(String url) throws SoftbankException {
		return getStr(url, null);
	}

	public String getStrUrl(String url) throws SoftbankException {
		log.info("-------------- start ------------------");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		if (cookieStore != null) {
			httpclient = HttpClients.custom().setDefaultCookieStore(cookieStore).build();
		}
		CloseableHttpResponse response = null;
		try {
			HttpGet httpget = new HttpGet(url);
			
			response = httpclient.execute(httpget);
			try {
				if (cookieStore == null) {
					cookieStore = new BasicCookieStore();
				}
				if (response.getFirstHeader("Set-Cookie") != null) {
					String cookie = response.getFirstHeader("Set-Cookie").getValue();
					boolean hasGitSetting = false;
					boolean hasWcSetting = false;
					if (cookieStore.getCookies() != null && cookieStore.getCookies().size() > 0) {
						for (int i = 0; i < cookieStore.getCookies().size(); i++) {
							Cookie coo = cookieStore.getCookies().get(i);
							if ("_gitlab_session".equals(coo.getName())) {
								hasGitSetting = true;
							}
							if ("wcsession".equals(coo.getName())) {
								hasWcSetting = true;
							}
						}
					}
					if (cookie.indexOf("_gitlab_session") >= 0 && !hasGitSetting) {
						String gitSession = cookie.substring(cookie.indexOf("_gitlab_session") + "_gitlab_session".length() + 1, cookie.indexOf(";"));
						BasicClientCookie cki = new BasicClientCookie("_gitlab_session", gitSession);
						cki.setDomain("10.229.17.11");
						cki.setPath("/");
						cookieStore.addCookie(cki);
					}
					if (cookie.indexOf("wcsession") >= 0 && !hasWcSetting) {
						String gitSession = cookie.substring(cookie.indexOf("wcsession") + "wcsession".length() + 1, cookie.indexOf(";"));
						BasicClientCookie cki = new BasicClientCookie("wcsession", gitSession);
						cki.setDomain("10.229.17.11");
						cki.setPath("/");
						cookieStore.addCookie(cki);
					}
				}
				String resultStr = EntityUtils.toString(response.getEntity());
				return resultStr;
			} finally {
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (response != null) {
					response.close();
				}
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public String getStr(String url, Map<String, String> params) throws SoftbankException {
		log.info("-------------- start ------------------");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			
			url =  makeUrl(ControlSettingMap.getInstance().getString("REDMINE_API_URL") + url);
			
			if (params != null) {
				for (String key : params.keySet()) {
					url += "&" + key + "=" + params.get(key);
				}
			}
			HttpGet httpget = new HttpGet(url);
			
			response = httpclient.execute(httpget);
			try {
				String resultStr = EntityUtils.toString(response.getEntity());
				log.info("resultStr = " + resultStr);
				log.info("-------------- end ------------------");
				return resultStr;
			} finally {
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				response.close();
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public Map<String, String> post(String url) throws SoftbankException {
		return post(url, null);
	}
	
	public Map<String, String> post(String url, Map<String, String> params) throws SoftbankException {
		Map<String, String> result = Maps.newHashMap();
		CloseableHttpClient httpclient = HttpClients.createDefault();
        try {

            HttpPost httppost = new HttpPost(makeUrl(ControlSettingMap.getInstance().getString("REDMINE_API_URL") + url));
            httppost.addHeader("Accept-Encoding", "gzip");
            
            if (params != null) {
            	List<NameValuePair> parameters = Lists.newArrayList();
            	for (String key : params.keySet()) {
            		parameters.add(new BasicNameValuePair(key, params.get(key)));
            	}
            	httppost.setEntity(new UrlEncodedFormEntity(parameters));
			}

            CloseableHttpResponse response = httpclient.execute(httppost);
            try {
            	String resultStr = EntityUtils.toString(response.getEntity());
            	log.info("resultStr = {}", Lists.newArrayList(resultStr).toArray());
                JSONObject resultJson = JSONObject.fromObject(resultStr);
                log.info("resultJson = {}", Lists.newArrayList(resultJson).toArray());
                if (resultJson == null || resultJson.isNullObject() || resultJson.isEmpty()) {
					return null;
				}
                for (Object key : resultJson.keySet()) {
                	String keyStr = StringUtils.toString(key);
                	result.put(keyStr, resultJson.getString(keyStr));
				}
            } finally {
                response.close();
            }
        } catch (ClientProtocolException e) {
			e.printStackTrace();
        } catch (NoHttpResponseException e) {
        	e.printStackTrace();
        	throw new SoftbankException(SoftbankExceptionType.NoHttpResponseException);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		} finally {
            try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
        return result;
	}
	
	public Map<String, String> put(String url) throws SoftbankException {
		return put(url, null);
	}
	
	public Map<String, String> put(String url, Map<String, String> params) throws SoftbankException {
		Map<String, String> result = Maps.newHashMap();
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			
			HttpPut httpput = new HttpPut(makeUrl(ControlSettingMap.getInstance().getString("REDMINE_API_URL") + url));
			httpput.addHeader("Accept-Encoding", "gzip");
			
			if (params != null) {
				List<NameValuePair> parameters = Lists.newArrayList();
				for (String key : params.keySet()) {
					parameters.add(new BasicNameValuePair(key, params.get(key)));
				}
				httpput.setEntity(new UrlEncodedFormEntity(parameters, "UTF-8"));
			}
			
			CloseableHttpResponse response = httpclient.execute(httpput);
			try {
				String resultStr = EntityUtils.toString(response.getEntity());
				if (StringUtils.isEmpty(resultStr)) {
					throw new SoftbankException("更新しました。", false);
				}
				log.info("resultStr = {}", Lists.newArrayList(resultStr).toArray());
				JSONObject resultJson = JSONObject.fromObject(resultStr);
				log.info("resultJson = {}", Lists.newArrayList(resultJson).toArray());
				System.out.println(resultJson);
				if (resultJson == null || resultJson.isNullObject() || resultJson.isEmpty()) {
					return null;
				}
				for (Object key : resultJson.keySet()) {
					String keyStr = StringUtils.toString(key);
					if ("errors".equals(key)) {
						JSONArray errorArray = resultJson.getJSONArray(keyStr);
						errorArray = errorArray.getJSONArray(0);
						throw new SoftbankException(errorArray.getString(0), errorArray.getString(1));
					} else {
						result.put(keyStr, resultJson.getString(keyStr));
					}
				}
			} finally {
				response.close();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	private String makeUrl(String url) {
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
        if (userInfoData != null) {
        	url += "?key=" + userInfoData.getApiToken();
		}
        return url;
	}

}
