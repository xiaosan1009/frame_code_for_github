package co.jp.softbank.qqmx.filter;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.lang.ObjectUtils.Null;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.ho.yaml.Yaml;
import org.springframework.context.ApplicationContext;

import co.jp.softbank.qqmx.application.CustomLoaderListener;
import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.handle.AbstractScriptEngineHandler;
import co.jp.softbank.qqmx.info.ControlRequestMap;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.bean.FilterRequestData;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.SessionData;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class RolesCheckFilter extends AbstractCommonFilter {
    
    public RolesCheckFilter() {
        super();
    }

    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
    @SuppressWarnings("unchecked")
	public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
    	
    	try {
    		if (request instanceof HttpServletRequest) {
    			final HttpServletRequest req = (HttpServletRequest) request;
    			if (ServletFileUpload.isMultipartContent(req)) {
                	chain.doFilter(request, response);
                	return;
                }
    			HttpContext httpContext = new HttpContext(request, response);
    			httpContext.createSession();
    			if (ControlRequestMap.getInstance().isIgnoreRole(httpContext.getParam())) {
    				chain.doFilter(request, response);
    				return;
    			}
    			
    			if (!doActionFilter(httpContext)) {
    				rolesException(httpContext);
    				return;
    			}
    			
    			SessionData sessionData = httpContext.getSessionData();
    			UserInfoData userInfoData = sessionData.getUserInfo();
    			if (userInfoData == null || userInfoData.isAdmin()) {
    				chain.doFilter(request, response);
                	return;
    			}
    			
    			db.setContext(httpContext);
    			int projectId = httpContext.getParam().projectId;
    			Map<String, Object> condition = Maps.newHashMap();
    			if (projectId != 0) {
    				condition.put("project_id", projectId);
    				condition.put("user_id", userInfoData.getId());
    				Map<String, Object> roleMap = Maps.newHashMap();
    				Map<String, Object> projectInfo = db.queryC("projects.getProjectInfoAndCustom", condition);
    				if (projectInfo == null) {
    					chain.doFilter(request, response);
    					return;
    				}
    				boolean isPublic = StringUtils.toBoolean(projectInfo.get("is_public"));
    				List<Map<String, Object>> roles = db.querysC("roles.selectUserRolesForProject", condition);
    				if (roles == null || roles.size() == 0) {
    					if (isPublic) {
    						if ("1".equals(projectInfo.get("only_member")) && !"3".equals(userInfoData.getEmployeeTypeCd())) {
    							rolesException(httpContext);
    							return;
    						}
    						Map<String, Object> nonRole = db.queryC("roles.selectNonmemberRoles");
    						List<String> nonRoles = (List<String>)Yaml.load(StringUtils.toString(nonRole.get("permissions")));
    						if (nonRoles!= null && nonRoles.size() > 0) {
    							for (int i = 0; i < nonRoles.size(); i++) {
    								String role = nonRoles.get(i);
    								if (role.startsWith(ConstantsUtil.Str.COLON)) {
    									role = role.substring(1);
    								}
    								roleMap.put(role, role);
    							}
    						}
    					} else {
    						rolesException(httpContext);
    						return;
    					}
    				} else {
    					for (int i = 0; i < roles.size(); i++) {
    						Map<String, Object> roleData = roles.get(i);
    						List<String> nonRoles = (List<String>)Yaml.load(StringUtils.toString(roleData.get("permissions")));
    						if (nonRoles!= null && nonRoles.size() > 0) {
    							for (int j = 0; j < nonRoles.size(); j++) {
    								String role = nonRoles.get(j);
    								if (role.startsWith(ConstantsUtil.Str.COLON)) {
    									role = role.substring(1);
    								}
    								roleMap.put(role, role);
    							}
    						}
    					}
    				}
    				sessionData.setRoles(roleMap);
				}
    		}
    		chain.doFilter(request, response);
    	} catch (FileUploadException e) {
    		e.printStackTrace();
    	} catch (SoftbankException e) {
    		e.printStackTrace();
    	} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
    }

	private boolean doActionFilter(HttpContext httpContext) throws SoftbankException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		List<FilterRequestData> filterList = ControlRequestMap.getInstance().getFilterList(httpContext.getParam());
		if (filterList == null || filterList.size() == 0) {
			return true;
		}
		final String logicName = ControlRequestMap.getInstance().getLogic(httpContext.getParam());
		final ApplicationContext wac = CustomLoaderListener.getApplicationContext();
		final Object logic = wac.getBean(logicName);
		if (logic instanceof AbstractBaseLogic) {
			final Class<? extends Object> clazz = logic.getClass();
			((AbstractBaseLogic)logic).applicationInit(httpContext);
			
			for (int i = 0; i < filterList.size(); i++) {
				FilterRequestData filterData = filterList.get(i);
				final String methodStr = filterData.getMethod();
				if (StringUtils.isNotEmpty(methodStr)) {
					Method method = clazz.getMethod(methodStr, new Class[]{});
					method.invoke(logic, new Object[]{});
					return httpContext.getResultBean().isFilter();
				}
			}
		}
		return true;
	}

    public void destroy() {
    }
    
}
