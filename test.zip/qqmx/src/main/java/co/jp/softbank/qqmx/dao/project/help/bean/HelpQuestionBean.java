package co.jp.softbank.qqmx.dao.project.help.bean;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;

public class HelpQuestionBean implements DaoBeanInterface {
	
	private int id;
	
	private String title;
	
	private String content;
	
	private String answer;
	
	private int author_id;
	
	private int category_id;
	
	private String created_on;
	
	private String updated_on;
	
//	private String file_path;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public int getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public String getCreated_on() {
		return created_on;
	}

	public void setCreated_on(String created_on) {
		this.created_on = created_on;
	}

	public String getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(String updated_on) {
		this.updated_on = updated_on;
	}

	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("id", this.id);
		dataObj.put("title", this.title);
		dataObj.put("content", this.content);
		dataObj.put("answer", this.answer);
		dataObj.put("author_id", this.author_id);
		dataObj.put("category_id", this.category_id);
		dataObj.put("created_on", this.created_on);
		dataObj.put("updated_on", this.updated_on);
	}

//	public String getFile_path() {
//		return file_path;
//	}
//
//	public void setFile_path(String file_path) {
//		this.file_path = file_path;
//	}

}
