package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.RoleListDao;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ForumAddLogic extends AbstractBaseLogic {

	
	public void getComments() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("news_id", context.getParam().get("news_id"));
		
		context.getResultBean().setData(db.querys("newsAdd.selectComments", conditions));
		
	}
	public void setComments() throws SoftbankException {

		UserInfoData userInfo = this.context.getSessionData().getUserInfo();
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("parent_id", StringUtils.toInt(context.getParam().get("parent_id")));
		conditions.put("board_id", StringUtils.toInt(context.getParam().get("board_id")));
		conditions.put("subject", "RE: "+ context.getParam().get("subject"));
		conditions.put("content", context.getParam().get("content"));
		conditions.put("author_id", userInfo.getId());
		conditions.put("locked", Boolean.FALSE);
		conditions.put("sticky", "0");
		
		db.insert("messages.addMessagesInfo", conditions);
		
		// replies_countを更新
		conditions.put("last_reply_id", StringUtils.toInt(conditions.get("id")));
		conditions.put("id", StringUtils.toInt(context.getParam().get("parent_id")));
		db.update("messages.updateRepliesCountUp", conditions);
	}
	
	public void delComments() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("messages_id", StringUtils.toInt(context.getParam().get("commented_id")));
		db.delete("messages.deleteMessagesById", conditions);
		
		// replies_countを更新
		conditions.put("id", StringUtils.toInt(context.getParam().get("parent_id")));
		db.update("messages.updateRepliesCountDown", conditions);
		
	}
	
}
