package co.jp.softbank.qqmx.logic.application.project;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.project.NewTicketDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.bean.InputErrorBean;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class NewTicketLogic extends AbstractBaseLogic {
	
	@Autowired
	private NewTicketDao newTicketDao;
	
	public LogicBean getTicketInfos() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();

		Map<String, Object> conditions = Maps.newHashMap();

		Integer projectId = context.getParam().projectId;
		
		Integer issue_id = null;
		Map<String, Object> issue = null;
		if (StringUtils.isNotEmpty(context.getParam().get("issue_id"))) {
			issue_id = Integer.valueOf(context.getParam().get("issue_id"));
			conditions.put("issue_id", issue_id);
			issue = db.query("issues.selectIssueById", conditions);
			resultMap.put("issue", issue);
			projectId = (Integer)issue.get("project_id");
		}

		conditions.put("project_id", projectId);
		List<Map<String, Object>> trackers = newTicketDao.getTrackers(conditions);
		resultMap.put("trackers", trackers);

		Object tracker_id = null;
		if (StringUtils.isNotEmpty(context.getParam().get("issue_tracker_id")) ) {
			tracker_id = Integer.parseInt(context.getParam().get("issue_tracker_id"));
		} else {
			if (issue != null) {
				tracker_id = issue.get("tracker_id");
			} else {
				tracker_id = trackers.get(0).get("id");
			}
		}
		
		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("user_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("tracker_id", tracker_id);
		List<Map<String, Object>> issueStatuses = newTicketDao.getIssueStatuses(conditions);
		resultMap.put("issueStatuses", issueStatuses);

		List<Map<String, Object>> issuePrioritys = newTicketDao.getIssuePrioritys();
		resultMap.put("issuePrioritys", issuePrioritys);

		List<Map<String, Object>> phases = newTicketDao.getPhases();
		resultMap.put("phases", phases);
		List<Map<String, Object>> testPhases = newTicketDao.getTestPhases();
		resultMap.put("testPhases", testPhases);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> members = newTicketDao.getMembers(conditions);
		resultMap.put("members", members);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> versions = newTicketDao.getVersions(conditions);
		resultMap.put("versions", versions);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("tracker_id", tracker_id);
		if (issue != null) {
			conditions.put("issue_id", issue.get("id"));
			resultMap.put("issueCustomFields", db.querys("issues.selectIssueCustomFieldsAndValues", conditions));
		} else {
			resultMap.put("issueCustomFields", db.querys("issues.getIssueCustomFields", conditions));
		}
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean changeProject() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();

		Integer projectId = Integer.valueOf(context.getParam().get("issue_project_id"));

		conditions.put("project_id", projectId);
		List<Map<String, Object>> trackers = newTicketDao.getTrackers(conditions);
		resultMap.put("trackers", trackers);

		Integer tracker_id = (Integer)trackers.get(0).get("id");
		for (Map<String, Object> tracker : trackers) {
			if ((Integer)tracker.get("id") == Integer.parseInt(context.getParam().get("issue_tracker_id"))) {
				tracker_id = (Integer)tracker.get("id");
				break;
			}
		}

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> members = newTicketDao.getMembers(conditions);
		resultMap.put("members", members);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> versions = newTicketDao.getVersions(conditions);
		resultMap.put("versions", versions);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("user_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("tracker_id", tracker_id);
		List<Map<String, Object>> issueStatuses = newTicketDao.getIssueStatuses(conditions);
		resultMap.put("issueStatuses", issueStatuses);

		List<Map<String, Object>> phases = newTicketDao.getPhases();
		resultMap.put("phases", phases);
		List<Map<String, Object>> testPhases = newTicketDao.getTestPhases();
		resultMap.put("testPhases", testPhases);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("tracker_id", tracker_id);
		resultMap.put("issueCustomFields", db.querys("issues.getIssueCustomFields", conditions));

		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean changeTracker() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();

		Integer projectId = Integer.valueOf(context.getParam().get("issue_project_id"));
		Integer tracker_id = Integer.parseInt(context.getParam().get("issue_tracker_id"));
		
		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("user_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("tracker_id", tracker_id);
		List<Map<String, Object>> issueStatuses = newTicketDao.getIssueStatuses(conditions);
		resultMap.put("issueStatuses", issueStatuses);

		List<Map<String, Object>> phases = newTicketDao.getPhases();
		resultMap.put("phases", phases);
		List<Map<String, Object>> testPhases = newTicketDao.getTestPhases();
		resultMap.put("testPhases", testPhases);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> members = newTicketDao.getMembers(conditions);
		resultMap.put("members", members);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("tracker_id", tracker_id);
		resultMap.put("issueCustomFields", db.querys("issues.getIssueCustomFields", conditions));

		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean searchTcketForParent() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		
		String search_keyword = "";
		if (StringUtils.isNotEmpty(context.getParam().get("search_keyword")) ) {
			search_keyword = context.getParam().get("search_keyword");
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(context.getParam().get("projectTicketId")));
		conditions.put("search_keyword", search_keyword);
		List<Map<String, Object>> parentIssues = newTicketDao.searchTcketForParent(conditions);
		resultMap.put("parentIssues", parentIssues);

		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean createTicket() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(context.getParam().get("projectTicketId"))); // TODO:
		conditions.put("tracker_id", Integer.parseInt(context.getParam().get("issue_tracker_id")));
		conditions.put("subject", context.getParam().get("issue_subject"));
		conditions.put("description", context.getParam().get("issue_description"));
		conditions.put("due_date", context.getParam().get("issue_due_date"));
		if (StringUtils.isNotEmpty(context.getParam().get("issue_category_id"))) {
			conditions.put("category_id", Integer.parseInt(context.getParam().get("issue_category_id")));
		}
		conditions.put("status_id", Integer.parseInt(context.getParam().get("issue_status_id")));
		if (StringUtils.isNotEmpty(context.getParam().get("issue_assigned_to_id"))) {
			conditions.put("assigned_to_id", Integer.parseInt(context.getParam().get("issue_assigned_to_id")));
		}
		conditions.put("priority_id", Integer.parseInt(context.getParam().get("issue_priority_id")));
		if (StringUtils.isNotEmpty(context.getParam().get("issue_fixed_version_id"))) {
			conditions.put("fixed_version_id", Integer.parseInt(context.getParam().get("issue_fixed_version_id")));
		}
		conditions.put("organization_cd", context.getParam().get("issue_organization_cd"));
		conditions.put("author_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("start_date", context.getParam().get("issue_start_date"));
		conditions.put("done_ratio", Integer.parseInt(context.getParam().get("issue_done_ratio")));
		conditions.put("estimated_hours", Double.valueOf(context.getParam().get("issue_estimated_hours")));
		if (StringUtils.isNotEmpty(context.getParam().get("issue_parent_issue_id"))) {
			conditions.put("parent_id", Integer.parseInt(context.getParam().get("issue_parent_issue_id")));
		}
		newTicketDao.insertIssueInfo(conditions);
		
		final int issueId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_parent_issue_id"))) {
			int rootId = selectRootIdInfo(Integer.parseInt(context.getParam().get("issue_parent_issue_id")));
			// TODO 共通LFT更新機能
		}else{
			conditions.put("issue_id", issueId);
			conditions.put("root_id", issueId);
			conditions.put("lft", 1);
			conditions.put("rgt", 2);
			conditions.put("root_seq", newTicketDao.getMaxRootSeq(conditions));
			newTicketDao.updateIssuesByIdAfterInsert(conditions);
		}

		
		
		final List<Map<String, Object>> customValuesList = Lists.newArrayList();
		context.getParam().each(new Param.EachFilter() {
			
			@Override
			public void filter(String key, String value) {
				if (key.startsWith("issue_custom_field_values_")) {
					Map<String, Object> customValueInfo = Maps.newHashMap();
					customValueInfo.put("customized_id", issueId);
					customValueInfo.put("custom_field_id", Integer.parseInt(key.substring("issue_custom_field_values_".length())));
					customValueInfo.put("value", value);
					customValuesList.add(customValueInfo);
				}
			}
		});
		
		if (customValuesList != null && customValuesList.size() > 0) {
			conditions = Maps.newHashMap();
			conditions.put("customValues", customValuesList);
			newTicketDao.insertIssueCustomValues(conditions);
		}

		String[] issue_watcher_user_ids = context.getParam().getList("issue_watcher_user_ids");
		if (issue_watcher_user_ids != null && issue_watcher_user_ids.length > 0) {
			for (String issue_watcher_user_id : issue_watcher_user_ids) {
				conditions.put("watchable_type", "Issue");
				conditions.put("watchable_id", issueId);
				conditions.put("user_id", Integer.parseInt(issue_watcher_user_id));
				newTicketDao.insertWatchers(conditions);
			}
		}

		resultMap.put("issue_id", issueId);
		logicBean.setData(resultMap);

		return logicBean;
	}
	
	
	@Override
	public void doValidate(List<InputErrorBean> errorInfos) throws SoftbankException {
		if ("3".equals(context.getParam().cmdCode)) {
			
			String status_id = context.getParam().get("issue_status_id");
			String done_ratio = context.getParam().get("issue_done_ratio");
			String parent_issue_id = context.getParam().get("issue_parent_issue_id");
			String str_start_date = context.getParam().get("issue_start_date");
			String str_due_date = context.getParam().get("issue_due_date");

			if ("1".equals(status_id) && !"0".equals(done_ratio) || "3".equals(status_id) && !"100".equals(done_ratio)){
				InputErrorBean inputErrorStatusBean = new InputErrorBean();
				inputErrorStatusBean.setTargetId("issue_status_id");
				inputErrorStatusBean.setMessage("ステータスと進捗率の内容が不整合です。再度入力してください。");
				errorInfos.add(inputErrorStatusBean);
				InputErrorBean inputErrorDoneRatioBean = new InputErrorBean();
				inputErrorDoneRatioBean.setTargetId("issue_done_ratio");
				inputErrorDoneRatioBean.setMessage("ステータスと進捗率の内容が不整合です。再度入力してください。");
				errorInfos.add(inputErrorDoneRatioBean);
			}

			if (!"".equals(parent_issue_id) && null != parent_issue_id){
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("search_keyword", parent_issue_id);
				List<Map<String, Object>> parentIssues = newTicketDao.searchExistTcketForParent(conditions);
				if (parentIssues.size() == 0){
					InputErrorBean inputErrorParentIssueBean = new InputErrorBean();
					inputErrorParentIssueBean.setTargetId("issue_parent_issue_id");
					inputErrorParentIssueBean.setMessage("親チケットは存在しません。");
					errorInfos.add(inputErrorParentIssueBean);
				}else{
					if (!parentIssues.get(0).get("project_id").equals(context.getParam().projectId)){
						InputErrorBean inputErrorParentIssueBean = new InputErrorBean();
						inputErrorParentIssueBean.setTargetId("issue_parent_issue_id");
						inputErrorParentIssueBean.setMessage("親チケット 同じプロジェクトに属していません。");
						errorInfos.add(inputErrorParentIssueBean);
					}
				}
			}
			
			if (!"".equals(str_start_date) && !"".equals(str_due_date)){
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date start_date = null;
				Date due_date = null;
				try {
					start_date = format.parse(str_start_date);
					due_date = format.parse(str_due_date);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				if (start_date.compareTo(due_date) > 0){
					InputErrorBean inputErrorSDateBean = new InputErrorBean();
					inputErrorSDateBean.setTargetId("issue_start_date");
					inputErrorSDateBean.setMessage("期日 を開始日より後にしてください。");
					errorInfos.add(inputErrorSDateBean);
					InputErrorBean inputErrorDateBean = new InputErrorBean();
					inputErrorDateBean.setTargetId("issue_due_date");
					inputErrorDateBean.setMessage("期日 を開始日より後にしてください。");
					errorInfos.add(inputErrorDateBean);
				}
			}
			
			String tracker_id = context.getParam().get("issue_tracker_id");
			if ("35".equals(tracker_id)){
				String custom_field_values_1251 = context.getParam().get("issue_custom_field_values_1251");
				String custom_field_values_1253 = context.getParam().get("issue_custom_field_values_1253");
				String custom_field_values_1256 = context.getParam().get("issue_custom_field_values_1256");
				doCustomFieldRequired(errorInfos,"1251","システム名 ",custom_field_values_1251);
				doCustomFieldRequired(errorInfos,"1253","[sec_op]ステータス  ",custom_field_values_1253);
				doCustomFieldRequired(errorInfos,"1256","次回対応期日 ",custom_field_values_1256);
			}else if("1".equals(tracker_id)){
				String custom_field_values_264 = context.getParam().get("issue_custom_field_values_264");
				doCustomFieldRequired(errorInfos,"264","対象フェーズ ",custom_field_values_264);
			}else if("2".equals(tracker_id) || "21".equals(tracker_id)){
				String custom_field_values_295 = context.getParam().get("issue_custom_field_values_295");
				doCustomFieldRequired(errorInfos,"295","区分 ",custom_field_values_295);
			}else if("16".equals(tracker_id) || "3".equals(tracker_id)){
				String custom_field_values_265 = context.getParam().get("issue_custom_field_values_265");
				doCustomFieldRequired(errorInfos,"265","テスト工程",custom_field_values_265);
				if("16".equals(tracker_id)){
					String custom_field_values_266 = context.getParam().get("issue_custom_field_values_266");
					doCustomFieldRequired(errorInfos,"266","テスト項目件数",custom_field_values_266);
					String custom_field_values_537 = context.getParam().get("issue_custom_field_values_537");
					doCustomFieldRequired(errorInfos,"537","テスト検証済件数",custom_field_values_537);
				}
			}else if("17".equals(tracker_id)){
				String custom_field_values_294 = context.getParam().get("issue_custom_field_values_294");
				String custom_field_values_270 = context.getParam().get("issue_custom_field_values_270");
				String custom_field_values_269 = context.getParam().get("issue_custom_field_values_269");
				doCustomFieldRequired(errorInfos,"294","評価種別",custom_field_values_294);
				doCustomFieldRequired(errorInfos,"270","アセスメントフェーズ ",custom_field_values_270);
				doCustomFieldRequired(errorInfos,"269","実施状況",custom_field_values_269);
			}else if("18".equals(tracker_id)){
				String custom_field_values_298 = context.getParam().get("issue_custom_field_values_298");
				doCustomFieldRequired(errorInfos,"298","実施可否",custom_field_values_298);
			}else if("34".equals(tracker_id)){
				String custom_field_values_1190 = context.getParam().get("issue_custom_field_values_1190");
				doCustomFieldRequired(errorInfos,"1190","サブステータス",custom_field_values_1190);
				String custom_field_values_1195 = context.getParam().get("issue_custom_field_values_1195");
				doCustomFieldRequired(errorInfos,"1195","優先度（ISC） ",custom_field_values_1195);
			}
		}
	}
	
	public void doCustomFieldRequired(List<InputErrorBean> errorInfos, String id, String messages, String value) throws SoftbankException {
		if ("".equals(value)){
			InputErrorBean inputErrorBean = new InputErrorBean();
			inputErrorBean.setTargetId("issue_custom_field_values_" + id);
			inputErrorBean.setMessage(messages + "は入力必須項目です.");
			errorInfos.add(inputErrorBean);
		}
	}
	
	public int selectRootIdInfo(int issueId) throws SoftbankException {
		int rootId = 0;
		if (!"null".equals(issueId)){
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issueId", issueId);
			List<Map<String, Object>> rootIdList = db.querys("issues.selectIssueRootId", conditions);
			if (rootIdList.size() > 0){
				rootId = Integer.parseInt(String.valueOf(rootIdList.get(0)));
			}
		}
		return rootId;
	}
		
	@Override
	protected IDaoInterface getDao() {
		return newTicketDao;
	}

}
