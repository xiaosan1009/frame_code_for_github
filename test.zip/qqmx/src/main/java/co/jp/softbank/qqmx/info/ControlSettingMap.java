package co.jp.softbank.qqmx.info;

import java.io.File;
import java.util.Map;

import org.slf4j.Logger;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.SettingInfoBean;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class ControlSettingMap {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	private static ControlSettingMap me;
	
	private static final String DEFAULT_PATH = "WEB-INF" + File.separator + "xml" + File.separator + "settings" + File.separator + "settings.xml";
	
	private SettingInfoBean settingInfoBean;
	
	private Map<Integer, Integer> customProjectInfoMap = Maps.newHashMap();
	
	private Map<Integer, Integer> customProjectLevelInfoMap = Maps.newHashMap();
	
	private Map<Integer, Integer> customProjectFieldMap = Maps.newHashMap();
	
	public interface SettingKey {
		String DEBUG_MODEL = "DEBUG_MODEL";
		String DEFAULT_USER = "DEFAULT_USER";
		String CASH_ALL_WATCHABLE_INFO = "CASH_ALL_WATCHABLE_INFO";
		String CASH_POINT_PROJECT_INFO = "CASH_POINT_PROJECT_INFO";
		String CHECK_CUSTOM_PROJECT_INFO = "CHECK_CUSTOM_PROJECT_INFO";
		String CHECK_CUSTOM_PROJECT_LEVEL_INFO = "CHECK_CUSTOM_PROJECT_LEVEL_INFO";
		String CHECK_CUSTOM_PROJECT_LEVEL = "CHECK_CUSTOM_PROJECT_LEVEL";
		String CHECK_CUSTOM_PROJECT_FIELD = "CHECK_CUSTOM_PROJECT_FIELD";
		String SQL_LOG_PRINT = "SQL_LOG_PRINT";
		String CASH_SQL_LOG_PRINT = "CASH_SQL_LOG_PRINT";
		String USE_EACTION = "USE_EACTION";
		String SCRIPT_IMMEDIATELY = "SCRIPT_IMMEDIATELY";
		String USE_WEBSOCKET = "USE_WEBSOCKET";
	}
	
	private ControlSettingMap() throws SoftbankException {
		super();
	}
	
	public static ControlSettingMap getInstance() throws SoftbankException {
		synchronized (ControlSettingMap.class) {
			if (me == null) {
				me = new ControlSettingMap();
			}
		}
		return me;
	}
	
	public void analyze(String path) throws SoftbankException {
		SettingsReader reader = new SettingsReader(path + DEFAULT_PATH);
		settingInfoBean = reader.read();
		if (StringUtils.isNotEmpty(getString(SettingKey.CHECK_CUSTOM_PROJECT_INFO))) {
			String[] pros = getString(SettingKey.CHECK_CUSTOM_PROJECT_INFO).split(",");
			for (int i = 0; i < pros.length; i++) {
				customProjectInfoMap.put(StringUtils.toInt(pros[i]), StringUtils.toInt(pros[i]));
			}
		}
		if (StringUtils.isNotEmpty(getString(SettingKey.CHECK_CUSTOM_PROJECT_LEVEL_INFO))) {
			String[] pros = getString(SettingKey.CHECK_CUSTOM_PROJECT_LEVEL_INFO).split(",");
			for (int i = 0; i < pros.length; i++) {
				customProjectLevelInfoMap.put(StringUtils.toInt(pros[i]), StringUtils.toInt(pros[i]));
			}
		}
		if (StringUtils.isNotEmpty(getString(SettingKey.CHECK_CUSTOM_PROJECT_FIELD))) {
			String[] fields = getString(SettingKey.CHECK_CUSTOM_PROJECT_FIELD).split(",");
			for (int i = 0; i < fields.length; i++) {
				customProjectFieldMap.put(StringUtils.toInt(fields[i]), StringUtils.toInt(fields[i]));
			}
		}
	}
	
	public String getString(String key) {
		if (settingInfoBean == null) {
			return null;
		}
		return settingInfoBean.get(key);
	}
	
	public boolean getBoolean(String key) {
		String value = getString(key);
		if (StringUtils.isEmpty(value)) {
			return false;
		}
		return StringUtils.toBoolean(value);
	}
	
	public int getInt(String key) {
		String value = getString(key);
		if (StringUtils.isEmpty(value)) {
			return 0;
		}
		return StringUtils.toInt(value);
	}
	
	public boolean isCheckCustom(int projectId) {
		if (customProjectInfoMap.size() > 0 && customProjectInfoMap.containsKey(projectId)) {
			return true;
		}
		return false;
	}
	
	public boolean isCheckCustomLevel(int projectId, int level, int field) {
		if (customProjectLevelInfoMap.size() == 0 || !customProjectLevelInfoMap.containsKey(projectId)) {
			return true;
		}
		if (StringUtils.isNotEmpty(getString(SettingKey.CHECK_CUSTOM_PROJECT_LEVEL)) 
				&& StringUtils.isNotEmpty(getString(SettingKey.CHECK_CUSTOM_PROJECT_FIELD))) {
			if (getInt(SettingKey.CHECK_CUSTOM_PROJECT_LEVEL) == level && customProjectFieldMap.containsKey(field)) {
				return true;
			}
		}
		return false;
	}

}
