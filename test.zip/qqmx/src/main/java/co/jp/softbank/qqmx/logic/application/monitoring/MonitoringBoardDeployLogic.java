package co.jp.softbank.qqmx.logic.application.monitoring;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

import com.google.common.collect.Maps;
/**
 * デプロイ状況一覧
 * @author dev68427470j
 *
 */
public class MonitoringBoardDeployLogic extends AbstractBaseLogic {
	/**
	 * 一覧を検索する
	 * 
	 * @throws SoftbankException
	 */
	public void getMonitoringBoardDeployInfo() throws SoftbankException {
		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		// プロジェクトID
		String projectId =context.getParam().get("projectId") ;
		if(!StringUtils.isEmpty(projectId)){
			conditions.put("projectId",   Integer.parseInt(projectId));
		}
		// 対象システム
		String systemId = context.getParam().get("systemId");
		if(!StringUtils.isEmpty(systemId)){
			conditions.put("systemId", Integer.parseInt(systemId));
		}
		// 対象フェーズ
		String versionId = context.getParam().get("versionId");

		if(!StringUtils.isEmpty(versionId)){
			conditions.put("versionId",  Integer.parseInt(versionId));
		}	
		// ジョブ名称
		String titleJobConvertName = (String)getJobName().get("titleJobConvertName");

		if(!StringUtils.isEmpty(titleJobConvertName)){
			conditions.put("titleJobConvertName",  titleJobConvertName);
		}
		
		if(!StringUtils.isEmpty(projectId)){
			context.getResultBean().setData(db.querys("monitoringBoardDeploy.getMonitoringBoardDeploy", conditions));
		}
		else{
			List<Map<String, Object>> tempListData = new ArrayList<Map<String, Object>>();
			Map<String, Object> tempMapData =  Maps.newHashMap();
			tempMapData.put("seikoukensuu_recent", "0");
			tempMapData.put("sippaikensuu_recent", "0");
			tempMapData.put("seikouritu_recent", "-");
			tempMapData.put("seikoukensuu", "0");
			tempMapData.put("sippaikensuu", "0");
			tempMapData.put("seikouritu", "-");
			tempMapData.put("birudo", "0");
			tempMapData.put("tesuto", "0");
			tempMapData.put("insupekusyon", "0");
			tempMapData.put("depuroi", "0");
			tempListData.add(tempMapData) ;
			context.getResultBean().setData(tempListData);	
		}
	}


	/**
	 * ビルド時間推移を検索する
	 * 
	 * @throws SoftbankException
	 */
	public void getBirudoJikanSuiiInfo() throws SoftbankException {
		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		// ジョブ名称
		String titleJobConvertName = (String)getJobName().get("titleJobConvertName");

		if(!StringUtils.isEmpty(titleJobConvertName)){
			conditions.put("titleJobConvertName",  titleJobConvertName);
		}
		// プロジェクトID
		String projectId =context.getParam().get("projectId") ;
		if(!StringUtils.isEmpty(projectId)){
		conditions.put("projectId",  Integer.parseInt(projectId) );
		}
		// 対象システム
		String systemId = context.getParam().get("systemId");
		if(!StringUtils.isEmpty(systemId)){
			conditions.put("systemId", Integer.parseInt(systemId));
		}
		// 対象フェーズ
		String versionId = context.getParam().get("versionId");

		if(!StringUtils.isEmpty(versionId)){
			conditions.put("versionId",  Integer.parseInt(versionId));
		}
		// ジョブのID値
		String titleJobName = context.getParam().get("titleJobName");

		if(!StringUtils.isEmpty(titleJobName)){
			conditions.put("titleJobName",  Integer.parseInt(titleJobName));
		}
				
		context.getResultBean().setData(db.querys("monitoringBoardDeploy.getBirudoJikanSuiiInfo", conditions));
	}

	/**
	 * ビルド成功率推移を検索する
	 * 
	 * @throws SoftbankException
	 */
	public void getBirudoSeikorituSuiiInfo() throws SoftbankException {
		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		// プロジェクトID
		String projectId =context.getParam().get("projectId") ;
		if(!StringUtils.isEmpty(projectId)){
		conditions.put("projectId",  Integer.parseInt(projectId) );
		}
		// 対象システム
		String systemId = context.getParam().get("systemId");
		if(!StringUtils.isEmpty(systemId)){
			conditions.put("systemId", Integer.parseInt(systemId));
		}
		// 対象フェーズ
		String versionId = context.getParam().get("versionId");
		if(!StringUtils.isEmpty(versionId)){
			conditions.put("versionId",  Integer.parseInt(versionId));
		}
		// ジョブのID値
		String titleJobName = context.getParam().get("titleJobName");

		if(!StringUtils.isEmpty(titleJobName)){
			conditions.put("titleJobName",  Integer.parseInt(titleJobName));
		}
		// ジョブ名称
		String titleJobConvertName = (String)getJobName().get("titleJobConvertName");

		if(!StringUtils.isEmpty(titleJobConvertName)){
			conditions.put("titleJobConvertName",  titleJobConvertName);
		}		
		context.getResultBean().setData(db.querys("monitoringBoardDeploy.getBirudoSeikourituSuiiInfo", conditions));
	}

	/**
	 * 各種所要時間推移を検索する
	 * 
	 * @throws SoftbankException
	 */
	public void getKakusyuSyoyouJikanSuiiInfo() throws SoftbankException {

		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		// プロジェクトID
		String projectId =context.getParam().get("projectId") ;
		if(!StringUtils.isEmpty(projectId)){
		conditions.put("projectId",  Integer.parseInt(projectId) );
		}
		// 対象システム
		String systemId = context.getParam().get("systemId");
		if(!StringUtils.isEmpty(systemId)){
			conditions.put("systemId", Integer.parseInt(systemId));
		}
		// 対象フェーズ
		String versionId = context.getParam().get("versionId");

		if(!StringUtils.isEmpty(versionId)){
			conditions.put("versionId",  Integer.parseInt(versionId));
		}
		// ジョブのID値
		String titleJobName = context.getParam().get("titleJobName");

		if(!StringUtils.isEmpty(titleJobName)){
			conditions.put("titleJobName",  Integer.parseInt(titleJobName));
		}
		// ジョブ名称
		String titleJobConvertName = (String)getJobName().get("titleJobConvertName");

		if(!StringUtils.isEmpty(titleJobConvertName)){
			conditions.put("titleJobConvertName",  titleJobConvertName);
		}		
		// 検索を行う
		context.getResultBean().setData(db.querys("monitoringBoardDeploy.getKakusyuSyoyouJikanSuiiInfo", conditions));
	}

	/**
	 * 明細データ取得
	 * 
	 * @throws SoftbankException
	 */
	public void getKaisekiInfor() throws SoftbankException {

		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		// プロジェクトID
		String projectId =context.getParam().get("projectId") ;
		if(!StringUtils.isEmpty(projectId)){
		conditions.put("projectId",  Integer.parseInt(projectId) );
		}
		// 対象システム
		String systemId = context.getParam().get("systemId");
		if(!StringUtils.isEmpty(systemId)){
			conditions.put("systemId", Integer.parseInt(systemId));
		}
		// 対象フェーズ
		String versionId = context.getParam().get("versionId");

		if(!StringUtils.isEmpty(versionId)){
			conditions.put("versionId",  Integer.parseInt(versionId));
		}
		// ジョブ名称
		String titleJobName = context.getParam().get("titleJobName");

		if(!StringUtils.isEmpty(titleJobName)){
			conditions.put("jobName",  Integer.parseInt(titleJobName));
		}
				
		conditions.put("version_name", '%');
		conditions.put("sub_project", '%');
		// 検索を行う
		
		PageListBean pageListBean = pageList(
				"monitoringBoardDeploy.getKaisekiInfor", conditions);
		
		List<Map<String, Object>> resultList = pageListBean.getDatas();
		for (int i = 0; i < resultList.size(); i++) {
			String jobName =(String)resultList.get(i).get("jobname");
			Integer projectIdDate =(Integer)resultList.get(i).get("project_id");
			String result =(String)resultList.get(i).get("result");
			conditions.put("jobName",  jobName);
			conditions.put("result", result);
			conditions.put("projectIdDate", projectIdDate);
			
			List<Map<String, Object>> resultListDate = db.querys("monitoringBoardDeploy.getKaisekiInforDate", conditions);
			if(!resultListDate.isEmpty()){
				if(resultListDate.get(0).get("success")!=null){
					pageListBean.getDatas().get(i).put("success", resultListDate.get(0).get("success"))	;
				}else if(resultListDate.get(0).get("failed")!=null)
				{
					pageListBean.getDatas().get(i).put("failed", resultListDate.get(0).get("failed"))	;
				}
			}
			List<Map<String, Object>> resultListSuccess = db.querys("monitoringBoardDeploy.getMonitoringBoardDeployRecent", conditions);
				if(!resultListSuccess.isEmpty()){
					 double recentSuccess = 0 ;
					 double recentFail = 0 ;
					if(BigDecimal.valueOf(recentSuccess+recentFail)!=BigDecimal.ZERO){
						recentSuccess =recentSuccess+Double.valueOf(( resultListSuccess.get(0).get("recent")).toString());
						recentFail =recentFail+Double.valueOf(( resultListSuccess.get(1).get("recent")).toString());
						pageListBean.getDatas().get(i).put("score",recentSuccess*100/(recentSuccess+recentFail)) ;
						}
				}
				
				conditions.put("job_name",  jobName);
				List<Map<String, Object>> sonarlist = db.querys("deploy.getSonarUrl", conditions);	
				if(sonarlist.size()!=0){
					resultList.get(i).put("sonarlist", sonarlist);
				}
			
		}
		context.getResultBean().setData(pageListBean);
	}
	/**
	 * 対象プロジェクト、対象システム、バージョン、JOB名称の変更場合、再検索を行う
	 * 
	 * @throws SoftbankException
	 */
	public void getSelectList() throws SoftbankException{
		Map<String, Object> conditions = select();
		// ジョブ名称
		String titleJobConvertName = (String)getJobName().get("titleJobConvertName");

		if(!StringUtils.isEmpty(titleJobConvertName)){
			conditions.put("titleJobConvertName",  titleJobConvertName);
		}
		List<Map<String, Object>> info = db.querys("monitoringBoardDeploy.getMonitoringBoardDeploy", conditions);
		if(info.isEmpty()){
			Map<String, Object> tempMapData =  Maps.newHashMap();
			tempMapData.put("seikoukensuu_recent", "0");
			tempMapData.put("sippaikensuu_recent", "0");
			tempMapData.put("seikouritu_recent", "-");
			tempMapData.put("seikoukensuu", "0");
			tempMapData.put("sippaikensuu", "0");
			tempMapData.put("seikouritu", "-");
			tempMapData.put("birudo", "0");
			tempMapData.put("tesuto", "0");
			tempMapData.put("insupekusyon", "0");
			tempMapData.put("depuroi", "0");
			info.add(tempMapData) ;
		}
		List<Map<String, Object>> systemList = db.querys("monitoringBoardDeploy.getSystemList", conditions);
		
		List<Map<String, Object>> versionList = db.querys("monitoringBoardDeploy.getVersionList", conditions);
		
		List<Map<String, Object>> titleJobName = db.querys("monitoringBoardDeploy.getTitleJobNameList", conditions);
		Map<String, Object> listMap = Maps.newHashMap();
		listMap.put("systemList", systemList);
		listMap.put("versionList", versionList);
		listMap.put("titleJobNameList", titleJobName);
		listMap.put("info", info);
		context.getResultBean().setData(listMap);
	}
	
	/**
	 * 対象プロジェクト、対象システム、バージョン、JOB名称取得
	 * @return　対象プロジェクト、対象システム、バージョン、JOB名称
	 */
	public Map<String, Object> select(){
		Map<String, Object> conditions = Maps.newHashMap();
		String projectId = context.getParam().get("projectId");
		String systemId = context.getParam().get("systemId");
		String versionId = context.getParam().get("versionId");
		String jobName = context.getParam().get("titleJobName");
		if(!StringUtils.isEmpty(versionId)){
			conditions.put("versionId", Integer.parseInt(versionId));
		}
		if(!StringUtils.isEmpty(systemId)){
			conditions.put("systemId", Integer.parseInt(systemId));
		}
		if (!StringUtils.isEmpty(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
		}
		if (!StringUtils.isEmpty(jobName)){
			conditions.put("jobName", Integer.parseInt(jobName));
		}
		
		return conditions;
	}
	/**
	 * 画面からジョブIDによってジョブ名称取得
	 * @return　ジョブ名称
	 * @throws SoftbankException
	 */
	private Map<String, Object> getJobName() throws SoftbankException{
		
		Map<String, Object> conditions = Maps.newHashMap();
		String jobName = context.getParam().get("titleJobName");
		if (!StringUtils.isEmpty(jobName)){
			conditions.put("id", Integer.parseInt(jobName));
		
		List<Map<String, Object>> titleJobConvertName = db.querys("monitoringBoardDeploy.getTitleJobConvertName", conditions);
		if(!titleJobConvertName.isEmpty()){
			conditions.put("titleJobConvertName", titleJobConvertName.get(0).get("job_name"));
		}
		}
		return conditions;
	}
	}
