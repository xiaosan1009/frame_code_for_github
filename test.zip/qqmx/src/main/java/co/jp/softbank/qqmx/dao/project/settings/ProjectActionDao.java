package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

public interface ProjectActionDao {
	
	List<Map<String, Object>> getEnabledModules(Map<String, Object> conditions);
	
	void insertEnabledModulesAction(Map<String, Object> conditions);
	
	void deleteAction(Map<String, Object> conditions);
}
