package co.jp.softbank.qqmx.task.info;

public enum ExceptionHandlerStatus {
	
	THROW,
    SKIP,
    END

}
