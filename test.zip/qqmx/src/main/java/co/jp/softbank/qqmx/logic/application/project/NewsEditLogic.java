package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class NewsEditLogic extends AbstractBaseLogic {
	
	public void getNewsListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		List<Map<String, Object>> attachments = db.querys("newsAdd.selectNews", conditions);
		context.getResultBean().setData(attachments);
	}
	
	public void saveNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("title", context.getParam().get("news_title"));
		conditions.put("summary", context.getParam().get("news_summary"));
		conditions.put("description", context.getParam().get("news_description"));
		conditions.put("author_id", context.getSessionData().getUserInfo().getId());
		db.insert("news.addNewsInfo", conditions);
	}
	public void updateNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String newsId = context.getParam().get("news_id");
		conditions.put("title", context.getParam().get("news_title"));
		conditions.put("summary", context.getParam().get("news_summary"));
		conditions.put("description", context.getParam().get("news_description"));
		conditions.put("author_id", context.getSessionData().getUserInfo().getId());
		conditions.put("news_id", newsId);
		db.update("news.updateNewsInfo", conditions);		
	}
	public void delNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("news_id", StringUtils.toInt(context.getParam().get("news_id")));		
		db.update("news.deleteNewsInfo", conditions);
		db.update("comments.deleteCommentsByNewsId", conditions);
	}
}
