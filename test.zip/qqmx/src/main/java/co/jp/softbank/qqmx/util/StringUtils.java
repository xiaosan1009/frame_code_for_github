package co.jp.softbank.qqmx.util;

import java.io.UnsupportedEncodingException;

public class StringUtils {
	
	public static String nvl(Object obj, String altVal) {
		if (obj == null) {
			return altVal;
		}
		return String.valueOf(obj);
	}
	
	public static String nvl(Object obj) {
		return nvl(obj, "");
	}
	
	public static String nvl(String obj) {
		return nvl(obj, "");
	}
	
	public static String nvl(String obj, String altVal) {
		if (obj == null) {
			return altVal;
		}
		return obj;
	}
	
	public static String trim(String str) {
		str = org.apache.commons.lang.StringUtils.trimToEmpty(str);
		str = org.apache.commons.lang.StringUtils.strip(str, "　");
		return str;
	}
	
	public static boolean isEmpty(Object obj) {
		return "".equals(trim(nvl(obj)));
	}
	
	public static boolean isNotEmpty(Object obj) {
		return !isEmpty(obj);
	}
	
	public static boolean isEmpty(String obj) {
		return "".equals(trim(nvl(obj))) || "null".equals(trim(nvl(obj)));
	}
	
	public static boolean isNotEmpty(String obj) {
		return !isEmpty(obj);
	}
	
	public static String toString(Object obj) {
		return trim(nvl(obj));
	}
	
	public static int toInt(Object obj) {
		if (isEmpty(obj)) {
			return -1;
		}
		return Integer.parseInt(toString(obj));
	}
	
	public static float toFloat(Object obj) {
		if (isEmpty(obj)) {
			return -1f;
		}
		return Float.parseFloat(toString(obj));
	}
	
	public static double toDouble(Object obj) {
		if (isEmpty(obj)) {
			return -1;
		}
		return Double.parseDouble(toString(obj));
	}
	
	public static boolean toBoolean(Object obj) {
		if (isEmpty(obj)) {
			return false;
		}
		return Boolean.parseBoolean(toString(obj));
	}
	
	public static int getByteLength(String value, String encoding)
            throws UnsupportedEncodingException {
        if (value == null || "".equals(value)) {
            return 0;
        }

        byte[] bytes = null;
        if (encoding == null || "".equals(encoding)) {
            bytes = value.getBytes();
        } else {
            try {
                bytes = value.getBytes(encoding);
            } catch (UnsupportedEncodingException e) {
                throw e;
            }
        }
        return bytes == null ? 0 : bytes.length;
    }

}
