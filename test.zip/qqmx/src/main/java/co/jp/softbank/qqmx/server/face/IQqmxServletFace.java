package co.jp.softbank.qqmx.server.face;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.jp.softbank.qqmx.exception.SoftbankException;

public interface IQqmxServletFace {
	
	void init(ServletContext servletContext) throws ServletException;
	
	void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException;
	
	void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException;
	
	void initialize(ServletContext context) throws SoftbankException;

}
