package co.jp.softbank.qqmx.util;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;

import com.google.common.collect.Maps;

/**
 * 项目名称 ： Web2.0开发引擎. 
 * 类名称 ： ClassUtil 
 * 类描述 ： 类处理相关的工具类 
 * 创建人 ： 金雷 
 * 联系方式 ： xiaosan9528@163.com 
 * QQ ： 26981791 
 * 创建时间 ： 2015.10.29
 * 
 * @author king
 */
public class ClassUtil {

	private static Logger log = new LogUtil(ClassUtil.class).getLog();
	
	private class PackagePropertyInfo {
		private String suffix;
		private Map<String, Properties> infos;
		private boolean isRecursive;
		public PackagePropertyInfo(String pkgName, Map<String, Properties> infos, String suffix, boolean isRecursive) throws SoftbankException {
			this.suffix = suffix;
			this.infos = infos;
			this.isRecursive = isRecursive;
			init(pkgName);
		}
		
		private void init(String pkgName) throws SoftbankException {
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			try {
				// 按文件的形式去查找
				String strFile = pkgName.replaceAll("\\.", "/");
				Enumeration<URL> urls = loader.getResources(strFile);
				while (urls.hasMoreElements()) {
					URL url = urls.nextElement();
					if (url != null) {
						String protocol = url.getProtocol();
						String pkgPath = url.getPath();
						log.info("protocol:" + protocol + " path:" + pkgPath);
						if ("file".equals(protocol)) {
							findPropertyInfo(pkgName, pkgPath);
						} else if ("jar".equals(protocol)) {
							findPropertyInfo(pkgName, url);
						}
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
				throw new SoftbankException(SoftbankExceptionType.IOException, e);
			}
		}
		
		private void findPropertyInfo(String pkgName, String pkgPath) {
			File[] files = filterFiles(pkgPath);
			if (files != null) {
				for (File f : files) {
					String fileName = f.getName();
					if (f.isFile()) {
						Properties properties = getProperties(f);
						infos.put(fileName, properties);
					} else {
						if (isRecursive) {
							String subPkgName = pkgName + "." + fileName;
							String subPkgPath = pkgPath + "/" + fileName;
							findPropertyInfo(subPkgName, subPkgPath);
						}
					}
				}
			}
		}
		
		private void findPropertyInfo(String pkgName, URL url) throws IOException {
			JarURLConnection jarURLConnection = (JarURLConnection) url.openConnection();
			JarFile jarFile = jarURLConnection.getJarFile();
			Enumeration<JarEntry> jarEntries = jarFile.entries();
			while (jarEntries.hasMoreElements()) {
				JarEntry jarEntry = jarEntries.nextElement();
				String jarEntryName = jarEntry.getName();
				String clazzName = jarEntryName.replace("/", ".");
				String fileName = ConstantsUtil.Str.EMPTY;
				pkgName = pkgName.replace("/", ".");
				int endIndex = clazzName.lastIndexOf(".");
				String prefix = null;
				if (endIndex > 0) {
					String prefix_name = clazzName.substring(0, endIndex);
					endIndex = prefix_name.lastIndexOf(".");
					if (endIndex > 0) {
						prefix = prefix_name.substring(0, endIndex);
						fileName = prefix_name.substring(endIndex + 1);
					}
				}
				if (prefix != null && jarEntryName.endsWith(suffix)) {
					if (prefix.equals(pkgName)) {
						Properties properties = getProperties(jarFile, jarEntry);
						infos.put(fileName, properties);
					} else if (isRecursive && prefix.startsWith(pkgName)) {
						Properties properties = getProperties(jarFile, jarEntry);
						infos.put(fileName, properties);
					}
				}
			}
		}
		
		private Properties getProperties(JarFile jarFile, JarEntry jarEntry) {
			final Properties properties = new Properties();
			try {
				InputStream in = jarFile.getInputStream(jarEntry);
				properties.load(in);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return properties;
		}

		private  Properties getProperties(File file) {
			final Properties properties = new Properties();
			try {
				InputStream fileUrl = new FileInputStream(file);
				properties.load(fileUrl);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return properties;
		}

		private File[] filterFiles(String pkgPath) {
			if (StringUtils.isEmpty(pkgPath)) {
				return null;
			}
			return new File(pkgPath).listFiles(new FileFilter() {
				@Override
				public boolean accept(File file) {
					return (file.isFile() && file.getName().endsWith(suffix)) || file.isDirectory();
				}
			});
		}
		
		public Map<String, Properties> getPackageInfos() {
			return infos;
		}
	}

	public static Map<String, Properties> getPackageProperties(String pkgName) throws SoftbankException {
		return getPackageProperties(pkgName, true);
	}
	
	public static Map<String, Properties> getPackageProperties(String pkgName, boolean isRecursive) throws SoftbankException {
		Map<String, Properties> infos = Maps.newHashMap();
		PackagePropertyInfo packagePropertyInfo = new ClassUtil(). new PackagePropertyInfo(pkgName, infos, ConstantsUtil.Suffix.PROPERTY, true);
		
		return packagePropertyInfo.getPackageInfos();
	}
	
	public static void main(String[] args) {
		try {
			Map<String, Properties> info = getPackageProperties("co/jp/softbank/qqmx/resource");
			System.out.println(info.size());
		} catch (SoftbankException e) {
			e.printStackTrace();
		}
	}

}