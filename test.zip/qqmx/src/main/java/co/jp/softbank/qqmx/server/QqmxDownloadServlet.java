package co.jp.softbank.qqmx.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.jp.softbank.qqmx.server.face.IQqmxServletFace;
import co.jp.softbank.qqmx.util.ConstantsUtil;


public class QqmxDownloadServlet implements IQqmxServletFace {
	
	private ServletContext context;

	@Override
	public void initialize(ServletContext context) {
		
	}

	@Override
	public void init(ServletContext servletContext) throws ServletException {
		this.context = servletContext;
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding(ConstantsUtil.Frame.ENCODING);
		String fileName = request.getParameter("fileName");
		String filepath = context.getRealPath(File.separator) + ConstantsUtil.Frame.UPLOAD_PATH + request.getParameter("filePath");
		response.setContentType("application/octet-stream");
		response.addHeader("Content-Disposition", "attachment;filename=" + new String(fileName.getBytes(ConstantsUtil.Frame.ENCODING), "ISO8859-1"));
		OutputStream os = response.getOutputStream();
		try {
			FileInputStream fis = new FileInputStream(filepath);
			try {
				byte[] buffer = new byte[1024 * 10];
				int read;
				while ((read = fis.read(buffer)) != -1) {
					os.write(buffer, 0, read);
				}
				response.flushBuffer();
			} catch (Exception e) {
				fis.close();
			}
		} catch (Exception e) {
			os.flush();
			os.close();
		}
	}

}
