package co.jp.softbank.qqmx.server.bean;

import java.util.List;
import java.util.Map;

import javax.websocket.Session;

import co.jp.softbank.qqmx.util.DateUtils;

import net.sf.json.JSONObject;

public class SocketClientInfo {
	
	public SocketClientInfo(Session session) {
		this.session = session;
		Map<String, List<String>> parameters = session.getRequestParameterMap();
		if (parameters.containsKey("userId")) {
			this.userId = parameters.get("userId").get(0);
		}
		this.sessionId = session.getId();
		this.dateTime = DateUtils.getNow(DateUtils.FORMAT_YYYYMMDDHHMMSS_DASH);
		this.time = DateUtils.getNow(DateUtils.FORMAT_HHMMSS);
	}
	
	private Session session;
	
	private String userId;
	
	private String userName;
	
	private String sessionId;
	
	private String dateTime;
	
	private String time;
	
	private String isMe;

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	
	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String toJsonStr() {
		return toJsonObj().toString();
	}
	
	
	
	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIsMe() {
		return isMe;
	}

	public void setIsMe(String isMe) {
		this.isMe = isMe;
	}

	public JSONObject toJsonObj() {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("userId", this.userId);
		jsonObject.put("sessionId", this.sessionId);
		jsonObject.put("dateTime", this.dateTime);
		jsonObject.put("time", this.time);
		jsonObject.put("userName", this.userName);
		jsonObject.put("isMe", this.isMe);
		return jsonObject;
	}

}
