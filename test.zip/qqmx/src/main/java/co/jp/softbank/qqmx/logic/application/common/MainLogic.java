package co.jp.softbank.qqmx.logic.application.common;

import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class MainLogic extends AbstractBaseLogic {
	
	public LogicBean getUserInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		Map<String, Object> data = Maps.newHashMap();
		data.put("id", StringUtils.toString(userInfoData.getId()));
		data.put("userLogin", userInfoData.getLogin());
		data.put("userName", userInfoData.getName());
		data.put("firstName", userInfoData.getFirstName());
		data.put("lastName", userInfoData.getLastName());
		if (StringUtils.isNotEmpty(context.getParam().get("gantt_query"))) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("query_id", context.getParam().get("gantt_query"));
			data.put("queryData", db.query("queries.selectQueriesInfoById", conditions));
		}
		logicBean.setData(data);
		return logicBean;
	}
	
	@Override
	protected IDaoInterface getDao() {
		return null;
	}

}
