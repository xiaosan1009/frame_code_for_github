package co.jp.softbank.qqmx.logic.application.batch;


import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

/**
 * 版管理ツール(Git)からソースファイルを取得して、
 * ソース規模情報を収集する処理を行う。
 */
public class SourceDiffCountGitLogic extends SourceScaleCount {
    
    /** 一時ディレクトリ（変更前） */
    private static final String OLD_TMP_DIR = "ipf_git_old_";
    /** 一時ディレクトリ（変更後） */
    private static final String NEW_TMP_DIR = "ipf_git_new_";
    
    /**
     * ソース規模データ収集(Git用) 
     * 
     * @param args コマンドライン引数
     *  引数1 : プロジェクトID（必須）
     *  引数2 : バージョン（必須）
     *  引数3 : リポジトリパス（必須）
     *  引数4 : 収集開始リビジョン番号（任意、デフォルト1）
     * 
     */
    public void sourceDiff() {
        try {
            String delFlg    = null;
            String projectId = context.getParam().get("projectId");
            String gitPath = context.getParam().get("gitPath");
            String repoPath = context.getParam().get("repoPath");
            String branch = context.getParam().get("branch");
            String version = context.getParam().get("version");
            String filePath = context.getParam().get("filePath");
            String oldRevStr = context.getParam().get("oldRevStr");
            String newRevStr = context.getParam().get("newRevStr");
            
            // テスト用　２３０不要 
            /*projectId = context.getParam().get("projectId");
            //String gitPath = context.getParam().get("gitPath");
            //gitPath = "C:\\Users\\dev68443190e\\Desktop\\gitRepository\\review-platform.git\\";
            repoPath = "C:\\Users\\dev68443190e\\Desktop\\gitRepository\\sample.git\\.git";
            version = "version_1.0";
            //filePath  = "C:\\Users\\dev68443190e\\Desktop\\difftest";
            oldRevStr = "43b2639bea82fc3f21dbd675d0db147cd9f2c4ce";
            newRevStr = "8d8a4f9165557ca73f9a55012e6df1a7a2321a77";  
            */
            // ２３０要　テスト不要 
		    checkoutFile(gitPath, branch);
            
            log.info("projectId   :" + projectId);
            log.info("version     :" + version);
            log.info("repoPath    :" + repoPath);
            log.info("filePath    :" + filePath);
            log.info("delFlg      :" + delFlg);
            log.info("oldRevStr   :" + oldRevStr);
            log.info("newRevStr   :" + newRevStr);
            
            if ("/".equals(filePath.substring(0, 1))) {
            	filePath = filePath.substring(1);
            }

    		if (newRevStr == null) {
    			newRevStr = "HEAD";
    		}

            // ソース規模収集
            sourceScaleCollect(projectId, version, repoPath, filePath, delFlg, oldRevStr, newRevStr);
            
        } catch (Throwable e) {
        } finally {
        }
    }
    
    public void checkoutFile(String gitPath, String branch) {
		try {
			String cmd = "/opt/ipftools/review-platform.git/checkoutGitFile.sh " 
	    			 + gitPath + " " + branch;
			Process process = Runtime.getRuntime().exec(cmd);

			process.waitFor();
			process.destroy();
			
			log.info("☆☆☆ cmd ☆☆☆" + cmd);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }

    /**
     * ソース規模データを集計してIPF・DBに登録する。
     * 
     * @param projectId プロジェクトID
     * @param version バージョン
     * @param repoPath リポジトリパス
     * @param oldRev 開始リビジョン
     * @param configInfo Pentaho 設定ファイル情報
     * @throws Exception 
     */
    public void sourceScaleCollect(
            String projectId, 
            String version, 
            String repoPath,
            String filePath, 
            String delFlg,
            String oldRev,
            String newRev
        ) throws Exception {

        File oldTmpDir = null;
        File newTmpDir = null;
        
        try {
            
            // 一時ディレクトリ作成
            oldTmpDir = createTempDirectory(projectId + "_" + version + "_" + OLD_TMP_DIR, ".tmp");
            newTmpDir = createTempDirectory(projectId + "_" + version + "_" + NEW_TMP_DIR, ".tmp");
            log.debug("Temp Dir Create.");

            // Gitソースエクスポート
            IpfJGitUtils.export(repoPath, oldRev, newRev, oldTmpDir, newTmpDir);

            // 前回のデータ削除
            if ("1".equals(delFlg)) {
                deleteSourceDiff(projectId, version);
            }
            
            // 差分処理
            diff(projectId, version, repoPath, filePath, oldTmpDir.getName(), newTmpDir.getName(), oldTmpDir, true);
            diff(projectId, version, repoPath, filePath, newTmpDir.getName(), oldTmpDir.getName(), newTmpDir, false);

			
		} catch (Exception e) {
			try {
			} catch (Exception e2) {
			}
		} finally {
        }
    }

	public void diff(String projectId, String version, String repoPath, String filePath, String dirPathFrom,
			String dirPathTo, File dirForm, boolean diffFlg) throws Exception {

		File[] files = dirForm.listFiles();

		if (files == null) {
			return;
		}
		
		for (File file : files) {
			if (!file.exists()) {
				continue;
			} else if (file.isDirectory()) {
				diff(projectId, version, repoPath, filePath, dirPathFrom, dirPathTo, file, diffFlg);
			} else if (file.isFile()) {
				// ソースファイル取得、ソース規模情報取得、DB登録
				sourceScaleCollectAndDbInsert(projectId, version, repoPath, filePath, file,
						new File(file.getPath().replaceAll(dirPathFrom, dirPathTo)), diffFlg);
			}
		}
	}
	
    /**
     * ソースファイルを取得して、ソース規模データを集計しDBに登録する。
     * 
     * @param conn DBコネクション
     * @param pstmt プレペアド・ステートメント
     * @param projectId プロジェクトID
     * @param version バージョン
     * @param repository リポジトリ
     * @param logEntry コミットログ
     * @param entryPath コミットファイル
     * @param oldTmpDir 一時ディレクトリ（変更前）
     * @param newTmpDir 一時ディレクトリ（変更後）
     * @throws Exception 
     */
    protected void sourceScaleCollectAndDbInsert (
            String projectId,
            String version,
            String repoPath,
            String filePathGit,
            File fromFile,
            File toFile,
            boolean diffFlg) throws Exception {

    	try {
	        long revision       = 0;  // リビジョン番号
	        
	        String filePath     = fromFile.getPath();                            // ファイルフルパス（ファイル名含む）
	        String filePathOnly = FilenameUtils.getPath(filePath);  				// ファイルパスのみ（ファイル名除く）
	        filePathOnly = filePathGit + FilenameUtils.separatorsToUnix(filePathOnly.substring(filePathOnly.indexOf(".tmp") + 5));
	        String fileName     = FilenameUtils.getName(filePath);                // ファイル名（拡張子含む）
	        String fileExt      = FilenameUtils.getExtension(filePath);           // 拡張子
	        
	        // ソース規模収集可否チェック
	        if (!isCountable(filePath)) {
	            // ログ出力（ファイル毎）（スキップ）
//	            String msgskip = String.format(resource.getString("log.file.collect.skip"), filePath);
//	            log.info(msgskip);
	            return;
	        }
	        
	        // ソース規模取得
	        SourceScaleResult result = null;
	        if (diffFlg) {
	        	result = count(fromFile, toFile);
	        } else {
	        	result = count(toFile, fromFile);
	        }
	        result.setRevision(Long.toString(revision));
	        result.setFilePath(filePathOnly);
	        result.setFileName(fileName);
	        result.setFileExt(fileExt);
	        
	        // ソース規模DB登録
	        insertSourceDiff(projectId, version, repoPath, result);
	        
	        // ログ出力（ファイル毎）（処理成功）
//	        String msgok = String.format(resource.getString("log.file.collect.end"), filePath);
//	        log.info(msgok);
        } finally {
            // 一時ファイル削除
            if (fromFile != null) FileUtils.deleteQuietly(fromFile);
            if (toFile != null) FileUtils.deleteQuietly(toFile);
            log.debug("File Remove.");
        }
            
    }
}
