package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.project.settings.CategoryListDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

public class CategoryListLogic extends AbstractBaseLogic {

	@Autowired
	private CategoryListDao categoryListDao;

	public void getCategoryListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		PageListBean pageListBean = pageList(categoryListDao, "getCategoryListInfo",conditions);
		context.getResultBean().setData(pageListBean);
	}
	
	public LogicBean getProjectCategoryUserList() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		groupBean.setData(categoryListDao.getProjectCategoryUserList(conditions));
		return groupBean;
	}
	
	public void saveProjectCategory() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		conditions.put("name", context.getParam().get("category_name"));
		conditions.put("assigned_to_id", Integer.parseInt(context.getParam().get("assigned_to_id")));
		String dataFlg = context.getParam().get("id");
		conditions.put("id", Integer.parseInt(dataFlg));
		
		if (dataFlg != ""){
			categoryListDao.updateProjectCategory(conditions);
		}else{
			categoryListDao.saveProjectCategory(conditions);
		}
		
	}
	
	public void delProjectCategory() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		conditions.put("id", Integer.parseInt(context.getParam().get("category_id")));
		categoryListDao.delProjectCategory(conditions);
	}
	
	public LogicBean getProjectCategoryId() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", Integer.parseInt(context.getParam().get("category_id")));
		groupBean.setData(categoryListDao.getProjectCategoryId(conditions));
		return groupBean;
	}
	
	
	
}
