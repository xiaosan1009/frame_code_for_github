package co.jp.softbank.qqmx.logic.application.test;

import java.applet.Applet;
import java.awt.Graphics;
import java.io.IOException;

public class TestApplet extends Applet {

	@Override
	public void paint(Graphics g) {
		g.drawString("Hello World!!!", 50, 50);
	}
	
	public static void main(String[] args) {
		try {
			Runtime.getRuntime().exec("cmd /c start \\\\devwcfs.local\\share3\\data3\\shareprj\\qqmx\\個人フォルダ\\王晨\\【フロント-顧客管理】Jedi（旧コンシス再構築）_20170112作業.xls");
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}
}
