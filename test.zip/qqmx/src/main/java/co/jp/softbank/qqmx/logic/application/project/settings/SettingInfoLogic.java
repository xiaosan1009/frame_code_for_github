package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.yaml.snakeyaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.project.settings.NewProjectDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class SettingInfoLogic extends AbstractBaseLogic {
	
	@Autowired
	private NewProjectDao newProjectDao;
	
	public void getRepositoriesList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projectId");
		int project_id = Integer.parseInt(projectIdString);
		conditions.put("project_id", project_id);
		PageListBean pageListBean = pageList("settingInfo.getRepositoriesList", conditions);
		context.getResultBean().setData(pageListBean);
	}
	
	public void saveRepositorie() throws SoftbankException {
		String str_is_default = "";
		boolean is_default = false;
		String url = "";
		String login = "";
		String password = "";
		String root_url = "";
		String path_encoding = "";
		String log_encoding = "";
		String extra_info = "";
		String type = context.getParam().get("scm");
		String identifier = context.getParam().get("identifier");
		str_is_default = context.getParam().get("is_default");
		String projectIdString = context.getParam().get("projectId");
		if ("true".equals(str_is_default)){is_default = true;}
		
		if ("Subversion".equals(type)){
			url = context.getParam().get("url_sub");
			login = context.getParam().get("login");
			password = context.getParam().get("password");
		}else if ("Git".equals(type)){
			url = context.getParam().get("url_git");
			path_encoding = context.getParam().get("path_encoding");
			extra_info = context.getParam().get("extra_report_last_commit");
		}

		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		conditions.put("url", url);
		conditions.put("login", login);
		conditions.put("password", password);
		conditions.put("root_url", root_url);
		conditions.put("type", type);
		conditions.put("path_encoding", path_encoding);
		conditions.put("log_encoding", log_encoding);
		conditions.put("extra_info", extra_info);
		conditions.put("identifier", identifier);
		conditions.put("is_default", is_default);
		
		String typeFlag = context.getParam().get("id");
		
		if ("undefined".equals(typeFlag)){
			db.insert("settingInfo.saveRepositorie" , conditions);
		}else{
			conditions.put("id", Integer.parseInt(typeFlag));
			db.update("settingInfo.updateRepositorie" , conditions);
		}
	}
	
	public void deleteRepositorie() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("repository_id", Integer.parseInt(context.getParam().get("repository_id")));
		db.delete("settingInfo.deleteRepositorie" , conditions);
	}
	
	public void editRepositorie() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("repository_id", Integer.parseInt(context.getParam().get("repository_id")));
		context.getResultBean().setData(db.querys("settingInfo.editRepositorie" , conditions));
	}
	
	public void getProjectInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projectId");
		int project_id = Integer.parseInt(projectIdString);
		conditions.put("projectId", project_id);
		context.getResultBean().setData(db.querys("settingInfo.getProjectInfo" , conditions));
	}
	@SuppressWarnings("unchecked")
	public LogicBean getProjectCustomListInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, String> settingsMap = Maps.newHashMap();
		String projectIdString = context.getParam().get("projectId");
		int project_id = Integer.parseInt(projectIdString);
		Map<String, Object> customFieldsBeanValues = Maps.newHashMap();
		customFieldsBeanValues.put("project_id", project_id);
		resultMap.put("customFields", newProjectDao.getCustomFieldsBeanValues(customFieldsBeanValues));
		// TODO project_id判断
		if ("".equals(project_id)){
			
			List<Map<String, Object>> settingsList = newProjectDao.getSettings();
			Map<String, Object> settingsData = settingsList.get(0);
			String settingsValue = StringUtils.toString(settingsData.get("value"));
			Yaml yaml = new Yaml();
			List<String> settingsList2 = (List<String>)yaml.load(settingsValue);
			for (int i = 0; i < settingsList2.size(); i++) {
				settingsMap.put(settingsList2.get(i), settingsList2.get(i));
			}
			resultMap.put("trackers", newProjectDao.getTrackers());
			resultMap.put("issuesCustomFields", newProjectDao.getIssuesCustomFields());
		}else{
			Map<String, Object> conditions = Maps.newHashMap();
			Map<String, String> enabledModulesMap = Maps.newHashMap();
			conditions.put("project_id", project_id);
			List<Map<String, String>> enabledModulesList = newProjectDao.getEnabledModules(conditions);
			for (int e = 0; e < enabledModulesList.size(); e++) {
				enabledModulesMap = enabledModulesList.get(e);
				settingsMap.put(enabledModulesMap.get("name"), enabledModulesMap.get("name"));
			}
			resultMap.put("trackers", newProjectDao.getProjectTrackers(conditions));
			resultMap.put("issuesCustomFields", newProjectDao.getProjectIssuesCustomFields(conditions));
		}
		
		resultMap.put("settings", settingsMap);
//		resultMap.put("plugins", ControlDbMemory.getInstance().getPluginInfoBeans());
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public void getProjectWiki() throws SoftbankException {
		String projectIdString = context.getParam().get("projectId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		context.getResultBean().setData(db.querys("settingInfo.getProjectWikiInfo" , conditions));
	}
	
	public void deleteProjectWiki() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		String projectIdString = context.getParam().get("projectId");
		conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		db.delete("settingInfo.deleteWikisInfos" , conditions);
	}
	
	public void submitProjectInfo() throws SoftbankException {
		String flg = context.getParam().get("flgId");
		// INFOの場合
		if ("setting-tab-info".equals(flg)){
			Map<String, Object> conditions = Maps.newHashMap();
			Integer parentId = null;
			if (StringUtils.isNotEmpty(context.getParam().get("project_parent_id"))) {
				parentId = Integer.parseInt(context.getParam().get("project_parent_id"));
			}
			String projectIdString = context.getParam().get("projectId");
			conditions.put("project_id", Integer.parseInt(projectIdString));
			conditions.put("project_name", context.getParam().get("project_name"));
			conditions.put("project_parent_id", parentId);
			conditions.put("project_description", context.getParam().get("project_description"));
			conditions.put("project_identifier", context.getParam().get("project_identifier"));
			conditions.put("project_is_public", ("1".equals(context.getParam().get("project_is_public")) ? true : false));
			conditions.put("project_homepage", context.getParam().get("project_homepage"));
			conditions.put("project_landingpage", ConstantsUtil.Str.EMPTY);
			db.update("settingInfo.updateProjectInfo", conditions);
		
			context.getParam().each(new Param.EachFilter() {
				@Override
				public void filter(String key, String value) throws SoftbankException {
					if (key.startsWith("project_custom_field_values_")) {
						String pIdString = context.getParam().get("projectId");
						Map<String, Object> customValueInfo = Maps.newHashMap();
						customValueInfo.put("customized_id", Integer.parseInt(pIdString));
						customValueInfo.put("custom_field_id", Integer.parseInt(key.substring("project_custom_field_values_".length())));
						customValueInfo.put("value", value);
						List<Map<String, Object>> projectInfos = null;
						try {
							projectInfos = db.querys("settingInfo.selectProjectsCustomValues", customValueInfo);
						} catch (SoftbankException e) {
							e.printStackTrace();
						}
						if (projectInfos.size() == 0){
							db.insert("settingInfo.insertProjectsCustomValues", customValueInfo);
						}else{
							db.update("settingInfo.updateProjectsCustomValues", customValueInfo);
						}
					}
				}
			});
			
			String[] projectsTrackers = context.getParam().getList("project_tracker_ids");
			if (projectsTrackers != null) {
				Map<String, Object> projectTrackers = Maps.newHashMap();
				projectTrackers.put("project_id", Integer.parseInt(projectIdString));
				db.delete("settingInfo.delProjectTrackerIds", projectTrackers);
				
				List<Map<String, Object>> projectsTrackerList = Lists.newArrayList();
				for (int i = 0; i < projectsTrackers.length; i++) {
					Map<String, Object> projectsTrackerInfo = Maps.newHashMap();
					projectsTrackerInfo.put("project_id", Integer.parseInt(projectIdString));
					projectsTrackerInfo.put("tracker_id", Integer.parseInt(projectsTrackers[i]));
					projectsTrackerList.add(projectsTrackerInfo);
				}
				conditions = Maps.newHashMap();
				conditions.put("projectsTrackers", projectsTrackerList);
				newProjectDao.insertProjectsTrackersInfos(conditions);
			}
			
			String[] customFields = context.getParam().getList("project_issue_custom_field_ids");
			if (customFields != null) {
				Map<String, Object> projectIssueCustomFields = Maps.newHashMap();
				projectIssueCustomFields.put("project_id", Integer.parseInt(projectIdString));
				db.delete("settingInfo.delProjectIssueCustomFields", projectIssueCustomFields);
				
				List<Map<String, Object>> customFieldList = Lists.newArrayList();
				for (int i = 0; i < customFields.length; i++) {
					Map<String, Object> customFieldInfo = Maps.newHashMap();
					customFieldInfo.put("project_id", Integer.parseInt(projectIdString));
					customFieldInfo.put("custom_field_id", Integer.parseInt(customFields[i]));
					customFieldList.add(customFieldInfo);
				}
				conditions = Maps.newHashMap();
				conditions.put("customFields", customFieldList);
				newProjectDao.insertProjectsCustomFields(conditions);
			}
		} else if ("setting-tab-wiki".equals(flg)){
			Map<String, Object> conditions = Maps.newHashMap();
			
			String projectIdString = context.getParam().get("projectId");
			String start_page = context.getParam().get("wiki_start_page");
			String data_start_page = context.getParam().get("data_start_page");
			conditions = Maps.newHashMap();
			conditions.put("project_id", Integer.parseInt(projectIdString));
			conditions.put("start_page", start_page);
			
			if (!"".equals(data_start_page) && null != data_start_page){
				db.update("settingInfo.updateWikisInfos", conditions);
			}else{
				db.insert("settingInfo.insertWikisInfos", conditions);
			}
		}

	}
}
