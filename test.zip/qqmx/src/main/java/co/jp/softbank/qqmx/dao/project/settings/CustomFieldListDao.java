package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface CustomFieldListDao extends IDaoInterface {
	List<Map<String, Object>> getCustomFieldListInfo(Map<String, Object> conditions);
	List<Map<String, Object>> getCustomFieldIdInfo(Map<String, Object> conditions);
	List<Map<String, Object>> getEditIssueCustomField(Map<String, Object> conditions);
	List<Map<String, Object>> getTrackersInfo(Map<String, Object> conditions);
	List<Map<String, Object>> getStatusInfo(Map<String, Object> conditions);
	void delCustomFieldIdInfo(Map<String, Object> conditions);

	void upCommonMSort(Map<String, Object> conditions);
	void upCommonPSort(Map<String, Object> conditions);
	void upCommonSort(Map<String, Object> conditions);
	void insertCustomFields(Map<String, Object> conditions);
	void insertCustomFieldsTrackers(Map<String, Object> conditions);
	void updataCustomFields(Map<String, Object> conditions);
	void deleteCustomFieldsTrackers(Map<String, Object> conditions);

}
