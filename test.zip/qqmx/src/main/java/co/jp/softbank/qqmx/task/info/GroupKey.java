package co.jp.softbank.qqmx.task.info;

import co.jp.softbank.qqmx.task.face.IValueExtractor;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.base.Preconditions;


public class GroupKey extends ComparableKey<GroupKey> {

	public static final String DEFAULT_GROUP = "defGroup";
	
	public GroupKey(String name, Comparable<?> value) {
        add(name, value);
    }
	
	public GroupKey add(String name, Comparable<?> value) {
        Preconditions.checkArgument(StringUtils.isNotEmpty(name), "name should not be null or empty.");
        super.add(name, value);
        return this;
    }
	
	public static IValueExtractor<GroupKey> newExtractor(final String key) {
        return new IValueExtractor<GroupKey>() {
            @Override
            public <T> T extract(GroupKey obj) {
                return (T) obj.getValues().get(key);
            }
        };
    }
}
