package co.jp.softbank.qqmx.dao.common;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

public class DbMemoryMonitorDaoService implements DbMemoryMonitorDao {
	
	@Autowired
	private DbMemoryMonitorDao dbMemoryMonitorDao;
	
	public Map<String, Object> getIssueUpdateTimestamp(Map<String, Object> conditions) {
		return dbMemoryMonitorDao.getIssueUpdateTimestamp(conditions);
	}

	@Override
	public Integer getProjectParentId(Map<String, Object> conditions) {
		return dbMemoryMonitorDao.getProjectParentId(conditions);
	}

}
