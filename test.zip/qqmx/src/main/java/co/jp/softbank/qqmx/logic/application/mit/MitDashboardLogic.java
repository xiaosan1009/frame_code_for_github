package co.jp.softbank.qqmx.logic.application.mit;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

public class MitDashboardLogic extends AbstractBaseLogic {
	
	
	
	
	public void getDashboardInfo() throws SoftbankException {
		if(isSosiki()){
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("project_id", 1464);
			conditions.put("tracker_id", 3);
			String organization_cd = "";
			if (StringUtils.isEmpty(context.getParam().get("organizationCd"))) {
				organization_cd = "10972670";
			} else {
				organization_cd = context.getParam().get("organizationCd");
			}
			conditions.put("organization_cd", organization_cd);
			context.getResultBean().setData(db.querys("mitDashboard.getMitTotalProjectListInfo", conditions));
		} else {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("tracker_id", 3);
//			String organization_cd = "";
//			if (StringUtils.isEmpty(context.getParam().get("organization_cd"))) {
//				organization_cd = "10972670";
//			} else {
//				organization_cd = context.getParam().get("organization_cd");
//			}
			
			String project_id = context.getParam().get("projectId");
			conditions.put("project_id", Integer.parseInt(project_id));
			String versionId = context.getParam().get("versionId") ;
			if(StringUtils.isNotEmpty(versionId)){
				conditions.put("versionId", Integer.parseInt(versionId));
			}
			
			context.getResultBean().setData(db.querys("mitDashboard.getMitProjectListInfo", conditions));
		}

	}
	
	public void getIssuesInfo() throws SoftbankException {
	
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		if(isSosiki()){
		
			conditions.put("tracker_id", 3);
			
			String sosiki_cd = context.getParam().get("organizationCd");
			conditions.put("organization_cd", sosiki_cd);
			
			conditions.put("project_id", 1464);
			List<Map<String, Object>> project = db.querys("dashboard.getProject", conditions);
		
			
			resultMap.put("project", project);
			List<Map<String, Object>> lstInfo = db.querys("mitDashboard.getTicketInfor", conditions);
			
			resultMap.put("lstInfo", lstInfo);
			List<Map<String, Object>> bugsInfo = db.querys("mitDashboard.getBugsInfor", conditions) ;
			resultMap.put("bugsInfo", bugsInfo);
			List<Map<String, Object>> sum = db.querys("mitDashboard.getMitTotalProjectListInfo", conditions);
			
			resultMap.put("sum", sum);
			context.getResultBean().setData(resultMap);
		}else{
			conditions.put("tracker_id", 3);
			//**************************
//			String organization_cd = "";
//			if (StringUtils.isEmpty(context.getParam().get("organization_cd"))) {
//				organization_cd = "10972670";
//			} else {
//				organization_cd = context.getParam().get("organization_cd");
//			}
			// ********************************
			String project_id = context.getParam().get("projectId");
			conditions.put("project_id", Integer.parseInt(project_id));
			String versionId = context.getParam().get("versionID") ;
			if(StringUtils.isNotEmpty(versionId)){
				conditions.put("versionId", Integer.parseInt(versionId));
			}
			List<Map<String, Object>> project = db.querys("dashboard.getProject", conditions);
		
			
			resultMap.put("project", project);
			List<Map<String, Object>> lstInfo = db.querys("mitDashboard.getEachTicketInfor", conditions);
			
			resultMap.put("lstInfo", lstInfo);
			List<Map<String, Object>> bugsInfo = db.querys("mitDashboard.getEachBugsInfor", conditions) ;
			resultMap.put("bugsInfo", bugsInfo);
			List<Map<String, Object>> sum = db.querys("mitDashboard.getMitProjectListInfo", conditions);
			
			resultMap.put("sum", sum);
			context.getResultBean().setData(resultMap);
		}
		
	}
	public void getTopicCommentRole() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions.put("project_id", projectId);
		conditions.put("user_id", loginUserId);
		context.getResultBean().setData(db.querys("mitDashboard.getTopicCommentRole", conditions));
	}
	public void getTopicCommentInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		conditions.put("organization_cd", "");
		context.getResultBean().setData(db.querys("mitDashboard.getTopicCommentInfo", conditions));
	}
	public void getTopicCommentValueInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		String shoriTime = context.getParam().get("shoriTime");
		conditions.put("project_id", projectId);
		conditions.put("organization_cd", "");
		conditions.put("shori_time", shoriTime);
		context.getResultBean().setData(db.querys("mitDashboard.getTopicCommentValueInfo", conditions));
	}
	public void insertTopicComment() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String shoriTime = context.getParam().get("shoriTime");
		String subPId = context.getParam().get("subPrjId");
		String pId = context.getParam().get("proId");
		String comment = context.getParam().get("commentData");
		
		int projectParentId = 0;
		int projectId = 0;
		if ("9898".equals(subPId)){
			projectParentId = Integer.parseInt(pId);
			projectId = Integer.parseInt(pId);
		}else{
			projectParentId = Integer.parseInt(pId);
			projectId = Integer.parseInt(subPId);
		}
		conditions.put("project_id", projectId);
		conditions.put("project_parent_id", projectParentId);
		conditions.put("shori_time", shoriTime);
		conditions.put("comment", comment);
		context.getResultBean().setData(db.insert("mitDashboard.insertTopicComment", conditions));
	}
	private boolean isSosiki(){
		String sosiki_cd = context.getParam().get("organizationCd");
		return StringUtils.isEmpty(sosiki_cd) ? false : true ;
	}
	
}
