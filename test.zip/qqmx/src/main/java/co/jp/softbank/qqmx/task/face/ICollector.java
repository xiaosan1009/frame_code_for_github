package co.jp.softbank.qqmx.task.face;

import java.io.Closeable;
import java.util.Iterator;

import co.jp.softbank.qqmx.exception.SoftbankException;

public interface ICollector<P> extends Iterator<P>, Iterable<P>, Closeable {
	
	P getPrevious();
	
	P getCurrent();
	
	P getNext();
	
	int size();
	
	void prepare(ITaskContext context) throws SoftbankException;

}
