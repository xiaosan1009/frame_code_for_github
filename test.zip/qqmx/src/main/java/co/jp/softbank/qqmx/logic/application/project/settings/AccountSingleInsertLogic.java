package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.yaml.snakeyaml.Yaml;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class AccountSingleInsertLogic extends AbstractBaseLogic {
	
	
	public LogicBean getPrivateSettingInfo() throws SoftbankException {
		
		LogicBean logicBean = new LogicBean();
		Map<String, Object> Conditions = Maps.newHashMap();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, String> settingsMap = Maps.newHashMap();
		
		String user_id = context.getParam().get("userId");
		if ("undefined".equals(user_id)) {
			UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
			Conditions.put("id", userInfoData.getId());
		}else{
			Conditions.put("id", Integer.parseInt(user_id));
		}
		

		List<Map<String, Object>> projectsTrackerList = Lists.newArrayList();
		projectsTrackerList = db.querys("privateSetting.getPrivateSettingInfo", Conditions);
		Map<String, Object> projectsTrackerData = projectsTrackerList.get(0);
		if ( !"".equals( projectsTrackerData.get("others") ) && projectsTrackerData.get("others") != null) {
			String settingsValue = StringUtils.toString(projectsTrackerData.get("others"));
			Yaml yaml = new Yaml();
			Map<String, Object> projectsTracker2Data = (Map<String, Object>)yaml.load(settingsValue);
			
			if (String.valueOf(projectsTracker2Data.get(":no_self_notified")).equals("false")){
				settingsMap.put("no_self_notified", "");
			}else{
				settingsMap.put("no_self_notified", "1");
			}
			settingsMap.put("pref_comments_sorting", StringUtils.toString(projectsTracker2Data.get(":comments_sorting")));
			settingsMap.put("backlogs_task_color", StringUtils.toString(projectsTracker2Data.get(":backlogs_task_color")));
			settingsMap.put("pref_warn_on_leaving_unsaved", StringUtils.toString(projectsTracker2Data.get(":warn_on_leaving_unsaved")));
			
		}else{
			
			settingsMap.put("no_self_notified", "");
			settingsMap.put("pref_comments_sorting",  "");
			settingsMap.put("backlogs_task_color", "");
			settingsMap.put("pref_warn_on_leaving_unsaved", "");
		}
		resultMap.put("projectsTrackerOthers", settingsMap);
		resultMap.put("projectsTracker", projectsTrackerData);
		logicBean.setData(resultMap);
		return logicBean;
	}	
	
	public void saveUser() throws SoftbankException {
		Map<String, Object> userConditions = Maps.newHashMap();
		String user_login = context.getParam().get("user_login");
		String user_firstname = context.getParam().get("user_firstname");
		String user_lastname = context.getParam().get("user_lastname");
		String user_mail = context.getParam().get("user_mail");
		String user_admin = context.getParam().get("user_admin");
		String user_landing_page = context.getParam().get("user_landing_page");
		String user_password = context.getParam().get("user_password");
		String user_password_confirmation = context.getParam().get("user_password_confirmation");
		String send_information = context.getParam().get("send_information");
		String user_mail_notification = context.getParam().get("user_mail_notification");
		String user_language = context.getParam().get("user_language");
		
		userConditions.put("login", user_login);
		userConditions.put("hashed_password", user_firstname);
		userConditions.put("firstname", user_firstname);
		userConditions.put("lastname", user_lastname);
		userConditions.put("mail", user_mail);
		if ("1".equals(user_admin)) {
			userConditions.put("admin", true );
		}else{
			userConditions.put("admin", false );
		}
		userConditions.put("language", user_language);
		userConditions.put("mail_notification", user_mail_notification);
		userConditions.put("landing_page", user_landing_page);
		
		
		Map<String, Object> userPreferenceConditions = Maps.newHashMap();
		String no_self_notified = context.getParam().get("no_self_notified");
		String pref_hide_mail = context.getParam().get("pref_hide_mail");
		String pref_time_zone = context.getParam().get("pref_time_zone");
		String pref_comments_sorting = context.getParam().get("pref_comments_sorting");
		String pref_warn_on_leaving_unsaved = context.getParam().get("pref_warn_on_leaving_unsaved");
	
		if ("1".equals(pref_hide_mail)) {
			userPreferenceConditions.put("hide_mail", true);
		}else{
			userPreferenceConditions.put("hide_mail", false);
		}
		userPreferenceConditions.put("time_zone", pref_time_zone);
		
		String user_id = context.getParam().get("userId");
		if ("undefined".equals(user_id)) {
			
			Map<String, Object> userPreferenceList = Maps.newHashMap();
			if ("1".equals(no_self_notified)) {
				userPreferenceList.put(":no_self_notified",true);
			}else{
				userPreferenceList.put(":no_self_notified",false);
			}
			
			userPreferenceList.put(":warn_on_leaving_unsaved",pref_warn_on_leaving_unsaved);
			userPreferenceList.put(":comments_sorting", pref_comments_sorting);
			String yamlDate = org.ho.yaml.Yaml.dump(userPreferenceList);
			userPreferenceConditions.put("others", yamlDate.replace("\"", "").replace("!java.util.LinkedHashMap", ""));
			
			db.insert("accountSingleInsert.saveUser", userConditions);
			user_id = StringUtils.toString(userConditions.get("id"));
			userPreferenceConditions.put("user_id", Integer.parseInt(user_id));
			db.insert("accountSingleInsert.saveUserPreferences", userPreferenceConditions);
		}else{
			userConditions.put("id", Integer.parseInt(user_id));
			List<Map<String, Object>> projectsTrackerList = Lists.newArrayList();
			projectsTrackerList = db.querys("privateSetting.getPrivateSettingInfo", userConditions);
			Map<String, Object> projectsTrackerData = projectsTrackerList.get(0);
			String settingsValue = StringUtils.toString(projectsTrackerData.get("others"));
			Yaml yaml = new Yaml();
			Map<String, Object> projectsTracker2Data = (Map<String, Object>)yaml.load(settingsValue);
			Map<String, Object> userPreferenceList1 = Maps.newHashMap();
			for (Entry<String, Object> date : projectsTracker2Data.entrySet()){
				userPreferenceList1.put(date.getKey(), date.getValue());
			}
			userPreferenceList1.put(":warn_on_leaving_unsaved",pref_warn_on_leaving_unsaved);
			userPreferenceList1.put(":comments_sorting", pref_comments_sorting);
			if ("1".equals(no_self_notified)) {
				userPreferenceList1.put(":no_self_notified",true);
			}else{
				userPreferenceList1.put(":no_self_notified",false);
			}
			
			String yamlDate = org.ho.yaml.Yaml.dump(userPreferenceList1);
			userPreferenceConditions.put("others", yamlDate.replace("\"", "").replace("!java.util.LinkedHashMap", ""));
			
			userPreferenceConditions.put("user_id", Integer.parseInt(user_id));
			db.update("accountSingleInsert.updateUser", userConditions);
			db.update("accountSingleInsert.updateUserPreferences", userPreferenceConditions);
		}
	}	
}
