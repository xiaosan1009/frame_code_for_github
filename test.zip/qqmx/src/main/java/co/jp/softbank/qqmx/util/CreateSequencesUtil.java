package co.jp.softbank.qqmx.util;

import java.util.List;
import java.util.Map;
import java.util.Stack;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.application.bean.HttpContext;

public final class CreateSequencesUtil {
    
    private CreateSequencesUtil() {
    }
    
    private static long sSequenceNo = 1;
    
    private static long sShortSequenceNo = 1;
    
    public static final long MAX_SIZE = 10000;
    
    public static final long MAX_SHORT_SIZE = 100000;

    public static final Object LOCK = new Object();
    
    public static final Object SHORT_LOCK = new Object();

    public static String createID() {
        return createID(ConstantsUtil.Str.EMPTY);
    }
    
    public static String createID(String key) {
        return createID(null, key);
    }
    
    public static String createID(HttpContext httpContext) {
        return createID(httpContext, ConstantsUtil.Str.EMPTY);
    }
    
    public static String createID(HttpContext httpContext, String key) {
        
        final String tranDate = DateUtils.getNowTime(DateUtils.FORMAT_YYYYMMDDHHSS3);
        int current = 10;
        synchronized (LOCK) {
            if (sSequenceNo > MAX_SIZE) {
                sSequenceNo = 10;
            }
            current += sSequenceNo++;
        }
        if (StringUtils.isEmpty(key)) {
            key = "CM";
        }
        final StringBuffer sb = new StringBuffer(key);
        if (httpContext != null && httpContext.getSessionData() != null && httpContext.getSessionData().getUserInfo() != null) {
            if (StringUtils.isNotEmpty(httpContext.getSessionData().getUserInfo().getDataSource())) {
                sb.append(httpContext.getSessionData().getUserInfo().getDataSource());
            } else {
                sb.append("00");
            }
            if (StringUtils.isNotEmpty(httpContext.getSessionData().getUserInfo().getProvinceId())) {
                sb.append(httpContext.getSessionData().getUserInfo().getProvinceId());
            } else {
                sb.append("00");
            }
        } else {
            sb.append("0000");
        }
        sb.append(tranDate).append(current);
        
        return sb.toString();
    }
    
    public static String createShortID(String key) {
    	int current = 10;
    	synchronized (SHORT_LOCK) {
    		if (sShortSequenceNo > MAX_SHORT_SIZE) {
    			sShortSequenceNo = 10;
    		}
    		current += sShortSequenceNo++;
    	}
    	if (StringUtils.isEmpty(key)) {
    		key = "CM";
    	}
    	final StringBuffer sb = new StringBuffer(key);
    	sb.append(current);
    	
    	return sb.toString();
    }
    
    public static void main(String[] args) {
    	Stack<String> stack = new Stack<String>();
    	stack.push("1");
    	stack.push("2");
    	stack.push("3");
    	stack.push("4");
    	stack.push("5");
    	stack.push("6");
    	stack.push("7");
    	System.out.println("stack = " + stack);
    	System.out.println("first = " + stack.peek());
    	System.out.println("stack = " + stack);
    	while (!stack.isEmpty()) {
    		System.out.println("pop = " + stack.pop());
		}
//    	List<Map<String, String>> list = Lists.newArrayList();
//    	Map<String, String> aMap = Maps.newHashMap();
//    	aMap.put("a", "a");
//    	list.add(aMap);
//    	Map<String, Map<String, String>> bMap = Maps.newHashMap();
//    	bMap.put("b", aMap);
//    	
//    	bMap.get("b").put("a", "a1");
//    	System.out.println(bMap);
//    	System.out.println(list);
//    	Map<String, String> aMap = Maps.newHashMap();
//    	aMap.put("a", "a");
//    	Map<String, String> bMap = Maps.newHashMap(aMap);
//    	bMap.put("b", "b");
//    	System.out.println(aMap);
//    	System.out.println(bMap);
//    	for (int i = 0; i < 1000; i++) {
//    		System.out.println(createShortID("n"));
//		}
    }
}
