package co.jp.softbank.qqmx.dao.project;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.project.bean.ProjectInfoBean;

public interface ProjectDao extends IDaoInterface {
	
	List<Map<String, Object>> getAllProjectInfos();
	
	List<Map<String, Object>> getProjectInfosByUser(Map<String, Object> conditions);
	
	ProjectInfoBean getProjectInfosById(Map<String, Object> conditions);

}
