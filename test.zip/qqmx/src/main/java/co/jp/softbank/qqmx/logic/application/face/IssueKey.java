package co.jp.softbank.qqmx.logic.application.face;

public interface IssueKey {
	
	interface PROCESS {
		String FLOOR_ID = "z1";
		String ISDELETE = "z2";
		String ADDFLG = "z3";
		String ISUPDATE = "z4";
		String ISPARENT = "z5";
		String ISPROJECT = "z6";
		String ISVERSION = "z7";
		String WATCHER_USER_IDS = "z8";
		String NOTES = "z9";
		String DATA_IS_CHANGED = "DATA_IS_CHANGED";
		String ONLY_ORDER_CHANGED = "ONLY_ORDER_CHANGED";
		String NOT_CHANGED = "NCD";
	}
	
	interface ISSUE_ID {
		String KEY = "issue_id";
		String KEY_JSON = "a";
	}
	
	interface TRACKER_ID {
		String KEY = "tracker_id";
		String KEY_JSON = "b";
	}
	
	interface PROJECT_ID {
		String KEY = "project_id";
		String KEY_JSON = "c";
	}
	
	interface SUBJECT {
		String KEY = "subject";
		String KEY_JSON = "d";
	}
	
	interface DESCRIPTION {
		String KEY = "description";
		String KEY_JSON = "e";
		String KEY_MAP = "t1_description";
	}
	
	interface DUE_DATE {
		String KEY = "due_date";
		String KEY_JSON = "f";
	}
	
	interface CATEGORY_ID {
		String KEY = "category_id";
		String KEY_JSON = "g";
	}
	
	interface STATUS_ID {
		String KEY = "status_id";
		String KEY_JSON = "h";
	}
	
	interface ASSIGNED_TO_ID {
		String KEY = "assigned_to_id";
		String KEY_JSON = "i";
	}
	
	interface ASSIGNED_TO_FIRSTNAME {
		String KEY_JSON = "i1";
	}
	
	interface ASSIGNED_TO_LASTNAME {
		String KEY_JSON = "i2";
	}
	
	interface AUTHOR_FIRSTNAME {
		String KEY_JSON = "i3";
	}
	
	interface AUTHOR_LASTNAME {
		String KEY_JSON = "i4";
	}
	
	interface PRIORITY_ID {
		String KEY = "priority_id";
		String KEY_JSON = "j";
	}
	
	interface FIXED_VERSION_ID {
		String KEY = "fixed_version_id";
		String KEY_JSON = "k";
	}
	
	interface FIXED_VERSION_NAME {
		String KEY_JSON = "k1";
	}
	
	interface START_DATE {
		String KEY = "start_date";
		String KEY_JSON = "l";
	}
	
	interface DONE_RATIO {
		String KEY = "done_ratio";
		String KEY_JSON = "m";
	}
	
	interface ESTIMATED_HOURS {
		String KEY = "estimated_hours";
		String KEY_JSON = "n";
	}
	
	interface PARENT_ID {
		String KEY = "parent_id";
		String KEY_JSON = "o";
	}
	
	interface ROOT_ID {
		String KEY = "root_id";
		String KEY_JSON = "p";
	}
	
	interface LFT {
		String KEY = "lft";
		String KEY_JSON = "q";
	}
	
	interface RGT {
		String KEY = "rgt";
		String KEY_JSON = "r";
	}
	
	interface ROOT_SEQ {
		String KEY = "root_seq";
		String KEY_JSON = "s";
	}
	
	interface ORGANIZATION_CD {
		String KEY = "organization_cd";
		String KEY_JSON = "t";
	}
	
	interface LOCK_VERSION {
		String KEY = "lock_version";
		String KEY_JSON = "u";
	}
	
	interface TREE_ID {
		String KEY_JSON = "v";
	}
	
	interface FLOOR {
		String KEY_JSON = "w";
	}
	
	interface TRACKER {
		String KEY_JSON = "x";
	}
	
	interface AUTHOR_ID {
		String KEY = "author_id";
		String KEY_JSON = "a1";
	}
	
	interface CUSTOMVALUES {
		String KEY = "customvalues";
		String KEY_JSON = "c_";
		String KEY_MAP = "CustomField";
	}

}
