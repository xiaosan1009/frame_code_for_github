package co.jp.softbank.qqmx.info.bean;

import java.util.List;
import java.util.Map;

public class CmdRequestData {
	
	private String code;
	
	private String jsp;
	
	private String method;
	
	private String logout;
	
	private String success;
	
	private String check;
	
	private boolean ignoreRole;
	
	private boolean ignoreAccessLog;
	
	private Map<String, MessageRequestData> messageMap;
	
	private List<DbRequestData> dbList;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getJsp() {
		return jsp;
	}

	public void setJsp(String jsp) {
		this.jsp = jsp;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getLogout() {
		return logout;
	}

	public void setLogout(String logout) {
		this.logout = logout;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}

	public Map<String, MessageRequestData> getMessageMap() {
		return messageMap;
	}

	public void setMessageMap(Map<String, MessageRequestData> messageMap) {
		this.messageMap = messageMap;
	}

	public List<DbRequestData> getDbList() {
		return dbList;
	}

	public void setDbList(List<DbRequestData> dbList) {
		this.dbList = dbList;
	}

	public boolean isIgnoreRole() {
		return ignoreRole;
	}

	public void setIgnoreRole(boolean ignoreRole) {
		this.ignoreRole = ignoreRole;
	}

	public boolean isIgnoreAccessLog() {
		return ignoreAccessLog;
	}

	public void setIgnoreAccessLog(boolean ignoreAccessLog) {
		this.ignoreAccessLog = ignoreAccessLog;
	}

}
