package co.jp.softbank.qqmx.info.bean;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.util.StringUtils;

public class ProjectTicketInfoBean {
	
	private List<Map<String, Object>> datas;
	
	private List<Map<String, Object>> projectList;
	
	private Map<String, Integer> issueMapping = Maps.newHashMap();
	
	private String minStartDate;
	
	private String maxEndDate;

	public List<Map<String, Object>> getDatas() {
		return datas;
	}

	public void setDatas(List<Map<String, Object>> datas) {
		this.datas = datas;
		createIssueMapping();
	}

	public List<Map<String, Object>> getProjectList() {
		return projectList;
	}

	public void setProjectList(List<Map<String, Object>> projectList) {
		this.projectList = projectList;
	}

	public String getMinStartDate() {
		return minStartDate;
	}

	public void setMinStartDate(String minStartDate) {
		if (StringUtils.isEmpty(minStartDate)) {
			return;
		}
		if (StringUtils.isEmpty(this.minStartDate) || this.minStartDate.compareTo(minStartDate) > 0) {
			this.minStartDate = minStartDate;
		}
	}

	public String getMaxEndDate() {
		return maxEndDate;
	}

	public void setMaxEndDate(String maxEndDate) {
		if (StringUtils.isEmpty(maxEndDate)) {
			return;
		}
		if (StringUtils.isEmpty(this.maxEndDate) || this.maxEndDate.compareTo(maxEndDate) < 0) {
			this.maxEndDate = maxEndDate;
		}
	}

	public void createIssueMapping(ProjectTicketInfoBean bean) {
		issueMapping.clear();
		issueMapping.putAll(bean.getIssueMapping());
	}
	
	public Map<String, Integer> getIssueMapping() {
		return issueMapping;
	}

	public void setIssueMapping(Map<String, Integer> issueMapping) {
		this.issueMapping = issueMapping;
	}
	
	public boolean issueExist(String issueId) {
		return issueMapping.containsKey(issueId);
	}
	
	public Map<String, Object> getIssueData(String issueId) {
		return datas.get(issueMapping.get(issueId));
	}

	private void createIssueMapping() {
		issueMapping.clear();
		if (datas != null && datas.size() > 0) {
			for (int i = 0; i < datas.size(); i++) {
				Map<String, Object> data = datas.get(i);
				issueMapping.put(StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY_JSON)), i);
			}
		}
	}

}
