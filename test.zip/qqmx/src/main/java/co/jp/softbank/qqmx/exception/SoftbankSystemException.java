package co.jp.softbank.qqmx.exception;

public class SoftbankSystemException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String message = null;
	
	public SoftbankSystemException(Throwable cause) {
		super(cause);
		this.message = "";
	}
	
	public SoftbankSystemException(Throwable cause, String message) {
		super(cause);
		this.message = message;
	}
	
	@Override
    public String getMessage() {
        if (this.message == null) {
            return "";
        }
        return this.message;
    }

}
