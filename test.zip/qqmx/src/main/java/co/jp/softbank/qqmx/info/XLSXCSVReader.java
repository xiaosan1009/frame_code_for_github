package co.jp.softbank.qqmx.info;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.InvalidOperationException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.BuiltinFormats;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.slf4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import com.google.common.collect.Lists;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.CellInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.DiffAnalizy;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.RowInfoBean;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class XLSXCSVReader {

	protected Logger log = new LogUtil(this.getClass()).getLog();

	enum xssfDataType {
		BOOL, ERROR, FORMULA, INLINESTR, SSTINDEX, NUMBER,
	}

	private ReadOnlySharedStringsTable strings;

	private OPCPackage xlsxPackage;

	public XLSXCSVReader(String path) throws SoftbankException {
		try {
			this.xlsxPackage = OPCPackage.open(path, PackageAccess.READ);
			this.strings = new ReadOnlySharedStringsTable(this.xlsxPackage);
		} catch (InvalidOperationException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidOperationException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SAXException, e);
		}
	}

	public XLSXCSVReader(File file) throws SoftbankException {
		try {
			this.xlsxPackage = OPCPackage.open(file, PackageAccess.READ);
			this.strings = new ReadOnlySharedStringsTable(this.xlsxPackage);
		} catch (InvalidOperationException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidOperationException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SAXException, e);
		}
	}

	public XLSXCSVReader(InputStream is) throws SoftbankException {
		try {
			this.xlsxPackage = OPCPackage.open(is);
			this.strings = new ReadOnlySharedStringsTable(this.xlsxPackage);
		} catch (InvalidOperationException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidOperationException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SAXException, e);
		}
	}

	public List<String[]> processSheet(StylesTable styles, InputStream sheetInputStream, boolean referFirst)
			throws SoftbankException {

		try {
			InputSource sheetSource = new InputSource(sheetInputStream);
			SAXParserFactory saxFactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxFactory.newSAXParser();
			XMLReader sheetParser = saxParser.getXMLReader();
			MyXSSFSheetHandler handler = new MyXSSFSheetHandler(styles, referFirst);
			if (strings != null) {
				handler.setSharedStringsTable(strings);
			}
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
			return handler.getRows();
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SAXException, e);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.ParserConfigurationException, e);
		}
	}

	public ReadOnlySharedStringsTable getStrings() {
		return strings;
	}

	public List<String[]> process(String sheetName) throws SoftbankException {
		return process(sheetName, false);
	}

	public List<String[]> process(String sheetName, boolean referFirst) throws SoftbankException {

		try {
			XSSFReader xssfReader = new XSSFReader(this.xlsxPackage);
			StylesTable styles = null;
			try {
				styles = xssfReader.getStylesTable();
			} catch (Exception e) {
				log.warn(e.getMessage());
			}
			XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
			while (iter.hasNext()) {
				InputStream stream = iter.next();
				try {
					String sheetNameTemp = iter.getSheetName();
					if (sheetName.equals(sheetNameTemp)) {
						return processSheet(styles, stream, referFirst);
					}
				} finally {
					stream.close();
				}
			}
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (OpenXML4JException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.OpenXML4JException, e);
		}
	}

	public ExcelInfoBean getSheetInfos() throws SoftbankException {
		try {
			ExcelInfoBean infoBean = new ExcelInfoBean();
			XSSFReader xssfReader;
			xssfReader = new XSSFReader(this.xlsxPackage);
			XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
			int index = 0;
			while (iter.hasNext()) {
				InputStream stream = iter.next();
				try {
					String sheetNameTemp = iter.getSheetName();
					infoBean.addSheetName((index++) + ConstantsUtil.Str.COLON + sheetNameTemp);
				} finally {
					stream.close();
				}
			}
			return infoBean;
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (OpenXML4JException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.OpenXML4JException, e);
		} finally {
			close();
		}
	}

	public ExcelInfoBean getSheetFirstRowInfos(String sheetName, DiffAnalizy diff) throws SoftbankException {
		try {
			ExcelInfoBean infoBean = new ExcelInfoBean();
			List<String[]> datas = process(sheetName);
			if (datas == null && datas.size() == 0) {
				return infoBean;
			}
			String[] row = datas.get(0);
			if (row == null) {
				return infoBean;
			}
			for (int i = 0; i < row.length; i++) {
				String cell = row[i];
				if (StringUtils.isNotEmpty(cell)) {
					infoBean.addFirstRowCellName(cell, i, diff);
				}
			}
			return infoBean;
		} finally {
			close();
		}
	}

	public ExcelInfoBean getAllCellInfos(String sheetName, boolean referFirst) throws SoftbankException {
		ExcelInfoBean infoBean = new ExcelInfoBean();
		List<String[]> datas = process(sheetName, referFirst);
		if (datas == null) {
			return infoBean;
		}
		int cellNumber = 0;
		for (int i = 0; i < datas.size(); i++) {
			String[] row = datas.get(i);
			if (row != null) {
				RowInfoBean rowInfo = new RowInfoBean(i);
				infoBean.addRow(rowInfo);
				if (referFirst) {
					if (i == 0) {
						cellNumber = row.length;
					}
				} else {
					cellNumber = row.length;
				}
				for (int j = 0; j < cellNumber; j++) {
					CellInfoBean cellInfo = new CellInfoBean(j);
					String cell = row[j];
					rowInfo.addCell(cellInfo);
					if (StringUtils.isNotEmpty(cell)) {
						cellInfo.setContent(cell);
					}
				}
			}
		}
		return infoBean;
	}

	public void close() throws SoftbankException {
		try {
			xlsxPackage.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
	}

	class MyXSSFSheetHandler extends DefaultHandler {

		/**
		 * Table with styles
		 */
		private StylesTable stylesTable;

		/**
		 * Table with unique strings
		 */
		private ReadOnlySharedStringsTable sharedStringsTable;

		// Set when V start element is seen
		private boolean vIsOpen;

		// Set when cell start element is seen;
		// used when cell close element is seen.
		private xssfDataType nextDataType;

		// Used to format numeric cell values.
		private short formatIndex;
		private String formatString;
		private final DataFormatter formatter;

		private int currentColumn = -1;
		private boolean referFirst;

		// Gathers characters as they are seen.
		private StringBuffer value;
		private String[] record;
		private List<String> recordList;
		private List<String[]> rows = Lists.newArrayList();
		private boolean isFinished = false;

		public MyXSSFSheetHandler(StylesTable styles) {
			this(styles, false);
		}

		public MyXSSFSheetHandler(StylesTable styles, boolean referFirst) {
			this.referFirst = referFirst;
			this.stylesTable = styles;
			this.value = new StringBuffer();
			this.nextDataType = xssfDataType.NUMBER;
			this.formatter = new DataFormatter();
			recordList = Lists.newArrayList();
			rows.clear();
		}

		public ReadOnlySharedStringsTable getSharedStringsTable() {
			return sharedStringsTable;
		}

		public void setSharedStringsTable(ReadOnlySharedStringsTable sharedStringsTable) {
			this.sharedStringsTable = sharedStringsTable;
		}

		public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
			if (isFinished) {
				return;
			}
			if ("inlineStr".equals(name) || "v".equals(name)) {
				vIsOpen = true;
				value.setLength(0);
			} else if ("c".equals(name)) {
				String r = attributes.getValue("r");
				int firstDigit = -1;
				for (int c = 0; c < r.length(); ++c) {
					if (Character.isDigit(r.charAt(c))) {
						firstDigit = c;
						break;
					}
				}
				currentColumn = nameToColumn(r.substring(0, firstDigit));

				this.nextDataType = xssfDataType.NUMBER;
				this.formatIndex = -1;
				this.formatString = null;
				String cellType = attributes.getValue("t");
				String cellStyleStr = attributes.getValue("s");
				if ("b".equals(cellType)) {
					nextDataType = xssfDataType.BOOL;
				} else if ("e".equals(cellType)) {
					nextDataType = xssfDataType.ERROR;
				} else if ("inlineStr".equals(cellType)) {
					nextDataType = xssfDataType.INLINESTR;
				} else if ("s".equals(cellType)) {
					nextDataType = xssfDataType.SSTINDEX;
				} else if ("str".equals(cellType)) {
					nextDataType = xssfDataType.FORMULA;
				} else if (cellStyleStr != null && stylesTable != null) {
					int styleIndex = Integer.parseInt(cellStyleStr);
					XSSFCellStyle style = stylesTable.getStyleAt(styleIndex);
					this.formatIndex = style.getDataFormat();
					this.formatString = style.getDataFormatString();
					if (this.formatString == null) {
						this.formatString = BuiltinFormats.getBuiltinFormat(this.formatIndex);
					}
				}
			}

		}

		public void endElement(String uri, String localName, String name) throws SAXException {

			if (isFinished) {
				return;
			}
			String data = null;

			if ("v".equals(name)) {
				switch (nextDataType) {

				case BOOL:
					char first = value.charAt(0);
					data = first == '0' ? "FALSE" : "TRUE";
					break;

				case ERROR:
					data = "\"ERROR:" + value.toString() + '"';
					break;

				case FORMULA:
					data = '"' + value.toString() + '"';
					break;

				case INLINESTR:
					XSSFRichTextString rtsi = new XSSFRichTextString(value.toString());
					data = '"' + rtsi.toString() + '"';
					break;

				case SSTINDEX:
					String sstIndex = value.toString();
					try {
						int idx = Integer.parseInt(sstIndex);
						XSSFRichTextString rtss = new XSSFRichTextString(sharedStringsTable.getEntryAt(idx));
						data = '"' + rtss.toString() + '"';
					} catch (NumberFormatException ex) {
						log.error(ex.getMessage(), ex);
					}
					break;

				case NUMBER:
					String n = value.toString();
					if (HSSFDateUtil.isADateFormat(this.formatIndex, n)) {
						Double d = Double.parseDouble(n);
						Date date = HSSFDateUtil.getJavaDate(d);
						data = formateDateToString(date);
					} else if (this.formatString != null)
						data = formatter.formatRawCellContents(Double.parseDouble(n), this.formatIndex,
								this.formatString);
					else
						data = n;
					break;

				default:
					data = "(TODO: Unexpected type: " + nextDataType + ")";
					break;
				}

				setData(data);

			} else if ("row".equals(name)) {
				if (currentColumn > 0) {
					addRow();
					if (!referFirst) {
						isFinished = true;
					}
				}
			}

		}

		private void setData(String data) {
			if (record != null) {
				record[currentColumn] = data;
			} else {
				recordList.add(data);
			}
		}

		private void addRow() {
			if (!checkRecordEmpty()) {
				rows.add(record);
				record = new String[recordList.size()];
			} else if (recordList.size() > 0 && rows.size() == 0) {
				rows.add(recordList.toArray(new String[0]));
				record = new String[recordList.size()];
			} else {
				isFinished = true;
			}
		}
		
		private boolean checkRecordEmpty() {
			if (record == null || record.length == 0) {
				return true;
			}
			for (int i = 0; i < record.length; i++) {
				if (StringUtils.isNotEmpty(record[i])) {
					return false;
				}
			}
			return true;
		}

		public List<String[]> getRows() {
			return rows;
		}

		public void setRows(List<String[]> rows) {
			this.rows = rows;
		}

		public void characters(char[] ch, int start, int length) throws SAXException {
			if (vIsOpen) {
				value.append(ch, start, length);
			}
		}

		private int nameToColumn(String name) {
			int column = -1;
			for (int i = 0; i < name.length(); ++i) {
				int c = name.charAt(i);
				column = (column + 1) * 26 + c - 'A';
			}
			return column;
		}

		private String formateDateToString(Date date) {
			SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.FORMAT_YYYYMMDD_DASH);
			return sdf.format(date);

		}

	}

	public static void main(String[] args) throws Exception {
//		String path = "C:\\Users\\dev6828503yu\\Documents\\workspace\\temp\\upload\\ipf_xls_importer_jedi-ffph1-shop_kihatar94.xlsx";
//		 String path = "C:\\Users\\dev6828503yu\\Documents\\workspace\\temp\\upload\\0621\\export00002017062117325811.xlsx";
		String path = "C:\\Users\\dev6828503yu\\Documents\\workspace\\temp\\upload\\0621\\Jedi品質管理_issues_export.xlsx";
//		String sheetName = "Sheet1";
		 String sheetName = "チケット";
//		XLSXCovertCSVReader xlsx2csv = new XLSXCovertCSVReader(path);
//		ExcelInfoBean bean = xlsx2csv.getSheetFirstRowInfos(sheetName, null);
//		List<String[]> rowInfoBeans = bean.getFirstRowCellNames();
//		for (int i = 0; i < rowInfoBeans.size(); i++) {
//			System.out.print(rowInfoBeans.get(i)[0] + ":" + rowInfoBeans.get(i)[1]);
//		}
		XLSXCSVReader xlsx2csv = new XLSXCSVReader(path);
		ExcelInfoBean bean = xlsx2csv.getAllCellInfos(sheetName, true);
		List<RowInfoBean> rowInfoBeans = bean.getRows();
		for (int i = 0; i < rowInfoBeans.size(); i++) {
			RowInfoBean rowInfoBean = rowInfoBeans.get(i);
			List<CellInfoBean> cells = rowInfoBean.getCells();
			for (int j = 0; j < cells.size(); j++) {
				CellInfoBean cell = cells.get(j);
				System.out.print(cell.getContent() + ",");
			}
			System.out.println();
		}
	}

}