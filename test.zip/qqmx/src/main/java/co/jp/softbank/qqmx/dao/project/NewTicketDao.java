package co.jp.softbank.qqmx.dao.project;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.project.settings.bean.CustomFieldsBean;

public interface NewTicketDao extends IDaoInterface {
	
	List<Map<String, Object>> getTrackers(Map<String, Object> conditions);
	
	List<Map<String, Object>> getIssueStatuses(Map<String, Object> conditions);
	
	List<Map<String, Object>> getIssuePrioritys();
	
	List<Map<String, Object>> getMembers(Map<String, Object> conditions);
	
	List<Map<String, Object>> getVersions(Map<String, Object> conditions);

	List<CustomFieldsBean> getIssueCustomFields(Map<String, Object> conditions);

	List<Map<String, Object>> getPhases();
	
	List<Map<String, Object>> getTestPhases();

	List<Map<String, Object>> searchTcketForParent(Map<String, Object> conditions);
	
	List<Map<String, Object>> searchExistTcketForParent(Map<String, Object> conditions);

	void insertIssueInfo(Map<String, Object> conditions);
	
	Integer getMaxRootSeq(Map<String, Object> conditions);
	
	void updateIssuesByIdAfterInsert(Map<String, Object> conditions);
	
	void insertIssueCustomValues(Map<String, Object> conditions);

	void insertWatchers(Map<String, Object> conditions);
}
