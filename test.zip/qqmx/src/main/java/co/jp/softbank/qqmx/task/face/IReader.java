package co.jp.softbank.qqmx.task.face;

import java.io.Closeable;

import co.jp.softbank.qqmx.exception.SoftbankException;

public interface IReader<V> extends Closeable {

	boolean hasNext();
	
	IKey getKey();
	
	V getValue();
	
	int size();
	
	void prepare(ITaskContext context) throws SoftbankException;
	
	void cleanup(ITaskContext context) throws SoftbankException;
}
