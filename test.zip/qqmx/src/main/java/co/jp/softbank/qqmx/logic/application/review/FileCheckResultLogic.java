package co.jp.softbank.qqmx.logic.application.review;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class FileCheckResultLogic extends AbstractBaseLogic {

	public void getFileCheckResults() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		conditions.put("issue_id", 691002);
		List<Map<String, Object>> fileCheckResultsList = db.querys("fileCheckResults.getFileCheckResults",conditions);
//		for (int i = 0; i < fileCheckResultsList.size() - 1; i ++ ) {
//			Map<String, Object> item = fileCheckResultsList.get(i);
//			if  ("xlsx".equals(item.get("type"))) {
//				String errorPath = "Excelファイルの " + item.get("sheet") + " シート、" + item.get("row") + "行 " + item.get("col") + "列 ";
//				item.put("errorPath", errorPath);
//				
//			}
//		}
		
		
		
		context.getResultBean().setData(fileCheckResultsList);
	}

}
