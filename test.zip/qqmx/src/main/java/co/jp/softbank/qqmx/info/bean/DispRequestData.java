package co.jp.softbank.qqmx.info.bean;

import java.util.List;
import java.util.Map;

public class DispRequestData {
	
	private String code;
	
	private String jsp;
	
	private String logic;
	
	private String logout;
	
	private boolean eaction;
	
	private Map<String, CmdRequestData> cmdMap;
	
	private List<FilterRequestData> filterList;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getJsp() {
		return jsp;
	}

	public void setJsp(String jsp) {
		this.jsp = jsp;
	}

	public String getLogic() {
		return logic;
	}

	public void setLogic(String logic) {
		this.logic = logic;
	}

	public Map<String, CmdRequestData> getCmdMap() {
		return cmdMap;
	}

	public void setCmdMap(Map<String, CmdRequestData> cmdMap) {
		this.cmdMap = cmdMap;
	}

	public String getLogout() {
		return logout;
	}

	public void setLogout(String logout) {
		this.logout = logout;
	}

	public boolean isEaction() {
		return eaction;
	}

	public void setEaction(boolean eaction) {
		this.eaction = eaction;
	}
	
	public List<FilterRequestData> getFilterList() {
		return filterList;
	}

	public void setFilterList(List<FilterRequestData> filterList) {
		this.filterList = filterList;
	}
	
}
