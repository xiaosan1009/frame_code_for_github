package co.jp.softbank.qqmx.dao.common;

import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;

import co.jp.softbank.qqmx.util.LogUtil;

public class DaoCommon {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	protected SqlSessionFactory sqlSessionFactory;
	
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		this.sqlSessionFactory = sqlSessionFactory;
	}
	
	protected String getSqlConditions(Object conditions) {
		if (!(conditions instanceof Map)) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		Map map = (Map)conditions;
		for (Object key : map.keySet()) {
			sb.append(key);
			sb.append(" : ");
			sb.append(map.get(key));
			sb.append("; ");
		}
		sb.append("]");
		return sb.toString();
	}

}
