package co.jp.softbank.qqmx.logic.application.project;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.RoleListDao;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ForumBoardsLogic extends AbstractBaseLogic {

	public void getBoardsList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		List<Map<String, Object>> attachments = db.querys("forumBoardsList.getBoardsList", conditions);
		
		String[][] forumArr = new String[attachments.size()][9];
		
		for (int i = 0; i < attachments.size(); i++) {
			Map<String, Object> dataMap = attachments.get(i);
			
			String name = StringUtils.toString(dataMap.get("name"));
			String description = StringUtils.toString(dataMap.get("description"));
			forumArr[i][0] = name;
			forumArr[i][5] = description;
			
			String topic = "0";
			String message = "0";
			if (StringUtils.isNotEmpty(dataMap.get("topic"))) {
				topic=StringUtils.toString(dataMap.get("topic"));
			}
			if (StringUtils.isNotEmpty(dataMap.get("message"))) {
				message=StringUtils.toString(dataMap.get("message"));
			}
			forumArr[i][1] = topic;
			forumArr[i][2] = message;
			
			// mes_user_nm
			if (StringUtils.isNotEmpty(dataMap.get("updater")) && StringUtils.isNotEmpty(dataMap.get("created_on"))) {
				
				forumArr[i][3] = StringUtils.toString(dataMap.get("updater")) + " が "
						+ StringUtils.toString(dataMap.get("created_on")) + " に追加";
			}
			
			forumArr[i][6] = StringUtils.toString(dataMap.get("subject"));
			
			forumArr[i][4] = StringUtils.toString(dataMap.get("id"));
			forumArr[i][7] = StringUtils.toString(dataMap.get("parent_id"));
			forumArr[i][8] = StringUtils.toString(dataMap.get("position"));
			
		}
		
		context.getResultBean().setData(forumArr);
	}
	
	public void selectBoardsCount() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(db.querys("forumBoardsList.selectBoardsCount", conditions));
	}
	
	public void delBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int boardsId = StringUtils.toInt(context.getParam().get("boardsId"));
		conditions.put("boardsId", boardsId);
		context.getResultBean().setData(db.querys("boards.deleteBoardsById", conditions));
		
		int position = StringUtils.toInt(context.getParam().get("position"));
		conditions.put("position", position);
		context.getResultBean().setData(db.querys("forumBoardsList.updatePosition", conditions));
		
	}
	
}
