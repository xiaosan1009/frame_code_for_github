package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.yaml.snakeyaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.project.settings.NewProjectDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class NewProjectLogic extends AbstractBaseLogic {
	
	@Autowired
	private NewProjectDao newProjectDao;
	
	@SuppressWarnings("unchecked")
	public LogicBean getProjectInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, String> settingsMap = Maps.newHashMap();
		String project_id = context.getParam().get("projectId");
		resultMap.put("customFields", newProjectDao.getCustomFieldsBeans());
		if ("".equals(project_id)){
			
			List<Map<String, Object>> settingsList = newProjectDao.getSettings();
			Map<String, Object> settingsData = settingsList.get(0);
			String settingsValue = StringUtils.toString(settingsData.get("value"));
			Yaml yaml = new Yaml();
			List<String> settingsList2 = (List<String>)yaml.load(settingsValue);
			for (int i = 0; i < settingsList2.size(); i++) {
				settingsMap.put(settingsList2.get(i), settingsList2.get(i));
			}
			resultMap.put("trackers", newProjectDao.getTrackers());
			resultMap.put("issuesCustomFields", newProjectDao.getIssuesCustomFields());
		}else{
			Map<String, Object> conditions = Maps.newHashMap();
			Map<String, String> enabledModulesMap = Maps.newHashMap();
			conditions.put("project_id", Integer.parseInt(project_id));
			List<Map<String, String>> enabledModulesList = newProjectDao.getEnabledModules(conditions);
			for (int e = 0; e < enabledModulesList.size(); e++) {
				enabledModulesMap = enabledModulesList.get(e);
				settingsMap.put(enabledModulesMap.get("name"), enabledModulesMap.get("name"));
			}
			resultMap.put("trackers", newProjectDao.getProjectTrackers(conditions));
			resultMap.put("issuesCustomFields", newProjectDao.getProjectIssuesCustomFields(conditions));
		}
		
		resultMap.put("settings", settingsMap);
		resultMap.put("plugins", ControlDbMemory.getInstance().getPluginInfoBeans());
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean saveProjectInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		Integer parentId = null;
		if (StringUtils.isNotEmpty(context.getParam().get("project_parent_id"))) {
			parentId = Integer.parseInt(context.getParam().get("project_parent_id"));
		}
		conditions.put("project_name", context.getParam().get("project_name"));
		conditions.put("project_parent_id", parentId);
		conditions.put("project_description", context.getParam().get("project_description"));
		conditions.put("project_identifier", context.getParam().get("project_identifier"));
		conditions.put("project_is_public", ("1".equals(context.getParam().get("project_is_public")) ? true : false));
		conditions.put("project_homepage", context.getParam().get("project_homepage"));
		conditions.put("project_landingpage", ConstantsUtil.Str.EMPTY);
		newProjectDao.insertProjectInfo(conditions);
		
		final int projectId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		log.info("projectId = " + projectId);
		String[] enabledModulesInfos = context.getParam().getList("project_enabled_module_names");
		if (enabledModulesInfos != null) {
			List<Map<String, Object>> enabledModulesInfoList = Lists.newArrayList();
			for (int i = 0; i < enabledModulesInfos.length; i++) {
				Map<String, Object> enabledModulesInfo = Maps.newHashMap();
				enabledModulesInfo.put("name", enabledModulesInfos[i]);
				enabledModulesInfo.put("project_id", projectId);
				enabledModulesInfoList.add(enabledModulesInfo);
			}
			conditions = Maps.newHashMap();
			conditions.put("enabledModulesInfos", enabledModulesInfoList);
			newProjectDao.insertEnabledModulesInfos(conditions);
		}
		
		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("start_page", "Wiki");
		newProjectDao.insertWikisInfos(conditions);
		
		String[] projectsTrackers = context.getParam().getList("project_tracker_ids");
		if (projectsTrackers != null) {
			List<Map<String, Object>> projectsTrackerList = Lists.newArrayList();
			for (int i = 0; i < projectsTrackers.length; i++) {
				Map<String, Object> projectsTrackerInfo = Maps.newHashMap();
				projectsTrackerInfo.put("project_id", projectId);
				projectsTrackerInfo.put("tracker_id", Integer.parseInt(projectsTrackers[i]));
				projectsTrackerList.add(projectsTrackerInfo);
			}
			conditions = Maps.newHashMap();
			conditions.put("projectsTrackers", projectsTrackerList);
			newProjectDao.insertProjectsTrackersInfos(conditions);
		}
		
		String[] customFields = context.getParam().getList("project_issue_custom_field_ids");
		if (customFields != null) {
			List<Map<String, Object>> customFieldList = Lists.newArrayList();
			for (int i = 0; i < customFields.length; i++) {
				Map<String, Object> customFieldInfo = Maps.newHashMap();
				customFieldInfo.put("project_id", projectId);
				customFieldInfo.put("custom_field_id", Integer.parseInt(customFields[i]));
				customFieldList.add(customFieldInfo);
			}
			conditions = Maps.newHashMap();
			conditions.put("customFields", customFieldList);
			newProjectDao.insertProjectsCustomFields(conditions);
		}
		
		final List<Map<String, Object>> customValuesList = Lists.newArrayList();
		context.getParam().each(new Param.EachFilter() {
			
			@Override
			public void filter(String key, String value) {
				if (key.startsWith("project_custom_field_values_")) {
					Map<String, Object> customValueInfo = Maps.newHashMap();
					customValueInfo.put("customized_id", projectId);
					customValueInfo.put("custom_field_id", Integer.parseInt(key.substring("project_custom_field_values_".length())));
					customValueInfo.put("value", value);
					customValuesList.add(customValueInfo);
				}
			}
		});
		
		if (customValuesList != null && customValuesList.size() > 0) {
			conditions = Maps.newHashMap();
			conditions.put("customValues", customValuesList);
			newProjectDao.insertProjectsCustomValues(conditions);
		}
		return logicBean;
	}
	
	@Override
	protected IDaoInterface getDao() {
		return newProjectDao;
	}

}
