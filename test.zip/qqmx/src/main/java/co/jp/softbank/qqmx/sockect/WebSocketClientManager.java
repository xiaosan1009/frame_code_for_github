
package co.jp.softbank.qqmx.sockect;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.Session;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.sockect.bean.WebSocketClientInfo;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class WebSocketClientManager {
	
	private static final Logger log = LoggerFactory.getLogger(WebSocketClientManager.class);

    private static WebSocketClientManager me;

    private ConcurrentHashMap<Integer, WebSocketClientInfo> socketClientSessions = new ConcurrentHashMap<Integer, WebSocketClientInfo>();

    private ConcurrentHashMap<String, Integer> socketClientMapping = new ConcurrentHashMap<String, Integer>();
    
    private ConcurrentHashMap<Integer, List<JSONObject>> ganttUserInfoMap = new ConcurrentHashMap<Integer, List<JSONObject>>();
    
    private ConcurrentHashMap<Integer, Map<Integer, List<JSONObject>>> ganttOperatorInfoMap = new ConcurrentHashMap<Integer, Map<Integer, List<JSONObject>>>();
    
    private ConcurrentHashMap<Integer, Map<Integer, JSONObject>> ganttMoveInfoMap = new ConcurrentHashMap<Integer, Map<Integer, JSONObject>>();

    public interface ExecuteLisener {
        void execute(WebSocketClientInfo clientInfo) throws SoftbankException;
    }

    public static WebSocketClientManager getInstance() {
        synchronized (WebSocketClientManager.class) {
            if (me == null) {
                me = new WebSocketClientManager();
            }
        }
        
        return me;
    }

    public WebSocketClientInfo addSession(WebSocketSession session) {
        WebSocketClientInfo clientInfo = new WebSocketClientInfo(session);
        socketClientSessions.put(clientInfo.getUserId(), clientInfo);
        socketClientMapping.put(session.getId(), clientInfo.getUserId());
        return clientInfo;
    }

    public ConcurrentHashMap<Integer, WebSocketClientInfo> getSessions() {
        return socketClientSessions;
    }

    public void sendAll(String message) throws SoftbankException {
    	log.info("message = {}", message);
        for (int key : socketClientSessions.keySet()) {
        	if (socketClientSessions.get(key).getSession() != null
        			&& socketClientSessions.get(key).getSession().isOpen()) {
        		send(socketClientSessions.get(key).getSession(), message);
        	} else {
        		socketClientSessions.remove(key);
        	}
        }
    }
    
    public void sendAll(final String message, int userId) throws SoftbankException {
    	log.info("message = {}, userId = {}", message, userId);
    	WebSocketClientInfo srcClient = socketClientSessions.get(userId);
    	execute(srcClient, new ExecuteLisener() {
			
			@Override
			public void execute(WebSocketClientInfo clientInfo) throws SoftbankException {
				send(clientInfo.getSession(), message);
			}
		});
    }
    
    public void addGanttUserInfoMap(JSONObject message) {
    	int project_id = message.getInt("project_id");
    	List<JSONObject> userInfoList = null;
    	if (ganttUserInfoMap.containsKey(project_id)) {
    		userInfoList = ganttUserInfoMap.get(project_id);
		} else {
			userInfoList = Lists.newArrayList();
			ganttUserInfoMap.put(project_id, userInfoList);
		}
    	for (int i = 0; i < userInfoList.size(); i++) {
    		JSONObject user = userInfoList.get(i).getJSONObject("user");
    		if (message.getJSONObject("user").getInt("id") == user.getInt("id")) {
    			return;
    		}
		}
    	userInfoList.add(message);
    }
    
    public void addGanttMoveInfoMap(JSONObject message) {
    	int project_id = message.getInt("project_id");
    	Map<Integer, JSONObject> userInfoMap = null;
    	if (ganttMoveInfoMap.containsKey(project_id)) {
    		userInfoMap = ganttMoveInfoMap.get(project_id);
    	} else {
    		userInfoMap = Maps.newHashMap();
    		ganttMoveInfoMap.put(project_id, userInfoMap);
    	}
    	int userId = message.getInt("user_id");
    	userInfoMap.put(userId, message);
    }
    
    public JSONArray getGanttUserInfos() {
    	JSONArray userinfoArr = new JSONArray();
    	for (int project_id : ganttUserInfoMap.keySet()) {
    		List<JSONObject> userInfoList = ganttUserInfoMap.get(project_id);
    		for (int i = 0; i < userInfoList.size(); i++) {
    			userinfoArr.add(userInfoList.get(i));
			}
		}
    	return userinfoArr;
    }
    
    public void removeGanttUserAllInfoMap(UserInfoData userInfoData) {
    	for (int project_id : ganttUserInfoMap.keySet()) {
    		List<JSONObject> userInfoList = ganttUserInfoMap.get(project_id);
    		for (int i = 0; i < userInfoList.size(); i++) {
    			JSONObject user = userInfoList.get(i).getJSONObject("user");
    			if (user.getInt("id") == userInfoData.getId()) {
    				userInfoList.remove(i);
    				break;
				}
			}
		}
    }
    
    public void removeGanttMoveInfoMap(UserInfoData userInfoData) {
    	for (int project_id : ganttMoveInfoMap.keySet()) {
    		Map<Integer, JSONObject> userInfoMap = ganttMoveInfoMap.get(project_id);
    		int userId = userInfoData.getId();
    		if (userInfoMap.containsKey(userId)) {
    			userInfoMap.remove(userId);
			}
    	}
    }
    
    public void send(WebSocketSession srcSession, String message) throws SoftbankException {
    	try {
			srcSession.sendMessage(new TextMessage(message));
		} catch (IOException e) {
			log.error(e.getMessage(), e);
            throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
    }

    public JSONArray getAllUserInfo() {
        JSONArray jsonArray = new JSONArray();
        for (int key : socketClientSessions.keySet()) {
            if (!checkSessionActive(key)) {
                continue;
            }
            jsonArray.add(socketClientSessions.get(key).toJsonObj());
        }
        return jsonArray;
    }

    public void execute(ExecuteLisener lisener) throws SoftbankException {
        execute(null, lisener, true);
    }

    public void execute(WebSocketClientInfo srcClient, ExecuteLisener lisener) throws SoftbankException {
        execute(srcClient, lisener, false);
    }

    public void execute(WebSocketClientInfo srcClient, ExecuteLisener lisener, boolean inCludeMe) throws SoftbankException {
        for (int key : socketClientSessions.keySet()) {
            if (!checkSessionActive(key)) {
                continue;
            }
            if (!inCludeMe && srcClient.getUserId() == key) {
                continue;
            }
            WebSocketClientInfo clientInfo = socketClientSessions.get(key);
            if (clientInfo.getSession() != null
    				&& clientInfo.getSession().isOpen()) {
            	lisener.execute(clientInfo);
			} else {
				socketClientSessions.remove(key);
			}
        }
    }

    public void remove(Session srcSession) {
        socketClientSessions.remove(socketClientMapping.get(srcSession.getId()));
    }

    private boolean checkSessionActive(int key) {
        if (socketClientSessions.get(key).getSession() == null
                || !socketClientSessions.get(key).getSession().isOpen()) {
            socketClientSessions.remove(key);
            return false;
        }
        return true;
    }

}
