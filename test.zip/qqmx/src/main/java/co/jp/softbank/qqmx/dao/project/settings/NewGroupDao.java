package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface NewGroupDao extends IDaoInterface {
	List<Map<String, Object>> getGroupProjectList(Map<String, Object> conditions);
	List<Map<String, Object>> getGroupName(Map<String, Object> conditions);
	List<Map<String, Object>> getGroupUserList(Map<String, Object> conditions);
	List<Map<String, Object>> selectProjectGroupMembers(Map<String, Object> conditions);
	List<Map<String, Object>> selectProjectGroupMemberId(Map<String, Object> conditions);
	void insertProjectSettingMembers(Map<String, Object> conditions);
	void saveGroupNewUser(Map<String, Object> conditions);
	List<Map<String, Object>> selectProjectSettingMembers(Map<String, Object> conditions);
	List<Map<String, Integer>> selectProjectSettingGroupMemberUsers(Map<String, Integer> conditions);
	List<Map<String, Object>> selectProjectSettingMemberUsers(Map<String, Object> conditions);
	List<Map<String, Object>> selectProjectMemberRoles(Map<String, Object> conditions);
	void deleteProjectSettingMemberUsers(Map<String, Object> conditions);
	void deleteProjectSettingUser(Map<String, Object> conditions);
	void deleteGroupListUsers(Map<String, Object> conditions);
	void updateGroupName(Map<String, Object> conditions);
	List<Map<String, Integer>> selectProjectSettingGroupUsers(Map<String, Integer> conditions);
	List<Map<String, Object>> getProjectSettingRoleList(Map<String, Object> conditions);
	List<Map<String, Object>> selectUserList(Map<String, Object> conditions);
	List<Map<String, Object>> getProjectList(Map<String, Object> conditions);
	List<Map<String, Object>> selectProjectMember(Map<String, Object> conditions);
	List<Map<String, Object>> selectMember(Map<String, Object> conditions);
	void insertProjectSettingUser(Map<String, Object> conditions);
	
}
