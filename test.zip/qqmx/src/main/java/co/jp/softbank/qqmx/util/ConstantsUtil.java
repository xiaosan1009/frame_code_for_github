package co.jp.softbank.qqmx.util;

import java.io.File;

public interface ConstantsUtil {
	
	interface Param {
		String DISP = "dispCode";
		
		String CMD = "cmdCode";
		
		String TYPE = "clientType";
		
		String PRO_ID = "proId";
		
		String PAGE_ROW_NUMBER = "page_row_number";
		
		String CURRENT_PAGE = "current_page";
		
		String PAGE_ORDERS = "page_orders";
		
		interface Test {
			String ENGINE = "k_e";
			String DO_ENGINE_TEST_VAL = "1";
		}
	}
	
	interface Jsp {
		
		String DEFAULT_JSP_PATH = "/WEB-INF/jsp";
		
		String JSON_JSP_PATH = "/common/json.jsp";
		
		String LOGIN_JSP_PATH = "/login.jsp";
		
		String ERROR_JSP_PATH = "/error.jsp";
		
	}
	
	interface Frame {
		
		String ENCODING = "UTF-8";
		
		String UPLOAD_PATH = "upload" + File.separator;
		
		String EXPORT_PATH = "export" + File.separator;
		
	}
	
	interface Suffix {
		
		String PROPERTY = "properties";
		
	}
	
	interface Lang {
		
		String JAPAN = "ja";
		
		String ENGLISH = "en";
		
	}
	
	interface Log {
        
        /**
         * 框架日志标识.
         */
        String FRAME_SIGN = "[Frame]:";
        
        String LEFT_SIGN = "[";
        
        String RIGHT_SIGN = "] ";
        
        String FRAME_LEFT_SIGN = "[";
        
        String FRAME_RIGHT_SIGN = "] ";
        
        String START_SIGN = "▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼";
        
        String END_SIGN = "▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲";
    }
	
	interface Str {
		
		String EMPTY = "";
		
		String UNDERLINE = "_";
		
		String REGEX_DOT = "\\.";
		
		String DOT = ".";
		
		String SPACE = " ";
		
		String COMMA = ",";
		
		String COLON = ":";
		
		String TRUE = "true";
		
		String FALSE = "false";
		
	}

}
