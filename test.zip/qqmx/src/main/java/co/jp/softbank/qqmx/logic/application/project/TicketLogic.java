package co.jp.softbank.qqmx.logic.application.project;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.NewTicketDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.bean.InputErrorBean;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class TicketLogic extends TicketBaseLogic {
	
	@Autowired
	private NewTicketDao newTicketDao;
	
	public LogicBean getTicketInfo() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", Integer.parseInt(context.getParam().get("issue_id")));
		
		Map<String, Object> issue = db.query("issues.selectIssueById", conditions);
		resultMap.put("issue", issue);

		List<Map<String, Object>> issue_childrens = db.querys("issues.selectIssueChildrensById", conditions);
		resultMap.put("issue_childrens", issue_childrens);

		List<Map<String, Object>> issue_journals = db.querys("issues.selectIssueJournalsById", conditions);
		resultMap.put("issue_journals", issue_journals);

		conditions.put("issue_id", issue.get("id"));
		conditions.put("project_id", issue.get("project_id"));
		conditions.put("tracker_id", issue.get("tracker_id"));
		resultMap.put("issueCustomFields", db.querys("issues.selectIssueCustomFieldsAndValues", conditions));

		conditions = Maps.newHashMap();
		conditions.put("project_id", issue.get("project_id"));
		List<Map<String, Object>> trackers = db.querys("issues.getTrackers", conditions);
		resultMap.put("trackers", trackers);

		Object tracker_id = null;
		if (StringUtils.isNotEmpty(context.getParam().get("issue_tracker_id")) ) {
			tracker_id = Integer.parseInt(context.getParam().get("issue_tracker_id"));
		} else {
			tracker_id = trackers.get(0).get("id");
		}
		
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions = Maps.newHashMap();
		conditions.put("project_id", issue.get("project_id"));
		conditions.put("user_id", loginUserId);
		conditions.put("tracker_id", tracker_id);
		List<Map<String, Object>> issueStatuses = db.querys("issues.getIssueStatuses", conditions);
		resultMap.put("issueStatuses", issueStatuses);

		List<Map<String, Object>> issuePrioritys = db.querys("issues.getIssuePrioritys", conditions);
		resultMap.put("issuePrioritys", issuePrioritys);

		List<Map<String, Object>> phases = db.querys("issues.getPhases", conditions);
		resultMap.put("phases", phases);
		List<Map<String, Object>> testPhases = db.querys("issues.getTestPhases", conditions);
		resultMap.put("testPhases", testPhases);

		conditions = Maps.newHashMap();
		conditions.put("project_id", issue.get("project_id"));
		List<Map<String, Object>> members = db.querys("issues.getMembers", conditions);
		resultMap.put("members", members);

		conditions = Maps.newHashMap();
		conditions.put("issue_id", issue.get("id"));
		List<Map<String, Object>> issueWatchers = db.querys("issues.getIssueWatchers", conditions);
		resultMap.put("issueWatchers", issueWatchers);
		
		resultMap.put("isWatch", "false");
		for (Map<String, Object> issueWatcher : issueWatchers) {
			Object userId = issueWatcher.get("user_id");
			if (userId != null && Integer.parseInt(userId.toString()) == loginUserId) {
				resultMap.put("isWatch", "true");
			}
		}

		conditions = Maps.newHashMap();
		conditions.put("project_id", issue.get("project_id"));
		List<Map<String, Object>> versions = db.querys("issues.getVersions", conditions);
		resultMap.put("versions", versions);

//		conditions = Maps.newHashMap();
//		conditions.put("project_id", issue.get("project_id"));
//		conditions.put("tracker_id", tracker_id);
//		List<Map<String, Object>> issueCustomFields = db.querys("issues.getIssueCustomFields", conditions);
//		resultMap.put("issueCustomFields", issueCustomFields);
		
		logicBean.setData(resultMap);
		
		return logicBean;
	}

	public void updateTicket() throws SoftbankException {
		final int issue_id = Integer.parseInt(context.getParam().get("issue_id"));
		updateTicket(issue_id);
		Map<String, Object> resultMap = Maps.newHashMap();
		resultMap.put("issue_id", issue_id);
		context.getResultBean().setData(resultMap);
	}

	public LogicBean deleteTicket() throws SoftbankException {
		final int issue_id = Integer.parseInt(context.getParam().get("issue_id"));

		deleteTicketById(issue_id);

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		resultMap.put("issue_id", issue_id);
		logicBean.setData(resultMap);

		return logicBean;
	}

	public LogicBean changeWatch() throws SoftbankException {

		final int issue_id = Integer.parseInt(context.getParam().get("issue_id"));
		final String isWatch = context.getParam().get("isWatch");
		
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issue_id);
		conditions.put("user_id", loginUserId);
		
		int count = db.query("issues.isIssueWatcher", conditions, Integer.class);

		boolean isUpdated = true;
		if ("true".equals(isWatch) && count == 0) {
			conditions.put("watchable_id", issue_id);
			conditions.put("user_id", loginUserId);
			db.insert("issues.insertWatchers", conditions);
		} else if ("false".equals(isWatch) && count > 0) {
			conditions.put("watchable_id", issue_id);
			conditions.put("user_id", loginUserId);
			db.delete("issues.deleteWatchers", conditions);
		} else {
			isUpdated = false;
		}

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();

		if (isUpdated) {
			conditions = Maps.newHashMap();
			conditions.put("issue_id", issue_id);
			List<Map<String, Object>> issueWatchers = db.querys("issues.getIssueWatchers", conditions);
			resultMap.put("issueWatchers", issueWatchers);
			
			conditions = Maps.newHashMap();
			conditions.put("project_id", Integer.parseInt(context.getParam().get("issue_project_id")));
			List<Map<String, Object>> members = db.querys("issues.getMembers", conditions);
			resultMap.put("members", members);
		}

		resultMap.put("issue_id", issue_id);
		logicBean.setData(resultMap);

		return logicBean;
	}
	
	private boolean isChanged(Object old_value, String value) {
		boolean isNotEmpty = false;
		if (old_value == null) {
			if (StringUtils.isNotEmpty(value)) {
				isNotEmpty = true;
			}
		} else {
			if (old_value instanceof Double) {
				if (StringUtils.isEmpty(value) || Double.parseDouble(value) != (Double)old_value) {
					isNotEmpty = true;
				}
			} else if (old_value instanceof Integer) {
				if (StringUtils.isEmpty(value) || Integer.parseInt(value) != (Integer)old_value) {
					isNotEmpty = true;
				}
			} else {
				if (!org.apache.commons.lang.StringUtils.equals(value, old_value.toString())) {
					isNotEmpty = true;
				}
			}
		}
		return isNotEmpty;
	}
	
	@Override
	public void doValidate(List<InputErrorBean> errorInfos) throws SoftbankException {
		if ("3".equals(context.getParam().cmdCode)) {
			
			String status_id = context.getParam().get("issue_status_id");
			String done_ratio = context.getParam().get("issue_done_ratio");
			String parent_issue_id = context.getParam().get("issue_parent_id");
			String str_start_date = context.getParam().get("issue_start_date");
			String str_due_date = context.getParam().get("issue_due_date");

			if ("1".equals(status_id) && !"0".equals(done_ratio) || "3".equals(status_id) && !"100".equals(done_ratio)){
				InputErrorBean inputErrorStatusBean = new InputErrorBean();
				inputErrorStatusBean.setTargetId("issue_status_id");
				inputErrorStatusBean.setMessage("ステータスと進捗率の内容が不整合です。再度入力してください。");
				errorInfos.add(inputErrorStatusBean);
				InputErrorBean inputErrorDoneRatioBean = new InputErrorBean();
				inputErrorDoneRatioBean.setTargetId("issue_done_ratio");
				inputErrorDoneRatioBean.setMessage("ステータスと進捗率の内容が不整合です。再度入力してください。");
				errorInfos.add(inputErrorDoneRatioBean);
			}

			if (!"".equals(parent_issue_id) && null != parent_issue_id){
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("search_keyword", parent_issue_id);
				List<Map<String, Object>> parentIssues = newTicketDao.searchExistTcketForParent(conditions);
				if (parentIssues.size() == 0){
					InputErrorBean inputErrorParentIssueBean = new InputErrorBean();
					inputErrorParentIssueBean.setTargetId("issue_parent_id");
					inputErrorParentIssueBean.setMessage("親チケットは存在しません。");
					errorInfos.add(inputErrorParentIssueBean);
				}else{
					if (!parentIssues.get(0).get("project_id").equals(context.getParam().projectId)){
						InputErrorBean inputErrorParentIssueBean = new InputErrorBean();
						inputErrorParentIssueBean.setTargetId("issue_parent_id");
						inputErrorParentIssueBean.setMessage("親チケット 同じプロジェクトに属していません。");
						errorInfos.add(inputErrorParentIssueBean);
					}
				}
			}
			
			if (!"".equals(str_start_date) && !"".equals(str_due_date)){
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date start_date = null;
				Date due_date = null;
				try {
					start_date = format.parse(str_start_date);
					due_date = format.parse(str_due_date);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				if (start_date.compareTo(due_date) > 0){
					InputErrorBean inputErrorSDateBean = new InputErrorBean();
					inputErrorSDateBean.setTargetId("issue_start_date");
					inputErrorSDateBean.setMessage("期日 を開始日より後にしてください。");
					errorInfos.add(inputErrorSDateBean);
					InputErrorBean inputErrorDateBean = new InputErrorBean();
					inputErrorDateBean.setTargetId("issue_due_date");
					inputErrorDateBean.setMessage("期日 を開始日より後にしてください。");
					errorInfos.add(inputErrorDateBean);
				}
			}
			
			String tracker_id = context.getParam().get("issue_tracker_id");
			if ("35".equals(tracker_id)){
				String custom_field_values_1251 = context.getParam().get("issue_custom_field_values_1251");
				String custom_field_values_1253 = context.getParam().get("issue_custom_field_values_1253");
				String custom_field_values_1256 = context.getParam().get("issue_custom_field_values_1256");
				doCustomFieldRequired(errorInfos,"1251","システム名 ",custom_field_values_1251);
				doCustomFieldRequired(errorInfos,"1253","[sec_op]ステータス  ",custom_field_values_1253);
				doCustomFieldRequired(errorInfos,"1256","次回対応期日 ",custom_field_values_1256);
			}else if("1".equals(tracker_id)){
				String custom_field_values_264 = context.getParam().get("issue_custom_field_values_264");
				doCustomFieldRequired(errorInfos,"264","対象フェーズ ",custom_field_values_264);
			}else if("2".equals(tracker_id) || "21".equals(tracker_id)){
				String custom_field_values_295 = context.getParam().get("issue_custom_field_values_295");
				doCustomFieldRequired(errorInfos,"295","区分 ",custom_field_values_295);
			}else if("16".equals(tracker_id) || "3".equals(tracker_id)){
				String custom_field_values_265 = context.getParam().get("issue_custom_field_values_265");
				doCustomFieldRequired(errorInfos,"265","テスト工程",custom_field_values_265);
				if("16".equals(tracker_id)){
					String custom_field_values_266 = context.getParam().get("issue_custom_field_values_266");
					doCustomFieldRequired(errorInfos,"266","テスト項目件数",custom_field_values_266);
					String custom_field_values_537 = context.getParam().get("issue_custom_field_values_537");
					doCustomFieldRequired(errorInfos,"537","テスト検証済件数",custom_field_values_537);
				}
			}else if("17".equals(tracker_id)){
				String custom_field_values_294 = context.getParam().get("issue_custom_field_values_294");
				String custom_field_values_270 = context.getParam().get("issue_custom_field_values_270");
				String custom_field_values_269 = context.getParam().get("issue_custom_field_values_269");
				doCustomFieldRequired(errorInfos,"294","評価種別",custom_field_values_294);
				doCustomFieldRequired(errorInfos,"270","アセスメントフェーズ ",custom_field_values_270);
				doCustomFieldRequired(errorInfos,"269","実施状況",custom_field_values_269);
			}else if("18".equals(tracker_id)){
				String custom_field_values_298 = context.getParam().get("issue_custom_field_values_298");
				doCustomFieldRequired(errorInfos,"298","実施可否",custom_field_values_298);
			}else if("34".equals(tracker_id)){
				String custom_field_values_1190 = context.getParam().get("issue_custom_field_values_1190");
				doCustomFieldRequired(errorInfos,"1190","サブステータス",custom_field_values_1190);
				String custom_field_values_1195 = context.getParam().get("issue_custom_field_values_1195");
				doCustomFieldRequired(errorInfos,"1195","優先度（ISC） ",custom_field_values_1195);
			}
		}
	}
	
	public void doCustomFieldRequired(List<InputErrorBean> errorInfos, String id, String messages, String value) throws SoftbankException {
		if ("".equals(value)){
			InputErrorBean inputErrorBean = new InputErrorBean();
			inputErrorBean.setTargetId("issue_custom_field_values_" + id);
			inputErrorBean.setMessage(messages + "は入力必須項目です.");
			errorInfos.add(inputErrorBean);
		}
	}
}
