package co.jp.softbank.qqmx.info.bean;

public class TuInfoBean {
	
	private String newDate;

	public String getNewDate() {
		return newDate;
	}

	public void setNewDate(String newDate) {
		this.newDate = newDate;
	}
	
}
