package co.jp.softbank.qqmx.logic.application.test;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.task.face.ITaskLogic;

public class TestTaskExecutor extends AbstractBaseLogic {
	
	private ITaskLogic task;
	
	public void testTask() {
		task.execute(context);
	}

	public void setTask(ITaskLogic task) {
		this.task = task;
	}
	
}
