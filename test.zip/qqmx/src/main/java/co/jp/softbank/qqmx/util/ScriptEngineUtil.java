package co.jp.softbank.qqmx.util;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import co.jp.softbank.qqmx.application.bean.HttpContext;

import sun.org.mozilla.javascript.internal.EvaluatorException;

public class ScriptEngineUtil {
	
	public static String createScriptImport() {
    	StringBuilder sb = new StringBuilder();
    	sb.append("importPackage(java.util);");
    	sb.append("importPackage(java.io);");
    	sb.append("importPackage(java.lang);");
    	sb.append("importPackage(net.sf.json);");
    	sb.append("importPackage(com.google.common.collect);");
    	return sb.toString();
    }
	
	public static void setScriptContext(HttpContext httpContext, ScriptEngine scriptEngine) {
		scriptEngine.put("_util", new EngineScriptUtil(httpContext));
	}
	
	public static void main(String[] args) {
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("js");
		TestFace testFace = null;
		try {
			String script = "importPackage(com.rich.client.engine.util);function test1(str) { var cc = 'test1 called ' + param + '***' + str;println(cc);return true; } \nfunction test1(abc) { var cc = 'test** called ' + param + '***' + abc;println(cc);return true; }";
			
			engine.eval(script);
			
			Invocable inv = (Invocable) engine;
			
			testFace = inv.getInterface(TestFace.class);
			engine.put("param", "376");
		} catch (ScriptException e) {
			e.printStackTrace();
			
		} catch (EvaluatorException e) {
		}
		try {
			boolean abcString = testFace.test1("Hello");
			System.out.println(abcString);
		} catch (EvaluatorException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
		}
	}
	
	public interface TestFace {
		boolean test1(String str);
		
		boolean test1(int abc);
	}

}
