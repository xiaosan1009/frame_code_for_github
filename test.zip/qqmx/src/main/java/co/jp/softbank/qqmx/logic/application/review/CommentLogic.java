package co.jp.softbank.qqmx.logic.application.review;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class CommentLogic extends AbstractBaseLogic {

	public void getCommentList() throws SoftbankException {
		List<Map<String, Object>> commentList = db.querys("comment.getCommentList");
		context.getResultBean().setData(commentList);
	}

}
