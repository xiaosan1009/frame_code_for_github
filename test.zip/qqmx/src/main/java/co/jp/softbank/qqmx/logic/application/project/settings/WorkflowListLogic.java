package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

import com.google.common.collect.Maps;

public class WorkflowListLogic extends AbstractBaseLogic {

	public void getWorkflowRoleInfo() throws SoftbankException {
		context.getResultBean().setData(db.querys("workflowList.getWorkflowRoleInfo"));
	}
	
	public void getWorkflowTrackerInfo() throws SoftbankException {
		context.getResultBean().setData(db.querys("workflowList.getWorkflowTrackerInfo"));
	}
	
	public void getWorkflowIssueStatusesInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String id = context.getParam().get("id");
		conditions.put("id", id);
		context.getResultBean().setData(db.querys("workflowList.getWorkflowIssueStatusesInfo" , conditions));
	}
	
	public void getWorkflowStatusesInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String tracker_id = context.getParam().get("tracker_id");
		conditions.put("tracker_id", Integer.parseInt(tracker_id));
		context.getResultBean().setData(db.querys("workflowList.getWorkflowStatusesInfo" , conditions));
	}
	
	public void getWorkflowListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String tracker_id = context.getParam().get("tracker_id");
		String role_id = context.getParam().get("role_id");
		
		String assignee = context.getParam().get("assignee");
		String author = context.getParam().get("author");
		boolean boolean_assignee = false; 
		boolean boolean_author = false; 
		if ("t".equals(assignee)){
			boolean_assignee = true;
		}
		if ("t".equals(author)){
			boolean_author = true;
		}
		conditions.put("tracker_id", Integer.parseInt(tracker_id));
		conditions.put("role_id", Integer.parseInt(role_id));
		conditions.put("assignee", boolean_assignee);
		conditions.put("author", boolean_author);
		context.getResultBean().setData(db.querys("workflowList.getWorkflowListInfo" , conditions));
	}
	
	public void getWorkflowRoleTrackerListInfo() throws SoftbankException {
		context.getResultBean().setData(db.querys("workflowList.getWorkflowRoleTrackerListInfo"));
	}
	
	public void cpWorkflowRoleTrackerInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String source_tracker_id = context.getParam().get("source_tracker_id");
		String source_role_id = context.getParam().get("source_role_id");
		String target_tracker_ids = context.getParam().get("target_tracker_ids");
		String target_role_ids = context.getParam().get("target_role_ids");
		String[] str_tracker_id = target_tracker_ids.split(",", 0);
		String[] str_role_id = target_role_ids.split(",", 0);

		conditions.put("source_tracker_id", Integer.parseInt(source_tracker_id));
		conditions.put("source_role_id", Integer.parseInt(source_role_id));
		String tracker_id;
		String role_id;
		for (int i=0; i<str_tracker_id.length; i++){
			tracker_id = str_tracker_id[i];
			for (int j=0; j<str_role_id.length; j++){
				role_id = str_role_id[j];
				conditions.put("target_tracker_ids", Integer.parseInt(tracker_id));
				conditions.put("target_role_ids", Integer.parseInt(role_id));
				context.getResultBean().setData(db.delete("workflowList.delWorkflowRoleTrackerInfo", conditions));
				context.getResultBean().setData(db.insert("workflowList.insertWorkflowRoleTrackerInfo", conditions));
			}
		}
	}
	
	public void saveWorkflowInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String tracker_id = context.getParam().get("tracker_id");
		String role_id = context.getParam().get("role_id");
		conditions.put("target_tracker_ids", Integer.parseInt(tracker_id));
		conditions.put("target_role_ids", Integer.parseInt(role_id));
		
		context.getResultBean().setData(db.insert("workflowList.delWorkflowRoleTrackerInfo", conditions));

		String[] inputCheckbox = context.getParam().getList("inputCheckbox");
		String[] inputCheckboxAuthor = context.getParam().getList("inputCheckboxAuthor");
		String[] inputCheckboxAssignee = context.getParam().getList("inputCheckboxAssignee");
		
		if (inputCheckbox != null && inputCheckbox.length > 0){
			
			for (int i=0; i<inputCheckbox.length; i++){
				String inputCheckboxValue = inputCheckbox[i];
				String[] str_tracker_id = inputCheckboxValue.split(";", 0);
				String old_status_id = str_tracker_id[0];
				String new_status_id = str_tracker_id[1];
				conditions.put("old_status_id", Integer.parseInt(old_status_id));			
				conditions.put("new_status_id", Integer.parseInt(new_status_id));			
				conditions.put("author", false);			
				conditions.put("assignee", false);	
				context.getResultBean().setData(db.insert("workflowList.saveWorkflowInfo", conditions));
			}
			
		}
		if (inputCheckboxAuthor != null && inputCheckboxAuthor.length > 0){
			
			for (int i=0; i<inputCheckboxAuthor.length; i++){
				String inputCheckboxValue = inputCheckboxAuthor[i];
				String[] str_tracker_id = inputCheckboxValue.split(";", 0);
				String old_status_id = str_tracker_id[0];
				String new_status_id = str_tracker_id[1];
				conditions.put("old_status_id", Integer.parseInt(old_status_id));			
				conditions.put("new_status_id", Integer.parseInt(new_status_id));	
				conditions.put("author", true);			
				conditions.put("assignee", false);	
				List<Map<String, Object>> getWorkflowIdCheckInfo = db.querys("workflowList.getWorkflowIdCheckInfo", conditions);
				if (getWorkflowIdCheckInfo.size() == 0){
					context.getResultBean().setData(db.insert("workflowList.saveWorkflowInfo", conditions));
				}
			}
		}
		
		if (inputCheckboxAssignee != null && inputCheckboxAssignee.length > 0){
			
			for (int i=0; i<inputCheckboxAssignee.length; i++){
				String inputCheckboxValue = inputCheckboxAssignee[i];
				String[] str_tracker_id = inputCheckboxValue.split(";", 0);
				String old_status_id = str_tracker_id[0];
				String new_status_id = str_tracker_id[1];
				conditions.put("old_status_id", Integer.parseInt(old_status_id));			
				conditions.put("new_status_id", Integer.parseInt(new_status_id));			
				conditions.put("author", false);			
				conditions.put("assignee", true);
				List<Map<String, Object>> getWorkflowIdCheckInfo = db.querys("workflowList.getWorkflowIdCheckInfo", conditions);
				if (getWorkflowIdCheckInfo.size() == 0){
					context.getResultBean().setData(db.insert("workflowList.saveWorkflowInfo", conditions));
				}
			}
		}
		
	}	
}
