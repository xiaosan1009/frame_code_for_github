package co.jp.softbank.qqmx.task.face;

public interface IContextFactory {
	
	ITaskContext getTaskContext();

}
