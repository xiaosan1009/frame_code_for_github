package co.jp.softbank.qqmx.server;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.slf4j.Logger;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.common.CommonDao;
import co.jp.softbank.qqmx.dao.common.DbMemoryMonitorDaoService;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.info.ControlDbMemoryMonitor;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.ControlSettingMap.SettingKey;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;


public class QqmxApplicationServlet extends AbstractQqmxBaseServlet {
	
	private Logger log = new LogUtil(this.getClass()).getLog();
	
	private CommonDao commonDaoService;
	
	private DbMemoryMonitorDaoService dbMemoryMonitorDaoService;
	
	private IDbExecute db;

	@Override
	public void initialize(ServletContext context) {
		try {
			ControlDbMemory.setDb(db);
			ControlDbMemory.setCommonDao(commonDaoService);
			ControlDbMemory dbMemory = ControlDbMemory.getInstance();
			
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_ALL_WATCHABLE_INFO)) {
				cashAllWatchableInfo();
			}
			
			cashPointProjectInfo();
			
			ControlDbMemoryMonitor.setDbMemoryMonitorDaoService(dbMemoryMonitorDaoService);
			ControlDbMemoryMonitor.setMessageAccessor(messageAccessor);
			ControlDbMemoryMonitor.getInstance();
			
			List<Map<String, Object>> tuNewDate = db.querys("tuReform.getNewDateInfo");
			if (StringUtils.isEmpty(tuNewDate.get(0).get("new_date"))) {
				Date now = DateUtils.getNow();
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("tu_created_on", now);
				conditions.put("name", "0" );
				db.insert("tuReform.setStudyInfo", conditions);
				dbMemory.setTuNewDate(DateUtils.makeFormat(now, DateUtils.FORMAT_YYYYMMDDHHMMSS));
			} else {
				dbMemory.setTuNewDate(StringUtils.toString(tuNewDate.get(0).get("new_date")));
			}
			
		} catch (SoftbankException e) {
			e.printStackTrace();
		}
	}
	
	public void setCommonDaoService(CommonDao commonDaoService) {
		this.commonDaoService = commonDaoService;
	}

	public void setDb(IDbExecute db) {
		this.db = db;
	}

	public void setDbMemoryMonitorDaoService(
			DbMemoryMonitorDaoService dbMemoryMonitorDaoService) {
		this.dbMemoryMonitorDaoService = dbMemoryMonitorDaoService;
	}
	
	private void cashPointProjectInfo() {
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					if (StringUtils.isNotEmpty(ControlSettingMap.getInstance().getString(SettingKey.CASH_POINT_PROJECT_INFO))) {
						String[] pros = ControlSettingMap.getInstance().getString(SettingKey.CASH_POINT_PROJECT_INFO).split(",");
						for (int i = 0; i < pros.length; i++) {
							ControlDbMemory.getInstance().refreshAllTicketsForParentProject(StringUtils.toInt(pros[i]));
						}
					}
				} catch (SoftbankException e) {
					e.printStackTrace();
					log.error(e.getErrorMsg(), e);
				}
			}
		});
		t.start();
	}
	
	private void cashAllWatchableInfo() throws SoftbankException {
		List<Map<String, Object>> result = db.querysC("projects.getWatchableProjects");
		for (int i = 0; i < result.size(); i++) {
			ControlDbMemory.getInstance().getTimestampWatchableMap().put(StringUtils.toInt(result.get(i).get("project_id")), DateUtils.calcDateForDate(new Date(), 1));
		}
	}

}
