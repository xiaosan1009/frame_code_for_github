package co.jp.softbank.qqmx.info;

import java.util.Date;
import java.util.Map;

import co.jp.softbank.qqmx.dao.common.DbMemoryMonitorDaoService;

import com.google.common.collect.Maps;

public class DbMemoryWatchableMonitorTask extends DbMemoryTaskBase {
	
	private DbMemoryMonitorDaoService dbMemoryMonitorDaoService;
	
	public DbMemoryWatchableMonitorTask(DbMemoryMonitorDaoService dbMemoryMonitorDaoService) {
		this.dbMemoryMonitorDaoService = dbMemoryMonitorDaoService;
	}
	
	@Override
	public void run() {
		try {
			Map<Integer, Date> timestampMap = ControlDbMemory.getInstance().getTimestampWatchableMap();
			for (Map.Entry<Integer, Date> projectTimestamp : timestampMap.entrySet()) {
				int projectId = projectTimestamp.getKey();
				Date memoryTimestamp = projectTimestamp.getValue();
				if ((new Date()).compareTo(memoryTimestamp) < 0) {
					ControlDbMemory.getInstance().refreshTicketsForWatchable(projectId);
					continue;
				}

				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("project_id", projectId);
				Map<String, Object> issueUpdateTimestampMap = dbMemoryMonitorDaoService.getIssueUpdateTimestamp(conditions);
				
				if (issueUpdateTimestampMap != null) {
					Date issueUpdateTimestamp = (Date)issueUpdateTimestampMap.get("updated_on");
					log.debug("project_id = {}, issueUpdateTimestamp = {}, memoryTimestamp = {}", projectId, issueUpdateTimestamp, memoryTimestamp);
					if (issueUpdateTimestamp.compareTo(memoryTimestamp) > 0) {
						log.debug("projectId = {}", projectId);
						ControlDbMemory.getInstance().refreshTicketsForWatchable(projectId);
						Integer parentId = dbMemoryMonitorDaoService.getProjectParentId(conditions);
						if (parentId != null) {
							log.debug("parentId = {}", parentId);
							ControlDbMemory.getInstance().refreshTicketsForWatchable(parentId);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
