package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.ProjectNormalInsertDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class NormalInsertLogic extends AbstractBaseLogic {

	@Autowired
	private ProjectNormalInsertDao projectNormalInsertDao;

	public LogicBean getGroupListInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();

		List<Map<String, Object>> groupList = projectNormalInsertDao
				.getGroupList();
		resultMap.put("groups", groupList);

		List<Map<String, Object>> statusList = projectNormalInsertDao
				.getStatusList();
		resultMap.put("status", statusList);

		logicBean.setData(resultMap);
		return logicBean;
	}

	public void getUserListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int status = 1;
		if (StringUtils.isNotEmpty(context.getParam().get("status"))) {
			status = Integer.parseInt(context.getParam().get("status"));
		}
		int groupId = 0;
		if (StringUtils.isNotEmpty(context.getParam().get("group_id"))) {
			groupId = Integer.parseInt(context.getParam().get("group_id"));
		}
		conditions.put("status", status);
		conditions.put("group_id", groupId);
		conditions.put("user_name", context.getParam().get("user_name"));
		PageListBean pageListBean = pageList(projectNormalInsertDao, "getUserList", conditions);
		List<Map<String, Object>> statusList = projectNormalInsertDao.getStatusList();
		for (int i = 0; i < statusList.size(); i++) {
			switch (Integer.parseInt(StringUtils.toString(statusList.get(i).get("status")))) {
			case 1:
				pageListBean.setData("lockCount", statusList.get(i).get("count"));
				break;
			case 2:
				pageListBean.setData("registCount", statusList.get(i).get("count"));
				break;
			case 3:
				pageListBean.setData("unlockCount", statusList.get(i).get("count"));
				break;

			default:
				break;
			}
		}
		context.getResultBean().setData(pageListBean);
	}

	public LogicBean getSelectUserListInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();

		int groupId = 0;
		if (StringUtils.isNotEmpty(context.getParam().get("group_id"))) {
			groupId = Integer.parseInt(context.getParam().get("group_id"));
		}
		conditions.put("status",
				Integer.parseInt(context.getParam().get("status")));
		conditions.put("group_id", groupId);
		conditions.put("user_name", context.getParam().get("user_name"));
		List<Map<String, Object>> userList = projectNormalInsertDao
				.getUserList(conditions);
		resultMap.put("users", userList);

		logicBean.setData(resultMap);
		return logicBean;
	}

	public void lockUserInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		conditions.put("id", Integer.parseInt(context.getParam().get("id")));
		projectNormalInsertDao.updateUsersLock(conditions);
		projectNormalInsertDao.updateMembers(conditions);
	}

	public void unlockUserInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		conditions.put("id", Integer.parseInt(context.getParam().get("id")));
		projectNormalInsertDao.updateUsersUnlock(conditions);
		projectNormalInsertDao.updateMembers(conditions);
	}

	public void deleteUserInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		conditions.put("id", Integer.parseInt(context.getParam().get("id")));
		projectNormalInsertDao.updateNormalInsertUsersAttachments(conditions);
		projectNormalInsertDao.updateNormalInsertUsersChangesets(conditions);
		projectNormalInsertDao.updateNormalInsertUsersComments(conditions);
		projectNormalInsertDao
				.updateNormalInsertUsersIssueCategories(conditions);
		projectNormalInsertDao
				.updateNormalInsertUsersIssuesAssigned(conditions);
		projectNormalInsertDao.updateNormalInsertUsersIssuesAuthor(conditions);
		projectNormalInsertDao
				.updateNormalInsertUsersJournalDetails(conditions);
		projectNormalInsertDao
				.updateNormalInsertUsersJournalDetailsOld(conditions);
		projectNormalInsertDao.updateNormalInsertUsersJournals(conditions);
		projectNormalInsertDao.updateNormalInsertUsersMessages(conditions);
		projectNormalInsertDao.updateNormalInsertUsersNews(conditions);
		projectNormalInsertDao.updateNormalInsertUsersQueries(conditions);
		projectNormalInsertDao.updateNormalInsertUsersTimeEntries(conditions);
		projectNormalInsertDao
				.updateNormalInsertUsersWikiContentVersions(conditions);
		projectNormalInsertDao.updateNormalInsertUsersWikiContents(conditions);
		projectNormalInsertDao.deleteNormalInsertCustomValues(conditions);
		projectNormalInsertDao.deleteNormalInsertQueries(conditions);
		projectNormalInsertDao.deleteNormalInsertTokens(conditions);
		projectNormalInsertDao.deleteNormalInsertUserPreferences(conditions);
		projectNormalInsertDao.deleteNormalInsertUsers(conditions);
		projectNormalInsertDao.deleteNormalInsertWatchers(conditions);
	}
}
