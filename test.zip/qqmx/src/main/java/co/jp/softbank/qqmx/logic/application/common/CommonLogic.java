package co.jp.softbank.qqmx.logic.application.common;

import java.util.Map;

import org.apache.commons.fileupload.FileItem;

import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.UploadFileInfo;

import com.google.common.collect.Maps;

public class CommonLogic extends AbstractBaseLogic {
	
	private static final String UPLOAD_IMAGE_FILE_PATH = "image/kindedit/";
	
	public LogicBean uploadKindeditorImage() {
		LogicBean logicBean = new LogicBean();
		if (context.getUploadFileItems() != null && context.getUploadFileItems().size() > 0) {
			for (int i = 0; i < context.getUploadFileItems().size(); i++) {
				logicBean.setData(analizeUploadKindeditorImageItem(context.getUploadFileItems().get(i)));
			}
		}
		return logicBean;
	}
	
	private Map<String, String> analizeUploadKindeditorImageItem(FileItem item) {
		Map<String, String> resultMap = Maps.newHashMap();
		UploadFileInfo fileInfo = doUpload(item, UPLOAD_IMAGE_FILE_PATH, UploadType.image);
		log.debug("url = " + fileInfo.getUrlPath());
		resultMap.put("url", fileInfo.getUrlPath());

		return resultMap;
	}

}
