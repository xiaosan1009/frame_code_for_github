package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.project.settings.GroupListDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

public class GroupListLogic extends AbstractBaseLogic {

	@Autowired
	private GroupListDao groupListDao;

	public void getGroupList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_name", context.getParam().get("group_name"));
		PageListBean pageListBean = pageList(groupListDao, "getGroupList", conditions);
		context.getResultBean().setData(pageListBean);
	}
	
	public LogicBean saveGroup() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_name", context.getParam().get("group_name"));
		groupListDao.saveGroup(conditions);
		return logicBean;
	}
	
	public LogicBean deleteGroup() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Integer> conditions = Maps.newHashMap();
		conditions.put("group_id", Integer.parseInt(context.getParam().get("group_id")));
		groupListDao.deleteGroup(conditions);
		groupListDao.deleteGroupUsers(conditions);
		
		List<Map<String, Integer>> selectMemberUsersList = groupListDao.selectProjectSettingMembers(conditions);
		for (int i = 0; i < selectMemberUsersList.size(); i++) {
			int member_id = selectMemberUsersList.get(i).get("id");
			Map<String, Integer> conditionMember = Maps.newHashMap();
			conditionMember.put("group_id", member_id);
			groupListDao.deleteProjectSettingMemberUsers(conditionMember);
			groupListDao.deleteProjectSettingUser(conditionMember);
		}
		return logicBean;
	}
	
}
