package co.jp.softbank.qqmx.dao.demos;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface DemosDao extends IDaoInterface {
	
	List<Map<String, Object>> getDemosList();

}
