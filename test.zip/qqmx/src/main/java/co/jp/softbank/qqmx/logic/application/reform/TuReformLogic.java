package co.jp.softbank.qqmx.logic.application.reform;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;


public class TuReformLogic extends AbstractBaseLogic {
	
	public void getSelectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String selectId = context.getParam().get("selectFlg");
		//統括
		String headquartersId = context.getParam().get("headquartersId").equals("")? "9898": context.getParam().get("headquartersId");
		//本部
		String divisionId = context.getParam().get("divisionId").equals("")? "9898": context.getParam().get("divisionId");
		//統括部
		String departmentId = context.getParam().get("departmentId").equals("")? "9898": context.getParam().get("departmentId");
		
		if ("headquarters".equals(selectId)){
			context.getResultBean().setData(db.querys("tuReform.getHeadquartersList"));
		} else if ("division".equals(selectId)){
			conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
			context.getResultBean().setData(db.querys("tuReform.getDivisionList", conditions));
		} else if ("department".equals(selectId)){
			conditions.put("division_id", Integer.parseInt(divisionId));
			context.getResultBean().setData(db.querys("tuReform.getDepartmentList", conditions));
		} else if ("region".equals(selectId)){
			conditions.put("department_Id", Integer.parseInt(departmentId));
			context.getResultBean().setData(db.querys("tuReform.getRegionList", conditions));
		} else {
			context.getResultBean().setData(Lists.newArrayList());
		}
	}
	
	public void getStudyList() throws SoftbankException {
		context.getResultBean().setData(db.querys("tuReform.getStudyList"));
	}
	
	public void getStudyInitInfo() throws SoftbankException {
		context.getResultBean().setData(db.querys("tuReform.getStudyInitInfo"));
	}
	
	public void delStudyInfo() throws SoftbankException {
		String id =  context.getParam().get("id");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", id);
		db.delete("tuReform.delStudyInfo", conditions);
	}
	
	public void setStudyInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String date = context.getParam().get("date");
		String date1 = context.getParam().get("date1");
		conditions.put("tu_created_on", DateUtils.formatToDate(date, DateUtils.FORMAT_YYYYMMDDHHMMSS_DASH));
		String name = context.getParam().get("tuReformName");
		String flg = context.getParam().get("flg");
		if ("update".equals(flg)) {
			conditions.put("name", "0" );
			db.insert("tuReform.setStudyInfo", conditions);
			db.delete("tuReform.deleteStudyInfo");
			ControlDbMemory.getInstance().setTuNewDate(date1);
		} else {
			conditions.put("name", name );
			db.insert("tuReform.setStudyInfo", conditions);
		}
	}
	
	public void upStudyNameInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String date = context.getParam().get("date");
		String name = context.getParam().get("name");
		conditions.put("tu_created_on", date);
		conditions.put("name", name);
		
		db.insert("tuReform.upStudyNameInfo", conditions);
	}

	public void getPopSelectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String selectId = context.getParam().get("selectFlg");
		//統括
		String headquartersId = context.getParam().get("headquartersIdPop").equals("")? "9898": context.getParam().get("headquartersIdPop");
		//本部
		String divisionId = context.getParam().get("divisionIdPop").equals("")? "9898": context.getParam().get("divisionIdPop");
		//統括部
		String departmentId = context.getParam().get("departmentIdPop").equals("")? "9898": context.getParam().get("departmentIdPop");
		
		if ("headquarters".equals(selectId)){
			context.getResultBean().setData(db.querys("tuReform.getHeadquartersList"));
		} else if ("division".equals(selectId)){
			conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
			context.getResultBean().setData(db.querys("tuReform.getDivisionList", conditions));
		} else if ("department".equals(selectId)){
			conditions.put("division_id", Integer.parseInt(divisionId));
			context.getResultBean().setData(db.querys("tuReform.getDepartmentList", conditions));
		} else if ("region".equals(selectId)){
			conditions.put("department_Id", Integer.parseInt(departmentId));
			context.getResultBean().setData(db.querys("tuReform.getRegionList", conditions));
		} else {
			context.getResultBean().setData(Lists.newArrayList());
		}
	}
	
	public void getNewDate() throws SoftbankException {
		context.getResultBean().setData(ControlDbMemory.getInstance().getTuNewDate());
	}
	
	public void doFilter() throws SoftbankException {
		UserInfoData userInfoData = context.getSessionData().getUserInfo();
		if (userInfoData == null || userInfoData.isAdmin()) {
			context.getResultBean().setFilter(true);
			return;
		}
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", 1593);
		List<Map<String, Object>> roles = db.querys("roles.selectUserRolesForProject", conditions);
		if (roles == null || roles.size() == 0) {
			return;
		}
		for (int i = 0; i < roles.size(); i++) {
			Map<String, Object> roleData = roles.get(i);
			List<String> nonRoles = (List<String>)Yaml.load(StringUtils.toString(roleData.get("permissions")));
			if (nonRoles!= null && nonRoles.size() > 0) {
				for (int j = 0; j < nonRoles.size(); j++) {
					String role = nonRoles.get(j);
					if (role.startsWith(ConstantsUtil.Str.COLON)) {
						role = role.substring(1);
					}
					if ("ipf_exec_graph_pattern_project".equals(role)) {
						context.getResultBean().setFilter(true);
						return;
					}
				}
			}
		}
		return;
	}
}
