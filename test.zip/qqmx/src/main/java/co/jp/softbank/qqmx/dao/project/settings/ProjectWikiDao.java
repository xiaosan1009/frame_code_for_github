package co.jp.softbank.qqmx.dao.project.settings;

import java.util.Map;

public interface ProjectWikiDao {
	
	Map<String, Object> getProjectWikiInfo(Map<String, Object> conditions);
	
	void updateWikisInfos(Map<String, Object> conditions);
	
	void insertWikisInfos(Map<String, Object> conditions);
	
	void deleteWikisInfos(Map<String, Object> conditions);
	
}
