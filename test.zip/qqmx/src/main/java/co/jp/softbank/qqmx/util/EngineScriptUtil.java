package co.jp.softbank.qqmx.util;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;

public class EngineScriptUtil {
	
	private HttpContext httpContext;
	
	public EngineScriptUtil(HttpContext httpContext) {
		this.httpContext = httpContext;
	}
	
	/**
     * 创建序列.
     * @return 序列
     */
	public String createID() {
		return CreateSequencesUtil.createID();
	}
	
	/**
     * 创建序列.
     * @param key 自定义序列KEY
     * @return 序列
     */
    public String createID(String key) {
        return CreateSequencesUtil.createID(null, key);
    }
    
    /**
     * 创建序列.
     * @param session session
     * @return 序列
     */
    public String createID(HttpContext httpContext) {
        return CreateSequencesUtil.createID(httpContext, ConstantsUtil.Str.EMPTY);
    }
    
    /**
     * 创建序列.
     * @param key 自定义序列KEY
     * @param session session
     * @return 序列
     */
    public String createID(HttpContext httpContext, String key) {
    	return CreateSequencesUtil.createID(httpContext, key);
    }
    
    public boolean isEmpty(Object obj) {
    	return StringUtils.isEmpty(obj);
    }
    
    public boolean isNotEmpty(Object obj) {
    	return StringUtils.isNotEmpty(obj);
    }
    
    public JSONObject getJson(String jsonContext) {
    	if (StringUtils.isEmpty(jsonContext)) {
			return new JSONObject();
		}
    	return JSONObject.fromObject(jsonContext);
    }
    
    public JSONArray getJsonArr(String jsonContext) {
    	if (StringUtils.isEmpty(jsonContext)) {
    		return new JSONArray();
    	}
    	return JSONArray.fromObject(jsonContext);
    }
    
    public static void main(String[] args) {
    	JSONArray datas = new JSONArray();
    	datas.add("1");
    	datas.add("2");
    	datas.add("3");
    	datas.add("4");
    	System.out.println(datas.toString());
	}
    
    public void createFolder(String path) {
    	FileUtils.createFolder(path);
    }
    
    public String getFileDataString(String path) throws SoftbankException {
    	return FileUtils.getFileDataString(path);
    }
    
    public void writeFileData(String fileName, String data) throws SoftbankException {
    	FileUtils.writeFileData(fileName, data);
    }
    
}
