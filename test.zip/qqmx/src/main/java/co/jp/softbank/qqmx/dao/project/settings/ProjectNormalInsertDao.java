package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface ProjectNormalInsertDao extends IDaoInterface {
	
	List<Map<String, Object>> getGroupList();
	
	List<Map<String, Object>> getStatusList();
	
	List<Map<String, Object>> getUserList(Map<String, Object> conditions);
	
	void updateUsersLock(Map<String, Object> conditions);
	
	void updateMembers(Map<String, Object> conditions);
	
	void updateUsersUnlock(Map<String, Object> conditions);
	
	void deleteNormalInsertCustomValues(Map<String, Object> conditions);
	void deleteNormalInsertQueries(Map<String, Object> conditions);
	void deleteNormalInsertTokens(Map<String, Object> conditions);
	void deleteNormalInsertUserPreferences(Map<String, Object> conditions);
	void deleteNormalInsertUsers(Map<String, Object> conditions);
	void deleteNormalInsertWatchers(Map<String, Object> conditions);
	
	void updateNormalInsertUsersAttachments(Map<String, Object> conditions);
	void updateNormalInsertUsersChangesets(Map<String, Object> conditions);
	void updateNormalInsertUsersComments(Map<String, Object> conditions);
	void updateNormalInsertUsersIssueCategories(Map<String, Object> conditions);
	void updateNormalInsertUsersIssuesAssigned(Map<String, Object> conditions);
	void updateNormalInsertUsersIssuesAuthor(Map<String, Object> conditions);
	void updateNormalInsertUsersJournalDetails(Map<String, Object> conditions);
	void updateNormalInsertUsersJournalDetailsOld(Map<String, Object> conditions);
	void updateNormalInsertUsersJournals(Map<String, Object> conditions);
	void updateNormalInsertUsersMessages(Map<String, Object> conditions);
	void updateNormalInsertUsersNews(Map<String, Object> conditions);
	void updateNormalInsertUsersQueries(Map<String, Object> conditions);
	void updateNormalInsertUsersTimeEntries(Map<String, Object> conditions);
	void updateNormalInsertUsersWikiContentVersions(Map<String, Object> conditions);
	void updateNormalInsertUsersWikiContents(Map<String, Object> conditions);
}
