package co.jp.softbank.qqmx.validator;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.ValidatorAction;

public class BaseValidatorChecks {
	
	protected void rejectValue(IValidationErrors errors, Field field, ValidatorAction va, Object bean) {
		errors.addError(bean, field, va);
	}
	
	protected void rejectValue(IValidationErrors errors, Field field, ValidatorAction va, Object bean, Object[] args) {
		errors.addError(bean, field, va, args);
	}

}
