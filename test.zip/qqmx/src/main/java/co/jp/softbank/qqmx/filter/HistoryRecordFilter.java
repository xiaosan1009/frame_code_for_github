package co.jp.softbank.qqmx.filter;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.lang.ObjectUtils.Null;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.ho.yaml.Yaml;
import org.springframework.context.ApplicationContext;

import co.jp.softbank.qqmx.application.CustomLoaderListener;
import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.handle.AbstractScriptEngineHandler;
import co.jp.softbank.qqmx.info.ControlRequestMap;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.bean.FilterRequestData;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.SessionData;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONObject;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class HistoryRecordFilter extends AbstractCommonFilter {
    
    public HistoryRecordFilter() {
        super();
    }

    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
    @SuppressWarnings("unchecked")
	public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
    	
    	try {
    		if (request instanceof HttpServletRequest) {
    			final HttpServletRequest req = (HttpServletRequest) request;
    			if (ServletFileUpload.isMultipartContent(req)) {
                	chain.doFilter(request, response);
                	return;
                }
    			HttpContext httpContext = new HttpContext(request, response);
    			
    			if (ControlRequestMap.getInstance().isIgnoreAccessLog(httpContext.getParam())) {
    				chain.doFilter(request, response);
                	return;
				}
    			httpContext.createSession();
    			
    			SessionData sessionData = httpContext.getSessionData();
    			UserInfoData userInfoData = sessionData.getUserInfo();
    			if (userInfoData == null) {
    				chain.doFilter(request, response);
                	return;
    			}
    			
    			db.setContext(httpContext);
    			Map<String, Object> conditions = Maps.newHashMap();
    			
    			conditions.put("user_id", userInfoData.getId());
    			conditions.put("ip", req.getRemoteAddr());
    			conditions.put("dispcode", httpContext.getParam().dispCode);
    			conditions.put("cmdcode", httpContext.getParam().cmdCode);
    			conditions.put("project_id", httpContext.getParam().projectId);
    			conditions.put("param", JSONObject.fromObject(httpContext.getParam().getRequestMap()).toString());
    			
    			db.insertC("access_logs.addAccessLog", conditions);
    		}
    		chain.doFilter(request, response);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		chain.doFilter(request, response);
		}
    	
    }

    public void destroy() {
    }
    
}
