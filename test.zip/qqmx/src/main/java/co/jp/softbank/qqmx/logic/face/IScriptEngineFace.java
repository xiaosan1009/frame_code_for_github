package co.jp.softbank.qqmx.logic.face;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;

public interface IScriptEngineFace {
	
	void execute(String method) throws SoftbankException;
}
