package co.jp.softbank.qqmx.info;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.face.IExcelWriter;
import co.jp.softbank.qqmx.logic.bean.ExportFileInfo;

public class ExcelWriter extends ExcelWriterBase implements IExcelWriter {

	public ExcelWriter(HttpContext context) throws SoftbankException {
		super(context);
	}

	@Override
	public ExportFileInfo create(List<Map<String, Object>> headerColumns, List<Map<String, Object>> datas) {
		return fileInfo;
	}
	
	@Override
	public ExportFileInfo getExport(Map<String, String> optMap, List<Map<String, Object>> datas, Map<String, Object> templateMap) {
		return fileInfo;
	}

}
