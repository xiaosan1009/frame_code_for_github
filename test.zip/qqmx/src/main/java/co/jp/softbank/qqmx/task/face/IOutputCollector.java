package co.jp.softbank.qqmx.task.face;

import java.io.Closeable;

public interface IOutputCollector<V> extends Closeable {
	
    void emit(V value);
    
    void emit(IKey key, V value);

    void prepare(ITaskContext context);

    void cleanup(ITaskContext context);

}
