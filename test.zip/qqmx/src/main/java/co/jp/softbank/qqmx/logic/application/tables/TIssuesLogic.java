package co.jp.softbank.qqmx.logic.application.tables;

import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

import com.google.common.collect.Maps;

public class TIssuesLogic extends AbstractBaseLogic {
	
	public void selectIssueById() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", context.getParam().get("issue_id"));
		context.getResultBean().setData(db.querys("issues.selectIssueById", conditions));
	}
}
