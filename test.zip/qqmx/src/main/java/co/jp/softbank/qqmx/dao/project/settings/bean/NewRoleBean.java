package co.jp.softbank.qqmx.dao.project.settings.bean;

import java.util.List;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;

public class NewRoleBean implements DaoBeanInterface {
	
	private int id;
	
	private String name;

	private String value;
	
	private String flg;
	
	private List<String> newRoleMap;
	
	private List<String> roleFlagMap;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	public String getFlg() {
		return flg;
	}
	
	public void setFlg(String flg) {
		this.flg = flg;
	}


	public List<String> getNewRoleMap() {
		return newRoleMap;
	}

	public void setNewRoleMap(List<String> newRoleMap) {
		this.newRoleMap = newRoleMap;
	}
	
	public List<String> getRoleFlagMap() {
		return roleFlagMap;
	}
	
	public void setRoleFlagMap(List<String> roleFlagMap) {
		this.roleFlagMap = roleFlagMap;
	}
	
	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("id", this.id);
		dataObj.put("name", this.name);
		dataObj.put("value", this.value);
		dataObj.put("flg", this.flg);
		dataObj.put("newRoleMap", this.newRoleMap);
		dataObj.put("roleFlagMap", this.roleFlagMap);
	}

}
