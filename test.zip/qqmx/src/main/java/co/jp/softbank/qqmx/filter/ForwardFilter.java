
package co.jp.softbank.qqmx.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;

public class ForwardFilter extends AbstractCommonFilter {

    /**
     * Take this filter out of service.
     */
    public void destroy() {
    }

    /**
     * Select and set (if specified) the character encoding to be used to
     * interpret request parameters for this request.
     * 
     * @param request The servlet request we are processing
     * @param response The servlet response we are creating
     * @param chain The filter chain we are processing
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet error occurs
     */
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {

    	if (request instanceof HttpServletRequest) {
    		final HttpServletRequest req = (HttpServletRequest) request;
    		HttpServletResponse res = (HttpServletResponse)response;
    		final String requestPath = req.getServletPath();
            final String requestUrl = StringUtils.toString(req.getRequestURL());
            final String remoteAddr = req.getRemoteAddr();
            final String remoteHost = req.getRemoteHost();
            final String remotePort = StringUtils.toString(req.getServerPort());
            final String queryString = req.getQueryString();

            log.info("requestPath = {},requestUrl = {}, queryString = {},remoteAddr = {},remoteHost = {}", 
                    Lists.newArrayList(requestPath, requestUrl, queryString, remoteAddr, remoteHost, remotePort).toArray());
            
            res.sendRedirect("/qqmx/qqmx.mx?" + queryString);
            return;
    	}
        // Pass control on to the next filter
        chain.doFilter(request, response);

    }

    /**
     * Place this filter into service.
     * 
     * @param filterConfig The filter configuration object
     */
    public void init(FilterConfig filterConfig) throws ServletException {

    }

}
