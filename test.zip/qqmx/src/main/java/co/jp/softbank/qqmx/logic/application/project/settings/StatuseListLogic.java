package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.StatuseListDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

import com.google.common.collect.Maps;

public class StatuseListLogic extends AbstractBaseLogic {

	@Autowired
	private StatuseListDao statuseListDao;

	public void getStatuseListInfo() throws SoftbankException {
//		List<Map<String, Object>> statuseList = statuseListDao.getStatuseListInfo();
//		context.getResultBean().setData(statuseList);
		PageListBean pageListBean = pageList(statuseListDao, "getStatuseListInfo");
		context.getResultBean().setData(pageListBean);
	}

	public void delStatuseListId() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("statuse_id", Integer.parseInt(context.getParam().get("statuse_id")));
		List<Map<String, Object>> statuseListIdList = statuseListDao.getStatuseListIdInfo(conditions);
		conditions.put("position_id", Integer.parseInt(String.valueOf(statuseListIdList.get(0).get("position"))));
		
		statuseListDao.updataStatuses(conditions);
		statuseListDao.delStatuseListId(conditions);
	}
	public void saveStatuses() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("issue_status_name"));
		conditions.put("is_default", "true".equals(context.getParam().get("issue_status_is_default")) ? true : false);
		conditions.put("is_closed", "true".equals(context.getParam().get("issue_status_is_closed")) ? true : false);
		
		if (!"0".equals(context.getParam().get("flg"))){
			conditions.put("id", Integer.parseInt(context.getParam().get("flg")));
			statuseListDao.upStatuses(conditions);
		}else{
			statuseListDao.saveStatuses(conditions);
		}
	}
	
	public LogicBean getStatuseIdInfo() throws SoftbankException {
		LogicBean statuseBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("statuse_id", Integer.parseInt(context.getParam().get("statuse_id")));
		statuseBean.setData(statuseListDao.getStatuseListIdInfo(conditions));
		return statuseBean;
	}
	
	public void upStatuseSort() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		List<Map<String, Object>> statuseListEndIdList = statuseListDao.getStatuseListInfo();
		String str_end_position = String.valueOf(statuseListEndIdList.get(Integer.parseInt(context.getParam().get("end_pos"))).get("position"));
		
		conditions.put("statuse_id", Integer.parseInt(context.getParam().get("statuse_id")));
		List<Map<String, Object>> statuseListIdList = statuseListDao.getStatuseListIdInfo(conditions);
		if (Integer.parseInt(str_end_position) > Integer.parseInt(String.valueOf(statuseListIdList.get(0).get("position")))){
			conditions.put("end_pos", Integer.parseInt(str_end_position));
			conditions.put("start_pos", Integer.parseInt(String.valueOf(statuseListIdList.get(0).get("position"))));
			statuseListDao.upCommonMSort(conditions);
		}else{
			conditions.put("end_pos", Integer.parseInt(String.valueOf(statuseListIdList.get(0).get("position"))));
			conditions.put("start_pos", Integer.parseInt(str_end_position));
			statuseListDao.upCommonPSort(conditions);
		}
		Map<String, Object> conditionSort = Maps.newHashMap();
		conditionSort.put("statuse_id", Integer.parseInt(context.getParam().get("statuse_id")));
		conditionSort.put("end_pos", Integer.parseInt(str_end_position));
		statuseListDao.upCommonSort(conditionSort);

	}
}
