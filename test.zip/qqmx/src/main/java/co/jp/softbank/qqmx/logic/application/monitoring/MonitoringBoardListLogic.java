package co.jp.softbank.qqmx.logic.application.monitoring;

import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

import com.google.common.collect.Maps;

public class MonitoringBoardListLogic extends AbstractBaseLogic {

	public void getMonitoringBoardListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		conditions.put("version_name", '%');
		conditions.put("sub_project", '%');
		
		String sort = context.getParam().get("clickSort");
		String click = context.getParam().get("clickData");

		if ("".equals(click)){
			click = "id";
		}
		conditions.put("sort", sort);
		conditions.put("click", click);
		
		
		String whole = context.getParam().get("whole_from");
		String name = context.getParam().get("name_from_id");
		String comment = context.getParam().get("comment_from");
		String pm = context.getParam().get("pm_from");
		String works = context.getParam().get("works_from");
		String design = context.getParam().get("design_from");
		String review = context.getParam().get("review_from");
		String production = context.getParam().get("production_from");
		String build = context.getParam().get("build_from");
		String quality = context.getParam().get("quality_from");
		String test005 = context.getParam().get("test005_from");
		String test006 = context.getParam().get("test006_from");
		String test007 = context.getParam().get("test007_from");
		String release = context.getParam().get("release_from");

		conditions.put("whole", regex(whole));
		conditions.put("name", regex(name));
		conditions.put("comment", regex(comment));
		conditions.put("pm", regex(pm));
		conditions.put("works", regex(works));
		conditions.put("design", regex(design));
		conditions.put("review", regex(review));
		conditions.put("production", regex(production));
		conditions.put("build", regex(build));
		conditions.put("quality", regex(quality));
		conditions.put("test005", regex(test005));
		conditions.put("test006", regex(test006));
		conditions.put("test007", regex(test007));
		conditions.put("release", regex(release));
		
		PageListBean pageListBean = pageList("monitoringBoardList.getMonitoringBoardList", conditions);
		
		context.getResultBean().setData(pageListBean);
	}
	
	public void getMonitoringBoardListHeadInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		String click = context.getParam().get("clickData");
		String sort = context.getParam().get("clickSort");
		if ("".equals(sort)){
			sort = "ASC";
		}
		
		conditions.put("version_name", '%');
		conditions.put("sub_project", '%');
		conditions.put("click", click);
		
		
		
		context.getResultBean().setData(db.querys("monitoringBoardList.getMonitoringBoardListHeadInfo", conditions));
	}
	public void getMonitoringBoardUserInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String loginUserName = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getName();
		conditions.put("user_name", loginUserName);
		context.getResultBean().setData(conditions);
	}
	
	public String regex(String str) {
		String r = "";
		if (str != null){
			String r1 = str.replaceAll("×", "1R");
			String r2 = r1.replaceAll("△", "2Y");
			String r3 = r2.replaceAll("○", "3B");
			String r4 = r3.replaceAll("空白", "");
			r = r4.replaceAll("－", "");
		}
		return r;
	}

}
