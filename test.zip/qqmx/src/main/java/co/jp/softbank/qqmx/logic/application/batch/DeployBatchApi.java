package co.jp.softbank.qqmx.logic.application.batch;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class DeployBatchApi extends AbstractBaseLogic {
	
	public void doApi() throws SoftbankException {
		final String job_name = context.getParam().get("job_name");
		final int new_build_count = Integer.valueOf(context.getParam().get("count"));
		final Integer project_id = Integer.valueOf(context.getParam().get("project_id"));
		log.info("job_name = {}, new_build_count = {}", job_name, new_build_count);
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					
					try {
						Thread.sleep(20000);
					} catch (InterruptedException e) {
						throw new SoftbankException(SoftbankExceptionType.SystemException,e);
					}
					externalHttpServer.getStrUrl(
							messageAccessor.getMessage("application.path") + ":8080/qqmx/qqmx.mx?dispCode=710002&cmdCode=1&job_name=" + job_name + "&count=" + new_build_count + "&project_id=" + project_id);
					
//					externalHttpServer.getStrUrl("http://localhost:8090/qqmx/qqmx.mx?dispCode=710002&cmdCode=1&job_name=" + job_name + "&count=" + new_build_count+ "&project_id=" + project_id);
				} catch (SoftbankException e) {
					e.printStackTrace();
					log.error(e.getErrorMsg(), e);
				}
			}
		});
		t.start();
	}
}
