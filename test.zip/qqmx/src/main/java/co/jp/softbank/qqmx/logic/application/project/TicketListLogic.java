package co.jp.softbank.qqmx.logic.application.project;

import java.io.File;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.validator.GenericTypeValidator;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.ExcelReaderFactory;
import co.jp.softbank.qqmx.info.ExcelWriterFactory;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.CellInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.RowInfoBean;
import co.jp.softbank.qqmx.info.bean.ProjectTicketInfoBean;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.info.face.IExcelWriter;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.bean.ExportFileInfo;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.logic.bean.SessionData;
import co.jp.softbank.qqmx.logic.bean.UploadFileInfo;
import co.jp.softbank.qqmx.util.CommonUtil;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.CreateSequencesUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;
import co.jp.softbank.qqmx.util.ValidationUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class TicketListLogic extends TicketBaseLogic {

	public static final String TICKET_IMPORT_FILE_PATH = "TICKET_IMPORT_FILE_PATH";

	public static final String TICKET_IMPORT_FILE_SHEET_NAME = "TICKET_IMPORT_FILE_SHEET_NAME";

	public static final String TICKET_IMPORT_FILE_INFOS = "TICKET_IMPORT_FILE_INFOS";

	public static final String TICKET_IMPORT_FILE_ERROR_INFOS = "TICKET_IMPORT_FILE_ERROR_INFOS";
	
	public static final String TICKET_IMPORT_FILE_ERROR_INFOS_KEY = "checkErr";

	public static final String TICKET_IMPORT_FILE_MAPPING_CONTEXT = "TICKET_IMPORT_FILE_MAPPING_CONTEXT";

	private static final String UPLOAD_FILE_PATH = "file/ticket/";
	
	private static final String INDEX_SIGN = "inx_";

	private List<String> importColumns = Lists.newArrayList(
			IssueKey.TREE_ID.KEY_JSON,
			IssueKey.PROJECT_ID.KEY_JSON,
			IssueKey.LOCK_VERSION.KEY_JSON,
			IssueKey.FLOOR.KEY_JSON,
			IssueKey.ROOT_ID.KEY_JSON,
			IssueKey.SUBJECT.KEY_JSON,
			IssueKey.ISSUE_ID.KEY_JSON,
			IssueKey.TRACKER.KEY_JSON,
			IssueKey.PARENT_ID.KEY_JSON,
			IssueKey.STATUS_ID.KEY_JSON,
			IssueKey.ASSIGNED_TO_ID.KEY_JSON,
			IssueKey.ASSIGNED_TO_FIRSTNAME.KEY_JSON,
			IssueKey.ASSIGNED_TO_LASTNAME.KEY_JSON,
			IssueKey.AUTHOR_FIRSTNAME.KEY_JSON,
			IssueKey.AUTHOR_LASTNAME.KEY_JSON,
			IssueKey.START_DATE.KEY_JSON,
			IssueKey.DUE_DATE.KEY_JSON,
			IssueKey.FIXED_VERSION_ID.KEY_JSON,
			IssueKey.FIXED_VERSION_NAME.KEY_JSON,
			IssueKey.ESTIMATED_HOURS.KEY_JSON,
			IssueKey.DONE_RATIO.KEY_JSON,
			IssueKey.PRIORITY_ID.KEY_JSON,
			"priority",
			IssueKey.PROCESS.ISPROJECT,
			IssueKey.PROCESS.ISVERSION,
			IssueKey.PROCESS.ISPARENT,
			"name",
			IssueKey.TRACKER_ID.KEY_JSON,
			"t3_status",
			IssueKey.LFT.KEY_JSON,
			IssueKey.RGT.KEY_JSON,
			IssueKey.ROOT_SEQ.KEY_JSON);

	private Map<String, List<String>> columnLinkMap = Maps.newHashMap();

	public TicketListLogic() {
//		columnLinkMap.put("author", Lists.newArrayList("t9_lastname", "t9_firstname"));
		columnLinkMap.put("updated_on", Lists.newArrayList("t1_updated_on"));
	}

	public void getImportFileTemplates() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		context.getResultBean().setData(db.querys("template.getImportFileTemplates", conditions));
	}
	
	public void getTicketById() throws SoftbankException {
		int issueId = StringUtils.toInt(context.getParam().get("issue_id"));
		Map<String, Object> issue = getTicketById(issueId, StringUtils.toInt(context.getParam().get("project_id")));
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		List<Map<String, Object>> issueWatchers = db.querys("issues.getIssueWatchers", conditions);
		issue.put("issueWatchers", issueWatchers);
		context.getResultBean().setData(issue);
	}
	
	public void getTicketByIds() throws SoftbankException {
		String loadTicketIds = context.getParam().get("loadTicketIds");
		JSONArray ticketIdArray = JSONArray.fromObject(loadTicketIds);
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		List<Map<String, Object>> customFields = db.querys("issues.getCustomFieldsForIssues", conditions);
		conditions.put("customFields", customFields);
		conditions.put("idList", ticketIdArray.toArray());
		List<Map<String, Object>> issueDatas = db.querys("issues.getTicketAllInfoByIds", conditions);
		List<Map<String, Object>> issueWatchers = db.querys("issues.getIssuesWatchers", conditions);
		Map<String, List<Map<String, Object>>> issueWatcherMap = Maps.newHashMap();
		for (int i = 0; i < issueWatchers.size(); i++) {
			Map<String, Object> watcher = issueWatchers.get(i);
			String tid = StringUtils.toString(watcher.get("watchable_id"));
			List<Map<String, Object>> watcherList = Lists.newArrayList();
			if (!issueWatcherMap.containsKey(tid)) {
				issueWatcherMap.put(tid, watcherList);
			} else {
				watcherList = issueWatcherMap.get(tid);
			}
			watcherList.add(watcher);
		}
		for (int i = 0; i < issueDatas.size(); i++) {
			Map<String, Object> issue = issueDatas.get(i);
			String tid = StringUtils.toString(issue.get("issue_id"));
			if (issueWatcherMap.containsKey(tid)) {
				issue.put("issueWatchers", issueWatcherMap.get(tid));
			}
		}
		context.getResultBean().setData(issueDatas);
	}

	public void getTickets() throws SoftbankException {
		Map<String, Object> result = Maps.newHashMap();
		result.put("holidays", db.querys("holidays.selectHolidays"));
		if ("1".equals(this.context.getParam().get("watchable"))) {
			setPageDatasInfoForWatchable(result);
			result.put("stageGatesInfo", db.querys("stage_gates.getStageGatesInfo"));
			context.getResultBean().setData(result);
			return;
		}
		
		Map<String, Object> trackerOptionMap = Maps.newHashMap();

		result.put("settings", db.query("ticketList.getSettings"));
		ProjectTicketInfoBean infoBean = null;
		if ("1".equals(this.context.getParam().get("portal")) || StringUtils.isNotEmpty(context.getParam().get("gantt_userid"))) {
			infoBean = setPageDatasInfoForPortal(result);
		} else {
			infoBean = setPageDatasInfo(result);
		}
		List<Map<String, Object>> projectList = infoBean.getProjectList();
		if (projectList != null && projectList.size() > 0) {
			Map<Integer, Object> membersMap = Maps.newHashMap();
			Map<Integer, Object> trackersMap = Maps.newHashMap();
			Map<Integer, Object> versionsMap = Maps.newHashMap();
			Map<Integer, Object> issueStatusesMap = Maps.newHashMap();
			Map<Integer, Object> customFieldsMap = Maps.newHashMap();
			for (int i = 0; i < projectList.size(); i++) {
				Map<String, Object> proMap = projectList.get(i);
				int projectId = StringUtils.toInt(proMap.get("id"));
				Map<String, Object> cons = Maps.newHashMap();
				cons.put("project_id", projectId);
				membersMap.put(projectId, db.querys("users.getMembersForCmb", cons));
				versionsMap.put(projectId, db.querys("issues.getVersionsForCmb", cons));
				trackersMap.put(projectId, getTrackerInfo(projectId));
				issueStatusesMap.put(projectId, getIssueStatuses(projectId));
				customFieldsMap.put(projectId, db.querys("issues.getCustomFields", cons));
			}
			trackerOptionMap.put("members", membersMap);
			trackerOptionMap.put("trackers", trackersMap);
			trackerOptionMap.put("versions", versionsMap);
			trackerOptionMap.put("issueStatuses", issueStatusesMap);
			result.put("customFields", customFieldsMap);
		}

		trackerOptionMap.put("phases", db.querys("phases.getPhasesForCmb"));

		trackerOptionMap.put("testphase", db.querys("test_phases.getTestPhasesForCmb"));
		
		trackerOptionMap.put("listlinks", createListlinkOptions());
		
		createListlinkOptions();

		List<Map<String, Object>> issueStatus = db.querys("issue_statuses.getIssueStatusesInfos");
		Map<Integer, Map<String, Object>> issueStatusMap = Maps.newHashMap();
		for (int i = 0; i < issueStatus.size(); i++) {
			Map<String, Object> issueStatusData = issueStatus.get(i);
			int issuestatusId = StringUtils.toInt(issueStatusData.get("id"));
			issueStatusMap.put(issuestatusId, issueStatusData);
		}

		result.put("issueStatusMap", issueStatusMap);

		result.put("trackerOptions", trackerOptionMap);
		
		result.put("colorDatas", getColorDatas());

		result.put("currentColumns", importColumns);

		result.put("issueRelations", db.querys("issue_relations.getIssueRelationsForProject"));

		result.put("milestones", db.querys("milestones.selectMilestones"));
		
		createRoleMap(result);

		context.getResultBean().setData(result);
	}

	private void createRoleMap(Map<String, Object> result) {
		Map<String, Object> roldMap = Maps.newHashMap();
		SessionData sessionData = context.getSessionData();
		UserInfoData userInfoData = sessionData.getUserInfo();
		if (userInfoData.isAdmin()) {
			roldMap.put("save", "1");
			roldMap.put("pq", "1");
			roldMap.put("sq", "1");
			roldMap.put("ei", "1");
		} else {
			Map<String, Object> roles = sessionData.getRoles();
			if (roles == null) {
				roldMap.put("save", "1");
				roldMap.put("pq", "1");
				roldMap.put("sq", "1");
				roldMap.put("ei", "1");
				return;
			}
			if (roles.containsKey("edit_issues")) {
				roldMap.put("save", "1");
			} else {
				roldMap.put("save", "0");
			}
			if (roles.containsKey("manage_public_queries")) {
				roldMap.put("pq", "1");
			} else {
				roldMap.put("pq", "0");
			}
			if (roles.containsKey("save_queries")) {
				roldMap.put("sq", "1");
			} else {
				roldMap.put("sq", "0");
			}
			if (roles.containsKey("ipf_exec_xls_importer")) {
				roldMap.put("ei", "1");
			} else {
				roldMap.put("ei", "0");
			}
		}
		
		result.put("roldMap", roldMap);
	}

	private Map<String, Map<String, Object>> createListlinkOptions() throws SoftbankException {
		List<Map<String, Object>> listlinks = db.querys("custom_field_links.selectfieldsInfoByProjectId");
		if (listlinks == null || listlinks.size() == 0) {
			return null;
		}
		Map<String, Map<String, Object>> result = Maps.newHashMap();
		Map<String, Object> filedMap = null;
		for (int i = 0; i < listlinks.size(); i++) {
			Map<String, Object> data = listlinks.get(i);
			String custom_field_id = StringUtils.toString(data.get("custom_field_id"));
			if (!result.containsKey(custom_field_id)) {
				filedMap = Maps.newHashMap();
				filedMap.put("pid", StringUtils.toString(data.get("parent_field_id")));
				result.put(custom_field_id, filedMap);
			}
			String parent_id = StringUtils.toString(data.get("parent_id"));
			String parent_name = StringUtils.toString(data.get("parent_name"));
			List<Map<String, Object>> opts = Lists.newArrayList();
			if (StringUtils.isEmpty(parent_name)) {
				if (filedMap.containsKey("opts")) {
					opts = (List<Map<String, Object>>)filedMap.get("opts");
				} else {
					filedMap.put("opts", opts);
				}
			} else {
				if (filedMap.containsKey(parent_id)) {
					opts = (List<Map<String, Object>>)filedMap.get(parent_id);
				} else {
					filedMap.put(parent_id, opts);
				}
			}
			opts.add(data);
		}
		return result;
	}

	private void createInitColumns() throws SoftbankException {
		List<Map<String, Object>> fields = db.querys("custom_field_links.selectfieldsByProjectId");
		if (fields != null && fields.size() > 0) {
			for (int i = 0; i < fields.size(); i++) {
				importColumns.add(IssueKey.CUSTOMVALUES.KEY_JSON + StringUtils.toString(fields.get(i).get("cid")));
			}
		}
	}
	
	private Map<String, Map<String, Object>> getColorDatas() throws SoftbankException {
		Map<String, Map<String, Object>> result = Maps.newHashMap();
		List<Map<String, Object>> colorDatas = db.querys("issues_gantt_color.selectIssuesGanttColorInfoByProject");
		for (int i = 0; i < colorDatas.size(); i++) {
			Map<String, Object> map = Maps.newHashMap();
			Map<String, Object> data = colorDatas.get(i);
			map.put("z10", data.get("background_color"));
			map.put("z11", data.get("font_color"));
			result.put(StringUtils.toString(data.get("issue_id")), map);
		}
		return result;
	}

	private Map<String, Map<String, List<Map<String, Object>>>> getIssueStatuses(int projectId) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> issueStatuses = db.querys("issue_statuses.getIssueStatuses", conditions);

		Map<String, Map<String, List<Map<String, Object>>>> issueStatusMap = Maps.newHashMap();

		for (int i = 0; i < issueStatuses.size(); i++) {
			Map<String, Object> data = issueStatuses.get(i);
			String trackerId = String.valueOf(data.get("tracker_id"));
			String trackerName = String.valueOf(data.get("tracker_name"));
			String oldStatusId = String.valueOf(data.get("old_status_id"));
			String oldStatusName = String.valueOf(data.get("old_status_name"));
			String oldStatusPosition = String.valueOf(data.get("old_status_position"));
			if (!issueStatusMap.containsKey(trackerId)) {
				Map<String, List<Map<String, Object>>> oldStatusMap = Maps.newHashMap();
				issueStatusMap.put(trackerId, oldStatusMap);
			}
			if (!issueStatusMap.get(trackerId).containsKey(oldStatusId)) {
				List<Map<String, Object>> newStatusList = Lists.newArrayList();
				Map<String, Object> newStatusMap = Maps.newHashMap();
				newStatusMap.put("value", oldStatusId);
				newStatusMap.put("label", oldStatusName);
				newStatusMap.put("position", oldStatusPosition);
				newStatusList.add(newStatusMap);
				issueStatusMap.get(trackerId).put(oldStatusId, newStatusList);
			}
			issueStatusMap.get(trackerId).get(oldStatusId).add(makeStatusOptionMap(data));
		}
		return issueStatusMap;
	}

	private List<Map<String, Object>> getDefaultIssueStatuses() throws SoftbankException {
		List<Map<String, Object>> statusList = Lists.newArrayList();
		List<Map<String, Object>> issueStatuses = db.querys("issue_statuses.getIssueStatusesInfosByProject");
		for (int i = 0; i < issueStatuses.size(); i++) {
			Map<String, Object> status = issueStatuses.get(i);
			Map<String, Object> option = Maps.newHashMap();
			option.put("value", StringUtils.toString(status.get("name")));
			option.put("label", StringUtils.toString(status.get("name")));
			statusList.add(option);
		}
		return statusList;
	}
	
	private List<Map<String, Object>> getDefaultIssuePriority() throws SoftbankException {
		List<Map<String, Object>> priorityList = Lists.newArrayList();
		Map<String, Object> option = Maps.newHashMap();
		option.put("value", "深刻");
		option.put("label", "深刻");
		priorityList.add(option);

		option = Maps.newHashMap();
		option.put("value", "影響大");
		option.put("label", "影響大");
		priorityList.add(option);

		option = Maps.newHashMap();
		option.put("value", "影響小");
		option.put("label", "影響小");
		priorityList.add(option);

		option = Maps.newHashMap();
		option.put("value", "影響無し");
		option.put("label", "影響無し");
		priorityList.add(option);
		return priorityList;
	}

	public void getAddColumnDatas() throws SoftbankException {
		List<Map<String, Object>> resultList = Lists.newArrayList();
		String addColumns = context.getParam().get("addColumns");
		JSONArray columnArray = JSONArray.fromObject(addColumns);
		List<Map<String, Object>> pageDatas = ControlDbMemory.getInstance().getProjectTicketInfos(context.getParam().projectId).getDatas();
		for (int i = 0; i < pageDatas.size(); i++) {
			Map<String, Object> data = pageDatas.get(i);
			if (data.containsKey(IssueKey.PROCESS.ISPROJECT) || data.containsKey(IssueKey.PROCESS.ISVERSION)) {
				continue;
			}
			Map<String, Object> resultMap = Maps.newHashMap();
			resultMap.put(IssueKey.ISSUE_ID.KEY_JSON, data.get(IssueKey.ISSUE_ID.KEY_JSON));
			for (int j = 0; j < columnArray.size(); j++) {
				String column = columnArray.getString(j);
				if (columnLinkMap.containsKey(column)) {
					List<String> linkColumnList = columnLinkMap.get(column);
					for (int k = 0; k < linkColumnList.size(); k++) {
						resultMap.put(linkColumnList.get(k), data.get(linkColumnList.get(k)));
					}
				} else {
					resultMap.put(column, data.get(column));
				}
			}
			resultList.add(resultMap);
		}
		context.getResultBean().setData(resultList);
	}

	private List<Map<String, Object>> getTrackerInfo(int projectId) throws SoftbankException {
//		Map<String, Object> trackersMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> trackers = db.querys("ticketList.getTrackerInfo", conditions);
//		if (trackers != null) {
//			for (int i = 0; i < trackers.size(); i++) {
//				Map<String, Object> tracker = trackers.get(i);
//				trackersMap.put(StringUtils.toString(tracker.get("id")), tracker.get("name"));
//			}
//		}
		return trackers;
	}

	private List<Map<String, Object>> getDefaultTrackerInfo(int projectId) throws SoftbankException {
		List<Map<String, Object>> trackersList = Lists.newArrayList();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> trackers = db.querys("ticketList.getTrackerInfo", conditions);
		if (trackers != null) {
			for (int i = 0; i < trackers.size(); i++) {
				Map<String, Object> option = Maps.newHashMap();
				Map<String, Object> tracker = trackers.get(i);
				option.put("value", tracker.get("name"));
				option.put("label", tracker.get("name"));
				trackersList.add(option);
			}
		}
		return trackersList;
	}
	
	public void getTicketsForPage() throws SoftbankException {
		Map<String, Object> result = Maps.newHashMap();
		setPageDatasInfo(result);
		context.getResultBean().setData(result);
	}

	public void getTicketVersionInfos() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("from_date", context.getParam().get("from_date"));
		conditions.put("project_id", context.getParam().projectId);
		String sql = "";
		if ("1".equals(this.context.getParam().get("watchable"))) {
			sql = "issues_historys.selectNewestIssuesHistorysForWatchable";
		} else {
			sql = "issues_historys.selectNewestIssuesHistorys";
		}
		List<Map<String, Object>> versionInfos = db.querys(sql, conditions);
		context.getResultBean().setData(versionInfos);
	}

	public ProjectTicketInfoBean setPageDatasInfo(Map<String, Object> result) throws SoftbankException {
		ProjectTicketInfoBean ticketInfoBean = ControlDbMemory.getInstance().getProjectTicketInfos(context.getParam().projectId);
		List<Map<String, Object>> pageDatas = ticketInfoBean.getDatas();
		if (pageDatas == null) {
			return ticketInfoBean;
		}
		List<Map<String, Object>> datas = getPageDatas(pageDatas);
		createInitColumns();
		datas = CommonUtil.createListByColumn(datas, importColumns);
		result.put("pageDatas", datas);
		result.put("allPage", getAllPage(pageDatas.size()));
		result.put("minStartDate", ticketInfoBean.getMinStartDate());
		result.put("maxEndDate", ticketInfoBean.getMaxEndDate());
		return ticketInfoBean;
	}

	public void setPageDatasInfoForWatchable(Map<String, Object> result) throws SoftbankException {
		ProjectTicketInfoBean ticketInfoBean = ControlDbMemory.getInstance().getProjectTicketInfosForWatchable(context.getParam().projectId);
		result.put("pageDatas", ticketInfoBean.getDatas());
		result.put("minStartDate", ticketInfoBean.getMinStartDate());
		result.put("maxEndDate", ticketInfoBean.getMaxEndDate());
		result.put("allPage", 1);
	}

	public ProjectTicketInfoBean setPageDatasInfoForPortal(Map<String, Object> result) throws SoftbankException {
		ProjectTicketInfoBean ticketInfoBean = getProjectTicketInfosForPortal();
		List<Map<String, Object>> pageDatas = ticketInfoBean.getDatas();
		result.put("pageDatas", pageDatas);
		result.put("allPage", 1);
		result.put("minStartDate", ticketInfoBean.getMinStartDate());
		result.put("maxEndDate", ticketInfoBean.getMaxEndDate());
		return ticketInfoBean;
	}

	private ProjectTicketInfoBean getProjectTicketInfosForPortal() throws SoftbankException {
		ProjectTicketInfoBean ticketInfoBean = new ProjectTicketInfoBean();
		List<Map<String, Object>> result = Lists.newArrayList();
		ticketInfoBean.setDatas(result);
		Map<String, Object> conditions = Maps.newHashMap();
		if (StringUtils.isNotEmpty(context.getParam().get("gantt_userid"))) {
			conditions.put("user_id", StringUtils.toInt(context.getParam().get("gantt_userid")));
		}
		List<Map<String, Object>> projectList = db.querys("ticketList.getProjectInfosForUser", conditions);
		if (projectList == null || projectList.size() == 0) {
			return ticketInfoBean;
		}
		ticketInfoBean.setProjectList(projectList);
		ControlDbMemory c = ControlDbMemory.getInstance();
		int preParentProjectId = 0;
		String rootId = null;
		conditions = Maps.newHashMap();
		for (int i = 0; i < projectList.size(); i++) {
			Map<String, Object> proMap = projectList.get(i);
			int parentId = StringUtils.toInt(proMap.get("parent_id"));
			if (parentId > 0) {
				rootId = c.getProjectId(parentId);
				if (parentId != preParentProjectId) {
					preParentProjectId = parentId;
					conditions.put("project_id", parentId);
					Map<String, Object> parentProjectInfo = db.query("projects.getProjectInfo", conditions);
					parentProjectInfo.put("floorId", rootId);
					c.setProjectInfo(parentProjectInfo, rootId);
					result.add(parentProjectInfo);
				}
			} else {
				int projectId = StringUtils.toInt(proMap.get("id"));
				preParentProjectId = projectId;
				rootId = null;
			}
			result.addAll(getProjectTicketInfosForPortal(proMap, rootId, ticketInfoBean));
		}
		return ticketInfoBean;
	}

	private List<Map<String, Object>> getProjectTicketInfosForPortal(
			Map<String, Object> projectInfo, String rootId, ProjectTicketInfoBean projectTicketInfoBean)
			throws SoftbankException {
		int projectId = StringUtils.toInt(projectInfo.get("id"));
		ControlDbMemory c = ControlDbMemory.getInstance();
		List<Map<String, Object>> result = Lists.newArrayList();
		String floorId = "";
		if (StringUtils.isEmpty(rootId)) {
			rootId = c.getProjectId(projectId);
			floorId = rootId;
		} else {
			floorId = rootId + ConstantsUtil.Str.SPACE + c.getProjectId(projectId);
		}
		projectInfo.put("floorId", floorId);
		c.setProjectInfo(projectInfo, rootId);
		result.add(projectInfo);

		ProjectTicketInfoBean ticketInfoBean = getProjectTicketInfosForPortal(projectInfo, projectId);
		projectTicketInfoBean.setMinStartDate(ticketInfoBean.getMinStartDate());
		projectTicketInfoBean.setMaxEndDate(ticketInfoBean.getMaxEndDate());
		result.addAll(ticketInfoBean.getDatas());
		return result;
	}

	private ProjectTicketInfoBean getProjectTicketInfosForPortal(Map<String, Object> projectInfo, int projectId)
			throws SoftbankException {
		ControlDbMemory c = ControlDbMemory.getInstance();
		ProjectTicketInfoBean ticketInfoBean = new ProjectTicketInfoBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> customFields = db.querys("issues.getCustomFieldsForIssues", conditions);
		conditions.put("customFields", customFields);
		if (StringUtils.isNotEmpty(context.getParam().get("gantt_userid"))) {
			conditions.put("user_id", StringUtils.toInt(context.getParam().get("gantt_userid")));
		}
		List<Map<String, Object>> datas = db.querys("issues.getTicketsForPortal", conditions);
		ticketInfoBean.setDatas(datas);
		c.anilizeTicketDatas(ticketInfoBean, projectInfo);
		return ticketInfoBean;
	}

	private int getAllPage(int allRows) {
		int pageRowNumber = Integer.parseInt(context.getParam().pageRowNumber);
		int allPage = allRows / pageRowNumber;
		if (allRows % pageRowNumber != 0) {
			allPage++;
		}
		return allPage;
	}

	private List<Map<String, Object>> getPageDatas(List<Map<String, Object>> pageDatas) {
		int currentPage = Integer.parseInt(context.getParam().currentPage);
		int pageRowNumber = Integer.parseInt(context.getParam().pageRowNumber);
		int startPageRow = pageRowNumber * (currentPage - 1);
		if (startPageRow >= pageDatas.size()) {
			return Lists.newArrayList();
		}
		int endPageRow = startPageRow + pageRowNumber;
		if (endPageRow > pageDatas.size()) {
			endPageRow = pageDatas.size();
		}
		return pageDatas.subList(startPageRow, endPageRow);
	}

	private Map<String, Object> makeStatusOptionMap(Map<String, Object> data) {
		Map<String, Object> newStatusMap = Maps.newHashMap();
		String newStatusId = String.valueOf(data.get("new_status_id"));
		String newStatusName = String.valueOf(data.get("new_status_name"));
		String newStatusPosition = String.valueOf(data.get("new_status_position"));
		newStatusMap.put("value", newStatusId);
		newStatusMap.put("label", newStatusName);
		newStatusMap.put("position", newStatusPosition);
		return newStatusMap;
	}

	public void addFilterQuery() throws SoftbankException {
		final String name = context.getParam().get("ticket_filter_name");
		final String type = context.getParam().get("ticket_filter_type");
		final String filters = context.getParam().get("ticket_filter_filters");
		final String columns = context.getParam().get("ticket_filter_columns");
		final String columnWidth = context.getParam().get("ticket_filter_column_width");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", name);
		conditions.put("filters", filters);
		conditions.put("column_names", columns);
		conditions.put("column_width", columnWidth);
		if ("0".equals(type)) {
			// 全PJ公開
			conditions.put("project_id", 0);
			conditions.put("user_id", 0);
		} else if ("1".equals(type)) {
			// 当PJ公開
			conditions.put("project_id", context.getParam().projectId);
			conditions.put("user_id", 0);
		} else if ("2".equals(type)) {
			// 全PJ個人
			conditions.put("project_id", 0);
			conditions.put("user_id", getUserInfos().getId());
		} else {
			// 当PJ個人
			conditions.put("project_id", context.getParam().projectId);
			conditions.put("user_id", getUserInfos().getId());
		}
		db.insert("queries.addQueriesInfo", conditions);
		context.getResultBean().setData(conditions.get("id"));
	}

	public void updateFilterQuery() throws SoftbankException {
		final String id = context.getParam().get("ticket_filter_id");
		final String name = context.getParam().get("ticket_filter_name");
		final String type = context.getParam().get("ticket_filter_type");
		final String filters = context.getParam().get("ticket_filter_filters");
		final String columns = context.getParam().get("ticket_filter_columns");
		final String columnWidth = context.getParam().get("ticket_filter_column_width");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("query_id", Integer.parseInt(id));
		conditions.put("name", name);
		conditions.put("filters", filters);
		conditions.put("column_names", columns);
		conditions.put("column_width", columnWidth);
		if ("0".equals(type)) {
			// 全PJ公開
			conditions.put("project_id", 0);
			conditions.put("user_id", 0);
		} else if ("1".equals(type)) {
			// 当PJ公開
			conditions.put("project_id", context.getParam().projectId);
			conditions.put("user_id", 0);
		} else if ("2".equals(type)) {
			// 全PJ個人
			conditions.put("project_id", 0);
			conditions.put("user_id", getUserInfos().getId());
		} else {
			// 当PJ個人
			conditions.put("project_id", context.getParam().projectId);
			conditions.put("user_id", getUserInfos().getId());
		}
		db.update("queries.updateQueriesInfo", conditions);
	}

	public void deleteFilterQuery() throws SoftbankException {
		final String id = context.getParam().get("ticket_filter_id");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("query_id", Integer.parseInt(id));
		db.update("queries.deleteQueriesInfo", conditions);
	}

	public void loadIssueHistory() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int issueId = StringUtils.toInt(context.getParam().get("issue_id"));
		conditions.put("issue_id", issueId);
		List<Map<String, Object>> issue_journals = db.querys("issues.selectIssueJournalsById", conditions);
		context.getResultBean().setData(issue_journals);
	}

	public void importTickectsInfo() throws SoftbankException {
		FileItem fileItem = context.getUploadFileItems().get(0);
		UploadFileInfo fileInfo = doUpload(fileItem, UPLOAD_FILE_PATH, UploadType.all, new UploadFileName() {
			
			@Override
			public String getFileName(String fileName, String newFileName) {
				return newFileName + ConstantsUtil.Str.UNDERLINE + getUserInfos().getId() + ConstantsUtil.Str.UNDERLINE + context.getParam().projectId;
			}
		});
		String realPath = fileInfo.getRealPath() + fileInfo.getNewFileName();
		context.getSessionData().set(TICKET_IMPORT_FILE_PATH, realPath);
		context.getResultBean().setData(ExcelReaderFactory.getReader(new File(realPath)).getSheetInfos().getSheetNames());
	}

	public void importSheetSelect() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		List<Map<String, Object>> optionList = createDefaultOption();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		optionList.addAll(db.querys("issues.getCustomFieldsForCmb", conditions));
		Map<String, String> optionMap = Maps.newHashMap();
		for (int i = 0; i < optionList.size(); i++) {
			Map<String, Object> option = optionList.get(i);
			String dataInx = StringUtils.toString(option.get("value"));
			if (optionMap.containsKey(dataInx)) {
				optionList.remove(i);
				i--;
			} else {
				optionMap.put(dataInx, dataInx);
			}
		}
		resultMap.put("optionList", optionList);
		readImportFileInfo(resultMap);
		context.getResultBean().setData(resultMap);
	}

	public void importDataMapping() throws SoftbankException {
		MappingContext mappingContext = new MappingContext();
		mappingContext.create(context, db);

		int headerRow = 0;
		String templateId = context.getParam().get("import_template_file");
		Map<String, Object> templateMap = getTemplateData(templateId);
		if (!templateMap.isEmpty()) {
			headerRow = StringUtils.toInt(templateMap.get("header_row"));
		}
		String realPath = context.getSessionData().getString(TICKET_IMPORT_FILE_PATH);
		int sheetIndex = context.getSessionData().getInt(TICKET_IMPORT_FILE_SHEET_NAME);
		ExcelInfoBean excelInfoBean = ExcelReaderFactory.getReader(new File(realPath)).getAllCellInfos(sheetIndex, true, headerRow);
		analyzeExcelRows(excelInfoBean.getRows(), mappingContext);
	}

	public void getImportResultSettings() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		MappingContext mappingContext = (MappingContext)context.getSessionData().get(TICKET_IMPORT_FILE_MAPPING_CONTEXT);
		resultMap.put("columns", mappingContext.getMappingTitleList());

		int projectId = context.getParam().projectId;
		Map<String, Object> optionMap = Maps.newHashMap();
		optionMap.put("phases", getDefaultPhases());
		optionMap.put("testphase", getDefaultTestphase());
		Map<String, Object> cons = Maps.newHashMap();
		cons.put("project_id", projectId);
		optionMap.put("members", getDefaultMembers());
		optionMap.put("versions", db.querys("issues.getVersionsForCmb", cons));
		optionMap.put("tracker", getDefaultTrackerInfo(projectId));
		optionMap.put("statuses", getDefaultIssueStatuses());
		optionMap.put("priority", getDefaultIssuePriority());
		optionMap.put("customFields", db.querys("issues.getCustomFields", cons));
		List<Map<String, Object>> issueStatus = db.querys("issue_statuses.getIssueStatusesInfos");
		Map<Integer, Map<String, Object>> issueStatusMap = Maps.newHashMap();
		for (int i = 0; i < issueStatus.size(); i++) {
			Map<String, Object> issueStatusData = issueStatus.get(i);
			int issuestatusId = StringUtils.toInt(issueStatusData.get("id"));
			issueStatusMap.put(issuestatusId, issueStatusData);
		}
		optionMap.put("issueStatusMap", issueStatusMap);

		resultMap.put("options", optionMap);
		
		int headerCol = 0;
		String templateId = context.getParam().get("import_template_file");
		Map<String, Object> templateMap = getTemplateData(templateId);
		if (!templateMap.isEmpty()) {
			headerCol = StringUtils.toInt(templateMap.get("header_col"));
		}
		resultMap.put("col", headerCol);

		context.getResultBean().setData(resultMap);
	}

	@SuppressWarnings("unchecked")
	public void getImportResultPageList() throws SoftbankException {
		List<Map<String, Object>> resultDataList = null;
		if ("1".equals(context.getParam().get("onlyErr"))) {
			resultDataList = (List<Map<String, Object>>)context.getSessionData().get(TICKET_IMPORT_FILE_ERROR_INFOS);
		} else {
			resultDataList = (List<Map<String, Object>>)context.getSessionData().get(TICKET_IMPORT_FILE_INFOS);
		}
		PageListBean pageListBean = getPageListInfo(resultDataList, resultDataList.size());
		context.getResultBean().setData(pageListBean);
	}

	@SuppressWarnings("unchecked")
	public void changeCellVal() throws SoftbankException {
		int colIndex = StringUtils.toInt(context.getParam().get("colIndex"));
		int rowIndex = StringUtils.toInt(context.getParam().get("rowIndex")) - 1;
		String value = context.getParam().get("colValue");
		String key = context.getParam().get("colKey");
		List<Map<String, Object>> resultDataList = (List<Map<String, Object>>)context.getSessionData().get(TICKET_IMPORT_FILE_INFOS);
		MappingContext mappingContext = (MappingContext)context.getSessionData().get(TICKET_IMPORT_FILE_MAPPING_CONTEXT);
		Map<String, Object> data = resultDataList.get(rowIndex);
		data.put(key, value);
		if (data.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
			data.remove(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
//			Map<String, String> checkErrMap = (Map<String, String>)data.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
//			if (checkErrMap.containsKey(key)) {
//				checkErrMap.remove(key);
//			}
		}
		List<String> keyOrder = Lists.newArrayList();
		List<String> customLinkOrder = mappingContext.getCustomLinkOrder();
		for (int i = 0; i < customLinkOrder.size(); i++) {
			keyOrder.add(customLinkOrder.get(i));
		}
		for (String k : data.keySet()) {
			if (!keyOrder.contains(k)) {
				keyOrder.add(k);
			}
		}
		for (int i = 0; i < keyOrder.size(); i++) {
			String k = keyOrder.get(i);
			int inx = mappingContext.getIndexByData(k);
			if (inx != -1) {
				String val = StringUtils.toString(data.get(k));
				checkRequired(inx, val, k, mappingContext, data);
				doDataChecker(inx, val, k, mappingContext, data);
			}
		}
		String startD = StringUtils.toString(data.get(IssueKey.START_DATE.KEY_JSON));
		String endD = StringUtils.toString(data.get(IssueKey.DUE_DATE.KEY_JSON));
		checkDateDiff(mappingContext, data, startD, endD);
		String status = StringUtils.toString(data.get(IssueKey.STATUS_ID.KEY_JSON));
		String doneRatio = StringUtils.toString(data.get(IssueKey.DONE_RATIO.KEY_JSON));
		checkStatusAndDoneRatio(mappingContext, data, status, doneRatio);
		refreshErrorMapping(resultDataList);
		context.getResultBean().setData(data);
	}
	
	@SuppressWarnings("unchecked")
	public void submitImportData() throws SoftbankException {
		List<Map<String, Object>> errorDataList = (List<Map<String, Object>>)context.getSessionData().get(TICKET_IMPORT_FILE_ERROR_INFOS);
		if (errorDataList != null && errorDataList.size() > 0) {
			throw new SoftbankException("submitImportDataError");
		}
		ImportDataResult importDataResult = new ImportDataResult(context);
		MappingContext mappingContext = (MappingContext)context.getSessionData().get(TICKET_IMPORT_FILE_MAPPING_CONTEXT);
//		int pageSize = StringUtils.toInt(context.getParam().get("pageSize"));
		List<Map<String, Object>> resultDataList = (List<Map<String, Object>>)context.getSessionData().get(TICKET_IMPORT_FILE_INFOS);
		
		importDataResult.analysisImportIssueData(resultDataList, mappingContext);
		
		List<Map<String, Object>> updateList = importDataResult.getUpdateList();
		
		Map<String, List<Map<String, Object>>> addMap = importDataResult.getAddMap();
		
//		double allPage = Math.ceil((double)resultDataList.size() / pageSize);
//		resultDataList = getImportPageData(pageSize, resultDataList);
//		
//		for (int i = 0; i < resultDataList.size(); i++) {
//			Map<String, Object> data = resultDataList.get(i);
//			for (String key : data.keySet()) {
//				if (!mappingContext.hasConversion(key)) {
//					continue;
//				}
//				data.put(key, mappingContext.doConversion(key, StringUtils.toString(data.get(key))));
//			}
//		}
		Map<String, Object> resultMap = Maps.newHashMap();
		resultMap.put("updateList", updateList);
		resultMap.put("addMap", addMap);
//		resultMap.put("allPage", allPage);
		context.getResultBean().setData(resultMap);
	}

	public void exportIssuesData() throws SoftbankException {
		String datas = context.getParam().get("datas");
		int floor = StringUtils.toInt(context.getParam().get("floor"));
		String selectOption = context.getParam().get("selectOption");
		JSONObject dataObject = JSONObject.fromObject(datas);
		Map<String, String> optMap = Maps.newHashMap();
		List<Map<String, Object>> optionList = createDefaultOption(floor + 1, true);
		optionList.addAll(db.querys("issues.getCustomFieldsForCmb"));
		Map<String, String> optionMap = Maps.newHashMap();
		for (int i = 0; i < optionList.size(); i++) {
			Map<String, Object> option = optionList.get(i);
			String dataInx = StringUtils.toString(option.get("value"));
			optMap.put(StringUtils.toString(option.get("label")), dataInx);
			if (IssueKey.SUBJECT.KEY_JSON.equals(dataInx)) {
				continue;
			}
			if (optionMap.containsKey(dataInx)) {
				optionList.remove(i);
				i--;
			} else {
				optionMap.put(dataInx, dataInx);
			}
		}
		if (StringUtils.isNotEmpty(selectOption)) {
			optionList = createDataOptions(selectOption, optionList);
		}
		ProjectTicketInfoBean ticketInfoBean = ControlDbMemory.getInstance().getProjectTicketInfos(context.getParam().projectId);
		List<Map<String, Object>> ticketDatas = ticketInfoBean.getDatas();
		List<Map<String, Object>> exportDataList = Lists.newArrayList();
		Map<String, String> subjectMap = Maps.newHashMap();
		ExportMapping exportMapping = new ExportMapping(context, db);
		exportMapping.createIndexList(optionList);
		for (int i = 0; i < ticketDatas.size(); i++) {
			Map<String, Object> data = ticketDatas.get(i);
			String tid = StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY_JSON));
			if (dataObject.containsKey(tid)) {
				subjectMap.put(tid, StringUtils.toString(data.get(IssueKey.SUBJECT.KEY_JSON)));
				Map<String, Object> d = Maps.newHashMap();
				String treeData = StringUtils.toString(data.get(IssueKey.TREE_ID.KEY_JSON));
				String[] trees = treeData.split(ConstantsUtil.Str.SPACE);
				List<String> subjectList = Lists.newArrayList();
				for (int j = 0; j < trees.length; j++) {
					if (subjectMap.containsKey(trees[j])) {
						subjectList.add(subjectMap.get(trees[j]));
					}
				}
				d.putAll(data);
				if (subjectList.size() > 0) {
					d.put("subjectList", subjectList);
				}
				exportMapping.analysisData(d);
				exportDataList.add(d);
			}
		}
		
		String templateId = context.getParam().get("export_template_file");
		Map<String, Object> templateExportMap = getTemplateData(templateId);
		if (templateExportMap != null && !templateExportMap.isEmpty()) {
			exportMapping.setTemplateMap(templateExportMap);
		}
		IExcelWriter excelWriter = createExcelWriter(exportMapping);
		
		ExportFileInfo fileInfo = null; 
		if (templateExportMap.isEmpty()) {
			fileInfo = excelWriter.create(optionList, exportDataList);
		} else {
			fileInfo = excelWriter.getExport(optMap, exportDataList, templateExportMap);
		}
		
		context.getResultBean().setData(fileInfo.getUrlPath());
	}
	
	public void exportErrorDatas() throws SoftbankException {
		MappingContext mappingContext = (MappingContext)context.getSessionData().get(TICKET_IMPORT_FILE_MAPPING_CONTEXT);
		List<Map<String, String>> titleList = mappingContext.getMappingTitleList();
		List<Map<String, Object>> optionList = Lists.newArrayList();
		for (int i = 0; i < titleList.size(); i++) {
			Map<String, String> title = titleList.get(i);
			Map<String, Object> option = Maps.newHashMap();
			option.put("value", title.get("dataInx"));
			option.put("label", title.get("label"));
			optionList.add(option);
		}
		List<Map<String, Object>> dataMappingResult = (List<Map<String, Object>>)context.getSessionData().get(TICKET_IMPORT_FILE_INFOS);
		List<Map<String, Object>> errorDataList = (List<Map<String, Object>>)context.getSessionData().get(TICKET_IMPORT_FILE_ERROR_INFOS);
		final Map<String, Map<String, Object>> errorDataMap = Maps.newHashMap();
		for (int i = 0; i < errorDataList.size(); i++) {
			Map<String, Object> ed = errorDataList.get(i);
			String tid = StringUtils.toString(ed.get("index"));
			errorDataMap.put(tid, ed);
		}
		IExcelWriter excelWriter = createExcelWriter();
		excelWriter.setCellErrorStyle(new IExcelWriter.CellErrorStyle() {
			
			@Override
			public CellStyle format(Workbook wb, SXSSFDrawing patriarch, Cell cell, Map<String, Object> data, String key, CellStyle style, int x, int y) {
				String tid = StringUtils.toString(data.get("index"));
				if (errorDataMap.containsKey(tid)) {
					Map<String, Object> ed = errorDataMap.get(tid);
					Map<String, String> checkErrMap = (Map<String, String>)ed.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
					if (checkErrMap != null && checkErrMap.containsKey(key)) {
						if (style == null) {
							style = wb.createCellStyle();
							style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
							style.setFillForegroundColor(HSSFColor.RED.index);
						}
						Comment comment = patriarch.createCellComment(patriarch.createAnchor(0, 0, 0, 0, y, x, y + 6, x + 4));
						comment.setString(new XSSFRichTextString(checkErrMap.get(key)));
						cell.setCellComment(comment);
						cell.setCellStyle(style);
					}
				}
				return style;
			}
		}).setCellAnalysis(new IExcelWriter.CellAnalysis() {
			
			@Override
			public void analysis(Cell cell, Map<String, Object> data, String key, String cellValue, int index) {
				if (IssueKey.DONE_RATIO.KEY_JSON.equals(key)) {
					BigDecimal doneRatio = new BigDecimal(0);
					if (StringUtils.isNotEmpty(cellValue)) {
						doneRatio = new BigDecimal(cellValue);
					}
					doneRatio = doneRatio.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
					cell.setCellValue(doneRatio.doubleValue());
				} else if (IssueKey.SUBJECT.KEY_JSON.equals(key)) {
					if (StringUtils.toInt(data.get(INDEX_SIGN + key)) == index) {
						cell.setCellValue(cellValue);
					} else {
						cell.setCellValue(ConstantsUtil.Str.EMPTY);
						
					}
				} else {
					cell.setCellValue(cellValue);
				}
			}
		});
		ExportFileInfo fileInfo = excelWriter.create(optionList, dataMappingResult);
		context.getResultBean().setData(fileInfo.getUrlPath());
	}

	private List<Map<String, Object>> createDataOptions(String selectOption, List<Map<String, Object>> optionList) {
		List<Map<String, Object>> result = Lists.newArrayList();
		JSONObject selectOptionJson = JSONObject.fromObject(selectOption);
		for (int i = 0; i < optionList.size(); i++) {
			Map<String, Object> option = optionList.get(i);
			String dataInx = StringUtils.toString(option.get("value"));
			if (selectOptionJson.containsKey(dataInx)) {
				option.put("sortIndex", selectOptionJson.get(dataInx));
				result.add(option);
			}
		}
		Collections.sort(result, new Comparator<Map<String, Object>>() {

			@Override
			public int compare(Map<String, Object> o1, Map<String, Object> o2) {
				int sortIndex1 = StringUtils.toInt(o1.get("sortIndex"));
				int sortIndex2 = StringUtils.toInt(o2.get("sortIndex"));
				if (IssueKey.SUBJECT.KEY_JSON.equals(StringUtils.toString(o1.get("value")))) {
					return -1;
				}
				if (IssueKey.SUBJECT.KEY_JSON.equals(StringUtils.toString(o2.get("value")))) {
					return 1;
				}
				if (sortIndex1 > sortIndex2) {
					return 1;
				} else if (sortIndex1 < sortIndex2) {
					return -1;
				}
				return 0;
			}
		});
		return result;
	}

	private IExcelWriter createExcelWriter() throws SoftbankException {
		return createExcelWriter(null);
	}
	
	private IExcelWriter createExcelWriter(final ExportMapping exportMapping) throws SoftbankException {
		IExcelWriter excelWriter = null;
		if (exportMapping == null) {
			excelWriter = ExcelWriterFactory.getWriterX(context, new IExcelWriter.CreateFileName() {
				
				@Override
				public String create() throws SoftbankException {
					String fileName = null;
					if ("1".equals(context.getParam().get("use_export_file_name")) 
							&& StringUtils.isNotEmpty(context.getParam().get("export_file_name"))) {
						fileName = context.getParam().get("export_file_name").replaceAll(ConstantsUtil.Str.SPACE, ConstantsUtil.Str.UNDERLINE) + ".xlsx";
					} else {
						Map<String, Object> projectInfo = db.queryC("projects.getProjectInfo");
						fileName = StringUtils.toString(projectInfo.get("name")).replaceAll(ConstantsUtil.Str.SPACE, ConstantsUtil.Str.UNDERLINE) + "_issues_export.xlsx";
					}
					return fileName;
				}
			});
			return excelWriter;
		}
		if (exportMapping.getTemplateMap() != null) {
			excelWriter = ExcelWriterFactory.getWriterX(context, exportMapping.getTemplateMap(), new IExcelWriter.CreateFileName() {
				
				@Override
				public String create() throws SoftbankException {
					String fileName = null;
					if ("1".equals(context.getParam().get("use_export_file_name")) 
							&& StringUtils.isNotEmpty(context.getParam().get("export_file_name"))) {
						fileName = context.getParam().get("export_file_name").replaceAll(ConstantsUtil.Str.SPACE, ConstantsUtil.Str.UNDERLINE) + ".xlsx";
					} else {
						Map<String, Object> projectInfo = db.queryC("projects.getProjectInfo");
						fileName = StringUtils.toString(projectInfo.get("name")).replaceAll(ConstantsUtil.Str.SPACE, ConstantsUtil.Str.UNDERLINE) + "_issues_export.xlsx";
					}
					return fileName;
				}
			});
		} else {
			excelWriter = ExcelWriterFactory.getWriterX(context, new IExcelWriter.CreateFileName() {
				
				@Override
				public String create() throws SoftbankException {
					String fileName = null;
					if ("1".equals(context.getParam().get("use_export_file_name")) 
							&& StringUtils.isNotEmpty(context.getParam().get("export_file_name"))) {
						fileName = context.getParam().get("export_file_name").replaceAll(ConstantsUtil.Str.SPACE, ConstantsUtil.Str.UNDERLINE) + ".xlsx";
					} else {
						Map<String, Object> projectInfo = db.queryC("projects.getProjectInfo");
						fileName = StringUtils.toString(projectInfo.get("name")).replaceAll(ConstantsUtil.Str.SPACE, ConstantsUtil.Str.UNDERLINE) + "_issues_export.xlsx";
					}
					return fileName;
				}
			});
		}
		excelWriter.setCellAnalysis(new IExcelWriter.CellAnalysis() {
			
			@Override
			public void analysis(Cell cell, Map<String, Object> data, String key, String cellValue, int index) {
				if (key.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) == 0) {
					MappingData mappingData = exportMapping.getMappingData(key);
					Map<String, Object> option = mappingData.getOption();
					String type = StringUtils.toString(option.get("type"));
					if ("int".equals(type)) {
						if (StringUtils.isNotEmpty(cellValue)) {
							try {
								cell.setCellValue(StringUtils.toInt(cellValue));
							} catch (Exception e) {
								cell.setCellValue("");
							}
						} else {
							cell.setCellValue(cellValue);
						}
					} else if ("float".equals(type)) {
						if (StringUtils.isEmpty(cellValue)) {
							cell.setCellValue(cellValue);
						} else {
							BigDecimal value = new BigDecimal(0);
							if (StringUtils.isNotEmpty(cellValue)) {
								value = new BigDecimal(cellValue);
							}
							cell.setCellValue(value.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
						}
					} else {
						cell.setCellValue(cellValue);
					}
				} else {
					if (IssueKey.SUBJECT.KEY_JSON.equals(key)) {
						String floors = StringUtils.toString(data.get("t0_parent_id"));
						int floor = floors.split(ConstantsUtil.Str.SPACE).length;
						if (floor == (index + 1)) {
							cell.setCellValue(cellValue);
						} else {
							if (index < floor) {
								List<String> subjectList = (List<String>)data.get("subjectList");
								if (subjectList != null && subjectList.size() > index) {
									cell.setCellValue(subjectList.get(index));
								} else {
									cell.setCellValue(ConstantsUtil.Str.EMPTY);
								}
							} else {
								cell.setCellValue(ConstantsUtil.Str.EMPTY);
							}
						}
					} else if (IssueKey.DONE_RATIO.KEY_JSON.equals(key)) {
						BigDecimal doneRatio = new BigDecimal(0);
						if (StringUtils.isNotEmpty(cellValue)) {
							doneRatio = new BigDecimal(cellValue);
						}
						doneRatio = doneRatio.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
						cell.setCellValue(doneRatio.doubleValue());
					} else if (IssueKey.ESTIMATED_HOURS.KEY_JSON.equals(key)) {
						BigDecimal estimatedHours = new BigDecimal(0);
						if (StringUtils.isNotEmpty(cellValue)) {
							estimatedHours = new BigDecimal(cellValue);
						}
						cell.setCellValue(estimatedHours.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
					} else if (IssueKey.ISSUE_ID.KEY_JSON.equals(key)) {
						if (StringUtils.isNotEmpty(cellValue)) {
							cell.setCellValue(StringUtils.toInt(cellValue));
						} else {
							cell.setCellValue(cellValue);
						}
					} else if (IssueKey.PARENT_ID.KEY_JSON.equals(key)) {
						if (StringUtils.isNotEmpty(cellValue)) {
							cell.setCellValue(StringUtils.toInt(cellValue));
						} else {
							cell.setCellValue(cellValue);
						}
					} else if (IssueKey.DESCRIPTION.KEY_JSON.equals(key)) {
						if (StringUtils.isNotEmpty(cellValue)) {
							String deString = cellValue.replaceAll("\r", "");
							cell.setCellValue(deString);
						} else {
							cell.setCellValue(cellValue);
						}
					} else {
						cell.setCellValue(cellValue);
					}
				}
			}
		}).setCellFormat(new IExcelWriter.CellFormat() {
			
			@Override
			public CellStyle format(Workbook wb, Cell cell, Map<String, Object> data, String key, CellStyle style) {
				if (key.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) == 0) {
					MappingData mappingData = exportMapping.getMappingData(key);
					Map<String, Object> option = mappingData.getOption();
					String type = StringUtils.toString(option.get("type"));
					if ("string".equals(type)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("@"));
						cell.setCellStyle(style);
					} else if ("int".equals(type)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("#0"));
						cell.setCellStyle(style);
					} else if ("float".equals(type)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("#0.00"));
						cell.setCellStyle(style);
					}
				} else {
					if (IssueKey.DONE_RATIO.KEY_JSON.equals(key)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("0%"));
						cell.setCellStyle(style);
					} else if (IssueKey.ESTIMATED_HOURS.KEY_JSON.equals(key)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("#0.00"));
						cell.setCellStyle(style);
					} else if (IssueKey.ISSUE_ID.KEY_JSON.equals(key)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("#0"));
						cell.setCellStyle(style);
					} else if (IssueKey.PARENT_ID.KEY_JSON.equals(key)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("#0"));
						cell.setCellStyle(style);
					} else if (IssueKey.ASSIGNED_TO_ID.KEY_JSON.equals(key)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("@"));
						cell.setCellStyle(style);
					} else if (IssueKey.DESCRIPTION.KEY_JSON.equals(key)) {
						DataFormat format = wb.createDataFormat();
						style = wb.createCellStyle();
						style.setDataFormat(format.getFormat("@"));
						cell.setCellStyle(style);
					}
				}
				return style;
			}
		});
		return excelWriter;
	}
	
	@SuppressWarnings("unchecked")
	private void checkRequired(int colIndex, String value, String key, MappingContext mappingContext, Map<String, Object> data) throws SoftbankException {
		if (mappingContext.isRequired(colIndex)) {
			if (StringUtils.isEmpty(value)) {
				if (key.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) == 0) {
					if (!ControlSettingMap.getInstance().isCheckCustom(context.getParam().projectId)) {
						return;
					}
					if (!mappingContext.customExsit(key, data)) {
						return;
					}
				}
				if (!data.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
					Map<String, String> checkErrMap = Maps.newHashMap();
					data.put(TICKET_IMPORT_FILE_ERROR_INFOS_KEY, checkErrMap);
				}
				String errorMsg = messageAccessor.getMessage("errors.required", new String[] {mappingContext.getLabel(colIndex)}, context);
				((Map<String, String>)data.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)).put(key, errorMsg);
			} else {
				if (data.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
					Map<String, String> checkErrMap = (Map<String, String>)data.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
					if (checkErrMap.containsKey(key)) {
						checkErrMap.remove(key);
					}
				}
			}
		}
	}

	private List<Map<String, Object>> getDefaultTestphase() throws SoftbankException {
		List<Map<String, Object>> result = Lists.newArrayList();
		List<Map<String, Object>> testPhases = db.querys("test_phases.getTestPhasesForCmb");
		for (int i = 0; i < testPhases.size(); i++) {
			Map<String, Object> option = Maps.newHashMap();
			String label = StringUtils.toString(testPhases.get(i).get("label"));
			option.put("value", label);
			option.put("label", label);
			result.add(option);
		}
		return result;
	}
	
	private List<Map<String, Object>> getDefaultPhases() throws SoftbankException {
		List<Map<String, Object>> result = Lists.newArrayList();
		List<Map<String, Object>> phases = db.querys("phases.getPhasesForCmb");
		for (int i = 0; i < phases.size(); i++) {
			Map<String, Object> option = Maps.newHashMap();
			String label = StringUtils.toString(phases.get(i).get("label"));
			option.put("value", label);
			option.put("label", label);
			result.add(option);
		}
		return result;
	}
	
	private List<Map<String, Object>> getDefaultMembers() throws SoftbankException {
		List<Map<String, Object>> result = Lists.newArrayList();
		List<Map<String, Object>> members = db.querys("users.getMembersForCmb");
		for (int i = 0; i < members.size(); i++) {
			Map<String, Object> option = Maps.newHashMap();
			String label = StringUtils.toString(members.get(i).get("label"));
			option.put("value", label);
			option.put("label", label);
			result.add(option);
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	private void analyzeExcelRows(List<RowInfoBean> rows, MappingContext mappingContext) throws SoftbankException {
		if (rows.size() > 1) {
			
			int headerRow = 0;
			String templateId = context.getParam().get("import_template_file");
			Map<String, Object> templateMap = getTemplateData(templateId);
			if (!templateMap.isEmpty()) {
				headerRow = StringUtils.toInt(templateMap.get("header_row")) - 1;
			}
			
			List<Map<String, Object>> dataMappingResult = Lists.newArrayList();
			List<Map<String, Object>> errorMappingResult = Lists.newArrayList();
			for (int i = headerRow; i < rows.size(); i++) {
				RowInfoBean rowInfoBean = rows.get(i);
				if (i == headerRow) {
					mappingContext.setLabels(getLables(rowInfoBean.getCells()));
					continue;
				}
				Map<String, Object> rowMappingMap = Maps.newHashMap();
				rowMappingMap.put("index", rowInfoBean.getIndex() - headerRow);
				mappingContext.clear();
				boolean addFlag = analyzeExcelCells(rowInfoBean.getCells(), rowMappingMap, mappingContext);
				if (!addFlag) {
					continue;
				}
				dataMappingResult.add(rowMappingMap);
				String startD = mappingContext.getTemporaryRecordValue(IssueKey.START_DATE.KEY_JSON);
				String endD = mappingContext.getTemporaryRecordValue(IssueKey.DUE_DATE.KEY_JSON);
				checkDateDiff(mappingContext, rowMappingMap, startD, endD);
				String status = mappingContext.getTemporaryRecordValue(IssueKey.STATUS_ID.KEY_JSON);
				String doneRatio = mappingContext.getTemporaryRecordValue(IssueKey.DONE_RATIO.KEY_JSON);
				checkStatusAndDoneRatio(mappingContext, rowMappingMap, status, doneRatio);
				if (rowMappingMap.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY) && ((Map<String, String>)rowMappingMap.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)).size() > 0) {
					errorMappingResult.add(rowMappingMap);
				}
			}
			context.getSessionData().set(TICKET_IMPORT_FILE_INFOS, dataMappingResult);
			context.getSessionData().set(TICKET_IMPORT_FILE_ERROR_INFOS, errorMappingResult);
			context.getSessionData().set(TICKET_IMPORT_FILE_MAPPING_CONTEXT, mappingContext);
		}
	}

	private Map<String, Object> getTemplateData(String templateId) throws SoftbankException {
		Map<String, Object> templateMap = Maps.newHashMap();
		if (!"".equals(templateId)) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("id", StringUtils.toInt(templateId));
			List<Map<String, Object>> templateList = db.querys("template.getImportFileTemplateInfo", conditions);
			if ( templateList.size() > 0) {
				templateMap = templateList.get(0);
			}
		}
		return templateMap;
	}

	@SuppressWarnings("unchecked")
	private void checkDateDiff(MappingContext mappingContext, Map<String, Object> rowMappingMap, String startD, String endD) throws SoftbankException {
		if (StringUtils.isEmpty(startD) || StringUtils.isEmpty(endD)) {
			return;
		}
		String errorMsg = messageAccessor.getMessage("errors.compareError", new String[] {
				mappingContext.getLabel(mappingContext.getTemporaryRecordIndex(IssueKey.DUE_DATE.KEY_JSON)),
				mappingContext.getLabel(mappingContext.getTemporaryRecordIndex(IssueKey.START_DATE.KEY_JSON)),
		}, context);
		if (rowMappingMap.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
			Map<String, String> checkErrMap = (Map<String, String>)rowMappingMap.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
			if ((checkErrMap.containsKey(IssueKey.START_DATE.KEY_JSON) && !errorMsg.equals(checkErrMap.get(IssueKey.START_DATE.KEY_JSON))) 
					|| (checkErrMap.containsKey(IssueKey.DUE_DATE.KEY_JSON)) && !errorMsg.equals(checkErrMap.get(IssueKey.DUE_DATE.KEY_JSON))) {
				return;
			}
		}
		Date startDate = DateUtils.formatToDate(startD, DateUtils.FORMAT_YMD2);
		Date endDate = DateUtils.formatToDate(endD, DateUtils.FORMAT_YMD2);
		if (startDate.compareTo(endDate) > 0) {
			Map<String, String> checkErrMap = Maps.newHashMap();
			if (!rowMappingMap.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
				rowMappingMap.put(TICKET_IMPORT_FILE_ERROR_INFOS_KEY, checkErrMap);
			} else {
				checkErrMap = (Map<String, String>)rowMappingMap.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
			}
			checkErrMap.put(IssueKey.START_DATE.KEY_JSON, errorMsg);
			checkErrMap.put(IssueKey.DUE_DATE.KEY_JSON, errorMsg);
		} else {
			if (rowMappingMap.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
				Map<String, String> checkErrMap = (Map<String, String>)rowMappingMap.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
				if (checkErrMap.containsKey(IssueKey.START_DATE.KEY_JSON)) {
					checkErrMap.remove(IssueKey.START_DATE.KEY_JSON);
				}
				if (checkErrMap.containsKey(IssueKey.DUE_DATE.KEY_JSON)) {
					checkErrMap.remove(IssueKey.DUE_DATE.KEY_JSON);
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private void checkStatusAndDoneRatio(MappingContext mappingContext, Map<String, Object> rowMappingMap, String status, String doneRatio) {
		if (StringUtils.isEmpty(status) || StringUtils.isEmpty(doneRatio)) {
			return;
		}
		String errorMsg = messageAccessor.getMessage("errors.contentNotFix", new String[] {
				mappingContext.getLabel(mappingContext.getTemporaryRecordIndex(IssueKey.STATUS_ID.KEY_JSON)),
				mappingContext.getLabel(mappingContext.getTemporaryRecordIndex(IssueKey.DONE_RATIO.KEY_JSON)),
		}, context);
		if (rowMappingMap.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
			Map<String, String> checkErrMap = (Map<String, String>)rowMappingMap.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
			if ((checkErrMap.containsKey(IssueKey.STATUS_ID.KEY_JSON) && !errorMsg.equals(checkErrMap.get(IssueKey.STATUS_ID.KEY_JSON))) 
					|| (checkErrMap.containsKey(IssueKey.DONE_RATIO.KEY_JSON)) && !errorMsg.equals(checkErrMap.get(IssueKey.DONE_RATIO.KEY_JSON))) {
				return;
			}
		}
		Map<String, Object> statusData = mappingContext.getStatusData(status);
		String defaultDoneRatio = StringUtils.toString(statusData.get("default_done_ratio"));
		String id = StringUtils.toString(statusData.get("id"));
		boolean checkFlg = true;
		if (StringUtils.isNotEmpty(defaultDoneRatio) && !defaultDoneRatio.equals(doneRatio)) {
			if (!"2".equals(id)){
				checkFlg = false;
			} else {
				if ("100".equals(doneRatio) || "0".equals(doneRatio)) {
					checkFlg = false;
				}
			}
		}
		
		if (!checkFlg) {
			Map<String, String> checkErrMap = Maps.newHashMap();
			if (!rowMappingMap.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
				rowMappingMap.put(TICKET_IMPORT_FILE_ERROR_INFOS_KEY, checkErrMap);
			} else {
				checkErrMap = (Map<String, String>)rowMappingMap.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
			}
			checkErrMap.put(IssueKey.STATUS_ID.KEY_JSON, errorMsg);
			checkErrMap.put(IssueKey.DONE_RATIO.KEY_JSON, errorMsg);
		} else {
			if (rowMappingMap.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
				Map<String, String> checkErrMap = (Map<String, String>)rowMappingMap.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
				if (checkErrMap.containsKey(IssueKey.STATUS_ID.KEY_JSON)) {
					checkErrMap.remove(IssueKey.STATUS_ID.KEY_JSON);
				}
				if (checkErrMap.containsKey(IssueKey.DONE_RATIO.KEY_JSON)) {
					checkErrMap.remove(IssueKey.DONE_RATIO.KEY_JSON);
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void refreshErrorMapping(List<Map<String, Object>> resultDataList) {
		List<Map<String, Object>> errorMappingResult = Lists.newArrayList();
		for (int i = 0; i < resultDataList.size(); i++) {
			if (resultDataList.get(i).containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY) && !(resultDataList.get(i).get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY) instanceof String) && ((Map<String, String>)resultDataList.get(i).get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)).size() > 0) {
				errorMappingResult.add(resultDataList.get(i));
			}
		}
		context.getSessionData().set(TICKET_IMPORT_FILE_ERROR_INFOS, errorMappingResult);
	}

	private String[] getLables(List<CellInfoBean> cells) {
		String[] labels = new String[cells.size()];
		for (int i = 0; i < cells.size(); i++) {
			labels[i] = cells.get(i).getContent();
		}
		return labels;
	}

	@SuppressWarnings("unchecked")
	private boolean analyzeExcelCells(List<CellInfoBean> cells, Map<String, Object> rowMappingMap, MappingContext mappingContext) throws SoftbankException {
		boolean result = false;
		int index = 0;
		if (cells.size() > 0) {
			for (int i = 0; i < cells.size(); i++) {
				CellInfoBean cellInfoBean = cells.get(i);
				String content = cellInfoBean.getContent();
				if (mappingContext.isDate(i)) {
					if (cellInfoBean.getDate() != null) {
						content = DateUtils.makeFormat(cellInfoBean.getDate(), DateUtils.FORMAT_YMD2);
					}
				}
				String dataInx = mappingContext.getDataInx(i);
				if (StringUtils.isEmpty(dataInx)) {
					continue;
				}
				if (rowMappingMap.containsKey(dataInx) && StringUtils.isNotEmpty(rowMappingMap.get(dataInx)) && StringUtils.isEmpty(content)) {
					index++;
					continue;
				}
				checkRequired(i, content, dataInx, mappingContext, rowMappingMap);
				doDataChecker(i, content, dataInx, mappingContext, rowMappingMap);
				if ((!rowMappingMap.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY) 
						|| !((Map<String, String>)rowMappingMap.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)).containsKey(dataInx)) 
						&& StringUtils.isNotEmpty(content)) {
					content = mappingContext.doAnalyze(i, content);
				}
				rowMappingMap.put(dataInx, content);
				if (StringUtils.isNotEmpty(content)) {
					rowMappingMap.put(INDEX_SIGN + dataInx, index);
					result = true;
				}
				index++;
			}
		}
		return result;
	}
	
	private void doDataChecker(int colIndex, String value, String key, MappingContext mappingContext, Map<String, Object> data) {
		if (data.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY) 
				&& ((Map<String, String>)data.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)).containsKey(key)) {
			return;
		}
		CheckResultType checkResult = mappingContext.doChecker(key, value, data);
		if (checkResult != CheckResultType.none) {
			Map<String, String> checkErrMap = null;
			if (!data.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
				checkErrMap = Maps.newHashMap();
				data.put(TICKET_IMPORT_FILE_ERROR_INFOS_KEY, checkErrMap);
			} else {
				checkErrMap = (Map<String, String>)data.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
				if (checkErrMap.containsKey(key)) {
					return;
				}
			}
			String errorMsg = null;
			switch (checkResult) {
			case optionNotExist:
				errorMsg = messageAccessor.getMessage("errors.optionNotExist", new String[] {mappingContext.getLabel(colIndex), value}, context);
				break;
			case dateFormat:
				errorMsg = messageAccessor.getMessage("errors.date", new String[] {mappingContext.getLabel(colIndex)}, context);
				break;
			case floatFormat:
				errorMsg = messageAccessor.getMessage("errors.float", new String[] {mappingContext.getLabel(colIndex)}, context);
				break;
			case integerFormat:
				errorMsg = messageAccessor.getMessage("errors.integer", new String[] {mappingContext.getLabel(colIndex)}, context);
				break;

			default:
				break;
			}
			checkErrMap.put(key, errorMsg);
		} else {
			if (data.containsKey(TICKET_IMPORT_FILE_ERROR_INFOS_KEY)) {
				Map<String, String> checkErrMap = (Map<String, String>)data.get(TICKET_IMPORT_FILE_ERROR_INFOS_KEY);
				if (checkErrMap.containsKey(key)) {
					checkErrMap.remove(key);
				}
			}
		}
	}

	private void readImportFileInfo(Map<String, Object> resultMap) throws SoftbankException {
		
		int headerRow = 0;
		String templateId = context.getParam().get("import_template_file");
		Map<String, Object> templateMap = getTemplateData(templateId);
		if (!templateMap.isEmpty()) {
			headerRow = StringUtils.toInt(templateMap.get("header_row"));
		}
		
		String realPath = context.getSessionData().getString(TICKET_IMPORT_FILE_PATH);
		int sheetIndex = StringUtils.toInt(context.getParam().get("ticket_import_sheet_name"));
		resultMap.put("fileTitles", (ExcelReaderFactory.getReader(new File(realPath))).getSheetFirstRowInfos(
				sheetIndex, new ExcelInfoBean.DiffAnalizy() {
					
					@Override
					public void addFirstRowCellName(List<String[]> firstRowCellNames, String cellName, int index) {
						if ("題名".equals(cellName)) {
							String[] data = firstRowCellNames.get(firstRowCellNames.size() - 1);
							data[0] = data[0] + '@' + index;
						}
					}
				}, headerRow).getFirstRowCellNames());
		context.getSessionData().set(TICKET_IMPORT_FILE_SHEET_NAME, sheetIndex);
	}
	
	private List<Map<String, Object>> createDefaultOption() {
		return createDefaultOption(1, false);
	}

	private List<Map<String, Object>> createDefaultOption(int floor, boolean isExport) {
		List<Map<String, Object>> result = Lists.newArrayList();
		Map<String, Object> optionMap = null;
		for (int i = 0; i < floor; i++) {
			optionMap = Maps.newHashMap();
			optionMap.put("value", IssueKey.SUBJECT.KEY_JSON);
			optionMap.put("label", "題名");
			result.add(optionMap);
		}
		
		if (isExport) {
			optionMap = Maps.newHashMap();
			optionMap.put("value", "project");
			optionMap.put("label", "プロジェクト");
			result.add(optionMap);
		}

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.ISSUE_ID.KEY_JSON);
		if (isExport) {
			optionMap.put("label", "#");
		} else {
			optionMap.put("label", "チケットID");
		}
		result.add(optionMap);

//		optionMap = Maps.newHashMap();
//		optionMap.put("value", IssueKey.PARENT_ID.KEY_JSON);
//		optionMap.put("label", "親チケット");
//		result.add(optionMap);

		if (isExport) {
			optionMap = Maps.newHashMap();
			optionMap.put("value", IssueKey.PARENT_ID.KEY_JSON);
			optionMap.put("label", "親チケット");
			result.add(optionMap);
		}
		
		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.TRACKER_ID.KEY_JSON);
		optionMap.put("label", "トラッカー");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.STATUS_ID.KEY_JSON);
		optionMap.put("label", "ステータス");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.START_DATE.KEY_JSON);
		optionMap.put("label", "開始日");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.DUE_DATE.KEY_JSON);
		optionMap.put("label", "期日");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.ASSIGNED_TO_ID.KEY_JSON);
		optionMap.put("label", "担当者");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.ESTIMATED_HOURS.KEY_JSON);
		optionMap.put("label", "予定工数");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.DONE_RATIO.KEY_JSON);
		optionMap.put("label", "進捗 %");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.PRIORITY_ID.KEY_JSON);
		optionMap.put("label", "優先度");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.AUTHOR_ID.KEY_JSON);
		optionMap.put("label", "作成者");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.FIXED_VERSION_ID.KEY_JSON);
		optionMap.put("label", "対象バージョン");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.DESCRIPTION.KEY_JSON);
		optionMap.put("label", "説明");
		result.add(optionMap);

		optionMap = Maps.newHashMap();
		optionMap.put("value", IssueKey.CATEGORY_ID.KEY_JSON);
		optionMap.put("label", "カテゴリ");
		result.add(optionMap);
		
		if (isExport) {
			optionMap = Maps.newHashMap();
			optionMap.put("value", "t1_updated_on");
			optionMap.put("label", "更新日");
			result.add(optionMap);
		}

		return result;
	}
	
	private static class MappingContext {
		private HttpContext context;
		private IDbExecute db;
		private Map<Integer, Map<String, Object>> customMap;
		private Map<String, Map<String, Object>> issueStatusMap = Maps.newHashMap();
		private Map<Integer, MappingData> indexMap;
		private Map<String, Integer> dataIndexMap = Maps.newHashMap();
		private String[] labels;
		private List<Map<String, String>> mappingTitleList = Lists.newArrayList();
		private Map<String, String> specialTypeMap = Maps.newHashMap();
		private Map<String, Map<String, String>> cmbMapping = Maps.newHashMap();
		private Map<String, Map<String, Object>> listLinkMapping = Maps.newHashMap();
		private List<String> customLinkOrder = Lists.newArrayList();
		private Map<String, TemporaryRecord> temporaryRecordMap = Maps.newHashMap();
		private List<String> requiredTypeList = Lists.newArrayList(
				IssueKey.SUBJECT.KEY_JSON,
				IssueKey.TRACKER_ID.KEY_JSON,
				IssueKey.STATUS_ID.KEY_JSON,
				IssueKey.START_DATE.KEY_JSON,
				IssueKey.DUE_DATE.KEY_JSON,
				IssueKey.DONE_RATIO.KEY_JSON,
				IssueKey.ESTIMATED_HOURS.KEY_JSON,
				IssueKey.PRIORITY_ID.KEY_JSON);
		private List<String> dateTypeList = Lists.newArrayList(
				IssueKey.START_DATE.KEY_JSON,
				IssueKey.DUE_DATE.KEY_JSON);
		private List<String> temporaryRecordList = Lists.newArrayList(
				IssueKey.STATUS_ID.KEY_JSON,
				IssueKey.DONE_RATIO.KEY_JSON,
				IssueKey.START_DATE.KEY_JSON,
				IssueKey.DUE_DATE.KEY_JSON);

		public void create(HttpContext context, IDbExecute db) throws SoftbankException {
			this.context = context;
			this.db = db;
			createCustomMap();
			createStatusMap();
			createIndexMap();
			createSpecialTypeMap();
			createMapping();
			createListlinkOptions();
		}

		public void clear() {
			temporaryRecordMap.clear();
		}

		public Map<Integer, Map<String, Object>> getCustomMap() {
			return customMap;
		}
		
		public boolean customExsit(String dataInx, Map<String, Object> data) {
			int cid = StringUtils.toInt(dataInx.substring(IssueKey.CUSTOMVALUES.KEY_JSON.length()));
			if (!customMap.containsKey(cid)) {
				return false;
			}
			if (StringUtils.isEmpty(data.get(IssueKey.TRACKER_ID.KEY_JSON))) {
				return false;
			}
			Map<String, Object> cinfo = customMap.get(cid);
			String trackerName = StringUtils.toString(cinfo.get("tracker_name"));
			if (!trackerName.equals(StringUtils.toString(data.get(IssueKey.TRACKER_ID.KEY_JSON)))) {
				return false;
			}
			return true;
		}

		public void setCustomMap(Map<Integer, Map<String, Object>> customMap) {
			this.customMap = customMap;
		}

		public String getLabel(int index) {
			return labels[index];
		}

		public String[] getLabels() {
			return labels;
		}

		public List<Map<String, String>> getMappingTitleList() {
			return mappingTitleList;
		}

		public void setLabels(String[] labels) {
			this.labels = labels;
			for (int i = 0; i < labels.length; i++) {
				String dataInx = getDataInx(i);
				if (StringUtils.isNotEmpty(dataInx)) {
					String type = "";
					String possibleValues = "";
					if (dataInx.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) == 0) {
						int cid = StringUtils.toInt(dataInx.substring(IssueKey.CUSTOMVALUES.KEY_JSON.length()));
						if (customMap.containsKey(cid)) {
							Map<String, Object> cinfo = customMap.get(cid);
							type = StringUtils.toString(cinfo.get("type"));
							possibleValues = StringUtils.toString(cinfo.get("possible_values"));
						}
					} else {
						type = specialTypeMap.get(dataInx);
					}
					Map<String, String> mappingTitle = Maps.newHashMap();
					mappingTitle.put("dataInx", dataInx);
					mappingTitle.put("label", labels[i]);
					mappingTitle.put("c_index", StringUtils.toString(i));
					mappingTitle.put("possible_values", possibleValues);
					if ("phase".equals(type)) {
						type = "list";
						mappingTitle.put("type2", "phase");
					} else if ("testphase".equals(type)) {
						type = "list";
						mappingTitle.put("type2", "testphase");
					} else if ("user".equals(type)) {
						type = "list";
						mappingTitle.put("type2", "user");
					}
					mappingTitle.put("type", type);
					mappingTitleList.add(mappingTitle);
				}
			}
		}

		public boolean isRequired(int index) {
			if (indexMap.containsKey(index) && indexMap.get(index).isRequired()) {
				return true;
			}
			return false;
		}

		public boolean isDate(int index) {
			if (indexMap.containsKey(index) && indexMap.get(index).isDate()) {
				return true;
			}
			return false;
		}

		public String getDataInx(int index) {
			if (indexMap.containsKey(index)) {
				return indexMap.get(index).getDataInx();
			}
			return null;
		}

		public String getTemporaryRecordValue(String dataInx) {
			if (temporaryRecordMap.containsKey(dataInx)) {
				return temporaryRecordMap.get(dataInx).getValue();
			}
			return null;
		}

		public int getTemporaryRecordIndex(String dataInx) {
			if (temporaryRecordMap.containsKey(dataInx)) {
				return temporaryRecordMap.get(dataInx).getIndex();
			}
			return -1;
		}

		public String doAnalyze(int index, String value) {
			if (indexMap.containsKey(index)) {
				Analyze analyze = indexMap.get(index).getAnalyze();
				if (analyze != null) {
					value = analyze.execute(value);
				}
				String dataInx = getDataInx(index);
				if (temporaryRecordList.contains(dataInx)) {
					TemporaryRecord temporaryRecord = new TemporaryRecord();
					temporaryRecord.setIndex(index);
					temporaryRecord.setValue(value);
					temporaryRecordMap.put(dataInx, temporaryRecord);
				}
			}
			return value;
		}
		
		public boolean hasConversion(String dataIndx) {
			if (!dataIndexMap.containsKey(dataIndx)) {
				return false;
			}
			int index = dataIndexMap.get(dataIndx);
			if (!indexMap.containsKey(index)) {
				return false;
			}
			if (indexMap.get(index).getConversion() == null) {
				return false;
			}
			return true;
		}
		
		public int getIndexByData(String dataIndx) {
			if (!dataIndexMap.containsKey(dataIndx)) {
				return -1;
			}
			return dataIndexMap.get(dataIndx);
		}
		
		public String doConversion(String dataIndx, String value, Map<String, Object> data) {
			if (!dataIndexMap.containsKey(dataIndx)) {
				return value;
			}
			int index = dataIndexMap.get(dataIndx);
			if (indexMap.containsKey(index)) {
				Conversion conversion = indexMap.get(index).getConversion();
				if (conversion != null) {
					conversion.setDataIndx(dataIndx);
					value = conversion.execute(value, data);
				}
			}
			return value;
		}
		
		public CheckResultType doChecker(String dataIndx, String value, Map<String, Object> data) {
			if (!dataIndexMap.containsKey(dataIndx)) {
				return CheckResultType.none;
			}
			int index = dataIndexMap.get(dataIndx);
			if (indexMap.containsKey(index) && StringUtils.isNotEmpty(value)) {
				Checker checker = indexMap.get(index).getChecker();
				if (checker != null) {
					return checker.execute(value, dataIndx, data);
				}
			}
			return CheckResultType.none;
		}
		
		public Map<String, Object> getStatusData(String statusName) {
			return issueStatusMap.get(statusName);
		}
		
		public List<String> getCustomLinkOrder() {
			return customLinkOrder;
		}

		private void createCustomMap() throws SoftbankException {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("project_id", context.getParam().projectId);
			List<Map<String, Object>> customs = db.querys("issues.getCustomFieldsForCmb", conditions);
			if (customs != null && customs.size() > 0) {
				customMap = Maps.newHashMap();
				for (int i = 0; i < customs.size(); i++) {
					Map<String, Object> custom = customs.get(i);
					customMap.put(StringUtils.toInt(custom.get("id")), custom);
				}
			}
		}
		
		private void createStatusMap() throws SoftbankException {
			List<Map<String, Object>> issueStatus = db.querys("issue_statuses.getIssueStatusesInfos");
			for (int i = 0; i < issueStatus.size(); i++) {
				Map<String, Object> issueStatusData = issueStatus.get(i);
				String issuestatusName = StringUtils.toString(issueStatusData.get("name"));
				issueStatusMap.put(issuestatusName, issueStatusData);
			}
		}

		private void createSpecialTypeMap() {
			specialTypeMap.put(IssueKey.ISSUE_ID.KEY_JSON, "int");
			specialTypeMap.put(IssueKey.SUBJECT.KEY_JSON, "string");
			specialTypeMap.put(IssueKey.TRACKER_ID.KEY_JSON, "list");
			specialTypeMap.put(IssueKey.STATUS_ID.KEY_JSON, "list");
			specialTypeMap.put(IssueKey.START_DATE.KEY_JSON, "date");
			specialTypeMap.put(IssueKey.DUE_DATE.KEY_JSON, "date");
			specialTypeMap.put(IssueKey.ASSIGNED_TO_ID.KEY_JSON, "list");
			specialTypeMap.put(IssueKey.ESTIMATED_HOURS.KEY_JSON, "int");
			specialTypeMap.put(IssueKey.DONE_RATIO.KEY_JSON, "int");
			specialTypeMap.put(IssueKey.PRIORITY_ID.KEY_JSON, "list");
			specialTypeMap.put(IssueKey.FIXED_VERSION_ID.KEY_JSON, "list");
			specialTypeMap.put(IssueKey.AUTHOR_ID.KEY_JSON, "list");
			specialTypeMap.put(IssueKey.DESCRIPTION.KEY_JSON, "area");
		}
		
		private void createMapping() throws SoftbankException {
			int projectId = context.getParam().projectId;
			cmbMapping.put("memberMap", getMembersMapping());
			cmbMapping.put("phasesMap", getPhasesMapping());
			cmbMapping.put("testphasesMap", getTestphaseMapping());
			cmbMapping.put("versionsMap", getVersionsMapping());
			cmbMapping.put("trackerInfoMap", getTrackerInfoMapping(projectId));
			cmbMapping.put("issueStatusesMap", getIssueStatusesMapping());
			cmbMapping.put("issuePriorityMap", getIssuePriorityMapping());
		}
		
		private void createListlinkOptions() throws SoftbankException {
			List<Map<String, Object>> listlinks = db.querys("custom_field_links.selectfieldsInfoByProjectId");
			if (listlinks == null || listlinks.size() == 0) {
				return;
			}
			Map<String, Object> filedMap = null;
			for (int i = 0; i < listlinks.size(); i++) {
				Map<String, Object> data = listlinks.get(i);
				String custom_field_id = StringUtils.toString(data.get("custom_field_id"));
				if (!listLinkMapping.containsKey(custom_field_id)) {
					customLinkOrder.add(custom_field_id);
					filedMap = Maps.newHashMap();
					filedMap.put("pid", StringUtils.toString(data.get("parent_field_id")));
					listLinkMapping.put(custom_field_id, filedMap);
				}
				String id = StringUtils.toString(data.get("id"));
				String name = StringUtils.toString(data.get("name"));
				String parent_id = StringUtils.toString(data.get("parent_id"));
				String parent_name = StringUtils.toString(data.get("parent_name"));
				Map<String, String> opts = Maps.newHashMap();
				if (StringUtils.isEmpty(parent_name)) {
					if (filedMap.containsKey("opts")) {
						opts = (Map<String, String>)filedMap.get("opts");
					} else {
						filedMap.put("opts", opts);
					}
				} else {
					if (filedMap.containsKey(parent_id)) {
						opts = (Map<String, String>)filedMap.get(parent_id);
					} else {
						filedMap.put(parent_id, opts);
					}
				}
				opts.put(name, id);
			}
			
		}
		
		private Map<String, String> getMembersMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> members = db.querys("users.getMembersForCmb");
			for (int i = 0; i < members.size(); i++) {
				String label = StringUtils.toString(members.get(i).get("label"));
				String value = StringUtils.toString(members.get(i).get("value"));
				result.put(label, value);
			}
			return result;
		}
		
		
		
		private Map<String, String> getPhasesMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> phases = db.querys("phases.getPhasesForCmb");
			for (int i = 0; i < phases.size(); i++) {
				String label = StringUtils.toString(phases.get(i).get("label"));
				String value = StringUtils.toString(phases.get(i).get("value"));
				result.put(label, value);
			}
			return result;
		}
		
		private Map<String, String> getTestphaseMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> testPhases = db.querys("test_phases.getTestPhasesForCmb");
			for (int i = 0; i < testPhases.size(); i++) {
				String label = StringUtils.toString(testPhases.get(i).get("label"));
				String value = StringUtils.toString(testPhases.get(i).get("value"));
				result.put(label, value);
			}
			return result;
		}
		
		private Map<String, String> getVersionsMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> versions = db.querys("issues.getVersionsForCmb");
			for (int i = 0; i < versions.size(); i++) {
				String label = StringUtils.toString(versions.get(i).get("label"));
				String value = StringUtils.toString(versions.get(i).get("value"));
				result.put(label, value);
			}
			return result;
		}
		
		private Map<String, String> getTrackerInfoMapping(int projectId) throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("project_id", projectId);
			List<Map<String, Object>> trackers = db.querys("ticketList.getTrackerInfo", conditions);
			if (trackers != null) {
				for (int i = 0; i < trackers.size(); i++) {
					String label = StringUtils.toString(trackers.get(i).get("name"));
					String value = StringUtils.toString(trackers.get(i).get("id"));
					result.put(label, value);
				}
			}
			return result;
		}
		
		private Map<String, String> getIssueStatusesMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> issueStatuses = db.querys("issue_statuses.getIssueStatusesInfosForMapping");
			for (int i = 0; i < issueStatuses.size(); i++) {
				Map<String, Object> status = issueStatuses.get(i);
				result.put(StringUtils.toString(status.get("name")), StringUtils.toString(status.get("id")));
			}
			return result;
		}
		
		private Map<String, String> getIssuePriorityMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			result.put("深刻", "15");
			result.put("影響大", "16");
			result.put("影響小", "17");
			result.put("影響無し", "18");
			return result;
		}
		
		private void createIndexMap() {
			indexMap = Maps.newHashMap();
			JSONObject mappingDataObject = JSONObject.fromObject(context.getParam().get("mappingData"));
			for (Object key : mappingDataObject.keySet()) {
				MappingData mappingData = new MappingData();
				String keys = StringUtils.toString(key);
				String dataInx = mappingDataObject.getString(keys);
				mappingData.setDataInx(dataInx);
				if (dataInx.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) == 0) {
					createCustomMappingData(mappingData, dataInx);
				} else {
					createDefaultMappingData(mappingData, dataInx);
				}
				if (keys.indexOf("@") != -1) {
					String[] ks = keys.split("@");
					for (int i = 0; i < ks.length; i++) {
						int index = StringUtils.toInt(ks[i]);
						indexMap.put(index, mappingData);
						dataIndexMap.put(dataInx, index);
					}
				} else {
					int index = StringUtils.toInt(key);
					indexMap.put(index, mappingData);
					dataIndexMap.put(dataInx, index);
				}
			}
		}

		private void createDefaultMappingData(MappingData mappingData, String dataInx) {
			if (requiredTypeList.contains(dataInx)) {
				mappingData.setRequired(true);
			}
			if (dateTypeList.contains(dataInx)) {
				mappingData.setDate(true);
			}
			if (IssueKey.DONE_RATIO.KEY_JSON.equals(dataInx)) {
				mappingData.setAnalyze(new Analyze() {

					@Override
					public String execute(String value) {
						if (value.endsWith("%")) {
							return value.substring(0, value.length() - 1);
						}
						BigDecimal result = BigDecimal.valueOf(Double.parseDouble(value));
						return StringUtils.toString(result.multiply(BigDecimal.valueOf(100)).intValue());
					}
				});
				mappingData.setChecker(new Checker() {
					
					@Override
					public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
						if (value.endsWith("%")) {
							value = value.substring(0, value.length() - 1);
						}
						if (GenericTypeValidator.formatFloat(value) == null) {
							return CheckResultType.floatFormat;
						}
						return CheckResultType.none;
					}
				});
			} else if (IssueKey.ISSUE_ID.KEY_JSON.equals(dataInx)) {
				mappingData.setAnalyze(new Analyze() {

					@Override
					public String execute(String value) {
						return StringUtils.toString((int)Float.parseFloat(value));
					}
				});
			} else if (IssueKey.START_DATE.KEY_JSON.equals(dataInx) || IssueKey.DUE_DATE.KEY_JSON.equals(dataInx)) {
				mappingData.setChecker(new Checker() {
					
					@Override
					public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
						Date date = ValidationUtil.toDate(value, null, DateUtils.FORMAT_YMD2);
						if (date == null) {
							return CheckResultType.dateFormat;
						}
						return CheckResultType.none;
					}
				});
			} else if (IssueKey.PRIORITY_ID.KEY_JSON.equals(dataInx)) {
				mappingData.setConversion(new Conversion() {
					
					@Override
					public String execute(String value, Map<String, Object> data) {
						return MappingContext.this.cmbMapping.get("issuePriorityMap").get(value);
					}

					private String dataIndx;
					@Override
					public void setDataIndx(String dataIndx) {
						this.dataIndx = dataIndx;
					}
				});
				mappingData.setChecker(new Checker() {
					
					@Override
					public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
						if (!MappingContext.this.cmbMapping.get("issuePriorityMap").containsKey(value)) {
							return CheckResultType.optionNotExist;
						}
						return CheckResultType.none;
					}
				});
			} else if (IssueKey.STATUS_ID.KEY_JSON.equals(dataInx)) {
				mappingData.setConversion(new Conversion() {
					
					@Override
					public String execute(String value, Map<String, Object> data) {
						return MappingContext.this.cmbMapping.get("issueStatusesMap").get(value);
					}
					
					private String dataIndx;
					@Override
					public void setDataIndx(String dataIndx) {
						this.dataIndx = dataIndx;
					}
				});
				mappingData.setChecker(new Checker() {
					
					@Override
					public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
						if (!MappingContext.this.cmbMapping.get("issueStatusesMap").containsKey(value)) {
							return CheckResultType.optionNotExist;
						}
						return CheckResultType.none;
					}
				});
			} else if (IssueKey.TRACKER_ID.KEY_JSON.equals(dataInx)) {
				mappingData.setConversion(new Conversion() {
					
					@Override
					public String execute(String value, Map<String, Object> data) {
						return MappingContext.this.cmbMapping.get("trackerInfoMap").get(value);
					}
					
					private String dataIndx;
					@Override
					public void setDataIndx(String dataIndx) {
						this.dataIndx = dataIndx;
					}
				});
				mappingData.setChecker(new Checker() {
					
					@Override
					public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
						if (!MappingContext.this.cmbMapping.get("trackerInfoMap").containsKey(value)) {
							return CheckResultType.optionNotExist;
						}
						return CheckResultType.none;
					}
				});
			} else if (IssueKey.ASSIGNED_TO_ID.KEY_JSON.equals(dataInx)) {
				mappingData.setConversion(new Conversion() {
					
					@Override
					public String execute(String value, Map<String, Object> data) {
						return MappingContext.this.cmbMapping.get("memberMap").get(value);
					}
					
					private String dataIndx;
					@Override
					public void setDataIndx(String dataIndx) {
						this.dataIndx = dataIndx;
					}
				});
				mappingData.setChecker(new Checker() {
					
					@Override
					public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
						if (!MappingContext.this.cmbMapping.get("memberMap").containsKey(value)) {
							return CheckResultType.optionNotExist;
						}
						return CheckResultType.none;
					}
				});
			} else if (IssueKey.ESTIMATED_HOURS.KEY_JSON.equals(dataInx)) {
				mappingData.setAnalyze(new Analyze() {

					@Override
					public String execute(String value) {
						if (value.endsWith(".0")) {
							return value.substring(0, value.indexOf(".0"));
						}
						return value;
					}
				});
				mappingData.setConversion(new Conversion() {
					
					@Override
					public String execute(String value, Map<String, Object> data) {
						if (value.endsWith(".0")) {
							return value.substring(0, value.indexOf(".0"));
						}
						return value;
					}
					
					private String dataIndx;
					@Override
					public void setDataIndx(String dataIndx) {
						this.dataIndx = dataIndx;
					}
				});
				mappingData.setChecker(new Checker() {
					
					@Override
					public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
						if (GenericTypeValidator.formatFloat(value) == null) {
							return CheckResultType.floatFormat;
						}
						return CheckResultType.none;
					}
				});
			} else if (IssueKey.FIXED_VERSION_ID.KEY_JSON.equals(dataInx)) {
				mappingData.setConversion(new Conversion() {
					
					@Override
					public String execute(String value, Map<String, Object> data) {
						return MappingContext.this.cmbMapping.get("versionsMap").get(value);
					}
					
					private String dataIndx;
					@Override
					public void setDataIndx(String dataIndx) {
						this.dataIndx = dataIndx;
					}
				});
			} else if (IssueKey.AUTHOR_ID.KEY_JSON.equals(dataInx)) {
				mappingData.setConversion(new Conversion() {
					
					@Override
					public String execute(String value, Map<String, Object> data) {
						if (MappingContext.this.cmbMapping.get("memberMap").containsKey(value)) {
							if (value.indexOf(ConstantsUtil.Str.SPACE) != -1) {
								data.put(IssueKey.AUTHOR_FIRSTNAME.KEY_JSON, value.split(ConstantsUtil.Str.SPACE)[1]);
								data.put(IssueKey.AUTHOR_LASTNAME.KEY_JSON, value.split(ConstantsUtil.Str.SPACE)[0]);
							}
							value = MappingContext.this.cmbMapping.get("memberMap").get(value);
						} else {
							UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
							data.put(IssueKey.AUTHOR_FIRSTNAME.KEY_JSON, userInfoData.getFirstName());
							data.put(IssueKey.AUTHOR_LASTNAME.KEY_JSON, userInfoData.getLastName());
						}
						return value;
					}
					
					private String dataIndx;
					@Override
					public void setDataIndx(String dataIndx) {
						this.dataIndx = dataIndx;
					}
				});
				mappingData.setChecker(new Checker() {
					
					@Override
					public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
						if (!MappingContext.this.cmbMapping.get("memberMap").containsKey(value)) {
							return CheckResultType.optionNotExist;
						}
						return CheckResultType.none;
					}
				});
			}
		}

		private void createCustomMappingData(MappingData mappingData, String dataInx) {
			int cid = StringUtils.toInt(dataInx.substring(IssueKey.CUSTOMVALUES.KEY_JSON.length()));
			if (customMap.containsKey(cid)) {
				Map<String, Object> cinfo = customMap.get(cid);
				String type = StringUtils.toString(cinfo.get("type"));
				if (ConstantsUtil.Str.TRUE.equals(StringUtils.toString(cinfo.get("is_required")))) {
					mappingData.setRequired(true);
				}
				if ("date".equals(type)) {
					mappingData.setDate(true);
				} else if ("phase".equals(type)) {
					mappingData.setConversion(new Conversion() {
						
						@Override
						public String execute(String value, Map<String, Object> data) {
							return MappingContext.this.cmbMapping.get("phasesMap").get(value);
						}
						
						private String dataIndx;
						@Override
						public void setDataIndx(String dataIndx) {
							this.dataIndx = dataIndx;
						}
					});
				} else if ("testphase".equals(type)) {
					mappingData.setConversion(new Conversion() {
						
						@Override
						public String execute(String value, Map<String, Object> data) {
							return MappingContext.this.cmbMapping.get("testphasesMap").get(value);
						}
						
						private String dataIndx;
						@Override
						public void setDataIndx(String dataIndx) {
							this.dataIndx = dataIndx;
						}
					});
				} else if ("user".equals(type)) {
					mappingData.setConversion(new Conversion() {
						
						@Override
						public String execute(String value, Map<String, Object> data) {
							return MappingContext.this.cmbMapping.get("memberMap").get(value);
						}
						
						private String dataIndx;
						@Override
						public void setDataIndx(String dataIndx) {
							this.dataIndx = dataIndx;
						}
					});
				} else if ("listlink".equals(type)) {
					mappingData.setConversion(new Conversion() {
						
						@Override
						public String execute(String value, Map<String, Object> data) {
							Map<String, Object> linkMap = MappingContext.this.listLinkMapping.get(this.dataIndx);
							Map<String, String> dataMap = null;
							if (StringUtils.isEmpty(linkMap.get("pid"))) {
								dataMap = (Map<String, String>)linkMap.get("opts");
							} else {
								String pid = StringUtils.toString(linkMap.get("pid"));
								String pv = StringUtils.toString(data.get(pid));
								dataMap = (Map<String, String>)linkMap.get(pv);
							}
							if (dataMap == null) {
								return null;
							}
							return dataMap.get(value);
						}
						
						private String dataIndx;
						@Override
						public void setDataIndx(String dataIndx) {
							this.dataIndx = dataIndx;
						}
					});
					
					mappingData.setChecker(new Checker() {
						
						@Override
						public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
							if (StringUtils.isEmpty(value)) {
								return CheckResultType.none;
							}
							Map<String, Object> linkMap = MappingContext.this.listLinkMapping.get(dataIndx);
							Map<String, String> dataMap = null;
							if (StringUtils.isEmpty(linkMap.get("pid"))) {
								dataMap = (Map<String, String>)linkMap.get("opts");
							} else {
								String pid = StringUtils.toString(linkMap.get("pid"));
								String pv = StringUtils.toString(data.get("_ck" + pid));
								if (StringUtils.isEmpty(pv)) {
									return CheckResultType.optionNotExist;
								}
								dataMap = (Map<String, String>)linkMap.get(pv);
							}
							if (dataMap == null) {
								return CheckResultType.optionNotExist;
							}
							String optionVal = dataMap.get(value);
							if (StringUtils.isEmpty(optionVal)) {
								return CheckResultType.optionNotExist;
							}
							data.put("_ck" + dataIndx, optionVal);
							return CheckResultType.none;
						}
					});
				} else if ("int".equals(type)) {
					mappingData.setChecker(new Checker() {
						
						@Override
						public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
							if (GenericTypeValidator.formatFloat(value) == null) {
								return CheckResultType.floatFormat;
							}
							return CheckResultType.none;
						}
					});
					mappingData.setConversion(new Conversion() {
						
						@Override
						public String execute(String value, Map<String, Object> data) {
							if (value.endsWith(".0")) {
								return value.substring(0, value.indexOf(".0"));
							}
							return value;
						}
						
						private String dataIndx;
						@Override
						public void setDataIndx(String dataIndx) {
							this.dataIndx = dataIndx;
						}
					});
				} else if ("date".equals(type)) {
					mappingData.setChecker(new Checker() {
						
						@Override
						public CheckResultType execute(String value, String dataIndx, Map<String, Object> data) {
							Date date = ValidationUtil.toDate(value, null, DateUtils.FORMAT_YMD2);
							if (date == null) {
								return CheckResultType.dateFormat;
							}
							return CheckResultType.none;
						}
					});
				} else if ("bool".equals(type)) {
					mappingData.setConversion(new Conversion() {
						
						@Override
						public String execute(String value, Map<String, Object> data) {
							if (StringUtils.isEmpty(value)) {
								return value;
							}
							if ("はい".equals(value)) {
								value = "1";
							} else {
								value = "0";
							}
							return value;
						}
						
						private String dataIndx;
						@Override
						public void setDataIndx(String dataIndx) {
							this.dataIndx = dataIndx;
						}
					});
				}
			}
		}

	}

	private static class MappingData {
		private boolean required;

		private boolean date;

		private String dataInx;

		private Analyze analyze;
		
		private Conversion conversion;
		
		private Checker checker;
		
		private Map<String, Object> option;

		public boolean isRequired() {
			return required;
		}

		public void setRequired(boolean required) {
			this.required = required;
		}

		public String getDataInx() {
			return dataInx;
		}

		public void setDataInx(String dataInx) {
			this.dataInx = dataInx;
		}

		public boolean isDate() {
			return date;
		}

		public void setDate(boolean date) {
			this.date = date;
		}

		public Analyze getAnalyze() {
			return analyze;
		}

		public void setAnalyze(Analyze analyze) {
			this.analyze = analyze;
		}

		public Conversion getConversion() {
			return conversion;
		}

		public void setConversion(Conversion conversion) {
			this.conversion = conversion;
		}

		public Checker getChecker() {
			return checker;
		}

		public void setChecker(Checker checker) {
			this.checker = checker;
		}

		public Map<String, Object> getOption() {
			return option;
		}

		public void setOption(Map<String, Object> option) {
			this.option = option;
		}

	}

	private static interface Analyze {
		String execute(String value);
	}
	
	private static interface Conversion {
		void setDataIndx(String dataIndx);
		String execute(String value, Map<String, Object> data);
	}
	
	private static interface Checker {
		CheckResultType execute(String value, String dataIndx, Map<String, Object> data);
	}
	
	private static enum CheckResultType {
		none, 
		optionNotExist, 
		floatFormat, 
		integerFormat, 
		dateFormat;
	}

	private static class TemporaryRecord {
		private int index;
		private String value;
		public int getIndex() {
			return index;
		}
		public void setIndex(int index) {
			this.index = index;
		}
		public String getValue() {
			return value;
		}
		public void setValue(String value) {
			this.value = value;
		}

	}
	
	private static class IssueAttr {
		private String dataIndx;
		private String label;
		public String getDataIndx() {
			return dataIndx;
		}
		public void setDataIndx(String dataIndx) {
			this.dataIndx = dataIndx;
		}
		public String getLabel() {
			return label;
		}
		public void setLabel(String label) {
			this.label = label;
		}
		
	}
	
	private static class ExportMapping {
		private HttpContext context;
		private IDbExecute db;
		private Map<String, Map<String, String>> cmbMapping = Maps.newHashMap();
		private Map<String, Map<String, String>> listLinkMapping = Maps.newHashMap();
		private List<MappingData> indexList = Lists.newArrayList();
		private Map<String, MappingData> indexMap = Maps.newHashMap();
		private Map<String, Object> templateMap;
		
		public ExportMapping(HttpContext context, IDbExecute db) throws SoftbankException {
			this.context = context;
			this.db = db;
			createMapping();
			createListlinkOptions();
		}
		
		public void createIndexList(List<Map<String, Object>> optionList) {
			for (int i = 0; i < optionList.size(); i++) {
				MappingData mappingData = new MappingData();
				Map<String, Object> option = optionList.get(i);
				String dataInx = StringUtils.toString(option.get("value"));
				mappingData.setDataInx(dataInx);
				mappingData.setOption(option);
				if (dataInx.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) == 0) {
					String type = StringUtils.toString(option.get("type"));
					if ("phase".equals(type)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("phasesMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if ("testphase".equals(type)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("testphasesMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if ("user".equals(type)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("memberMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if ("listlink".equals(type)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.listLinkMapping.get(this.dataIndx).get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if ("bool".equals(type)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								if (StringUtils.isEmpty(value)) {
									return value;
								}
								if ("1".equals(value)) {
									value = "はい";
								} else {
									value = "いいえ";
								}
								return value;
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					}
				} else {
					if (IssueKey.PRIORITY_ID.KEY_JSON.equals(dataInx)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("issuePriorityMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if (IssueKey.STATUS_ID.KEY_JSON.equals(dataInx)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("issueStatusesMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if (IssueKey.TRACKER_ID.KEY_JSON.equals(dataInx)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("trackerInfoMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if (IssueKey.ASSIGNED_TO_ID.KEY_JSON.equals(dataInx)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("memberMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if (IssueKey.FIXED_VERSION_ID.KEY_JSON.equals(dataInx)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("versionsMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					} else if (IssueKey.AUTHOR_ID.KEY_JSON.equals(dataInx)) {
						mappingData.setConversion(new Conversion() {
							
							@Override
							public String execute(String value, Map<String, Object> data) {
								return ExportMapping.this.cmbMapping.get("memberMap").get(value);
							}
							
							private String dataIndx;
							@Override
							public void setDataIndx(String dataIndx) {
								this.dataIndx = dataIndx;
							}
						});
					}
				}
				indexMap.put(dataInx, mappingData);
				if (mappingData.getConversion() != null) {
					mappingData.getConversion().setDataIndx(dataInx);
					indexList.add(mappingData);
				}
			}
		}
		
		public void analysisData(Map<String, Object> data) {
			for (int i = 0; i < indexList.size(); i++) {
				MappingData mappingData = indexList.get(i);
				String dataInx = mappingData.getDataInx();
				String dString = StringUtils.toString(data.get(dataInx));
				if (StringUtils.isNotEmpty(dString)) {
					dString = mappingData.getConversion().execute(dString, data);
					data.put(dataInx, dString);
				}
			}
		}
		
		public MappingData getMappingData(String dataInx) {
			return indexMap.get(dataInx);
		}
		
		private void createMapping() throws SoftbankException {
			int projectId = context.getParam().projectId;
			cmbMapping.put("memberMap", getMembersMapping());
			cmbMapping.put("phasesMap", getPhasesMapping());
			cmbMapping.put("testphasesMap", getTestphaseMapping());
			cmbMapping.put("versionsMap", getVersionsMapping());
			cmbMapping.put("trackerInfoMap", getTrackerInfoMapping(projectId));
			cmbMapping.put("issueStatusesMap", getIssueStatusesMapping());
			cmbMapping.put("issuePriorityMap", getIssuePriorityMapping());
		}
		
		private void createListlinkOptions() throws SoftbankException {
			List<Map<String, Object>> listlinks = db.querys("custom_field_links.selectfieldsInfoByProjectId");
			if (listlinks == null || listlinks.size() == 0) {
				return;
			}
			Map<String, String> filedMap = null;
			for (int i = 0; i < listlinks.size(); i++) {
				Map<String, Object> data = listlinks.get(i);
				String custom_field_id = StringUtils.toString(data.get("custom_field_id"));
				if (!listLinkMapping.containsKey(custom_field_id)) {
					filedMap = Maps.newHashMap();
					listLinkMapping.put(custom_field_id, filedMap);
				}
				String id = StringUtils.toString(data.get("id"));
				String name = StringUtils.toString(data.get("name"));
				filedMap.put(id, name);
			}
		}
		
		private Map<String, String> getMembersMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> members = db.querys("users.getMembersForCmb");
			for (int i = 0; i < members.size(); i++) {
				String label = StringUtils.toString(members.get(i).get("label"));
				String value = StringUtils.toString(members.get(i).get("value"));
				result.put(value, label);
			}
			return result;
		}
		
		private Map<String, String> getPhasesMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> phases = db.querys("phases.getPhasesForCmb");
			for (int i = 0; i < phases.size(); i++) {
				String label = StringUtils.toString(phases.get(i).get("label"));
				String value = StringUtils.toString(phases.get(i).get("value"));
				result.put(value, label);
			}
			return result;
		}
		
		private Map<String, String> getTestphaseMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> testPhases = db.querys("test_phases.getTestPhasesForCmb");
			for (int i = 0; i < testPhases.size(); i++) {
				String label = StringUtils.toString(testPhases.get(i).get("label"));
				String value = StringUtils.toString(testPhases.get(i).get("value"));
				result.put(value, label);
			}
			return result;
		}
		
		private Map<String, String> getVersionsMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			List<Map<String, Object>> versions = db.querys("issues.getVersionsForCmb");
			for (int i = 0; i < versions.size(); i++) {
				String label = StringUtils.toString(versions.get(i).get("label"));
				String value = StringUtils.toString(versions.get(i).get("value"));
				result.put(value, label);
			}
			return result;
		}
		
		private Map<String, String> getTrackerInfoMapping(int projectId) throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("project_id", projectId);
			List<Map<String, Object>> trackers = db.querys("ticketList.getTrackerInfo", conditions);
			if (trackers != null) {
				for (int i = 0; i < trackers.size(); i++) {
					String label = StringUtils.toString(trackers.get(i).get("name"));
					String value = StringUtils.toString(trackers.get(i).get("id"));
					result.put(value, label);
				}
			}
			return result;
		}
		
		private Map<String, String> getIssueStatusesMapping() throws SoftbankException {
			List<Map<String, Object>> issueStatuses = db.querys("issue_statuses.getIssueStatusesInfosForMapping");
			Map<String, String> result = Maps.newHashMap();
			for (int i = 0; i < issueStatuses.size(); i++) {
				Map<String, Object> status = issueStatuses.get(i);
				result.put(StringUtils.toString(status.get("id")), StringUtils.toString(status.get("name")));
			}
			return result;
		}
		
		private Map<String, String> getIssuePriorityMapping() throws SoftbankException {
			Map<String, String> result = Maps.newHashMap();
			result.put("15", "深刻");
			result.put("16", "影響大");
			result.put("17", "影響小");
			result.put("18", "影響無し");
			return result;
		}

		public Map<String, Object> getTemplateMap() {
			return templateMap;
		}

		public void setTemplateMap(Map<String, Object> templateMap) {
			this.templateMap = templateMap;
		}
		
	}
	
	private static class ImportDataResult {
		private HttpContext context;
		private List<Map<String, Object>> updateList = Lists.newArrayList();
		public List<Map<String, Object>> getUpdateList() {
			return updateList;
		}

		private Map<String, List<Map<String, Object>>> addMap = Maps.newHashMap();
		
		public Map<String, List<Map<String, Object>>> getAddMap() {
			return addMap;
		}

		public ImportDataResult(HttpContext context) {
			this.context = context;
		}
		
		public void analysisImportIssueData(List<Map<String, Object>> resultDataList, MappingContext mappingContext) throws SoftbankException {
			JSONObject selectModel = null;
			if (StringUtils.isNotEmpty(context.getParam().get("selectModel"))) {
				selectModel = JSONObject.fromObject(context.getParam().get("selectModel"));
			}
			JSONObject lastModel = null;
			if (StringUtils.isNotEmpty(context.getParam().get("lastModel"))) {
				lastModel = JSONObject.fromObject(context.getParam().get("lastModel"));
			}
			ProjectTicketInfoBean ticketInfoBean = ControlDbMemory.getInstance().getProjectTicketInfos(context.getParam().projectId);
			Map<Integer, Map<String, Object>> floorMap = Maps.newHashMap();
			Map<Integer, Map<String, Object>> floorBorderMap = Maps.newHashMap();
			Map<String, Map<String, Object>> dataMap = Maps.newHashMap();
			Stack<String> parentStack = new Stack<String>();
			Map<String, List<Map<String, Object>>> childrenMap = Maps.newHashMap();
			for (int i = 0; i < resultDataList.size(); i++) {
				Map<String, Object> data = resultDataList.get(i);
				Map<String, Object> issueData = null;
				dataConversion(mappingContext, data);
				int floor = StringUtils.toInt(data.get(INDEX_SIGN + IssueKey.SUBJECT.KEY_JSON));
				String tid = StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY_JSON));
				Map<String, Object> currentFloorMap = Maps.newHashMap();
				if (ticketInfoBean.issueExist(tid)) {
					issueData = ticketInfoBean.getIssueData(tid);
					if (diffUpdateDate(issueData, data)) {
						dataMap.put(tid, data);
						updateList.add(data);
					}
					currentFloorMap.put("add_root_id", tid);
					currentFloorMap.put(IssueKey.TREE_ID.KEY_JSON, issueData.get(IssueKey.TREE_ID.KEY_JSON));
					currentFloorMap.put(IssueKey.PROJECT_ID.KEY_JSON, issueData.get(IssueKey.PROJECT_ID.KEY_JSON));
					if (floorMap.containsKey(floor - 1)) {
						Map<String, Object> parentMap = floorMap.get(floor - 1);
						Map<String, Object> borderFloorMap = Maps.newHashMap();
						borderFloorMap.put(StringUtils.toString(parentMap.get("add_root_id")), tid);
						floorBorderMap.put(floor, borderFloorMap);
					} else {
						Map<String, Object> borderFloorMap = Maps.newHashMap();
						borderFloorMap.put("root", tid);
						floorBorderMap.put(floor, borderFloorMap);
					}
				} else {
					tid = newTicketId();
					String pid = null;
					String proId = null;
					String addKey = "root";
					if (floorMap.containsKey(floor - 1)) {
						Map<String, Object> parentMap = floorMap.get(floor - 1);
						pid = parentMap.get(IssueKey.TREE_ID.KEY_JSON) + ConstantsUtil.Str.SPACE + tid;
						proId = StringUtils.toString(parentMap.get(IssueKey.PROJECT_ID.KEY_JSON));
						addKey = StringUtils.toString(parentMap.get("add_root_id"));
						currentFloorMap.put("add_root_id", StringUtils.toString(parentMap.get("add_root_id")));
						if (parentMap.containsKey("isNew")) {
							addKey = StringUtils.toString(parentMap.get("isNew"));
						} else {
							if (floorBorderMap.containsKey(floor)) {
								Map<String, Object> borderFloorMap = floorBorderMap.get(floor);
								if (borderFloorMap.containsKey(addKey)) {
									addKey += '|' + StringUtils.toString(borderFloorMap.get(addKey));
								}
							}
						}
					} else if (selectModel != null) {
						String selectTid = selectModel.getString(IssueKey.ISSUE_ID.KEY_JSON);
						if (selectTid.startsWith("p")) {
							pid = selectModel.getString(IssueKey.TREE_ID.KEY_JSON) + ConstantsUtil.Str.SPACE + tid;
						} else {
							pid = (selectModel.getString(IssueKey.TREE_ID.KEY_JSON) + ConstantsUtil.Str.SPACE).replaceAll(
									ConstantsUtil.Str.SPACE + selectTid + ConstantsUtil.Str.SPACE, ConstantsUtil.Str.SPACE + tid);
						}
						proId = selectModel.getString(IssueKey.PROJECT_ID.KEY_JSON);
						currentFloorMap.put("add_root_id", addKey);
					} else if (lastModel != null) {
						pid = lastModel.getString(IssueKey.TREE_ID.KEY_JSON) + ConstantsUtil.Str.SPACE + tid;
						proId = lastModel.getString(IssueKey.PROJECT_ID.KEY_JSON);
						currentFloorMap.put("add_root_id", addKey);
					}
					if ("root".equals(addKey)) {
						if (floorBorderMap.containsKey(floor)) {
							Map<String, Object> borderFloorMap = floorBorderMap.get(floor);
							if (borderFloorMap.containsKey(addKey)) {
								addKey += '|' + StringUtils.toString(borderFloorMap.get(addKey));
							}
						}
					}
					currentFloorMap.put("isNew", addKey);
					currentFloorMap.put(IssueKey.TREE_ID.KEY_JSON, pid);
					currentFloorMap.put(IssueKey.PROJECT_ID.KEY_JSON, proId);
					data.put(IssueKey.ISSUE_ID.KEY_JSON, tid);
					data.put(IssueKey.TREE_ID.KEY_JSON, pid);
					data.put(IssueKey.PROJECT_ID.KEY_JSON, proId);
					data.put("isAdd", true);
					setClosestIdByParentId(data);
					List<Map<String, Object>> addList = null;
					if (addMap.containsKey(addKey)) {
						addList = addMap.get(addKey);
					} else {
						addList = Lists.newArrayList();
						addMap.put(addKey, addList);
					}
					addList.add(data);
					dataMap.put(tid, data);
					createParentData(parentStack, childrenMap, data);
				}
				floorMap.put(floor, currentFloorMap);
			}
			renderParentData(parentStack, childrenMap, dataMap);
		}
		
		private boolean diffUpdateDate(Map<String, Object> oldData, Map<String, Object> newData) {
			boolean result = false;
			HashSet<String> dataKeySet = Sets.newHashSet(newData.keySet());
			for (String key : dataKeySet) {
				if (IssueKey.AUTHOR_ID.KEY_JSON.equals(key) || IssueKey.AUTHOR_FIRSTNAME.KEY_JSON.equals(key) || IssueKey.AUTHOR_LASTNAME.KEY_JSON.equals(key)) {
					continue;
				}
				if (key.startsWith(INDEX_SIGN) || TICKET_IMPORT_FILE_ERROR_INFOS_KEY.equals(key) || "index".equals(key)) {
					newData.remove(key);
					continue;
				}
				if (oldData.containsKey(key)) {
					if (StringUtils.isNotEmpty(newData.get(key))) {
						if (StringUtils.isNotEmpty(oldData.get(key))) {
							if (oldData.get(key) instanceof String) {
								String newValue = StringUtils.toString(newData.get(key)).replaceAll("\r", "").replaceAll("\n", "");
								String oldValue = StringUtils.toString(oldData.get(key)).replaceAll("\r", "").replaceAll("\n", "");
								if (!newValue.equals(oldValue)) {
									result = true;
								}
							} else if (oldData.get(key) instanceof Double) {
								double newValue = Double.parseDouble(StringUtils.toString(newData.get(key)));
								double oldValue = Double.parseDouble(StringUtils.toString(oldData.get(key)));
								if (newValue != oldValue) {
									result = true;
								}
							} else if (oldData.get(key) instanceof Integer) {
								int newValue = Integer.parseInt(StringUtils.toString(newData.get(key)));
								int oldValue = Integer.parseInt(StringUtils.toString(oldData.get(key)));
								if (newValue != oldValue) {
									result = true;
								}
							}
						} else {
							result = true;
						}
					} else {
						if (StringUtils.isNotEmpty(oldData.get(key))) {
							result = true;
						}
					}
				} else {
					if (StringUtils.isNotEmpty(newData.get(key))) {
						result = true;
					}
				}
			}
			return result;
		}

		private void dataConversion(MappingContext mappingContext, Map<String, Object> data) {
			HashSet<String> dataKeySet = Sets.newHashSet(data.keySet());
			List<String> keyList = Lists.newArrayList();
			for (String key : dataKeySet) {
				if (!mappingContext.hasConversion(key)) {
					continue;
				}
				keyList.add(key);
			}
			Collections.sort(keyList, new Comparator<String>() {

				@Override
				public int compare(String o1, String o2) {
					if (o1.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) == 0 
							|| o2.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) == 0) {
						if (o1.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) != 0) {
							return 1;
						}
						if (o2.indexOf(IssueKey.CUSTOMVALUES.KEY_JSON) != 0) {
							return -1;
						}
						int left = StringUtils.toInt(o1.substring(IssueKey.CUSTOMVALUES.KEY_JSON.length()));
						int right = StringUtils.toInt(o2.substring(IssueKey.CUSTOMVALUES.KEY_JSON.length()));
						if (left > right) {
							return 1;
						} else {
							return -1;
						}
					}
					return 0;
				}
			});
			for (int i = 0; i < keyList.size(); i++) {
				String key = keyList.get(i);
				data.put(key, mappingContext.doConversion(key, StringUtils.toString(data.get(key)), data));
			}
		}

		private void renderParentData(Stack<String> parentStack, Map<String, List<Map<String, Object>>> childrenMap, Map<String, Map<String, Object>> dataMap) throws SoftbankException {
			while (!parentStack.isEmpty()) {
				String parentId = parentStack.pop();
				if (!dataMap.containsKey(parentId)) {
					continue;
				}
				Map<String, Object> parentMap = dataMap.get(parentId);
				List<Map<String, Object>> childrenList = childrenMap.get(parentId);
				String startDate = null;
				String endDate = null;
				double doneRatio = 0;
				double estimatedHours = 0;
				double doneRatioSum = 0;
				double allDoneRatioSum = 0;
				int statusId = 0;
				for (int i = 0; i < childrenList.size(); i++) {
					Map<String, Object> child = childrenList.get(i);
					String sd = StringUtils.toString(child.get(IssueKey.START_DATE.KEY_JSON));
					String ed = StringUtils.toString(child.get(IssueKey.DUE_DATE.KEY_JSON));
					double eh = StringUtils.toDouble(child.get(IssueKey.ESTIMATED_HOURS.KEY_JSON));
					double dr = StringUtils.toDouble(child.get(IssueKey.DONE_RATIO.KEY_JSON));
					if (StringUtils.isEmpty(startDate)) {
						startDate = sd;
					} else {
						if (DateUtils.compare(sd, startDate, DateUtils.FORMAT_YMD2) == -1) {
							startDate = sd;
						}
					}
					if (StringUtils.isEmpty(endDate)) {
						endDate = ed;
					} else {
						if (DateUtils.compare(endDate, ed, DateUtils.FORMAT_YMD2) == -1) {
							endDate = ed;
						}
					}
					doneRatioSum += eh * dr;
					allDoneRatioSum += dr;
					estimatedHours += eh;
				}
				if (estimatedHours == 0) {
					doneRatio = allDoneRatioSum / childrenList.size();
				} else {
					doneRatio = Math.floor(( doneRatioSum * Math.pow(10, 2)) / (estimatedHours * Math.pow(10, 2)));
				}
				if ( doneRatio > 100) {
					doneRatio = 100;
				}
				if (doneRatio == 0) {
					statusId = 1;
				} else if (doneRatio == 100) {
					statusId = 3;
				} else {
					statusId = 2;
				}
				parentMap.put(IssueKey.START_DATE.KEY_JSON, startDate);
				parentMap.put(IssueKey.DUE_DATE.KEY_JSON, endDate);
				parentMap.put(IssueKey.DONE_RATIO.KEY_JSON, doneRatio);
				parentMap.put(IssueKey.ESTIMATED_HOURS.KEY_JSON, estimatedHours);
				parentMap.put(IssueKey.STATUS_ID.KEY_JSON, statusId);
				parentMap.put(IssueKey.PROCESS.ISPARENT, true);
			}
		}

		private void createParentData(Stack<String> parentStack, Map<String, List<Map<String, Object>>> childrenMap,
				Map<String, Object> data) {
			String parentId = StringUtils.toString(data.get(IssueKey.PARENT_ID.KEY_JSON));
			if (StringUtils.isNotEmpty(parentId)) {
				List<Map<String, Object>> childrenList = null;
				if (!childrenMap.containsKey(parentId)) {
					parentStack.push(parentId);
					childrenList = Lists.newArrayList();
					childrenMap.put(parentId, childrenList);
				} else {
					childrenList = childrenMap.get(parentId);
				}
				childrenList.add(data);
			}
		}

		private String newTicketId() {
			return CreateSequencesUtil.createShortID("n");
		}
		
		private void setClosestIdByParentId(Map<String, Object> data) {
			String pid = StringUtils.toString(data.get(IssueKey.TREE_ID.KEY_JSON));
			String[] pds = pid.split(ConstantsUtil.Str.SPACE);
			String closestId = null;
			if (pds.length > 1) {
				closestId = pds[pds.length - 2];
				if (closestId.indexOf( 'p' ) != -1 || closestId.indexOf( 'v' ) != -1) {
					closestId = null;
				}
			}
			data.put(IssueKey.PARENT_ID.KEY_JSON, closestId);
		}
	}
	

}
