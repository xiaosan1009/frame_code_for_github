package co.jp.softbank.qqmx.info.bean;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.common.bean.HolidaysBean;
import co.jp.softbank.qqmx.dao.common.bean.PluginInfoBean;
import co.jp.softbank.qqmx.dao.roles.bean.RolesBaseBean;
import co.jp.softbank.qqmx.util.DateUtils;

public class DbMemoryBean {
	
	private List<HolidaysBean> holidaysBeans;
	
	private Map<String, HolidaysBean> holidaysMap;
	
	private List<PluginInfoBean> pluginInfoBeans;
	
	private List<RolesBaseBean> rolesBaseBeans;
	
	private List<Map<String, Object>> enabledScmInfos;
	
	private Map<Integer, ProjectTicketInfoBean> ticketsMap = Maps.newHashMap();
	
	private Map<Integer, List<Map<String, Object>>> ticketsWatchableMap = Maps.newHashMap();
	
	private Map<Integer, Date> timestampMap = Maps.newHashMap();
	
	private Map<Integer, Date> timestampWatchableMap = Maps.newHashMap();
	
	private Map<Integer, Long> rootTokenMap = Maps.newHashMap();
	
	private Map<Integer, List<Map<String, Object>>> customListMap = Maps.newHashMap();
	
	private Map<Integer, Map<Integer, Integer>> customFieldTrackerMap = Maps.newHashMap();
	
	public List<HolidaysBean> getHolidaysBeans() {
		return holidaysBeans;
	}
	
	public List<PluginInfoBean> getPluginInfoBeans() {
		return pluginInfoBeans;
	}

	public void setHolidaysBeans(List<HolidaysBean> holidaysBeans) {
		this.holidaysBeans = holidaysBeans;
		if (holidaysBeans != null) {
			holidaysMap = Maps.newHashMap();
			for (int i = 0; i < holidaysBeans.size(); i++) {
				HolidaysBean holidaysBean = holidaysBeans.get(i);
				holidaysMap.put(holidaysBean.getHolidayStr(), holidaysBean);
			}
		}
	}
	
	public void setPluginInfoBeans(List<PluginInfoBean> pluginInfoBeans) {
		this.pluginInfoBeans = pluginInfoBeans;
	}

	public boolean isHoliday(Date date) {
		return isHoliday(DateUtils.makeFormat(date, DateUtils.FORMAT_YYYYMMDD_DASH));
	}
	
	public boolean isHoliday(String date) {
		return holidaysMap.containsKey(date);
	}

	public Map<String, HolidaysBean> getHolidaysMap() {
		return holidaysMap;
	}

	public List<RolesBaseBean> getRolesBaseBeans() {
		return rolesBaseBeans;
	}

	public void setRolesBaseBeans(List<RolesBaseBean> rolesBaseBeans) {
		this.rolesBaseBeans = rolesBaseBeans;
	}

	public Map<Integer, ProjectTicketInfoBean> getTicketsMap() {
		return ticketsMap;
	}

	public Map<Integer, List<Map<String, Object>>> getTicketsWatchableMap() {
		return ticketsWatchableMap;
	}
	
	public Map<Integer, List<Map<String, Object>>> getCustomListMap() {
		return customListMap;
	}
	
	public Map<Integer, Map<Integer, Integer>> getCustomFieldTrackerMap() {
		return customFieldTrackerMap;
	}

	public Map<Integer, Date> getTimestampMap() {
		return timestampMap;
	}

	public void setTimestampMap(Map<Integer, Date> timestampMap) {
		this.timestampMap = timestampMap;
	}

	public Map<Integer, Date> getTimestampWatchableMap() {
		return timestampWatchableMap;
	}

	public void setTimestampWatchableMap(Map<Integer, Date> timestampWatchableMap) {
		this.timestampWatchableMap = timestampWatchableMap;
	}
	
	public long getRootToken(int rootId) {
		if (!rootTokenMap.containsKey(rootId)) {
			return 0;
		}
		return rootTokenMap.get(rootId);
	}
	
	public void setRootToken(int rootId, long token) {
		rootTokenMap.put(rootId, token);
	}

	public List<Map<String, Object>> getEnabledScmInfos() {
		return enabledScmInfos;
	}

	public void setEnabledScmInfos(List<Map<String, Object>> enabledScmInfos) {
		this.enabledScmInfos = enabledScmInfos;
	}

}
