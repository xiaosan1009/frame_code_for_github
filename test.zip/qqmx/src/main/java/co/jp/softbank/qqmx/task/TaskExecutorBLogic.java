package co.jp.softbank.qqmx.task;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.task.bean.Worker;
import co.jp.softbank.qqmx.task.face.IContextFactory;
import co.jp.softbank.qqmx.task.face.IKey;
import co.jp.softbank.qqmx.task.face.IOutputCollector;
import co.jp.softbank.qqmx.task.face.IReader;
import co.jp.softbank.qqmx.task.face.ITask;
import co.jp.softbank.qqmx.task.face.ITaskContext;
import co.jp.softbank.qqmx.task.face.ITaskLogic;
import co.jp.softbank.qqmx.task.info.TaskInfo;
import co.jp.softbank.qqmx.util.LogUtil;

import com.google.common.io.Closeables;
import com.google.common.io.Closer;

public class TaskExecutorBLogic implements ITaskLogic {
	
	private long pollWorkerMillis = 100;
	
	private IContextFactory contextFactory;
	
	private LinkedList<TaskInfo> taskList = new LinkedList<TaskInfo>();
	
	private IOutputCollector<? extends Object> collector;
	
	private ThreadPoolExecutor executor;
	
	private List<Worker> workers = new LinkedList<Worker>();
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	public interface TaskExecuteStatus {
		int OK = 100;
		int ERROR = 0;
	}

	@Override
	public int execute(HttpContext httpContext) {
		int status = TaskExecuteStatus.ERROR;
		ITaskContext context = contextFactory.getTaskContext();
		if (context == null) {
            return status;
        }
		context.setHttpContext(httpContext);
		try {
			collector = runTasks(context);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		return TaskExecuteStatus.OK;
	}
	
	@SuppressWarnings({ "rawtypes" })
	private IOutputCollector runTasks(ITaskContext context) throws Exception {
		TaskInfo taskInfo = taskList.getFirst();
		collector.prepare(context);
		while (taskInfo != null) {
			Closer closer = Closer.create();
			try {
				IReader<? extends Object> reader = taskInfo.getReader();
				closer.register(reader);
				reader.prepare(context);
				
				runTask(context, taskInfo);
				
                reader.cleanup(context);
                taskInfo = taskInfo.getNext();
			} catch (Exception e) {
				e.printStackTrace();
				 Closeables.close(collector, true);
				 throw e;
			} finally {
				collector.cleanup(context);
				closer.close();
			}
		}
		return collector;
	}
	
	protected void runTask(ITaskContext ctx, TaskInfo taskInfo) throws Exception {

        try {
            handleTaskStart(ctx, taskInfo);

            ITask<?> task = taskInfo.getTask();
            try {
                List<Future<Worker>> futures = new LinkedList<Future<Worker>>(executor.invokeAll(workers));

                IReader<? extends Object> reader = taskInfo.getReader();
                while (reader.hasNext()) {
                    IKey key = reader.getKey();
                    Object value = reader.getValue();
                    Worker worker = null;
                    do {
                        worker = pollWorker(futures);
                    } while (worker == null);
                    worker.setKeyValue(key, value);
                    futures.add(executor.submit(worker));
                }

                while (!futures.isEmpty()) {
                    Worker worker = pollWorker(futures);
                    if (worker == null || worker.getContext() == null) {
                        continue;
                    }
                }

            } catch (ExecutionException e) {
                if (e.getCause() instanceof Error) {
                    throw (Error) e.getCause();
                }
            }
        } finally {
            handleTaskEnd(ctx, taskInfo);
        }
    }
	
	protected Worker pollWorker(List<Future<Worker>> futures) throws InterruptedException, ExecutionException {
        int index = -1;
        for (int i = 0; i < futures.size(); i++) {
            Future<Worker> temp = futures.get(i);
            if (temp.isDone()) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            synchronized (futures) {
                futures.wait(pollWorkerMillis);
            }
        }
        return index < 0 ? null : futures.remove(index).get();
    }
	
	public void handleTaskStart(ITaskContext context, TaskInfo taskInfo) throws Exception {

        int threads = taskInfo.numOfThreads();
        // タスクを処理するExecutor。スレッド名をline-worker-Xとする
        executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(threads, new ThreadFactory() {
            int count = 0;

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("line-worker-" + count++);
                return t;
            }
        });
        AtomicInteger lines = new AtomicInteger(0);
        workers.clear();
        taskInfo.getTask().prepare(context);
        for (int i = 0; i < threads; i++) {
            workers.add(new Worker(context.copy(), taskInfo.getTask(), lines));
        }
    }
	
	public void handleTaskEnd(ITaskContext context, TaskInfo taskInfo) throws Exception {
        try {
            for (Worker worker : workers) {
                worker.cleanup();
            }
            executor.shutdown();
            workers.clear();
            taskInfo.getTask().reprocess(context);
        } finally {
        }
    }

	public void setContextFactory(IContextFactory contextFactory) {
		this.contextFactory = contextFactory;
	}

	public void setTasks(List<ITask<?>> tasks) throws SoftbankException {
		for (int i = 0; i < tasks.size(); i++) {
			TaskInfo taskInfo = new TaskInfo(tasks.get(i));
			TaskInfo preTaskInfo = null;
			if (this.taskList.size() > 0) {
				preTaskInfo = taskList.getLast();
				preTaskInfo.setNext(taskInfo);
			}
			taskInfo.setPre(preTaskInfo);
			taskList.addLast(taskInfo);
		}
	}

	public void setCollector(IOutputCollector<? extends Object> collector) {
		this.collector = collector;
	}

}
