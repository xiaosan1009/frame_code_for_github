package co.jp.softbank.qqmx.util;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.message.IMessageAccessor;

public class CommonUtil {
	
	private static Logger log = new LogUtil(CommonUtil.class).getLog();
	
	public static Locale getLocale(String key) {
		if (ConstantsUtil.Lang.JAPAN.equals(key)) {
			return Locale.JAPANESE;
		} else if (ConstantsUtil.Lang.ENGLISH.equals(key)) {
			return Locale.ENGLISH;
		}
		return Locale.JAPANESE;
	}

	/**
	 * メール送信処理
	 * 
	 * @throws Exception
	 * 例外
	 */
//	private static void sendMail(WbsTicket wbsTicket) throws Exception {
	public static void sendMail(Map<String, Object> conditions, String key, IMessageAccessor messageAccessor) throws Exception {

//		final String SMTP_HOST = IPFConfig.getInstance().getProperty("SMTP_HOST");
//		final String SMTP_PORT = IPFConfig.getInstance().getProperty("SMTP_PORT");
//		final String MAIL_FROM = IPFConfig.getInstance().getProperty("MAIL_FROM");
//		final String MAIL_CC = IPFConfig.getInstance().getProperty("MAIL_CC");
//		final String MAIL_SUBJECT = IPFConfig.getInstance().getProperty("MAIL_SUBJECT");
//		final String MAIL_TICKET_TEXT = IPFConfig.getInstance().getProperty("MAIL_TICKET_TEXT");
		
		final String SMTP_HOST = messageAccessor.getMessage("SMTP_HOST");
		final String SMTP_PORT = messageAccessor.getMessage("SMTP_PORT");
		final String MAIL_FROM = messageAccessor.getMessage("MAIL_FROM");
		// TODO CCいらない？
		final String MAIL_CC = "QQM-X@g.softbank.co.jp";
		
		final String MAIL_SUBJECT = "質問『%s』が受付しました";
		final String MAIL_SUBJECT_ANSWER = "質問『%s』が回答されました";
		final String MAIL_TICKET_TEXT = "質問NO.%s<br/>・質問タイトル：%s<br/>・URL：//10.216.80.167/qqmx/qqmx?dispCode=300013&cmdCode=0&id=%s&%s<br/><br/><br/>------------------------------------------------------------<br/>本メールはQQM-Xより自動送信している為、<br/>返信は行わないで下さい。<br/>------------------------------------------------------------";


// MAIL_SUBJECT = QQM-X品質管理アラートメール
// MAIL_TEXT = 下記対象システムのサマリ評価が赤に更新されています。\n・対象システム：%s\n\nDashboardの対象グラフを確認の上、\n適切な対応を実施してください。\nhttp://10.36.44.76:81/birt-viewer/dashboard?PROJECT_ID=%s\n\n\n------------------------------------------------------------\n本メールはQQM-Xより自動送信している為、\n返信は行わないで下さい。\n------------------------------------------------------------


		// メール送信準備
		Properties props = new Properties();
		props.put("mail.smtp.host", SMTP_HOST);
		props.put("mail.smtp.port", SMTP_PORT);

		Session session = Session.getDefaultInstance(props);
		session.setDebug(true);

		// メール作成
		MimeMessage mime = new MimeMessage(session);

		// FROM設定
		if (!StringUtils.isEmpty(MAIL_FROM)) {
			mime.addFrom(InternetAddress.parse(MAIL_FROM));
		}

		// TO設定  TODO ユーザからメアドを取得してくる必要あり
		String sendTO = "SBMGRP-epmxdevelopment@g.softbank.co.jp";
		if (key.endsWith("question")) {
			sendTO = StringUtils.toString(conditions.get("user_address"));
		}
		
		mime.setRecipients(Message.RecipientType.TO, InternetAddress.parse(sendTO));

		// CC設定
//		String projectMail = wbsTicket.getProjectMail();
		// TODO なしにする？
		String projectMail = "";
		if (!StringUtils.isEmpty(projectMail)) {
			mime.setRecipients(Message.RecipientType.CC,
					InternetAddress.parse(projectMail));
		}
		
//		// タイトル設定
//		mime.setSubject(String.format(MAIL_SUBJECT, wbsTicket.getProjectName(), wbsTicket.getTName(), wbsTicket.getTicketId(), wbsTicket.getTicketName(), wbsTicket.getDaysTitle()), "iso-2022-jp");
//		// 本文設定
//		mime.setText(String.format(MAIL_TICKET_TEXT, wbsTicket.getProjectName(), wbsTicket.getTName(), wbsTicket.getTicketId(), wbsTicket.getTicketName(), wbsTicket.getToname(), wbsTicket.getDaysText(), wbsTicket.getTicketId(), wbsTicket.getTName(), wbsTicket.getTicketId(), wbsTicket.getTicketName(), wbsTicket.getAuthorname(), wbsTicket.getSName(), wbsTicket.getEName(), wbsTicket.getAssignedname(),wbsTicket.getPlannedStartDate(), wbsTicket.getDueDate()), "iso-2022-jp", "html");

		// タイトル設定
		String titleFormat = String.format(MAIL_SUBJECT, conditions.get("question_title"));
		if (key.startsWith("for")) {
			titleFormat = String.format(MAIL_SUBJECT_ANSWER, conditions.get("question_title"));
		}
		log.debug("question_title = " + titleFormat);
		mime.setSubject(titleFormat);
		

		// 本文設定
		String contentFormat = String.format(MAIL_TICKET_TEXT, conditions.get("question_id"), conditions.get("question_title"), conditions.get("question_id"), key);
		log.debug("question_content = " + contentFormat);
//		mime.setText(contentFormat);
		mime.setContent(contentFormat, "text/html;charset=UTF-8");
		

		// 送信日時設定
		mime.setSentDate(new Date());

		// 送信処理
		Transport.send(mime);
	}
	
	public static List<Map<String, Object>> createListByColumn(List<Map<String, Object>> list, List<String> columns) {
		List<Map<String, Object>> result = Lists.newArrayList();
		for (int i = 0; i < list.size(); i++) {
			Map<String, Object> obj = list.get(i);
			Map<String, Object> data = Maps.newHashMap();
			for (int j = 0; j < columns.size(); j++) {
				String key = columns.get(j);
				data.put(key, obj.get(key));
			}
			result.add(data);
		}
		return result;
	}
}
