package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.NewRoleDao;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class NewRoleLogic extends AbstractBaseLogic {

	@Autowired
	private NewRoleDao newRoleDao;

	public LogicBean getNewRoleInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String roleId = context.getParam().get("roleId");
		if ("".equals(roleId)){
			roleId = "2";
		}
		List<Map<String, Object>> rolesBaseList = newRoleDao.getRolesBaseList();
		
		Map<String, Object> roleMap = Maps.newHashMap();
		List<Map<String, Object>> roledataListMap = Lists.newArrayList();
		
		for (int i = 0; i < rolesBaseList.size(); i++) {
			Map<String, Object> roledataMap = Maps.newHashMap();
			List<NewRoleBean> resultBean = Lists.newArrayList();
			Map<String, Object> rolesBaseData = rolesBaseList.get(i);
			
			
			Map<String, Object> rolesBaseSub = Maps.newHashMap();
			rolesBaseSub.put("id", rolesBaseData.get("id"));
			List<Map<String, Object>> rolesBaseSubList = newRoleDao.getRolesBaseSubList(rolesBaseSub);
			
			for (int j = 0; j < rolesBaseSubList.size(); j++) {
				NewRoleBean newRoleBean = new NewRoleBean();
				Map<String, Object> rolesBaseSubData = rolesBaseSubList.get(j);
				newRoleBean.setId(Integer.valueOf(String.valueOf(rolesBaseSubData.get("id"))));
				newRoleBean.setName(String.valueOf(rolesBaseSubData.get("name")));
				newRoleBean.setValue(String.valueOf(rolesBaseSubData.get("value")));
				
				Map<String, Object> rolesCheck = Maps.newHashMap();
				rolesCheck.put("value", rolesBaseSubData.get("value"));
				rolesCheck.put("id", Integer.valueOf(roleId));
				List<Map<String, Object>> rolesCheckFlg = newRoleDao.getRolesCheckFlg(rolesCheck);
				if (rolesCheckFlg.size()>0) {
					newRoleBean.setFlg("t");
				}else{
					newRoleBean.setFlg("f");
				}
				resultBean.add(newRoleBean);
			}
			roledataMap.put("data", resultBean);
			roledataMap.put("name", rolesBaseData.get("name"));
			roledataMap.put("value", rolesBaseData.get("value"));
			roledataListMap.add(roledataMap);
			
		}
		roleMap.put("newRole", roledataListMap);
		logicBean.setData(roleMap);
		return logicBean;
	}
	
	public LogicBean getRoleList() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> roleMap = Maps.newHashMap();
		List<Map<String, Object>> roleList = newRoleDao.getRoleList();
		roleMap.put("role", roleList);
		logicBean.setData(roleMap);
		return logicBean;
	}
	
	public LogicBean getRoleIdInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> roleMap = Maps.newHashMap();
		String roleId = context.getParam().get("roleId");
		Map<String, Object> roles = Maps.newHashMap();
		roles.put("id", Integer.valueOf(roleId));
		List<Map<String, Object>> roleList = newRoleDao.getRoleIdInfo(roles);
		roleMap.put("role", roleList);
		logicBean.setData(roleMap);
		return logicBean;
	}
	
	public void saveRole() throws SoftbankException {
		Map<String, Object> roleMap = Maps.newHashMap();
		String role_name = context.getParam().get("role_name");
		String role_issues_visibility = context.getParam().get("role_issues_visibility");
		String role_assignable = context.getParam().get("role_assignable");
		String copy_workflow_role_from = context.getParam().get("copy_workflow_role_from");
		List<String> permissionsList = Lists.newArrayList(); 
		
		List<Map<String, Object>> rolesBaseList = newRoleDao.getRolesBaseList();
		for (int b = 0; b < rolesBaseList.size(); b++){
			Map<String, Object> rolesBaseData = rolesBaseList.get(b);
			String value = String.valueOf(rolesBaseData.get("value"));
			String[] permissions = context.getParam().getList("project_new_role_names" + value);
			if (permissions != null){
				for (int p = 0; p < permissions.length; p++) {
//				String strPermission = ":"+permissions[p];
					String strPermission = permissions[p];
					permissionsList.add(strPermission);
				}
				
//			} else {
//				if ("".equals(copy_workflow_role_from) || "null".equals(copy_workflow_role_from)){
//					copy_workflow_role_from = "1";
//				}
//				Map<String, Object> rolePermission = Maps.newHashMap();
//				rolePermission.put("id", StringUtils.toInt(copy_workflow_role_from));
//				List<Map<String, Object>> selectRolePermissionList = newRoleDao.selectRolePermissionList(rolePermission);
//				roleMap.put("permissions", selectRolePermissionList.get(0).get("permissions"));
			}
		}
		roleMap.put("permissions", Yaml.dump(permissionsList));
		roleMap.put("name", role_name);
		roleMap.put("issues_visibility", role_issues_visibility);
		roleMap.put("assignable", "true".equals(role_assignable) ? true : false);
		
		String roleId = context.getParam().get("roleId");
		int newRoleId = 0;
		if (!"".equals(roleId)){
			newRoleId = Integer.valueOf(roleId);
			roleMap.put("id", newRoleId);
			newRoleDao.updateRole(roleMap);
		}else{
			newRoleDao.saveRole(roleMap);
			newRoleId = Integer.parseInt(StringUtils.toString(roleMap.get("id")));
		}
		
		if ("".equals(copy_workflow_role_from) || "null".equals(copy_workflow_role_from)){
			copy_workflow_role_from = "1";
		}
		
		List<Map<String, Object>> selectTrackersList = newRoleDao.selectTrackers();
		for (int i = 0; i < selectTrackersList.size(); i++) {
			Map<String, Object> workflowsMap = Maps.newHashMap();
			String tracker_id = String.valueOf(selectTrackersList.get(i).get("id"));
			workflowsMap.put("tracker_id", Integer.valueOf(tracker_id));
			workflowsMap.put("new_role_id", Integer.valueOf(newRoleId));
			
			workflowsMap.put("bak_role_id", Integer.valueOf(copy_workflow_role_from));
			
			newRoleDao.deleteWorkflows(workflowsMap);
			newRoleDao.inserWorkflows(workflowsMap);
		}
	}
}
