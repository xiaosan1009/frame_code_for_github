package co.jp.softbank.qqmx.logic.application.batch;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.server.ExternalHttpServer;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class DeployDetailLogic {
	
	private IDbExecute db;
	
	public DeployDetailLogic(IDbExecute db) {
		this.db = db;
	}

	public void getDetaiInfo(String url,String sonarUrl,Integer deploy_id)  throws SoftbankException{
		
		// checkStyle
		ExternalHttpServer externalHttpServer = new ExternalHttpServer(null);
		String checkStyle = externalHttpServer.getStrUrl(url +"/checkstyleResult/api/json?depth=2");
		List<List<String>> filenameList =  Lists.newArrayList();
		List<Map<String, Map<String, Object>>> resultList =  Lists.newArrayList();
		if(!checkStyle.contains("<html>")){
			JSONObject csjson = JSONObject.fromObject(checkStyle);
			String warnings = csjson.get("warnings").toString();
			if(!warnings.equals("[]")){
				JSONArray array = JSONArray.fromObject(warnings); 
				for(int i = 0; i < array.size(); i++){
					String fileStr = array.get(i).toString();
					JSONObject filejson = JSONObject.fromObject(fileStr);
					String fileName = filejson.get("fileName").toString();
					int index = fileName.lastIndexOf("/");
					fileName = fileName.substring(index+1, fileName.length());
					String packageName = filejson.get("packageName").toString();
					if(filenameList.size() == 0){
						List<String> list = Lists.newArrayList();
						list.add(fileName);
						list.add(packageName);
						filenameList.add(list);
					}else{
						for(int j = 0;j<filenameList.size();j++){
							if(filenameList.get(j).get(0).equals(fileName) && filenameList.get(j).get(1).equals(packageName)){
								break;
							}else{
								if(j+1 == filenameList.size()){
									List<String> list = Lists.newArrayList();
									list.add(fileName);
									list.add(packageName);
									filenameList.add(list);
								}
							}
						}
					}
				}
				for(int j = 0;j<filenameList.size();j++){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					int style_high_number = 0;
					int style_normal_number = 0; 
					int style_low_number = 0;
					String name =  filenameList.get(j).get(0);
					String packname =  filenameList.get(j).get(1);
					for(int i = 0; i < array.size(); i++){
						String fileStr = array.get(i).toString();
						JSONObject filejson = JSONObject.fromObject(fileStr);
						String fileName = filejson.get("fileName").toString();
						int index = fileName.lastIndexOf("/");
						fileName = fileName.substring(index+1, fileName.length());
						String packageName = filejson.get("packageName").toString();
						if(name.equals(fileName) && packname.equals(packageName)){
							String priority = filejson.get("priority").toString();
							if(priority.equals("NORMAL")){
								style_normal_number++;
							}else if(priority.equals("HIGH")){
								style_high_number++;
							}else{
								style_low_number++;
							}
							data.put("packageName", packageName);
						}
					}
					data.put("style_high_number", style_high_number);
					data.put("style_normal_number", style_normal_number);
					data.put("style_low_number", style_low_number);
					keyData.put(name, data);
					resultList.add(keyData);
				}
				System.out.println(resultList);
			}
		}
		
		
		//　findbugs
		String findbugs = externalHttpServer.getStrUrl(url +"/findbugsResult/api/json?depth=2");
		if(!findbugs.contains("<html>")){
			JSONObject fbjson = JSONObject.fromObject(findbugs);
			String warnings = fbjson.get("warnings").toString();
			if(!warnings.equals("[]")){
				JSONArray array = JSONArray.fromObject(warnings); 
				for(int i = 0; i < array.size(); i++){
					String fileStr = array.get(i).toString();
					JSONObject filejson = JSONObject.fromObject(fileStr);
					String fileName = filejson.get("fileName").toString();
					int index = fileName.lastIndexOf("/");
					fileName = fileName.substring(index+1, fileName.length());
					String packageName = filejson.get("packageName").toString();
					if(filenameList.size() == 0){
						List<String> list = Lists.newArrayList();
						list.add(fileName);
						list.add(packageName);
						filenameList.add(list);
					}else{
						for(int j = 0;j<filenameList.size();j++){
							if(filenameList.get(j).get(0).equals(fileName) && filenameList.get(j).get(1).equals(packageName)){
								break;
							}else{
								if(j+1 == filenameList.size()){
									List<String> list = Lists.newArrayList();
									list.add(fileName);
									list.add(packageName);
									filenameList.add(list);
								}
							}
						}
					}
				}
				for(int j = 0;j<filenameList.size();j++){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					int bugs_high_number = 0;
					int bugs_normal_number = 0; 
					int bugs_low_number = 0;
					String name =  filenameList.get(j).get(0);
					String packname =  filenameList.get(j).get(1);
					for(int i = 0; i < array.size(); i++){
						String fileStr = array.get(i).toString();
						JSONObject filejson = JSONObject.fromObject(fileStr);
						String fileName = filejson.get("fileName").toString();
						int index = fileName.lastIndexOf("/");
						fileName = fileName.substring(index+1, fileName.length());
						String packageName = filejson.get("packageName").toString();
						if(name.equals(fileName) && packname.equals(packageName)){
							String priority = filejson.get("priority").toString();
							if(priority.equals("NORMAL")){
								bugs_normal_number++;
							}else if(priority.equals("HIGH")){
								bugs_high_number++;
							}else{
								bugs_low_number++;
							}
							data.put("packageName", packageName);
						}
					}
					boolean flag = true;
					for(int n = 0; n < resultList.size();n++){
						if(resultList.get(n).get(name) != null){
							data = resultList.get(n).get(name);
							flag = false;
						}
					}
					data.put("bugs_high_number", bugs_high_number);
					data.put("bugs_normal_number", bugs_normal_number);
					data.put("bugs_low_number", bugs_low_number);
					keyData.put(name, data);
					if(flag){
						resultList.add(keyData);
					}
				}
				System.out.println(resultList);
			}
		}
		
		
		// junit
		String junit = externalHttpServer.getStrUrl(url + "/testReport/api/json");
		if(!junit.contains("<html>")){
			JSONObject junitJson = JSONObject.fromObject(junit);
			String suites = "";
			if(junitJson.has("childReports")){
				String childReport  = junitJson.get("childReports").toString();
				JSONObject childReportJson = JSONObject.fromObject(childReport.substring(1, childReport.length()-1));
				JSONObject resultJson = JSONObject.fromObject(childReportJson.get("child").toString());
				String detailUrl = resultJson.get("url").toString();
				String junitDetail = externalHttpServer.getStrUrl(detailUrl + "testReport/api/json?depth=2");
				JSONObject detailJson = JSONObject.fromObject(junitDetail);
				suites = detailJson.get("suites").toString();
			}else{
				suites = junitJson.get("suites").toString();
			}
			if(!suites.equals("[]")){
				JSONArray array = JSONArray.fromObject(suites); 
				for(int i = 0; i < array.size(); i++){
					String fileStr = array.get(i).toString();
					JSONObject filejson = JSONObject.fromObject(fileStr);
					String cases = filejson.get("cases").toString();
					JSONArray caseArr = JSONArray.fromObject(cases); 
					for(int n = 0; n < caseArr.size(); n++){
						String caseStr = caseArr.get(n).toString();
						JSONObject casejson = JSONObject.fromObject(caseStr);
						String fileName = casejson.get("className").toString();
						int index = fileName.lastIndexOf(".");
						String packageName = fileName.substring(0, index);
						fileName = fileName.substring(index+1, fileName.length()) +".java";
						if(filenameList.size() == 0){
							List<String> list = Lists.newArrayList();
							list.add(fileName);
							list.add(packageName);
							filenameList.add(list);
						}else{
							for(int j = 0;j<filenameList.size();j++){
								if(filenameList.get(j).get(0).equals(fileName) && filenameList.get(j).get(1).equals(packageName)){
									break;
								}else{
									if(j+1 == filenameList.size()){
										List<String> list = Lists.newArrayList();
										list.add(fileName);
										list.add(packageName);
										filenameList.add(list);
									}
								}
							}
						}
					}
				}
				for(int j = 0;j<filenameList.size();j++){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					String name =  filenameList.get(j).get(0);
					String packname =  filenameList.get(j).get(1);
					int skipCount =0;
					int passCount =0;
					int failCount = 0;
					for(int i = 0; i < array.size(); i++){
						String fileStr = array.get(i).toString();
						JSONObject filejson = JSONObject.fromObject(fileStr);
						String cases = filejson.get("cases").toString();
						JSONArray caseArr = JSONArray.fromObject(cases); 
						for(int n = 0; n < caseArr.size(); n++){
							String caseStr = caseArr.get(n).toString();
							JSONObject casejson = JSONObject.fromObject(caseStr);
							String fileName = casejson.get("className").toString();
							int index = fileName.lastIndexOf(".");
							fileName = fileName.substring(index+1, fileName.length()) +".java";
							String packageName = casejson.get("className").toString().substring(0, index);
							if(name.equals(fileName) && packname.equals(packageName)){
								String status = casejson.get("status").toString();
								if(status.equals("PASSED")){
									passCount++;
								}else if(status.equals("SKIPPED")){
									skipCount++;
								}else if(status.equals("FAILED")){
									failCount++;
								}
								data.put("packageName", packageName);
							}
						}
						boolean flag = true;
						for(int n = 0; n < resultList.size();n++){
							if(resultList.get(n).get(name) != null){
								data = resultList.get(n).get(name);
								flag = false;
							}
						}
						
						data.put("passCount", passCount);
						data.put("doCount", skipCount+passCount+failCount);
						keyData.put(name, data);
						if(flag){
							resultList.add(keyData);
						}
					}
				}
				System.out.println(resultList);
			}
		}
		
		// jacoco
		for(int j = 0;j<filenameList.size();j++){
			String name =  filenameList.get(j).get(0);
			String packname =  filenameList.get(j).get(1);
			if(name.contains(".java")){
				String filename = name.substring(0,name.indexOf("."));
				String jacocoUrl = url + "/jacoco/"+packname+"/"+filename+"/api/json";
				String jacoco = externalHttpServer.getStrUrl(jacocoUrl);
				if(!jacoco.contains("<html>")){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					data.put("packageName", packname);
					JSONObject jacocoJson = JSONObject.fromObject(jacoco);
					String branchCoverage  = jacocoJson.get("branchCoverage").toString();
					String instructionCoverage  = jacocoJson.get("instructionCoverage").toString();
					JSONObject branchJson = JSONObject.fromObject(branchCoverage);
					Integer branchCovered  = Integer.valueOf(branchJson.get("covered").toString());
					Integer branchTotal  = Integer.valueOf(branchJson.get("total").toString());
					
					JSONObject instructionJson = JSONObject.fromObject(instructionCoverage);
					Integer instructionCovered  = Integer.valueOf(instructionJson.get("covered").toString());
					Integer instructionTotal  = Integer.valueOf(instructionJson.get("total").toString());
					boolean flag = true;
					for(int n = 0; n < resultList.size();n++){
						if(resultList.get(n).get(name) != null){
							data = resultList.get(n).get(name);
							flag = false;
						}
					}
					data.put("branchCovered", branchCovered);
					data.put("branchTotal", branchTotal);
					data.put("instructionCovered", instructionCovered);
					data.put("instructionTotal", instructionTotal);
					keyData.put(name, data);
					if(flag){
						resultList.add(keyData);
					}
				}
				
			}
		}
		
		System.out.println(resultList);
		
		// sonarQube
		// http://10.157.2.148:9000/api/resources?resource=jp.co.softbank.test.gip.jedi.chronosfamily:rpe:feature-arquillian-ci&&metrics=duplicated_lines_density,complexity,ncloc,sqale_index&depth=2
//		sonarUrl = "http://10.157.2.148:9000/api/resources?resource=jp.co.softbank:qqsa:develop&&metrics=duplicated_lines_density,complexity,ncloc,sqale_index";
		if(sonarUrl.length()!=0){
			String sonarStr = externalHttpServer.getStrUrl(sonarUrl+"&depth=2");
			if(!sonarStr.contains("<html>")){
				JSONArray sonarArr = JSONArray.fromObject(sonarStr); 
				for(int i = 0; i < sonarArr.size(); i++){
					String obj = sonarArr.get(i).toString();
					JSONObject objjson = JSONObject.fromObject(obj);
					String fileName = objjson.get("name").toString();
					if(objjson.get("msr") == null  || objjson.get("scope").toString().equals("PRJ")  || objjson.get("scope").toString().equals("DIR")){
						continue;
					}
					String keyurl = objjson.get("key").toString();
					int index = keyurl.lastIndexOf(":");
					int lastindex = keyurl.lastIndexOf("/");
					String packageName = keyurl.substring(index+1,lastindex);
					packageName = packageName.replace("/", ".");
					if(filenameList.size() == 0){
						List<String> list = Lists.newArrayList();
						list.add(fileName);
						list.add(packageName);
						filenameList.add(list);
					}else{
						for(int j = 0;j<filenameList.size();j++){
							if(filenameList.get(j).get(0).equals(fileName)){
								break;
							}else{
								if(j+1 == filenameList.size()){
									List<String> list = Lists.newArrayList();
									list.add(fileName);
									list.add(packageName);
									filenameList.add(list);
								}
							}
						}
					}
				}
				for(int j = 0;j<filenameList.size();j++){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					int ncloc = 0;
					int complexity = 0; 
					int duplicated_lines = 0;
					int lines = 0;
					String sqale_index ="";
					Integer s = 0;
					Float duplications = null;
					String name =  filenameList.get(j).get(0);
					String packname =  filenameList.get(j).get(1);
					for(int i = 0; i < sonarArr.size(); i++){
						String obj = sonarArr.get(i).toString();
						JSONObject objjson = JSONObject.fromObject(obj);
						String fileName = objjson.get("name").toString();
//					String keyurl = objjson.get("key").toString();
//					int index = keyurl.lastIndexOf(":");
//					int lastindex = keyurl.lastIndexOf("/");
//					String packageName = keyurl.substring(index,lastindex);
						if(name.equals(fileName)){
							if(objjson.get("msr") == null || objjson.get("scope").toString().equals("PRJ") || objjson.get("scope").toString().equals("DIR")){
								continue;
							}
							String msr = objjson.get("msr").toString();
							JSONArray msrArr = JSONArray.fromObject(msr); 
							for(int n = 0; n < msrArr.size(); n++){
								JSONObject msrjson = JSONObject.fromObject(msrArr.get(n).toString());
								String key = msrjson.get("key").toString();
								if(key.equals("sqale_index")){
									sqale_index = msrjson.get("frmt_val").toString();
									sqale_index = sqale_index.replaceAll(" ", "");
									if(sqale_index.contains("d")){
										int d = sqale_index.indexOf("d");
										String dStr = sqale_index.substring(0, d);
										sqale_index = sqale_index.substring(d+1,sqale_index.length());
										int day = Integer.valueOf(dStr);
										s = day*24*60*60;
									}
									if(sqale_index.contains("h")){
										int h = sqale_index.indexOf("h");
										String hStr = sqale_index.substring(0, h);
										sqale_index = sqale_index.substring(h+1,sqale_index.length());
										int hours = Integer.valueOf(hStr);
										s = s + hours*60*60;
									}
									if(sqale_index.contains("min")){
										int m = sqale_index.indexOf("min");
										String minStr = sqale_index.substring(0, m);
										int min = Integer.valueOf(minStr);
										s = s + min*60;
									}
								}
								if(key.equals("duplicated_lines_density")){
									String duplicated_lines_density = msrjson.get("frmt_val").toString();
									duplicated_lines_density = duplicated_lines_density.substring(0, duplicated_lines_density.length()-1);
									duplications = Float.valueOf(duplicated_lines_density);
								}
								if(key.equals("ncloc")){
									String number = msrjson.get("frmt_val").toString().replaceAll(",", "");
									ncloc = Integer.valueOf(number);
								}
								if(key.equals("complexity")){
									String number = msrjson.get("frmt_val").toString().replaceAll(",", "");
									complexity = Integer.valueOf(number);
								}
								if(key.equals("duplicated_lines")){
									String duplicatedLines = msrjson.get("frmt_val").toString().replaceAll(",", "");
									duplicated_lines = Integer.valueOf(duplicatedLines);
								}
								if(key.equals("lines")){
									String l = msrjson.get("frmt_val").toString().replaceAll(",", "");
									lines = Integer.valueOf(l);
								}
								data.put("packageName", packname);
							}
						}
						boolean flag = true;
						for(int n = 0; n < resultList.size();n++){
							if(resultList.get(n).get(name) != null){
								data = resultList.get(n).get(name);
								flag = false;
							}
						}
						data.put("ncloc", ncloc);
						data.put("complexity", complexity);
						data.put("technical_debt", s);
						data.put("duplications", duplications);
						data.put("duplicated_lines", duplicated_lines);
						data.put("lines", lines);
						keyData.put(name, data);
						if(flag){
							resultList.add(keyData);
						}
					}
				}
			}
		}
		
		System.out.println(resultList);
		for(int j = 0; j<resultList.size();j++){
			Map<String, Object> conditions = Maps.newHashMap();
			Map<String,Map<String, Object>> keyData = resultList.get(j);
			for(Map.Entry entry:keyData.entrySet()){
				String filename = entry.getKey().toString();
				conditions.put("file_name", filename);
				conditions.put("deploy_id", deploy_id);
				Map<String, Object> data = (Map<String, Object>)entry.getValue();
				conditions.put("package_name", data.get("packageName"));
				conditions.put("style_high_number",  data.get("style_high_number"));
				conditions.put("style_normal_number",  data.get("style_normal_number"));
				conditions.put("style_low_number",  data.get("style_low_number"));
				conditions.put("bugs_high_number",  data.get("bugs_high_number"));
				conditions.put("bugs_normal_number",  data.get("bugs_normal_number"));
				conditions.put("bugs_low_number",  data.get("bugs_low_number"));
				conditions.put("doCount",  data.get("doCount"));
				conditions.put("successCount",  data.get("passCount"));
				conditions.put("steps",  data.get("ncloc"));
				conditions.put("complexity", data.get("complexity"));
				conditions.put("duplications", data.get("duplications"));
				conditions.put("duplicated_lines", data.get("duplicated_lines"));
				conditions.put("lines", data.get("lines"));
				conditions.put("technical_debt", data.get("technical_debt"));
				conditions.put("branch_covered", data.get("branchCovered"));
				conditions.put("branch_total", data.get("branchTotal"));
				conditions.put("instruction_covered", data.get("instructionCovered"));
				conditions.put("instruction_total", data.get("instructionTotal"));
				db.insert("deploy.insertDeployDetailInfo",conditions);
			}
		}
		System.out.println(resultList);
	}
		
		
}
