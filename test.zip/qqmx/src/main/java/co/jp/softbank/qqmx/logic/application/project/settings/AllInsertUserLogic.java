package co.jp.softbank.qqmx.logic.application.project.settings;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.FileUtils;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class AllInsertUserLogic extends AbstractBaseLogic {

	/**
	 * ファイルデータを一括表示
	 * @throws SoftbankException 
	 */
	public void addFileInfo() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		resultMap.put("fileRealName", context.getParam().get("fileRealName"));
		resultMap.put("fileLines", FileUtils.getFileData(context.getParam().get("fileRealPath"), new FileUtils.ReadLineExecutor() {
			private List<String> list = Lists.newArrayList();
			@Override
			public boolean processLine(String arg0) throws IOException {
				list.add(arg0.replaceAll("\"", ""));
				return true;
			}
			
			@Override
			public List<String> getResult() {
				return list;
			}
		}));
		context.getResultBean().setData(resultMap);
	}
	
	/**
	 * ユーザーデータを一括登録
	 * @throws SoftbankException 
	 */
	public void insertUserInfo() throws SoftbankException {
		String fileLines = context.getParam().get("fileLines");
		if (StringUtils.isNotEmpty(fileLines)) {
			JSONArray array = JSONArray.fromObject(fileLines);
			List<Map<String, Object>> insertUserList = Lists.newArrayList();
			List<Integer> errorList = Lists.newArrayList();
			
			for (int i = 1; i < array.size(); i++) {
				String[] fileDataStr = array.getString(i).split(",");
				Map<String, Object> map = Maps.newHashMap();
				boolean addFlg = true;
				for (int j = 0; j < fileDataStr.length; j++) {
					String key = context.getParam().get("inx_" + j);
					if ("field_login".equals(key)) {
						
						Map<String, Object> conditions = Maps.newHashMap();
						conditions.put("login", fileDataStr[0]);
						List<Map<String, Object>> attachments = db.querys(
								"allInsert.selectUsers", conditions);
						
						if (0 != attachments.size()) {
							addFlg = false;
							errorList.add(i);
							break;
						}
					}
					map.put(key, fileDataStr[j]);
				}
				if (addFlg) {
					insertUserList.add(map);
				}
			}
			
			if (insertUserList != null && insertUserList.size() != 0) {
				Map<String, Object> mapCondition = Maps.newHashMap();
				mapCondition.put("customValues", insertUserList);
				db.insert("allInsert.insertUsersValues", mapCondition);
			}
			
			String message = "";
			if (errorList != null && errorList.size() > 0) {
				message = getMessage("301410.add_error_users_result",
						new Integer[] { errorList.size() });
			}
			if (insertUserList != null && insertUserList.size() > 0) {
				message += getMessage("301410.add_users_result",
						new Integer[] { insertUserList.size() });
			}
			context.getResultBean().setResultMsg(message);
			context.getResultBean().setData(errorList);
		}
	}
	
}
