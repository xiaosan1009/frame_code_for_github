
package co.jp.softbank.qqmx.util;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import com.google.common.io.LineProcessor;

/**
 * 譁?ｻｶ逧??騾壽桃菴懃ｱｻ.
 * 
 * @author King
 * @since 2011.07.22
 */
public final class FileUtils {
    
    public static final Object LOCK = new Object();
    
    private static final long MAX_SIZE = 10000;
    
    private static long sSequenceNo = 1;
    
    private static Logger log = new LogUtil(FileUtils.class).getLog();

    private FileUtils() {
    }
    
    public interface ReadLineExecutor extends LineProcessor<List<String>> {
    }

    public static File createFile(String fileName) throws SoftbankException {
    	File file = new File(fileName);
    	if (!file.exists()) {
    		createFile(file.getAbsolutePath(), file);
		}
    	return file;
	}
	
    public static void createFile(String path, final File file) throws SoftbankException {
		try {
			createFolder(path);
			
			if (file.exists()) {
				file.delete();
			}
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
	}
    
    public static File createFolder(String path) {
        final File folder = new File(path);
        
        if (!folder.exists()) {
            folder.mkdirs();
        }
        return folder;
    }
    
    public static String getFileName(File file) {
    	String fileName = file.getName();
    	if (file.isDirectory() || fileName.indexOf(ConstantsUtil.Str.DOT) == -1) {
    		return fileName;
    	}
    	return fileName.substring(0, fileName.indexOf(ConstantsUtil.Str.DOT));
    }
    
    public static List<String> getFilesName(String path) {
    	List<String> result = Lists.newArrayList();
    	final File folder = new File(path);
    	if (folder.isDirectory()) {
//			folder.listFiles();
    	}
    	return result;
    }
    
    public static void deleteFile(String path) {
        if (StringUtils.isNotEmpty(path)) {
            final File file = new File(path);
            
            if (file.exists()) {
                file.delete();
            }
        }
    }
    
    public static boolean deleteAllFile(String path) {
    	File dir = new File(path);
    	if (!dir.exists()) {
			return true;
		}
        return deleteAllFile(dir);
    }
    
	public static boolean deleteAllFile(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteAllFile(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}
		return dir.delete();
	}
    
    public static List<String> getFileData(String path) {

        final File f = new File(path);
        
        return getFileData(f, null);
    }
    
    public static List<String> getFileData(String path, ReadLineExecutor executor) {
    	
    	final File f = new File(path);
    	
    	return getFileData(f, executor);
    }
    
    public static List<String> getFileData(File f, ReadLineExecutor executor) {
    	List<String> list1 = null;
    	try {
    		if (executor != null) {
    			list1 = Files.readLines(f, Charsets.UTF_8, executor);
			} else {
				list1 = Files.readLines(f, Charsets.UTF_8);
			}
    	} catch (IOException e1) {
    		return null;
    	}
    	
    	return list1;
    }
    
    public static String getFileDataString(String path) throws SoftbankException {
        return getFileDataString(path, ConstantsUtil.Frame.ENCODING);
    }
    
    public static String getFileDataString(String path, String encode) throws SoftbankException {
        
        final File f = new File(path);
        
        return getFileDataString(f, encode);
    }
    
    public static String getFileDataString(File file) throws SoftbankException {
    	return getFileDataString(file, ConstantsUtil.Frame.ENCODING);
    }
    
    public static String getFileDataString(File file, String encode) throws SoftbankException {
    	
    	Charset charset = Charset.forName(encode);
    	
    	String str = "";
		try {
			str = Files.toString(file, charset);
		} catch (IOException e1) {
			e1.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e1);
		}
        
        return str;
    }
    
    public static void writeFileData(String fileName, String data) 
        throws SoftbankException {

    	writeFileData(fileName, data, ConstantsUtil.Frame.ENCODING);
    }
    
    public static void writeFileData(String fileName, String data, String encode) 
    		throws SoftbankException {
    	try {
    		Charset charset = Charset.forName(encode);
    		File newFile = createFile(fileName);
    		Files.write(data, newFile, charset);
    	} catch (IOException e) {
    		e.printStackTrace();
    		throw new SoftbankException(SoftbankExceptionType.IOException, e);
    	}
    }
    
    public static String createFileId(String fileName) {
        int current = 10;
        synchronized (LOCK) {
            if (sSequenceNo > MAX_SIZE) {
                sSequenceNo = 10;
            }
            current += sSequenceNo++;
        }
        return fileName + current;
    }
    
    
}