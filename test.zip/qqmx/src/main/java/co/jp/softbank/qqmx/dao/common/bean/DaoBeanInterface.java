package co.jp.softbank.qqmx.dao.common.bean;

import net.sf.json.JSONObject;

public interface DaoBeanInterface {
	
	void toJson(JSONObject dataObj);
	
	void setId(int id);

}
