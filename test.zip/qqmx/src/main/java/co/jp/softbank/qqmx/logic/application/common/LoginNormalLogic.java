package co.jp.softbank.qqmx.logic.application.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.issues.IssuesDao;
import co.jp.softbank.qqmx.dao.issues.bean.IssuesBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.server.ExternalHttpServer;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class LoginNormalLogic extends AbstractBaseLogic {
	
	public LogicBean userLogin() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		Param param = context.getParam();
		
		UserInfoData userInfoData = new UserInfoData();
		Map<String, String> params = Maps.newHashMap();
		params.put("username", param.get("userLogin"));
		params.put("password", param.get("userPwd"));
		Map<String, Object> userInfo = db.query("users.doUserLogin", params);
		
		if (userInfo == null) {
			logicBean.setResultFlg(false);
			logicBean.setResultMsg("無効なアカウントまたはパスワードです。入力し直してください。");
			return logicBean;
		}
		userInfoData.setId(StringUtils.toInt(userInfo.get("id")));
		userInfoData.setLogin(StringUtils.toString(userInfo.get("login")));
		userInfoData.setApiToken(StringUtils.toString(userInfo.get("api_token")));
		userInfoData.setAdmin("true".equals(userInfo.get("admin")));
		userInfoData.setName(userInfo.get("lastname") + " " + userInfo.get("firstname"));
		userInfoData.setFirstName(StringUtils.toString(userInfo.get("firstname")));
		userInfoData.setLastName(StringUtils.toString(userInfo.get("lastname")));
		context.getSessionData().set(UserInfoData.USER_INFO_KEY, userInfoData);
		
		Map<String, String> data = new HashMap<String, String>();
		data.put("userLogin", userInfoData.getLogin());
		data.put("userName", userInfoData.getName());
		String forwardUrl = context.getForwardUrlPath();
		if (StringUtils.isNotEmpty(forwardUrl)) {
			data.put("forwardUrl", forwardUrl);
		}
		logicBean.setData(data);
		context.setLang(ConstantsUtil.Lang.JAPAN);
		return logicBean;
	}

	@Override
	protected IDaoInterface getDao() {
		return null;
	}

}
