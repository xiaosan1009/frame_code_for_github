package co.jp.softbank.qqmx.logic.application.batch;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang.StringUtils;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import com.google.common.collect.Maps;


/**
 * 版管理ツール(Git)からソースファイルを取得して、
 */
public class GitFileCheckLogic extends SourceScaleCount {
	/**
	* ソース規模データ収集(FileCheckBatch用) 
	* 
	*/
	public void sourceCheck() {
		try {
			String gitPath   = context.getParam().get("gitPath");
			String repoPath    = gitPath + "/.git";
			String branch      = context.getParam().get("branch");

			checkoutFile(gitPath, branch);

			getSourceInfo(repoPath);

		} catch (Exception e) {

		} finally {

		}
	}
	
	public void checkoutFile(String gitPath, String branch) {
		try {
//			String cmd = "/opt/ipftools/testreview-platform.git/checkoutGitFile.sh " 
			String cmd = "/opt/ipftools/checkout-review-platform.git/checkoutGitFile.sh " 
					 + gitPath + " " + branch;
			Process process = Runtime.getRuntime().exec(cmd);

			log.info("☆☆☆ cmd ☆☆☆" + cmd);
			process.waitFor();
			process.destroy();
			
			log.info("☆☆☆ cmd ☆☆☆" + cmd);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void getSourceInfo(String repoPath) throws Exception {

		RevWalk rwalk = null;
		try {

			// Git コミットログ取得
			Repository repository = IpfJGitUtils.getGitRepository(repoPath);
			// リビジョンリストを取得
			rwalk = IpfJGitUtils.getAllRevWalk(repository);
//
			Iterator<RevCommit> revIter = null;

			log.info("全リビジョン取得.");
			// 全リビジョン
			revIter = IpfJGitUtils.getRevList(repository);
			log.info(revIter);
//			}

			String commitCode = null;
			if (revIter.hasNext()) {
				RevCommit commit = revIter.next();
				if (commit == null) {
					log.info("☆☆☆ commit null　： ☆☆☆");
					return;
				}
				log.info("☆☆☆ commit　： ☆☆☆" + commit);
				log.info("☆☆☆ commit　： ☆☆☆" + IpfJGitUtils.getCommitDate(commit));
				log.info("☆☆☆ commit　： ☆☆☆" + commit.getName());
				commitCode = getIssuesId (commit); 
				log.info("☆☆☆ commitCode1　： ☆☆☆" + commitCode);
				if (commitCode.equals("")) {
					log.info("☆☆☆ commit 空　： ☆☆☆");
					return;
				}
			}
			
			revIter = IpfJGitUtils.getRevList(repository);
			Date firstCommit = new Date();
			firstCommit.getTime();
			String testVersion = null;
			// リビジョンで繰り返し
			while (revIter.hasNext()) {
				RevCommit commit = revIter.next();
				
				String commitCodeBefore = getIssuesId (commit);              // コミットメッセージ
				if(commitCodeBefore.equals(commitCode)){
					firstCommit = IpfJGitUtils.getCommitDate(commit);
					testVersion = commit.getName();
				}
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String createdData = sdf.format(firstCommit);
			
			log.info("☆☆☆ firstCommit　： ☆☆☆" + firstCommit);
			log.info("☆☆☆ testVersion　： ☆☆☆" + testVersion);
			log.info("☆☆☆ createdData　： ☆☆☆" + createdData);
			
			revIter = IpfJGitUtils.getRevList(repository);
			if (revIter.hasNext()) {
				RevCommit commit = revIter.next();
				log.info("☆☆☆ commit　： ☆☆☆" + IpfJGitUtils.getCommitDate(commit));
				log.info("☆☆☆ commit　： ☆☆☆" + commit.getName());

				TreeWalk twalk = null;
				try {
					twalk = IpfJGitUtils.getTreeWalk(repository, commit, rwalk);
					// ソースファイル数分繰り返し
					while (twalk.next()) {
						doFileCheck( commit, twalk, createdData);
					}

				} catch (IpfSQLNormalException isne) {

				} catch (Exception e) {

				} finally {
					if (twalk != null) {
						twalk.release();
					}
				}
			}

		} finally {

		}
	}

	protected void doFileCheck (RevCommit commit,TreeWalk twalk,String createdData) throws Exception {

		String issuesId = getIssuesId (commit);              // コミットメッセージ
		String revision = commit.getName();                     // リビジョン
		Date updDate = IpfJGitUtils.getCommitDate(commit);   // 更新日時

		byte[] filePathBytes = twalk.getRawPath();                          // ファイルフルパス（ファイル名含む） バイト配列
		String gitPath   = context.getParam().get("gitPath");
		String filePath      = gitPath + "/" + IpfJGitUtils.getDecodeStr(filePathBytes);    // ファイルフルパス（ファイル名含む）

		log.info("filePath: " + filePath);
		log.info("issuesId: " + issuesId);
		log.info("revision: " + revision);
		log.info("updDate: " + updDate);
//		externalHttpServer.getStrUrl("http://10.157.30.230:8080/qqrp/qqrp.mx?dispCode=900006&cmdCode=1&issueId=" + issuesId + "&gitFlg=1&filePath=" + filePath + "&createdData=" + createdData); //230環境 誤字脱字
//		externalHttpServer.getStrUrl("http://10.157.30.230:8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + issuesId); //230環境 コメント
		externalHttpServer.getStrUrl("http://10.216.80.167:8080/qqrp/qqrp.mx?dispCode=900006&cmdCode=1&issueId=" + issuesId + "&gitFlg=1&filePath=" + filePath + "&createdData=" + createdData); //本番環境 誤字脱字
		externalHttpServer.getStrUrl("http://10.216.80.167:8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + issuesId); //本番環境 コメント

	}


	protected String getIssuesId (RevCommit commit) throws Exception {
		
		String message = commit.getFullMessage();			// コミットメッセージ
		String issuesId = "";
		if(message.indexOf("refs #") != -1){
			String regEx = "[^0-9]";
			Pattern p = Pattern.compile(regEx);
			if(commit != null){
				Matcher m = p.matcher(message);
				issuesId = m.replaceAll("").trim();
			}
		}
		return issuesId;
	}
	
}
