package co.jp.softbank.qqmx.util.tag;

import javax.servlet.jsp.tagext.BodyTagSupport;

import org.apache.commons.fileupload.FileUploadException;
import org.slf4j.Logger;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.util.LogUtil;

public class BodyTagSupportBase extends BodyTagSupport {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	protected HttpContext getHttpContext() throws FileUploadException, SoftbankException {
		return new HttpContext(pageContext.getRequest(), pageContext.getResponse());
	}

}
