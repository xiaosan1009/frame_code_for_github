package co.jp.softbank.qqmx.logic.application.reform;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

public class TuLogicBase extends AbstractBaseLogic {
	
	protected final static String EMPTY = "9898";
	
	protected final static Map<String, String> actionLabelMap = Maps.newHashMap();
	
	static {
		actionLabelMap.put("620101", "①レベル別施策効果積み上げ計画");
		actionLabelMap.put("620003", "②責任者別活動サマリー");
		actionLabelMap.put("620007", "③健康度");
		actionLabelMap.put("620005", "④施策遅延状況サマリー");
		actionLabelMap.put("620006", "⑤施策別効果一覧");
		actionLabelMap.put("620004", "⑥一時コスト一覧");
		actionLabelMap.put("620102", "人工削減目標数推移");
		actionLabelMap.put("620104", "業託削減目標数推移");
		actionLabelMap.put("620103", "施策立案状況");
		actionLabelMap.put("620106", "2カ年月次要員リソース推移");
		actionLabelMap.put("620010", "組織別レベルサマリー");
	}
	
	public List<Map<String, Object>> querys(String sql, Map<String, Object> conditions) throws SoftbankException {
		return db.querys(sql, conditions);
	}
	
	public void doFilter() throws SoftbankException {
		try {
			String dispCode = context.getParam().dispCode;
			
			String[] params = null;
			
			if ("620002".equals(dispCode)) {
				context.getResultBean().setFilter(true);
				return;
			}
			
			// 全従業員/社員/業託
			String dispartch = context.getParam().get("dispartchId");
			if (StringUtils.isEmpty(dispartch)) {
				dispartch = EMPTY;
			}
			if (!EMPTY.equals(dispartch)) {
				dispartch = URLDecoder.decode(dispartch, "utf-8");
			}
			
			// 新規/既存
			String category = context.getParam().get("categoryId");
			if (StringUtils.isEmpty(category)) {
				category = EMPTY;
			}
			if (!EMPTY.equals(category)) {
				category = URLDecoder.decode(category, "utf-8");
			}
			
			// 人工数/金額/施策数
			String status = context.getParam().get("statusId");
			if (StringUtils.isEmpty(status)) {
				status = EMPTY;
			}
			if (!EMPTY.equals(status)) {
				status = URLDecoder.decode(status, "utf-8");
			}
			
			if ("金額".equals(status) && "正社員".equals(dispartch)) {
				params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {"金額", "正社員"})};
				setErrorFilter(params);
				return;
			}
			
			// 組織別活動サマリー
			if ("620010".equals(dispCode)) {
				if ("金額".equals(status) || "施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {status})};
					setErrorFilter(params);
					return;
				}
			}
			
			// ②責任者別活動サマリー
			if ("620003".equals(dispCode)) {
				if ("金額".equals(status) || "施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {status})};
					setErrorFilter(params);
					return;
				}
			}
			
			// ③健康度
			if ("620007".equals(dispCode)) {
				if ("施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {"施策数"})};
					setErrorFilter(params);
					return;
				}
			}
			
			// ⑤施策別効果一覧
			if ("620006".equals(dispCode)) {
				if ("金額".equals(status) || "施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {status})};
					setErrorFilter(params);
					return;
				}
			}
			
			// ⑥一時コスト一覧
			if ("620004".equals(dispCode)) {
				if ("施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {"施策数"})};
					setErrorFilter(params);
					return;
				}
			}
			
			// 人工削減目標数推移
			if ("620102".equals(dispCode)) {
				if ("施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {"施策数"})};
					setErrorFilter(params);
					return;
				}
			}
			
			// 業託削減目標数推移
			if ("620104".equals(dispCode)) {
				if ("施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {status})};
					setErrorFilter(params);
					return;
				}
				if ("正社員".equals(dispartch)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {dispartch})};
					setErrorFilter(params);
					return;
				}
			}
			
			// 施策立案状況
			if ("620103".equals(dispCode)) {
				if ("施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {"施策数"})};
					setErrorFilter(params);
					return;
				}
			}
			
			// 2カ年月次要員リソース推移
			if ("620106".equals(dispCode)) {
				if ("施策数".equals(status)) {
					params = new String[] {actionLabelMap.get(dispCode), createErrorMessage(new String[] {"施策数"})};
					setErrorFilter(params);
					return;
				}
			}
			context.getResultBean().setFilter(true);
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}
	
	private void setErrorFilter(String[] params) {
		context.getResultBean().setResultMsg(messageAccessor.getMessage("tu.roles.message", params));
		context.getResultBean().setFilter(false);
		context.getResultBean().setShowPanel(true);
	}
	
	private String createErrorMessage(String[] msgs) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < msgs.length; i++) {
			sb.append("<br>・" + msgs[i]);
		}
		return sb.toString();
	}
	
	@Override
	protected void paramInit() {
//		if (StringUtils.isEmpty(context.getParam().get("newDate"))) {
//			String newDate = StringUtils.toString(db.query("selectNewDate").get("newDate"));
//		}

	}

}
