package co.jp.softbank.qqmx.server;

import co.jp.softbank.qqmx.server.face.ISocketLogicInterface;
import co.jp.softbank.qqmx.server.impl.UserChatLogicImpl;

public class SocketLogicFactory {
	
	public enum SocketLogicType {
		CHAT("chat"),
		GANTT("gantt");
		
		private String type;
		
		private SocketLogicType(String type) {
			this.type = type;
		}
		
		public static SocketLogicType get(String type) {
			final SocketLogicType[] enums = SocketLogicType.values();
			for (int i = 0; i < enums.length; i++) {
				if (type.equals(enums[i].type)) {
					return enums[i];
				}
			}
			return null;
		}
	}
	
	public static ISocketLogicInterface getLogic(SocketLogicType type) {
		switch (type) {
		case CHAT:
			return new UserChatLogicImpl();

		default:
			break;
		}
		return null;
	}

}
