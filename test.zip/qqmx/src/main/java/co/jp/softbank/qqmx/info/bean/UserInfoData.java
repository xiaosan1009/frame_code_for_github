package co.jp.softbank.qqmx.info.bean;

import net.sf.json.JSONObject;

public class UserInfoData {
	
	public static final String USER_INFO_KEY = "USER_INFO_KEY";
	
	private int id;
	
	private String login;
	
	private String pwd;
	
	private String name;
	
	private String firstName;
	
	private String lastName;
	
	private String commonEmployeeNumber;
	
	private String dataSource;
	
	private String provinceId;
	
	private String apiToken;
	
	private String employeeTypeCd;
	
	private String employeeTypeName;
	
	private boolean admin;

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getApiToken() {
		return apiToken;
	}

	public void setApiToken(String apiToken) {
		this.apiToken = apiToken;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCommonEmployeeNumber() {
		return commonEmployeeNumber;
	}

	public void setCommonEmployeeNumber(String commonEmployeeNumber) {
		this.commonEmployeeNumber = commonEmployeeNumber;
	}
	
	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(String provinceId) {
		this.provinceId = provinceId;
	}

	public String getEmployeeTypeCd() {
		return employeeTypeCd;
	}

	public void setEmployeeTypeCd(String employeeTypeCd) {
		this.employeeTypeCd = employeeTypeCd;
	}

	public String getEmployeeTypeName() {
		return employeeTypeName;
	}

	public void setEmployeeTypeName(String employeeTypeName) {
		this.employeeTypeName = employeeTypeName;
	}

	public JSONObject toJson() {
		JSONObject object = new JSONObject();
		object.put("id", id);
		object.put("login", login);
		object.put("name", name);
		object.put("firstName", firstName);
		object.put("lastName", lastName);
		object.put("commonEmployeeNumber", commonEmployeeNumber);
		object.put("apiToken", apiToken);
		object.put("employeeTypeCd", employeeTypeCd);
		object.put("employeeTypeName", employeeTypeName);
		object.put("admin", admin);
		return object;
	}

}
