package co.jp.softbank.qqmx.info;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.util.ClassUtil;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;

public final class ControlResourceMap {
    
	private Logger log = new LogUtil(this.getClass()).getLog();
    
    private static final String COMMON_PROPERTIES_KEY = "COMMON_PROPERTIES_KEY";
    
    private static final String COMMON_PROPERTIES_PATH = "co/jp/softbank/qqmx/resource";
    
    private static ControlResourceMap sMe;
    
    private Map<String, Properties> itemNameMap;
    
    private static String sPath;
    
    /**
     * 构造函数
     * @throws RichClientWebException RichClientWebException
     */
    private ControlResourceMap() throws SoftbankException {
        super();
        itemNameMap = new HashMap<String, Properties>();
        
        addCommonResource();
        
        if (StringUtils.isNotEmpty(sPath)) {
            readItemField(sPath, ConstantsUtil.Suffix.PROPERTY);
        }
//        String framePath = Config.getProperty("");
//        readItemField(sFramePath, "properties", itemNameMap);
    }
    
    /**
     * 本类对象生成.
     * @return ControlResourceMap 本类对象
     * @throws RichClientWebException RichClientWebException
     */
    public static ControlResourceMap getInstance() throws SoftbankException {
        
        synchronized (ControlResourceMap.class) {
            if (sMe == null) {
                sMe = new ControlResourceMap();
            }
        }
        return sMe;
    }

    /**
     * 文件路径取得.
     * @return sPath 文件路径
     */
    public static String getPath() {
        return sPath;
    }

    /**
     * 文件路径设定.
     * @param path 文件路径
     */
    public static void setPath(String path) {
        ControlResourceMap.sPath = path;
    }
    
    /**
     * 项目名称取得.
     * @param itemId 项目ID
     * @return 项目名称
     */
    public String getItemName(String itemId) {
        return getItemName(null, itemId);
    }
    
    /**
     * 项目名称取得.
     * @param httpContext 容器对象
     * @param itemId 项目ID
     * @return 项目名称
     */
    public String getItemName(HttpContext httpContext, String itemId) {
        log.debug("httpContext = {},itemId = {},itemNameMap = {}", Lists.newArrayList(httpContext, itemId, itemNameMap).toArray());
        if (StringUtils.isEmpty(itemId)) {
            return ConstantsUtil.Str.EMPTY;
        }
        String itemName = ConstantsUtil.Str.EMPTY;
        if (itemNameMap != null) {
        	String lang = httpContext.getLang();
        	String resourceKey = getFileKey(httpContext.getParam().dispCode, lang);
        	log.debug("resourceKey = {}", resourceKey);
        	String commonPropertyKey = getCommonPropertyKey(lang);
        	log.debug("commonPropertyKey = {}", commonPropertyKey);
            if (itemNameMap.get(resourceKey) != null && itemNameMap.get(resourceKey).get(itemId) != null) {
                itemName = (String)itemNameMap.get(resourceKey).get(itemId);
            } else if (itemNameMap.get(commonPropertyKey) != null 
                    && itemNameMap.get(commonPropertyKey).get(itemId) != null) {
                itemName = StringUtils.toString(itemNameMap.get(commonPropertyKey).get(itemId));
            }
        }
        log.debug("itemName = " + itemName);
        return itemName;
    }
    
    /**
     * 资源文件对象取得.
     * @param path 文件路径
     * @param extension 文件后缀
     * @param retMap 资源文件对象
     * @throws RichClientWebException RichClientWebException
     */
    private void readItemField(String path, String extension) throws SoftbankException {
        
        log.debug("path = " + path);
        
        final File dir = new File(path);
        
        if (!dir.isDirectory()) {
            return;
        }
        final File[] dirs = dir.listFiles();
        
        for (int i = 0; i < dirs.length; i++) {
            
            if (dirs[i].isDirectory()) {
                
                final File[] files = dirs[i].listFiles();
                for (File file : files) {
                    addProperties(file, extension);
                }
            } else if (dirs[i].isFile()) {
                addProperties(dirs[i], extension);
            }
        }
        
    }
    
    private void addCommonResource() throws SoftbankException {
    	Map<String, Properties> propertiesInfo = ClassUtil.getPackageProperties(COMMON_PROPERTIES_PATH);
    	
    	for (String name : propertiesInfo.keySet()) {
    		final Properties properties = propertiesInfo.get(name);
    		final String lang = getFileLang(name);
    		final String commonKey = getCommonPropertyKey(lang);
    		if (itemNameMap.containsKey(commonKey)) {
    			itemNameMap.get(commonKey).putAll(properties);
    		} else {
    			itemNameMap.put(commonKey, properties);
    		}
    	}
    }
    
    private String getCommonPropertyKey(String lang) {
    	return getFileKey(COMMON_PROPERTIES_KEY, lang);
    }
    
    private String getFileKey(String name, String lang) {
    	return name + ConstantsUtil.Str.UNDERLINE + lang;
    }
    
    private String getFileLang(String fileName) {
    	String lang = fileName.substring(fileName.indexOf(ConstantsUtil.Str.UNDERLINE) + 1);
    	if (lang.indexOf(ConstantsUtil.Str.REGEX_DOT) != -1) {
    		lang = lang.substring(0, lang.indexOf(ConstantsUtil.Str.REGEX_DOT));
		}
    	log.info("lang = " + lang);
    	return lang;
    }
    
    /**
     * 添加资源文件对象.
     * @param retMap 资源文件对象
     * @param file 文件对象
     * @param extension 文件后缀
     * @throws RichClientWebException RichClientWebException
     */
    private void addProperties(File file, String extension) throws SoftbankException {
        
        try {
            if (file.getName().endsWith(extension)) {
                final Properties map = new Properties();
                final Properties properties = new Properties();
                
                properties.load(new FileInputStream(file));
                map.putAll(properties);
                
                String fileName = file.getName();
                final int extIdx = getExtensionIndex(fileName, extension);
                
                if (extIdx > 0) {
                    fileName = fileName.substring(0, extIdx);
                    itemNameMap.put(fileName, map);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.FileNotFoundException, e);
        } catch (IOException e) {
            e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.IOException, e);
        }
    }
    
    /**
     * 资源文件后缀位置取得.
     * @param fileName 文件名
     * @param extension 文件后缀
     * @return 资源文件后缀
     */
    private int getExtensionIndex(String fileName, String extension) {
        final int extIdx = fileName.indexOf(ConstantsUtil.Str.DOT + extension);
        return extIdx;
    }
}
