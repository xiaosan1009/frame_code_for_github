package co.jp.softbank.qqmx.filter;

import java.io.IOException;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.lang.ObjectUtils.Null;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.ControlRequestMap;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.ControlSettingMap.SettingKey;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.bean.SessionData;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class SessionCheckFilter extends AbstractCommonFilter {
    
    public SessionCheckFilter() {
        super();
    }

    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
        
        try {
        
            if (request instanceof HttpServletRequest) {
                final HttpServletRequest req = (HttpServletRequest) request;
                if (ServletFileUpload.isMultipartContent(req)) {
                	chain.doFilter(request, response);
                	return;
                }
                HttpContext httpContext = new HttpContext(request, response);
                final String explorerInfo = req.getHeader("user-agent");
                final Cookie[] cookies = req.getCookies();
                final StringBuffer cookieBuff = new StringBuffer();
                if (cookies != null && cookies.length > 0) {
                    for (int i = 0; i < cookies.length; i++) {
                        final Cookie cookie = cookies[i];
                        cookieBuff.append(cookie.getName() + "=" + cookie.getValue() + ";");
                    }
                }
                final String cookieInfo = cookieBuff.toString();
                final String requestPath = req.getServletPath();
                final String requestUrl = StringUtils.toString(req.getRequestURL());
                final String remoteAddr = req.getRemoteAddr();
                final String remoteHost = req.getRemoteHost();
                final String remotePort = StringUtils.toString(req.getServerPort());
                final String queryString = req.getQueryString();

                if (httpContext.isEngineTest()) {
                	log.info("user-agent = {}, requestPath = {},requestUrl = {}, queryString = {},remoteAddr = {},remoteHost = {},cookieInfo = {}", 
                			Lists.newArrayList(explorerInfo, requestPath, requestUrl, queryString, remoteAddr, remoteHost, remotePort, cookieInfo).toArray());
				}
                if ("/websocket.mx".equals(requestPath)) {
//                	chain.doFilter(request, response);
                	return;
                }
                SessionData seData = null;
                UserInfoData ope = null;
                HttpSession session = req.getSession(false);
                log.debug("session == " + session);
                httpContext.createSession();
                if (session != null) {
                    final Object obj = session.getAttribute(SessionData.APPLICATION_SESSION_KEY);
                    log.debug("sessionData == " + obj);
                    if (obj != null) {
                        if (obj instanceof SessionData) {
                            seData = (SessionData)obj;
                            ope = (UserInfoData)seData.get(UserInfoData.USER_INFO_KEY);
                        }
                    }
                }
                if (httpContext.isEngineTest()) {
                	log.info("httpContext.getLang = {}", httpContext.getLang());
				}
                httpContext.getRequest().setAttribute("qqmxLocale", httpContext.getLang());
                if (httpContext.isEngineTest()) {
                	log.info("dispCode = {},cmdCode = {}", 
                			Lists.newArrayList(httpContext.getParam().dispCode, httpContext.getParam().cmdCode).toArray());
                }
                
                // 当画面ID与方法ID其一不存在的
                if (StringUtils.isEmpty(httpContext.getParam().dispCode) || StringUtils.isEmpty(httpContext.getParam().cmdCode)) {
                    log.warn("dispcode or cmdcode is empty!");
                    forwardError(httpContext, SoftbankExceptionType.RequestParamterError);
                    return;
                }
                
                if (!checkSessionExist(httpContext, ope)) {
                    log.info("doFilter", "user session timeout!");
                    httpContext.setForwardUrlPath(requestUrl + "?" + queryString);
                    sessionTimeOut(httpContext);
                    seData = null;
//                    if (session != null) {
//                        session.invalidate();
//                    }
                    session = null;
                    return;
                }
                chain.doFilter(request, response);
            }
        } catch (SoftbankException e) {
            e.printStackTrace();
        } catch (FileUploadException e) {
			e.printStackTrace();
		}
    }
    
    private void doUserLogin(UserInfoData userInfoData) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("login", userInfoData.getLogin().toLowerCase());
		Map<String, Object> userInfo = db.queryC("users.getUserInfoByLogin", conditions);
		userInfoData.setId(StringUtils.toInt(userInfo.get("id")));
		userInfoData.setLogin(StringUtils.toString(userInfo.get("login")));
		userInfoData.setAdmin("true".equals(StringUtils.toString(userInfo.get("admin"))));
		userInfoData.setName(StringUtils.toString(userInfo.get("userName")));
		userInfoData.setFirstName(StringUtils.toString(userInfo.get("firstname")));
		userInfoData.setLastName(StringUtils.toString(userInfo.get("lastname")));
		userInfoData.setApiToken(StringUtils.toString(userInfo.get("apiToken")));
		userInfoData.setEmployeeTypeCd(StringUtils.toString(userInfo.get("employee_type_cd")));
		userInfoData.setEmployeeTypeName(StringUtils.toString(userInfo.get("employee_type_name")));
		userInfoData.setCommonEmployeeNumber(StringUtils.toString(userInfo.get("commonEmployeeNumber")));
		
		Map<String, Object> conditionLoginInfos = Maps.newHashMap();
		conditionLoginInfos.put("login_id", userInfoData.getLogin());
		db.insertC("co.jp.softbank.qqmx.dao.common.CommonDao.saveLoginInfos", conditionLoginInfos);
	}

    private boolean checkSessionExist(HttpContext httpContext, UserInfoData userInfo) throws SoftbankException {
        boolean hasSession = true;
        if (!ControlRequestMap.getInstance().isAutoLogout(httpContext.getParam())) {
			hasSession = true;
		} else {
			if (ControlRequestMap.getInstance().isEaction(httpContext.getParam())) {
				log.debug("userInfo = " + userInfo);
				if (userInfo == null) {
					String loginUser = httpContext.getRequest().getHeader("x-forwarded-user");
					log.debug("loginUser = " + loginUser);
					if (StringUtils.isEmpty(loginUser)) {
						if (ControlSettingMap.getInstance().getBoolean(ControlSettingMap.SettingKey.DEBUG_MODEL)) {
							if (StringUtils.isNotEmpty(ControlSettingMap.getInstance().getString(SettingKey.DEFAULT_USER))) {
								loginUser = ControlSettingMap.getInstance().getString(SettingKey.DEFAULT_USER);
							} else {
								loginUser = "os62";
							}
						} else {
							return false;
						}
					}
					UserInfoData userInfoData = new UserInfoData();
					userInfoData.setLogin(loginUser);
					doUserLogin(userInfoData);
					httpContext.getSessionData().set(UserInfoData.USER_INFO_KEY, userInfoData);
				}
			} else {
				if (userInfo == null) {
					log.info("userInfo == null");
					hasSession = false;
				} else {
					hasSession = true;
				}
			}
		}
        return hasSession;
    }

    public void destroy() {
    }
    
}
