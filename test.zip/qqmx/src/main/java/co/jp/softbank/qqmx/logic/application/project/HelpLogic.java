package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.help.HelpDao;
import co.jp.softbank.qqmx.dao.project.help.bean.HelpQuestionBean;
import co.jp.softbank.qqmx.dao.project.help.bean.HelpQuestionCategoryBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.UploadFileInfo;
import co.jp.softbank.qqmx.util.CommonUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class HelpLogic extends AbstractBaseLogic {
	
	private static final String UPLOAD_FILE_PATH = "file/help/";
	
	@Autowired
	private HelpDao helpDao;
	
	private CommonUtil commonUtil;

	/**
	 * カテゴリ取得
	 */
	public void getQuestionsCategory() {
		// カテゴリを取得
		List<HelpQuestionCategoryBean> helpQuestionCategoryBeans = helpDao.getQuestionsCategory();
		context.getResultBean().setData(helpQuestionCategoryBeans);
	}

	/**
	 * カテゴリごとに質問取得
	 */
	public LogicBean getQuestionsByCategory() {
		LogicBean logicBean = new LogicBean();
		// FAQ内容を取得
		String categoryId = context.getParam().get("categoryId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("category_id", Integer.parseInt(categoryId));
		List<HelpQuestionBean> helpQuestionBeans = helpDao.getQuestions(conditions);
		logicBean.setData(helpQuestionBeans);
		return logicBean;
	}
	
	/**
	 * 質問閲覧歴増
	 * cmdNo.3
	 * @throws SoftbankException 
	 */
	public LogicBean addQuestionHistory() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
//		int authorId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
//		int authorId = 1142;
		// TODO 本番はこっち
		Map<String, Object> userInfo = db.query("users.getUserInfoByLogin");
		int authorId = StringUtils.toInt(userInfo.get("id"));
		int questionId = Integer.parseInt(context.getParam().get("questionId"));
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("author_id", authorId);
		conditions.put("question_id", questionId);
		helpDao.addQuestionHistory(conditions);
		return logicBean;
	}
	
	/**
	 * ユーザにより、質問閲覧歴一覧
	 * @throws SoftbankException 
	 */
	public LogicBean getQuestionHistoryByUser() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
//		int authorId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
//		int authorId = 1142;
		// TODO 本番はこっち
		Map<String, Object> userInfo = db.query("users.getUserInfoByLogin");
		int authorId = StringUtils.toInt(userInfo.get("id"));
		int questionId = Integer.parseInt(context.getParam().get("questionId"));
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("author_id", authorId);
		conditions.put("question_id", questionId);

		List<HelpQuestionBean> helpQuestionBeans = helpDao.getQuestionHistoryByUser(conditions);
		logicBean.setData(helpQuestionBeans);
		
		return logicBean;
	
	}
	
	/**
	 * 質問新規登録
	 * @throws SoftbankException 
	 */
	public void addQuestion() throws SoftbankException {
		Map<String, Object> userInfo = db.query("users.getUserInfoByLogin");
		int authorId = StringUtils.toInt(userInfo.get("id"));
		String userAddress = StringUtils.toString(userInfo.get("mail"));
		log.debug("authorId = {}, userAddress = {}", Lists.newArrayList(authorId, userAddress).toArray());
		String questionTitle = context.getParam().get("question_title");
		int categoryId = Integer.parseInt(context.getParam().get("category_id"));
		String questionContent = context.getParam().get("questionContent");
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("author_id", authorId);
		
		conditions.put("question_title", questionTitle);
		conditions.put("category_id", categoryId);
		conditions.put("question_content", renderQuestionContent(questionContent));
		if (context.getUploadFileItems() != null && context.getUploadFileItems().size() > 0) {
			for (int i = 0; i < context.getUploadFileItems().size(); i++) {
				FileItem fileItem = context.getUploadFileItems().get(i);
				if ("faq-file".equals(fileItem.getFieldName()) && fileItem.getSize() > 0) {
					UploadFileInfo fileInfo = doUpload(context.getUploadFileItems().get(0), UPLOAD_FILE_PATH, UploadType.all);
					String filePath = fileInfo.getUrlPath();
					conditions.put("file_path", filePath);
				}
			}
		}
		helpDao.addQuestion(conditions);
//		db.insert("co.jp.softbank.qqmx.dao.project.help.HelpDao.addQuestion", conditions);
		int questionId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		log.debug("questionId = " + questionId);
		conditions.put("question_id", questionId);
		conditions.put("user_address", userAddress);
		
		try {
			CommonUtil.sendMail(conditions, "to_answer", messageAccessor);
			CommonUtil.sendMail(conditions, "to_question", messageAccessor);
		} catch (Exception e) {
			System.out.println("質問用メール送信失敗しました");
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			
		}
	}
	
	private String renderQuestionContent(String content) {
		String urlPath = messageAccessor.getMessage("application.path");
		content = content.replaceAll("<img src=\"/qqmx/upload/", "<img src=\"" + urlPath + "/qqmx/upload/");
		return content;
	}

	/**
	 *  FAQ検索
	 */
	public LogicBean getQuestionsByKeyword() {
		LogicBean logicBean = new LogicBean();
		
        String Keyword = context.getParam().get("question_search_keyword");
        Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("question_search_keyword", Keyword);
		
		List<HelpQuestionBean> helpQuestionBeans = helpDao.getQuestionsByKeyword(conditions);
		logicBean.setData(helpQuestionBeans);
		
		return logicBean;
	}
	
	public static void main(String[] args) {
		String url = "http://10.216.80.167";
		System.out.println("".replaceAll("<img src=\"/qqmx/upload/", "<img src=\""+url+"/qqmx/upload/"));
	}
	
	/**
	 *  最新FAQ
	 */
	public void getLatestQuestion() {
		
		List<HelpQuestionCategoryBean> helpQuestionCategoryBeans = helpDao.getLatestQuestion();
		context.getResultBean().setData(helpQuestionCategoryBeans);
		
	}
	
	/**
	 *  参照の多いFAQ
	 */
	public void getOftenSeeQuestion() {
		
		List<HelpQuestionCategoryBean> helpQuestionCategoryBeans = helpDao.getOftenSeeQuestion();
		context.getResultBean().setData(helpQuestionCategoryBeans);
	}
	
	/**
	 *  NEWS取得
	 */
	public void getNews() {

		List<Map<String, Object>> news = helpDao.getNews();
		context.getResultBean().setData(news);
	}
	
	/**
	 * idで質問取得
	 */
	public void getQuestionsById() {
		// FAQ内容を取得
		String questionId = context.getParam().get("questionId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("question_id", Integer.parseInt(questionId));
		List<Map<String, Object>> helpQuestionBeans = helpDao.getQuestionsById(conditions);
		context.getResultBean().setData(helpQuestionBeans);
	}
	
	/**
	 * idで質問更新（回答が追加される）
	 */
	public void updateQuestionById() {
		// FAQ内容を取得
		String questionId = context.getParam().get("questionId");
		String answerContent = context.getParam().get("answerContent");
		String questionTitle = context.getParam().get("questionTitle");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("question_id", Integer.parseInt(questionId));
		conditions.put("answerContent", answerContent);
		if (context.getUploadFileItems() != null && context.getUploadFileItems().size() > 0) {
			for (int i = 0; i < context.getUploadFileItems().size(); i++) {
				FileItem fileItem = context.getUploadFileItems().get(i);
				if ("answer_file".equals(fileItem.getFieldName()) && fileItem.getSize() > 0) {
					UploadFileInfo fileInfo = doUpload(context.getUploadFileItems().get(0), UPLOAD_FILE_PATH, UploadType.all);
					String answerFilePath = fileInfo.getUrlPath();
					conditions.put("answer_file_path", answerFilePath);
				}
			}
		}
		List<Map<String, Object>> helpQuestionBeans = helpDao.updateQuestionById(conditions);
		context.getResultBean().setData(helpQuestionBeans);
		
		conditions.put("question_title", questionTitle);
		try {
			CommonUtil.sendMail(conditions, "for_answer", messageAccessor);
			CommonUtil.sendMail(conditions, "for_question", messageAccessor);
		} catch (Exception e) {
			System.out.println("回答用メール送信失敗しました");
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			
		}
	}
}
