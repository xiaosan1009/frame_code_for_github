package co.jp.softbank.qqmx.logic.application.project;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.ProjectDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;

import com.google.common.collect.Maps;

public class ProjectLogic extends AbstractBaseLogic {
	
	@Autowired
	private ProjectDao projectDao;
	
	public LogicBean getProjectInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		if (userInfoData.isAdmin()) {
			logicBean.setData(projectDao.getAllProjectInfos());
		} else {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("user_id", userInfoData.getId());
			logicBean.setData(projectDao.getProjectInfosByUser(conditions));
		}
		
		return logicBean;
	}
	
	public void getProjectInfoById() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		context.getResultBean().setData(projectDao.getProjectInfosById(conditions));
	}

}
