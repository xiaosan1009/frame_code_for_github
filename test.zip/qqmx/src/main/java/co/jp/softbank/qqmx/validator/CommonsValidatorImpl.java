package co.jp.softbank.qqmx.validator;

import java.util.Locale;

import org.apache.commons.validator.Form;
import org.apache.commons.validator.Validator;
import org.apache.commons.validator.ValidatorException;
import org.apache.commons.validator.ValidatorResources;
import org.apache.commons.validator.ValidatorResults;

import co.jp.softbank.qqmx.util.ConstantsUtil;

public class CommonsValidatorImpl extends Validator {

    private static final long serialVersionUID = -7315991856716383283L;
    
    private ValidatorException validatorException = null;

    public CommonsValidatorImpl(ValidatorResources resources, String formName) {
        super(resources, formName);
    }

    public ValidatorException getValidatorException() {
        return validatorException;
    }

    @Override
    public ValidatorResults validate() throws ValidatorException {
        try {
        	Locale locale = (Locale) this.getParameterValue(LOCALE_PARAM);

            if (locale == null) {
                locale = Locale.getDefault();
            }
        	Form form = this.resources.getForm(locale, this.formName);
        	if (form == null && this.formName.indexOf(ConstantsUtil.Str.UNDERLINE) != -1) {
        		this.formName = this.formName.split(ConstantsUtil.Str.UNDERLINE)[0];
			}
            return super.validate();
        } catch (ValidatorException e) {
            validatorException = e;
            throw e;
        }
    }
    
    @Override
    public void clear() {
        super.clear();
        this.validatorException = null;
    }
}
