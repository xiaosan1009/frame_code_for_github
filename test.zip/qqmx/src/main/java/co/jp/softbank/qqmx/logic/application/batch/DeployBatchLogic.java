package co.jp.softbank.qqmx.logic.application.batch;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

public class DeployBatchLogic extends AbstractBaseLogic {
	
	private String sonarQubeUrl = "";
	private Integer deployId = null;
	
	public void insertDeployInfo()  throws SoftbankException{
		
		String job_name = context.getParam().get("job_name");
//		String job_name = "qqmx_monitoring_board"; //ResourceTracer
		int new_build_count = Integer.valueOf(context.getParam().get("count"));
//		int new_build_count =  78; //62
		String url = "http://10.157.2.146/job/" + job_name + "/" + new_build_count;
		getDeployInfo(url,job_name,new_build_count);
		
		DeployDetailLogic deployDetail = new DeployDetailLogic(db);
		deployDetail.getDetaiInfo(url,sonarQubeUrl,deployId);
		
	}
	
	public void getDeployInfo(String url,String job_name,Integer new_build_count)  throws SoftbankException{
		Map<String, Object> conditions = Maps.newHashMap();
		String jenkinsStr = externalHttpServer.getStrUrl(url + "/api/json");
		JSONObject json = JSONObject.fromObject(jenkinsStr);
		String result = json.get("result").toString();
		Double timestamp = Double.valueOf(json.get("timestamp").toString());
		Double duration = Double.valueOf(json.get("duration").toString());
		conditions.put("job_name", job_name);
		conditions.put("new_build_count", new_build_count);
		conditions.put("result", result);
		conditions.put("new_build_time", timestamp);
		conditions.put("deploy_time", duration);
		log.info("duration*"+duration);
		
		String scoreStr = externalHttpServer.getStrUrl("http://10.157.2.146/job/" + job_name + "/api/json");
		JSONObject scorejson = JSONObject.fromObject(scoreStr);
		String healthReport = scorejson.get("healthReport").toString();
		healthReport =healthReport.substring(1, healthReport.length()-1);
		JSONObject healthReportjson = JSONObject.fromObject(healthReport);
		int score = (Integer)healthReportjson.get("score");
		conditions.put("score", score);
		
		String junit = externalHttpServer.getStrUrl(url + "/testReport/api/json");
		if(!junit.contains("<html>")){
			JSONObject junitJson = JSONObject.fromObject(junit);
			int failCount = (Integer)junitJson.get("failCount");
			int skipCount = (Integer)junitJson.get("skipCount");
			long junitDuration = 0;
			int successCount = 0;
			int doCount = 0;
			if(junitJson.has("childReports")){
				String childReport  = junitJson.get("childReports").toString();
				JSONObject childReportJson = JSONObject.fromObject(childReport.substring(1, childReport.length()-1));
				JSONObject resultJson = JSONObject.fromObject(childReportJson.get("result").toString());
				Double d = Double.valueOf(resultJson.get("duration").toString());
				junitDuration = Math.round(d*1000);
				int totalCount = (Integer)junitJson.get("totalCount");
				doCount = totalCount- skipCount;
				successCount = totalCount- failCount-skipCount;
			}else{
				Double d = Double.valueOf(junitJson.get("duration").toString());
				junitDuration = Math.round(d*1000);
				successCount = (Integer)junitJson.get("passCount");
				doCount = failCount + skipCount+successCount;
			}
			conditions.put("successCount", successCount);
			conditions.put("doCount", doCount);
			conditions.put("test_time", junitDuration);
		}
		
		String checkStyle = externalHttpServer.getStrUrl(url +"/checkstyleResult/api/json");
		if(!checkStyle.contains("<html>")){
			JSONObject csjson = JSONObject.fromObject(checkStyle);
			int style_high_number = (Integer)csjson.get("numberOfHighPriorityWarnings");
			int style_middle_number = (Integer)csjson.get("numberOfNormalPriorityWarnings");
			int style_low_number = (Integer)csjson.get("numberOfLowPriorityWarnings");
			conditions.put("style_high_number", style_high_number);
			conditions.put("style_middle_number", style_middle_number);
			conditions.put("style_low_number", style_low_number);
		}
		
		
		String findbugs = externalHttpServer.getStrUrl(url +"/findbugsResult/api/json");
		if(!findbugs.contains("<html>")){
			JSONObject fbjson = JSONObject.fromObject(findbugs);
			int bugs_high_number = (Integer)fbjson.get("numberOfHighPriorityWarnings");
			int bugs_middle_number = (Integer)fbjson.get("numberOfNormalPriorityWarnings");
			int bugs_low_number = (Integer)fbjson.get("numberOfLowPriorityWarnings");
			conditions.put("bugs_high_number", bugs_high_number);
			conditions.put("bugs_middle_number", bugs_middle_number);
			conditions.put("bugs_low_number", bugs_low_number);
		}
		
		String logUrl = url +"/consoleFull";
		Map<String, Object> checkFindBugsDate = getCheckFindBugsDate(logUrl);
		Long checktime = null;
		if(checkFindBugsDate.get("checktime") != null){
			checktime = Long.parseLong(checkFindBugsDate.get("checktime").toString());
		}
		Long bugtime = null;
		if(checkFindBugsDate.get("bugtime") != null){
			bugtime = Long.parseLong(checkFindBugsDate.get("bugtime").toString());
		}
		conditions.put("check_time", checktime);
		conditions.put("bug_time", bugtime);
		if(checkFindBugsDate.get("revision") != null){
			conditions.put("revision", checkFindBugsDate.get("revision").toString());
		}
		
		List<Map<String, Object>> issuesIdList = db.querys("deploy.getIssuesId", conditions);
		int issuse_id = 0;
		Integer project_id = null;
		if(issuesIdList.size() != 0){
			issuse_id = Integer.parseInt(issuesIdList.get(0).get("ticket_id").toString());
			project_id = Integer.parseInt(issuesIdList.get(0).get("project_id").toString());
		}
		
		Map<String, Object> projectInfo = getProjectInfo(issuse_id);
		if(project_id == null){
			String projectId = context.getParam().get("project_id");
			project_id = Integer.valueOf(projectId);
		}
		conditions.put("project_id",project_id);
		if(projectInfo != null){
			conditions.put("version_id", projectInfo.get("version_id"));
			if(projectInfo.get("system_id") != null){
				conditions.put("system_id", Integer.valueOf(projectInfo.get("system_id").toString()));
			}
			conditions.put("issue_id", issuse_id);
		}
		
		Long build_time = getBulidTime(logUrl);
		conditions.put("build_time", build_time);
		
		String jacoco = externalHttpServer.getStrUrl(url + "/jacoco/api/json");
		if(!jacoco.contains("<html>")){
			JSONObject jacocoJson = JSONObject.fromObject(jacoco);
			String branchCoverage = jacocoJson.get("branchCoverage").toString();
			JSONObject branchCoverageJson = JSONObject.fromObject(branchCoverage);
			String branchPercent = branchCoverageJson.get("percentage").toString();
			float f = Float.valueOf(branchPercent);
			conditions.put("branchPercent", f);
			
			String instructionCoverage = jacocoJson.get("instructionCoverage").toString();
			JSONObject instructionCoverageJson = JSONObject.fromObject(instructionCoverage);
			String instructionPercent = instructionCoverageJson.get("percentage").toString();
			float f1 = Float.valueOf(instructionPercent);
			conditions.put("instructionPercent", f1);
		}
		
		String sonar = externalHttpServer.getStrUrl(url + "/api/json");
		if(!sonar.contains("<html>")){
			JSONObject sonarJson = JSONObject.fromObject(sonar);
			String actions = sonarJson.get("actions").toString();
			JSONArray array = JSONArray.fromObject(actions); 
			for(int i = 0;i<array.size();i++){
				if(array.get(i).toString().contains("sonarqubeDashboardUrl")){
					String sonarqube = array.get(i).toString();
					JSONObject sonarqubeJson = JSONObject.fromObject(sonarqube);
					String sonarUrl = sonarqubeJson.get("sonarqubeDashboardUrl").toString();
					Map<String, Object> sonarMap =  getSonarqubeInfor(sonarUrl);
					if(sonarMap != null && !sonarMap.isEmpty()){
						String str = sonarMap.get("duplications").toString();
						Float duplications = Float.valueOf(str);
						log.info("steps*"+ sonarMap.get("steps"));
						conditions.put("steps", sonarMap.get("steps"));
						conditions.put("complexity", sonarMap.get("complexity"));
						conditions.put("duplications", duplications);
						conditions.put("technical_debt", sonarMap.get("technical_debt"));
						int index = sonarUrl.lastIndexOf("/");
						sonarUrl = sonarUrl.substring(index+1, sonarUrl.length());
						conditions.put("sonar_url", sonarUrl);
					}
				}else{
					List<Map<String, Object>> list = db.querys("deploy.getSonarUrl", conditions);
					if(list.size() != 0){
						for (int n = 0;n < list.size();n++) {
							String sonar_url = list.get(n).get("sonar_url").toString();
							Map<String, Object> sonarMap =  getSonarqubeInfor(sonar_url);
							if(sonarMap != null && !sonarMap.isEmpty()){
								String str = sonarMap.get("duplications").toString();
								Float duplications = Float.valueOf(str);
								conditions.put("steps", sonarMap.get("steps"));
								conditions.put("complexity", sonarMap.get("complexity"));
								conditions.put("duplications", duplications);
								conditions.put("technical_debt", sonarMap.get("technical_debt"));
								int index = sonar_url.lastIndexOf("/");
								sonar_url = sonar_url.substring(index+1, sonar_url.length());
								conditions.put("sonar_url", sonar_url);
								String id = list.get(n).get("id").toString();
								conditions.put("sonar_id", Integer.valueOf(id));
								db.update("deploy.updateSonarQube",conditions);
							}
						}
					}
				}
			}
		}
		
		db.insert("deploy.insertDeployInfo", conditions);
		deployId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		
	}
	
	
	public Map<String, Object> getSonarqubeInfor (String strProjectPram) throws SoftbankException{
		Map<String, Object> resultMap = Maps.newHashMap();
		if(!"".equals(strProjectPram) && strProjectPram != null && !"null".equals(strProjectPram)){
			
			int index = strProjectPram.lastIndexOf("/");
			strProjectPram = strProjectPram.substring(index+1, strProjectPram.length());
			
			sonarQubeUrl = "http://10.157.2.148:9000/api/resources?resource="+strProjectPram+"&&metrics=duplicated_lines_density,duplicated_lines,lines,complexity,ncloc,sqale_index";
			String resultTemp = externalHttpServer.getStrUrl(sonarQubeUrl);
	
			String result="";
			if(!StringUtils.isEmpty(resultTemp)){
				result=resultTemp.substring(1, resultTemp.length()-1);
			}
			JSONObject js = new JSONObject();
			if(result.length()>0){
				js = JSONObject.fromObject(result) ;
			}
			
			JSONArray jsResult = JSONArray.fromObject(js.get("msr"));
			for (int i = 0;i < jsResult.size();i++) {
				JSONObject object = JSONObject.fromObject(jsResult.get(i));
				if("sqale_index".equals(object.getString("key"))){
					resultMap.put("technical_debt", object.getString("frmt_val"));
				}
				else if("ncloc".equals(object.getString("key"))){
					resultMap.put("steps", object.getString("frmt_val"));
					log.info("steps:"+ object.getString("frmt_val"));
				}
				else if("complexity".equals(object.getString("key"))){
					resultMap.put("complexity", object.getString("frmt_val"));
				}
				else if("duplicated_lines_density".equals(object.getString("key"))){
					resultMap.put("duplications", object.getString("val"));
				}
			}
	    }
		return resultMap;
	}
	
	
	// TODO
	public Map<String, Object> getProjectInfo(Integer issuse_id) throws SoftbankException{
		Map<String, Object> resultMap = Maps.newHashMap();
		resultMap.put("issues_id", issuse_id);
		Map<String, Object> info =  db.query("deploy.getProjectInfo",resultMap);
		return info;
	}
	
	
	public Map<String, Object> getCheckFindBugsDate(String url) throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		String str = externalHttpServer
				.getStrUrl(url);
		String[] strs = str.split("(\r\n|\r|\n|\n\r)");
		String startRegex = "<span class=\"timestamp\">\\s*<b>([0-9:]+)</b>\\s*</span>.*(?=maven-mojo.*maven-checkstyle-plugin)";
		String endRegex = "<span class=\"timestamp\">\\s*<b>([0-9:]+)</b>\\s*</span>.*(?=\\[CHECKSTYLE\\]\\s+Successfully)";
		Pattern spattern = Pattern.compile(startRegex);
		Pattern epattern = Pattern.compile(endRegex);
		List<String[]> resultList = Lists.newArrayList();
		for (int i = 0; i < strs.length; i++) {
			String s = strs[i];
			if(s.contains("Checking out Revision")){
				String revision = s.substring(s.indexOf("Revision")+9,s.lastIndexOf(" "));
				resultMap.put("revision", revision);
			}
			Matcher matcher = spattern.matcher(s);
			if (matcher.find()) {
				String[] data = new String[2];
				data[0] = matcher.group(1);
				resultList.add(data);
			} else {
				matcher = epattern.matcher(s);
				if (matcher.find()) {
					resultList.get(resultList.size() - 1)[1] = matcher.group(1);
				}
			}
		}
		
		Date checkStartDate = null;
		Date checkEndDate = null;
		Long checktime = null;
		SimpleDateFormat sdf= new SimpleDateFormat("HH:mm:ss");
		for(int j = 0;j < resultList.size(); j++ ){
			String checkEnd = resultList.get(j)[1];
			if("".equals(checkEnd) || checkEnd == null){
				continue;
			}
			if(checktime == null){
				checktime = 0L;
			}
			String checkStart = resultList.get(j)[0];
			try {
				checkStartDate = sdf.parse(checkStart);
				checkEndDate = sdf.parse(checkEnd);
				checktime = checktime + checkEndDate.getTime()-checkStartDate.getTime();
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		
		startRegex = "<span class=\"timestamp\">\\s*<b>([0-9:]+)</b>\\s*</span>.*(?=maven-mojo.*findbugs-maven-plugin)";
		endRegex = "<span class=\"timestamp\">\\s*<b>([0-9:]+)</b>\\s*</span>.*(?=\\[FINDBUGS\\]\\s+Successfully)";
		spattern = Pattern.compile(startRegex);
		epattern = Pattern.compile(endRegex);
		resultList = Lists.newArrayList();
		for (int i = 0; i < strs.length; i++) {
			String s = strs[i];
			Matcher matcher = spattern.matcher(s);
			if (matcher.find()) {
				String[] data = new String[2];
				data[0] = matcher.group(1);
				resultList.add(data);
			} else {
				matcher = epattern.matcher(s);
				if (matcher.find()) {
					resultList.get(resultList.size() - 1)[1] = matcher.group(1);
				}
			}
		}
		
		Date bugStartDate = null;
		Date bugEndDate = null;
		Long bugtime = null;
		for(int j = 0;j < resultList.size(); j++ ){
			String bugEnd = resultList.get(j)[1];
			if("".equals(bugEnd) || bugEnd == null){
				continue;
			}
			String bugStart = resultList.get(j)[0];
			if(bugtime == null){
				bugtime = 0L;
			}
			try {
				bugStartDate = sdf.parse(bugStart);
				bugEndDate = sdf.parse(bugEnd);
				bugtime = bugtime + bugEndDate.getTime()-bugStartDate.getTime();
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		resultMap.put("checktime", checktime);
		resultMap.put("bugtime", bugtime);
		
		return resultMap;
	}
	
	
	public Long getBulidTime(String url) throws SoftbankException{
		String str = externalHttpServer
				.getStrUrl(url);
		String[] strs = str.split("(\r\n|\r|\n|\n\r)");
		String endRegex = "Total time:\\s*([0-9\\.]+.*)";
		Pattern pattern = Pattern.compile(endRegex);
		Long build_time= null;
		for (int i = 0; i < strs.length; i++) {
			String s = strs[i];
			Matcher matcher = pattern.matcher(s);
			if(matcher.find()){
				String time = matcher.group(1);
				if(build_time == null){
					build_time = 0L;
				}
				if(time.contains("s")){
					time = time.substring(0, time.length()-2);
					int ss = Integer.parseInt(time.substring(0, time.indexOf(".")));
					int ms = Integer.parseInt(time.substring(time.indexOf(".")+1,time.length()));
					build_time = build_time + ss*1000 + ms;
					System.out.println(time + s +"s-------" + build_time);
				}else if(time.contains("min")){
					time = time.substring(0, time.length()-4);
					int min = Integer.parseInt(time.substring(0, time.indexOf(":")));
					int ss = Integer.parseInt(time.substring(time.indexOf(":")+1,time.length()));
					build_time = build_time + (min*60 + ss)*1000;
					System.out.println(time + s +"min-------" + build_time);
				}
				
			}
		}
		return build_time;
	}
	
}
