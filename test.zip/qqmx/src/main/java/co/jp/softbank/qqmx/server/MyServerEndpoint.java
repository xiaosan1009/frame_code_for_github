package co.jp.softbank.qqmx.server;

import javax.websocket.EndpointConfig;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.bean.SessionData;
import co.jp.softbank.qqmx.server.SocketLogicFactory.SocketLogicType;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.SocketClientManager;

@ServerEndpoint(value="/websocket.ws", configurator=SocketConfigurator.class)
public class MyServerEndpoint {

	private Logger log = new LogUtil(this.getClass()).getLog();
	
	private Session session;
	
	@OnOpen
	public void OnOpen(Session session, EndpointConfig config, @PathParam(value = "userId")String user) {
		try {
			this.session = session;
			SessionData sessionData = (SessionData)config.getUserProperties().get(SessionData.class.getName());
			session.addMessageHandler(new MySocketMessageHandler(session, session.getBasicRemote()));
			SocketClientManager.getInstance().addSession(session, (UserInfoData)sessionData.get(UserInfoData.USER_INFO_KEY));
			SocketLogicFactory.getLogic(SocketLogicType.CHAT).connect(session);
		} catch (SoftbankException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
//	@OnMessage
//	public void OnMessage(Session session, String message) {
//		System.out.println("OnMessage = " + message);
//		this.session.getId();
//	}
	
	@OnClose
	public void OnClose(Session session) {
		System.out.println("OnClose");
		SocketClientManager.getInstance().remove(session);
		SocketLogicFactory.getLogic(SocketLogicType.CHAT).closed(session);
	}
	
	@OnError
	public void onError(Session session, Throwable throwable) {
		throwable.printStackTrace();
		System.out.println("onError");
	}
}
