package co.jp.softbank.qqmx.logic.bean;

import java.util.Map;

public class LogicBean {
	
	public static final String RESPONSE_DATA = "RESPONSE_DATA";
	
	private boolean resultFlg = true;
	
	private boolean filter;
	
	private boolean showPanel;
	
	private String resultCode;
	
	private String resultMsg;
	
	private Object data;
	
	private boolean notAnalysis;

	public boolean isResultFlg() {
		return resultFlg;
	}

	public void setResultFlg(boolean resultFlg) {
		this.resultFlg = resultFlg;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultMsg() {
		return resultMsg;
	}

	public void setResultMsg(String resultMsg) {
		this.resultMsg = resultMsg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
//		if (data instanceof Map) {
//			if (((Map)data).containsKey("is-error") && "true".equals(((Map)data).get("is-error"))) {
//				this.resultFlg = false;
//				this.resultMsg = ((Map<String, String>)data).get("errors");
//			} else if (((Map)data).containsKey("result-message")) {
//				this.resultMsg = ((Map<String, String>)data).get("result-message");
//			}
//		}
	}

	public boolean isNotAnalysis() {
		return notAnalysis;
	}

	public void setNotAnalysis(boolean notAnalysis) {
		this.notAnalysis = notAnalysis;
	}

	public boolean isFilter() {
		return filter;
	}

	public void setFilter(boolean filter) {
		this.filter = filter;
	}

	public boolean isShowPanel() {
		return showPanel;
	}

	public void setShowPanel(boolean showPanel) {
		this.showPanel = showPanel;
	}

}
