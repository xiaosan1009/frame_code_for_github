package co.jp.softbank.qqmx.dao.tables;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface TQueriesDao extends IDaoInterface {
	
	List<Map<String, Object>> selectQueriesInfo(Map<String, Object> conditions);

}
