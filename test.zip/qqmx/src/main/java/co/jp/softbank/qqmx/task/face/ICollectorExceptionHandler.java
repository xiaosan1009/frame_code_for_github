package co.jp.softbank.qqmx.task.face;

import co.jp.softbank.qqmx.task.bean.DataObjectBean;
import co.jp.softbank.qqmx.task.info.ExceptionHandlerStatus;


public interface ICollectorExceptionHandler {
	
	ExceptionHandlerStatus handleException(DataObjectBean dataValueObject);

}
