package co.jp.softbank.qqmx.info.bean;

import java.util.Date;
import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ExcelInfoBean {
	
	private List<String> sheetNames = Lists.newArrayList();
	
	private List<String[]> firstRowCellNames = Lists.newArrayList();
	
	private List<RowInfoBean> rows = Lists.newArrayList();
	
	private Map<String, String> diffMap = Maps.newHashMap();

	public List<String> getSheetNames() {
		return sheetNames;
	}

	public void setSheetNames(List<String> sheetNames) {
		this.sheetNames = sheetNames;
	}
	
	public void addSheetName(String sheetName) {
		sheetNames.add(sheetName);
	}

	public List<String[]> getFirstRowCellNames() {
		return firstRowCellNames;
	}

	public void setFirstRowCellNames(List<String[]> firstRowCellNames) {
		this.firstRowCellNames = firstRowCellNames;
	}
	
	public void addFirstRowCellName(String cellName, int index) {
		addFirstRowCellName(cellName, index, null);
	}
	
	public void addFirstRowCellName(String cellName, int index, DiffAnalizy checkDiff) {
		String[] data = new String[2];
		data[0] = StringUtils.toString(index);
		data[1] = cellName;
		if (checkDiff != null) {
			if (!diffMap.containsKey(cellName)) {
				diffMap.put(cellName, cellName);
				firstRowCellNames.add(data);
			} else {
				checkDiff.addFirstRowCellName(firstRowCellNames, cellName, index);
			}
		} else {
			firstRowCellNames.add(data);
		}
	}
	
	public List<RowInfoBean> getRows() {
		return rows;
	}

	public void setRows(List<RowInfoBean> rows) {
		this.rows = rows;
	}
	
	public void addRow(RowInfoBean row) {
		rows.add(row);
	}

	public static class RowInfoBean {
		private long index; 
		private List<CellInfoBean> cells = Lists.newArrayList();
		
		public RowInfoBean(long index) {
			this.index = index;
		}
		
		public long getIndex() {
			return index;
		}
		public void setIndex(long index) {
			this.index = index;
		}
		public List<CellInfoBean> getCells() {
			return cells;
		}
		public void setCells(List<CellInfoBean> cells) {
			this.cells = cells;
		}
		public void addCell(CellInfoBean cell) {
			cells.add(cell);
		}
	}
	
	public static class CellInfoBean {
		private long index; 
		private String content;
		private Date date;
		
		public CellInfoBean(long index) {
			this.index = index;
		}

		public long getIndex() {
			return index;
		}

		public void setIndex(long index) {
			this.index = index;
		}

		public String getContent() {
			return content;
		}

		public void setContent(String content) {
			this.content = content;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		} 
		
	}
	
	public static interface DiffAnalizy {
		void addFirstRowCellName(List<String[]> firstRowCellNames, String cellName, int index);
	}

}
