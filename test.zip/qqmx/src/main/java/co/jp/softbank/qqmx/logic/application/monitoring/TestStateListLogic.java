package co.jp.softbank.qqmx.logic.application.monitoring;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class TestStateListLogic extends AbstractBaseLogic {

	public void getTestStateList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		if(!StringUtils.isEmpty(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
			context.getResultBean().setData(db.querys("testStateList.getTestStateList", conditions));
		}else{
			context.getResultBean().setData(db.querys("testStateList.getTestStateNullList", conditions));
		}
	}
	
	public void getSelectVersionInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		if(!StringUtils.isEmpty(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
			context.getResultBean().setData(db.querys("testStateList.getSelectVersionInfo", conditions));
		}else{
			conditions.put("projectId", 0);
			context.getResultBean().setData(db.querys("testStateList.getSelectVersionInfo", conditions));
		}
	}
	
	public void getHeadquartersIdilInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		if(!StringUtils.isEmpty(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
		}
		
		context.getResultBean().setData(db.querys("testStateList.getHeadquartersIdilInfo", conditions));
	}
	
	public void getTestStateListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		String subProject = context.getParam().get("systemId");
		String versionId = context.getParam().get("versionId");
		String versionIdFlg = context.getParam().get("versionIdFlg");
		
		if(!StringUtils.isEmpty(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
		}
		if ("".equals(versionIdFlg) && "".equals(versionId)) {
			List<Map<String, Object>> versionMaxId = db.querys("testStateList.getSelectVersionInfo", conditions);
			if ( versionMaxId.size() > 0 ) {
				versionId = versionMaxId.get(0).get("id").toString();
			}
		}

		if("".equals(versionId)){
			conditions.put("version_name", "%");
		}else{
			Map<String, Object> versionMap = Maps.newHashMap();
			versionMap.put("version_id", Integer.parseInt(versionId));
			List<Map<String, Object>> versionList = db.querys("testStateList.getVersionNameInfo", versionMap);
			conditions.put("version_name", versionList.get(0).get("name"));
		}
		
		if("".equals(subProject)){
			conditions.put("sub_project", "%");
		}else{
			Map<String, Object> subProjectConditions = Maps.newHashMap();
			subProjectConditions.put("projectId", Integer.parseInt(subProject));
			List<Map<String, Object>> subProjectList = db.querys("testStateList.getTestStateList", subProjectConditions);
			conditions.put("sub_project", subProjectList.get(0).get("name"));
		}
		context.getResultBean().setData(db.querys("testStateList.getTestStateListInfo", conditions));
	}
	public void getTestStateDetailInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		String subProject = context.getParam().get("systemId");
		String versionId = context.getParam().get("versionId");
		String versionIdFlg = context.getParam().get("versionIdFlg");
		
		if(!StringUtils.isEmpty(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
		}
		if ("".equals(versionIdFlg) && "".equals(versionId)) {
			List<Map<String, Object>> versionMaxId = db.querys("testStateList.getSelectVersionInfo", conditions);
			if ( versionMaxId.size() > 0 ) {
				versionId = versionMaxId.get(0).get("id").toString();
			}
		}
		

		if("".equals(versionId)){
			conditions.put("version_name", "%");
		}else{
			Map<String, Object> versionMap = Maps.newHashMap();
			versionMap.put("version_id", Integer.parseInt(versionId));
			List<Map<String, Object>> versionList = db.querys("testStateList.getVersionNameInfo", versionMap);
			conditions.put("version_name", versionList.get(0).get("name"));
		}
		
		if("".equals(subProject)){
			conditions.put("sub_project", "%");
		}else{
			Map<String, Object> subProjectConditions = Maps.newHashMap();
			subProjectConditions.put("projectId", Integer.parseInt(subProject));
			List<Map<String, Object>> subProjectList = db.querys("testStateList.getTestStateList", subProjectConditions);
			conditions.put("sub_project", subProjectList.get(0).get("name"));
		}
		
		conditions.put("phase", "PHASE_005");
		List<Map<String, Object>> phase005List = db.querys("testStateList.getTestStateDetailInfo", conditions);
		conditions.put("phase", "PHASE_006");
		List<Map<String, Object>> phase006List = db.querys("testStateList.getTestStateDetailInfo", conditions);
		conditions.put("phase", "PHASE_007");
		List<Map<String, Object>> phase007List = db.querys("testStateList.getTestStateDetailInfo", conditions);
		
		Map<String, Object> listMap = Maps.newHashMap();		
		listMap.put("phase005List", phase005List);
		listMap.put("phase006List", phase006List);
		listMap.put("phase007List", phase007List);

		context.getResultBean().setData(listMap);
	}
	
	public void getSelectInfo() throws SoftbankException{
		String projectId = context.getParam().get("projectId");
		Map<String, Object> conditions = Maps.newHashMap();
		if (!"".equals(projectId) && projectId != null){
			conditions.put("projectId", Integer.parseInt(projectId));
		}
		
		List<Map<String, Object>> systemList = db.querys("testStateList.getSubProjectList", conditions);
		
		List<Map<String, Object>> versionList = db.querys("deliverables.getVersionList", conditions);
		
		
		Map<String, Object> listMap = Maps.newHashMap();
		listMap.put("systemList", systemList);
		listMap.put("versionList", versionList);
		
		context.getResultBean().setData(listMap);
	}

	
}
