package co.jp.softbank.qqmx.logic.application.project;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.UploadFileInfo;

import com.google.common.collect.Maps;

public class FileLogic extends AbstractBaseLogic {

	public void getFileListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("container_id", context.getParam().projectId);
		conditions.put("container_type", "Project");
		List<Map<String, Object>> attachments = db.querys("attachments.selectAttachments", conditions);
		context.getResultBean().setData(attachments);
	}
	
	public void getFileVersionListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		List<Map<String, Object>> attachments = db.querys("attachments.getFileVersionListInfo", conditions);
		context.getResultBean().setData(attachments);
	}
	
	public void deleteFileInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String file_id = context.getParam().get("file_id");
		conditions.put("id", Integer.parseInt(file_id));
		context.getResultBean().setData(db.delete("attachments.deleteFileInfo" , conditions));
	}
	
	public void downloadFileInfo() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		String file_id = context.getParam().get("file_id");
		conditions.put("id", Integer.parseInt(file_id));
		context.getResultBean().setData(db.delete("attachments.updateFileInfo" , conditions));
	}
	
	public void saveFileListInfo() throws SoftbankException, FileNotFoundException, IOException, NoSuchAlgorithmException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		String version_id = context.getParam().get("version_id");
		
		if ("".equals(version_id) || version_id == null){
			conditions.put("container_id", context.getParam().projectId);
			conditions.put("container_type", "Project");
		}else{
			conditions.put("container_id", Integer.parseInt(version_id));
			conditions.put("container_type", "Version");
		}
		
		conditions.put("author_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("downloads", 0);
		String[] attachments_description = context.getParam().getList("attachments_description_name");
		
		List<FileItem> files = context.getUploadFileItems();
		for (int i = 0; i < files.size(); i++) {
			FileItem fileItem = files.get(i);
			
			final String fileName = fileItem.getName();
			conditions.put("filename", fileName);
			conditions.put("filesize", fileItem.getSize());
			conditions.put("content_type", fileItem.getContentType());
			
			MessageDigest md = MessageDigest.getInstance("MD5");
            DigestInputStream input = new DigestInputStream(fileItem.getInputStream(), md);
            InputStreamReader ir = new InputStreamReader(input, "EUCJP");
            BufferedReader readBuffer = new BufferedReader(ir);
            String line;
            while((line = readBuffer.readLine()) != null) {
                System.out.println(line);
            }
            byte[] digest = md.digest();
            StringBuffer buffer = new StringBuffer();
            for(int j = 0; j < digest.length; j++) {
                String tmp = Integer.toHexString(digest[j] & 0xff);
                if(tmp.length() == 1) {
                    buffer.append('0').append(tmp);
                } else {
                    buffer.append(tmp);
                }
            }
            
            UploadFileInfo fileInfo = doUpload(files.get(i), "", UploadType.all, new UploadFileName() {
				@Override
				public String getFileName(String fileName, String newFileName) {
					SimpleDateFormat df = new SimpleDateFormat("yyMMddHHmmss");
					String md5FileName = "";
					MessageDigest md = null;
					try {
						md = MessageDigest.getInstance("MD5");
					} catch (NoSuchAlgorithmException e) {
						e.printStackTrace();
					}
					md.update(fileName.getBytes());
					byte[] hashBytes = md.digest();
					int[] hashInts = new int[hashBytes.length];
					StringBuilder sb = new StringBuilder();
					for (int i=0; i < hashBytes.length; i++) {
						hashInts[i] = (int)hashBytes[i] & 0xff;
						if (hashInts[i] <= 15) {
							sb.append("0");
						}
						sb.append(Integer.toHexString(hashInts[i]));
					}
					md5FileName = sb.toString();
					return df.format(new Date()) + "_" + md5FileName;
				}
			});
			
			conditions.put("disk_filename", fileInfo.getNewFileName());
			conditions.put("description", attachments_description[i]);
			conditions.put("digest", String.valueOf(buffer));
			context.getResultBean().setData(db.insert("attachments.insertAttachments" , conditions));
		}
	}
}
