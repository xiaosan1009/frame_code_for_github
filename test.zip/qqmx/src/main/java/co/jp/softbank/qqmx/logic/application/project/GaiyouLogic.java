package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.GaiyouDao;
import co.jp.softbank.qqmx.dao.project.ProjectDao;
import co.jp.softbank.qqmx.dao.project.bean.ProjectInfoBean;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class GaiyouLogic extends AbstractBaseLogic {

	@Autowired
	private GaiyouDao gaiyouDao;
	
	@Autowired
	private ProjectDao projectDao;
	
	public LogicBean gaiyouInfoInit() {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		resultMap.put("members", gaiyouDao.getMembers(conditions));
		List<Map<String, Object>> trackers = gaiyouDao.getTrackers(conditions);
		List<Map<String, Object>> trackerCounts = gaiyouDao.getTrackerCounts(conditions);
		List<Map<String, Object>> trackerAllCounts = gaiyouDao.getTrackerAllCounts(conditions);
		for (int i = 0; i < trackers.size(); i++) {
			for (int j = 0; j < trackerCounts.size(); j++) {
				if (Integer.parseInt(StringUtils.toString(trackers.get(i).get("id"))) == Integer.parseInt(StringUtils.toString(trackerCounts.get(j).get("tracker_id")))) {
					trackers.get(i).put("count_now", trackerCounts.get(j).get("count_all"));
					continue;
				}
			}
			for (int j = 0; j < trackerAllCounts.size(); j++) {
				if (Integer.parseInt(StringUtils.toString(trackers.get(i).get("id"))) == Integer.parseInt(StringUtils.toString(trackerAllCounts.get(j).get("tracker_id")))) {
					trackers.get(i).put("count_all", trackerAllCounts.get(j).get("count_all"));
					continue;
				}
			}
		}
		resultMap.put("trackers", trackers);
		resultMap.put("customValues", gaiyouDao.getCustomValues(conditions));
		resultMap.put("project_description", projectDao.getProjectInfosById(conditions).getDescription());
		logicBean.setData(resultMap);
		return logicBean;
	}
}
