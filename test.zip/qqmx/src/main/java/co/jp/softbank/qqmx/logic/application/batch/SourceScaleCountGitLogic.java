

package co.jp.softbank.qqmx.logic.application.batch;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.jgit.lib.AnyObjectId;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.treewalk.TreeWalk;

import com.google.common.collect.Maps;

/**
 * 版管理ツール(Git)からソースファイルを取得して、
 * ソース規模情報を収集する処理を行う。
 */
public class SourceScaleCountGitLogic extends SourceScaleCount {

    /** 一時ディレクトリ（変更前） */
    private static final String OLD_TMP_DIR = "ipf_git_old_";
    /** 一時ディレクトリ（変更後） */
    private static final String NEW_TMP_DIR = "ipf_git_new_";
    
    /**
     * ソース規模データ収集(Subversion用) 
     * 
     */
    public void sourceScale() {
        try {
            String projectId   = context.getParam().get("projectId");
            String gitPath   = context.getParam().get("gitPath");
            String repoPath    = gitPath + "/.git";
            String branch      = context.getParam().get("branch");
            
		    Integer project_id = 0;
		    if (projectId != null && projectId != "") {
		    	project_id = Integer.parseInt(projectId);
		    }
		    
		    checkoutFile(gitPath, branch);

            sourceScaleCollect(project_id, repoPath, branch);

        } catch (Exception e) {

        } finally {

        }
    }
    
    public void checkoutFile(String gitPath, String branch) {
		try {
			String cmd = "/opt/ipftools/review-platform.git/checkoutGitFile.sh " 
	    			 + gitPath + " " + branch;
			Process process = Runtime.getRuntime().exec(cmd);

			process.waitFor();
			process.destroy();
			
			log.info("☆☆☆ cmd ☆☆☆" + cmd);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
    
    /**
     * ソース規模データを集計してIPF・DBに登録する。
     * 
     * @param project_id プロジェクトID
     * @param repoPath リポジトリパス
     * @param oldRev 旧リビジョン（収集開始リビジョンの１つ前のリビジョン。旧リビション自身は収集されないので注意。）
     * @param newRev 新リビジョン
     * @param configInfo Pentaho 設定ファイル情報
     * @throws Exception 
     */
    public void sourceScaleCollect(
            Integer project_id, 
            String repoPath,
            String branch
        ) throws Exception {

        File oldTmpDir = null;
        File newTmpDir = null;
        
        RevWalk rwalk = null;
        try {
            // 一時ディレクトリ作成
            oldTmpDir = createTempDirectory(OLD_TMP_DIR, ".tmp");
            newTmpDir = createTempDirectory(NEW_TMP_DIR, ".tmp");
            
            // Git コミットログ取得
            Repository repository = IpfJGitUtils.getGitRepository(repoPath);
            // リビジョンリストを取得
            rwalk = IpfJGitUtils.getAllRevWalk(repository);
            
            // DBの最新リビジョンを取得
            String oldRev = getLatestRevision(project_id, repoPath, branch);
            
            log.info("☆☆☆ oldRev　： ☆☆☆" + oldRev);

            String newRev = branch;
            
            Iterator<RevCommit> revIter = null;
            if (StringUtils.isNotBlank(oldRev)) {
                if (StringUtils.isNotBlank(newRev)) {
                	
                	log.info("newRev is not Blank.");
                	
                    // 指定リビジョン(oldRev ... newRev)
                    revIter = IpfJGitUtils.getRevList(repository, oldRev, newRev);
                } else {
                	log.info("newRev is Blank.");
                	
                    // 指定リビジョン(oldRev ... )
                    revIter = IpfJGitUtils.getRevList(repository, oldRev);
                }
            } else {
            	log.info("全リビジョン取得.");
                // 全リビジョン
                revIter = IpfJGitUtils.getRevList(repository);
            }
            
            // リビジョンで繰り返し
            while (revIter.hasNext()) {
                RevCommit commit = revIter.next();
                
                TreeWalk twalk = null;
                try {
                    
                    twalk = IpfJGitUtils.getTreeWalk(repository, commit, rwalk);
                    // ソースファイル数分繰り返し
                    while (twalk.next()) {
                        // ソースファイル取得、ソース規模情報取得、DB登録
                        sourceScaleCollectAndDbInsert(project_id, repository, repoPath, branch, commit, twalk, oldTmpDir, newTmpDir);
                    }

                } catch (IpfSQLNormalException isne) {
                    
                } catch (Exception e) {
                    
                } finally {
                    if (twalk != null) {
                      twalk.release();
                    }
                }
            }
            // リビジョンで繰り返し
            
        } finally {

        }
        
    }
    
    /**
     * ソースファイルを取得して、ソース規模データを集計しDBに登録する。
     * 
     * @param conn DBコネクション
     * @param pstmt プレペアド・ステートメント
     * @param projectId プロジェクトID
     * @param repository リポジトリ
     * @param repoPath
     * @param branch
     * @param revCommit 
     * @param treeWalk 
     * @param oldTmpDir 一時ディレクトリ（変更前）
     * @param newTmpDir 一時ディレクトリ（変更後）
     * @throws Exception 
     */
    protected void sourceScaleCollectAndDbInsert (
            Integer project_id,
            Repository repository,
            String repoPath,
            String branch,
            RevCommit commit,
            TreeWalk twalk,
            File oldTmpDir,
            File newTmpDir) throws Exception {
    	
        String revision     = commit.getName();                     // リビジョン
        String message      = commit.getFullMessage();              // コミットメッセージ
        String author       = commit.getCommitterIdent().getName(); // 更新者
        Date updDate        = IpfJGitUtils.getCommitDate(commit);   // 更新日時
        
        byte[] filePathBytes = twalk.getRawPath();                          // ファイルフルパス（ファイル名含む） バイト配列
        String filePath      = IpfJGitUtils.getDecodeStr(filePathBytes);    // ファイルフルパス（ファイル名含む）

        String filePathOnly = FilenameUtils.getPathNoEndSeparator(filePath);  // ファイルパスのみ（ファイル名除く）
        String fileName     = FilenameUtils.getName(filePath);                // ファイル名（拡張子含む）
        String fileExt      = FilenameUtils.getExtension(filePath);           // 拡張子
        
        AnyObjectId[] objectIds = new AnyObjectId[2];
        char chg            = IpfJGitUtils.getChangeType(twalk, objectIds);   // 変更種別
        AnyObjectId  oldObjectId = objectIds[0];   // 旧ファイルオブジェクト
        AnyObjectId  newObjectId = objectIds[1];   // 新ファイルオブジェクト
        
        File oldTmpFile = null;
        File newTmpFile = null;
        try {
            // ソースファイル取得
            oldTmpFile = new File(oldTmpDir, fileName);
            newTmpFile = new File(newTmpDir, fileName);
            
            // 一時ファイル作成
            log.debug("Temp File Create.");
            switch (chg) {
            case 'A':
                IpfJGitUtils.createFile(repository, filePath, newObjectId, newTmpFile);
                break;
            case 'D':
                IpfJGitUtils.createFile(repository, filePath, oldObjectId, oldTmpFile);
                break;
            case 'M':
                IpfJGitUtils.createFile(repository, filePath, oldObjectId, oldTmpFile);
                IpfJGitUtils.createFile(repository, filePath, newObjectId, newTmpFile);
                break;
            }
            
            // ソース規模取得
            SourceScaleResult result = count(oldTmpFile, newTmpFile);
            if (result.getFileSize() == 0) {
            	return;
            }
            result.setRevision(revision);
            result.setAuthor(author);
            result.setUpdDate(updDate);
            result.setMessage(message);
            result.setFilePath(filePathOnly);
            result.setFileName(fileName);
            result.setFileExt(fileExt);
            
            // ソース規模DB登録
            insertSourceScale(project_id, repoPath, branch, result);
            
        } finally {
            // 一時ファイル削除
            if(oldTmpFile != null) FileUtils.deleteQuietly(oldTmpFile);
            if(newTmpFile != null) FileUtils.deleteQuietly(newTmpFile);
            log.debug("Temp File Remove.");
        }
    }

    /**
     * ソース規模データの最新リビジョンを取得する
     * 
     * @param configInfo Pentaho 設定ファイル情報
     * @param projectId プロジェクトID
     * @return 最新リビジョン
     * @throws Exception 
     */
    protected String getLatestRevision (
            Integer projectId,
            String repoPath,
            String branch) throws Exception {
    	
    	String rev = "";

        Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("repository", repoPath);
		conditions.put("branch", branch);
		
		Map<String, Object> latestRevision = db.query("sourceScale.getLatestRevision", conditions);
		
		if (latestRevision != null) {
			rev = latestRevision.get("revision").toString();
		}
        
        return rev;
    }

}
