package co.jp.softbank.qqmx.task.face;

public interface IValueExtractor<O> {
	
	<T> T extract(O obj);

}
