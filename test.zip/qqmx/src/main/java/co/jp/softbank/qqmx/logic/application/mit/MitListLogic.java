package co.jp.softbank.qqmx.logic.application.mit;

import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;


public class MitListLogic extends AbstractBaseLogic {
	
	public void getMitProjectListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String divisionId = context.getParam().get("divisionId");
		String departmentId = context.getParam().get("departmentId");
		String regionId = context.getParam().get("regionId");
		String statusId = context.getParam().get("statusId");
		String searchName = context.getParam().get("searchName");
		
		String organizationCd = divisionId;
		if (!"9898".equals(regionId)) {
			organizationCd = regionId;
		} else if (!"9898".equals(departmentId)) {
			organizationCd = departmentId;
		}
		conditions.put("organization_cd", organizationCd);
		conditions.put("status_Id", Integer.valueOf(statusId));
		conditions.put("search_name", searchName);
		
		PageListBean pageListBean = pageList("mitlist.getMitProjectListInfo",conditions);
		context.getResultBean().setData(pageListBean);
		
	}

	public void getMitSumProjectListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String divisionId = context.getParam().get("divisionId");
		String departmentId = context.getParam().get("departmentId");
		String regionId = context.getParam().get("regionId");
		String statusId = context.getParam().get("statusId");
		String searchName = context.getParam().get("searchName");
		
		String organizationCd = divisionId;
		if (!"9898".equals(regionId)) {
			organizationCd = regionId;
		} else if (!"9898".equals(departmentId)) {
			organizationCd = departmentId;
		}
		conditions.put("organization_cd", organizationCd);
		conditions.put("status_Id", Integer.valueOf(statusId));
		conditions.put("search_name", searchName);
		
		PageListBean pageListBean = pageList("mitlist.getMitSumProjectListInfo",conditions);
		context.getResultBean().setData(pageListBean);
	}
}
