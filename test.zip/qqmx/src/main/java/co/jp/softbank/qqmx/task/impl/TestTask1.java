package co.jp.softbank.qqmx.task.impl;

import co.jp.softbank.qqmx.task.AbstractTask;
import co.jp.softbank.qqmx.task.bean.FileBean;
import co.jp.softbank.qqmx.task.face.IKey;
import co.jp.softbank.qqmx.task.face.ITaskContext;

public class TestTask1 extends AbstractTask<FileBean> {

	@Override
	public void execute(ITaskContext context, IKey key, FileBean value) throws Exception {
		log.info("execute key = {}, value = {}", key, value.getAbstractPath());
	}

	@Override
	public void reprocess(ITaskContext context) throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		
	}

}
