package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.ProjectListDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class PrjectListLogic extends AbstractBaseLogic {

	@Autowired
	private ProjectListDao projectListDao;
	
	public void getProjectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int status = 1;
		if (StringUtils.isNotEmpty(context.getParam().get("status"))) {
			status = Integer.parseInt(context.getParam().get("status"));
		}
		conditions.put("status", status);
		conditions.put("user_name", context.getParam().get("user_name"));
		PageListBean pageListBean = pageList(projectListDao, "getProjectList", conditions);

		context.getResultBean().setData(pageListBean);
	}

	public void updateProjectSave() throws SoftbankException {
		Map<String, Object> conditionsProjectId = Maps.newHashMap();
		int project_id = Integer.parseInt(context.getParam().get("project_id"));
		conditionsProjectId.put("id", project_id);
		
		if ("9".equals(context.getParam().get("status_id"))){
			// 親プロジェクトの検索。
			List<Map<String, Object>> selectProjectId = projectListDao.selectProjectIdList(conditionsProjectId);
			
			for (int n=0; n<selectProjectId.size(); n++){
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("status", Integer.parseInt(context.getParam().get("status_id")));
				conditions.put("id", selectProjectId.get(n).get("id"));
				projectListDao.updateProjectSave(conditions);
			}
		}else{
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("status", Integer.parseInt(context.getParam().get("status_id")));
			conditions.put("id", project_id);
			projectListDao.updateProjectSave(conditions);
		}
	}
	
	public void deleteProject() throws SoftbankException {
		Map<String, Object> conditionsProjectId = Maps.newHashMap();
		
		int project_id = Integer.parseInt(context.getParam().get("project_id"));
		conditionsProjectId.put("id", project_id);
		// 親プロジェクトの検索。
		List<Map<String, Object>> selectProjectId = projectListDao.selectProjectIdList(conditionsProjectId);
		
		// 親プロジェクト、サブプロジェクトの削除する。
		for (int n=0; n<selectProjectId.size(); n++){
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("id", selectProjectId.get(n).get("id"));
			
			// Issues関連テーブル
			projectListDao.deleteProjectIssuesJournalDetails(conditions);
			projectListDao.deleteProjectIssuesJournals(conditions);
			projectListDao.deleteProjectIssuesIssueRelations(conditions);
			projectListDao.deleteProjectIssuesCustomValues(conditions);
			projectListDao.deleteProjectIssuesWatchers(conditions);
			projectListDao.deleteProjectIssuesAttachments(conditions);
			projectListDao.deleteProjectIssuesUserIssueMonths(conditions);
			projectListDao.deleteProjectIssues(conditions);
			// Wikis関連テーブル
			List<Map<String, Object>> selectProjectWikis = projectListDao.selectProjectWikis(conditions);
			Map<String, Object> conditionsWikis = Maps.newHashMap();
			if (selectProjectWikis.size() > 0){
				conditionsWikis.put("wiki_id", selectProjectWikis.get(0).get("id"));
				projectListDao.deleteProjectWikiRedirects(conditionsWikis);
				projectListDao.deleteProjectWatchers(conditionsWikis);
				projectListDao.deleteProjectWikiAttachments(conditionsWikis);
				projectListDao.deleteProjectWikiPages(conditionsWikis);
				projectListDao.deleteProjectWikiContents(conditionsWikis);
				projectListDao.deleteProjectWikis(conditionsWikis);
			}
			
			// repositoriesリポジトリ情報
			projectListDao.deleteProjectChanges(conditions);
			projectListDao.deleteProjectChangesetsIssues(conditions);
			projectListDao.deleteProjectChangesets(conditions);
			projectListDao.deleteProjectRepositories(conditions);
			
			
			// Project関連テーブル
			projectListDao.deleteProjectWtMemberOrders(conditions);
			projectListDao.deleteProjectGraphPatterns(conditions);
			projectListDao.deleteProjectDashboards(conditions);
			projectListDao.deleteProjectMetricsLinks(conditions);
			projectListDao.deleteProjectBoards(conditions);
			projectListDao.deleteProjectNews(conditions);
			projectListDao.deleteProjectDocuments(conditions);
			projectListDao.deleteProjectVersions(conditions);
			projectListDao.deleteProjectEnabledModules(conditions);
			projectListDao.deleteProjectTimeEntries(conditions);
			projectListDao.deleteProjectQueries(conditions);
			projectListDao.deleteProjectIssueCategories(conditions);
			projectListDao.deleteProjectCustomValues(conditions);
			projectListDao.deleteProjectMemberRoles(conditions);
			projectListDao.deleteProjectMembers(conditions);
			projectListDao.deleteProjectCustomFieldsProjects(conditions);
			projectListDao.deleteProjectProjectsTrackers(conditions);
			projectListDao.deleteProjectAttachments(conditions);
			projectListDao.deleteProjectProjects(conditions);
			
		}
	}
}
