package co.jp.softbank.qqmx.info;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimerTask;

import co.jp.softbank.qqmx.dao.common.DbMemoryMonitorDaoService;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.sockect.WebSocketClientManager;
import co.jp.softbank.qqmx.sockect.impl.AbstractSocketLogic;
import co.jp.softbank.qqmx.sockect.impl.AbstractSocketLogic.SocketMessageType;

import com.google.common.collect.Maps;

public class DbMemoryMonitorTask extends DbMemoryTaskBase {
	
	private DbMemoryMonitorDaoService dbMemoryMonitorDaoService;
	
	public DbMemoryMonitorTask(DbMemoryMonitorDaoService dbMemoryMonitorDaoService) {
		this.dbMemoryMonitorDaoService = dbMemoryMonitorDaoService;
	}
	
	@Override
	public void run() {
		try {
			@SuppressWarnings("unchecked")
			HashMap<Integer, Date> timestampMap = (HashMap<Integer, Date>)((HashMap<Integer, Date>)ControlDbMemory.getInstance().getTimestampMap()).clone();
			for (Map.Entry<Integer, Date> projectTimestamp : timestampMap.entrySet()) {
				int projectId = projectTimestamp.getKey();
				Date memoryTimestamp = projectTimestamp.getValue();

				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("project_id", projectId);
				Map<String, Object> issueUpdateTimestampMap = dbMemoryMonitorDaoService.getIssueUpdateTimestamp(conditions);

				if (issueUpdateTimestampMap != null) {
					Date issueUpdateTimestamp = (Date)issueUpdateTimestampMap.get("updated_on");
					if (issueUpdateTimestamp.compareTo(memoryTimestamp) > 0) {
						log.info("project_id = {}", projectId);
						log.info("issueUpdateTimestamp = {}, memoryTimestamp = {}", issueUpdateTimestamp.getTime(), memoryTimestamp.getTime());
						ControlDbMemory.getInstance().refreshTickets(projectId);
					}
				}
			}
		} catch (SoftbankException e) {
			e.printStackTrace();
		}
	}
}
