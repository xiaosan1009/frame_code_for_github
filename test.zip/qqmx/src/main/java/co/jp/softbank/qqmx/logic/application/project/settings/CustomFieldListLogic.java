package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.CustomFieldListDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;
import sun.org.mozilla.javascript.internal.Undefined;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class CustomFieldListLogic extends AbstractBaseLogic {

	@Autowired
	private CustomFieldListDao customFieldListDao;

	public void getIssueCustomFieldInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("custom_field_type", "IssueCustomField");
//		List<Map<String, Object>> customFieldList = customFieldListDao.getCustomFieldListInfo(conditions);
//		context.getResultBean().setData(customFieldList);
		PageListBean pageListBean = pageList(customFieldListDao, "getCustomFieldListInfo", conditions);
		context.getResultBean().setData(pageListBean);
	}
	public void getProjectCustomFieldInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("custom_field_type", "ProjectCustomField");
//		List<Map<String, Object>> customFieldList = customFieldListDao.getCustomFieldListInfo(conditions);
//		context.getResultBean().setData(customFieldList);
		PageListBean pageListBean = pageList(customFieldListDao, "getCustomFieldListInfo", conditions);
		context.getResultBean().setData(pageListBean);
	}
	public void getVersionCustomFieldInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("custom_field_type", "VersionCustomField");
//		List<Map<String, Object>> customFieldList = customFieldListDao.getCustomFieldListInfo(conditions);
//		context.getResultBean().setData(customFieldList);
		PageListBean pageListBean = pageList(customFieldListDao, "getCustomFieldListInfo", conditions);
		context.getResultBean().setData(pageListBean);
	}
	public void getUserCustomFieldInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("custom_field_type", "UserCustomField");
//		List<Map<String, Object>> customFieldList = customFieldListDao.getCustomFieldListInfo(conditions);
//		context.getResultBean().setData(customFieldList);
		PageListBean pageListBean = pageList(customFieldListDao, "getCustomFieldListInfo", conditions);
		context.getResultBean().setData(pageListBean);
	}

	public void delCustomFieldIdInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", Integer.parseInt(context.getParam().get("custom_field_id")));
		customFieldListDao.delCustomFieldIdInfo(conditions);
	}

	public LogicBean getTrackersInfo() throws SoftbankException {
		LogicBean trackerBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		if ("".equals(context.getParam().get("custom_field_id"))){
			conditions.put("id", 0);
		}else{
			conditions.put("id", Integer.parseInt(context.getParam().get("custom_field_id")));
		}
		trackerBean.setData(customFieldListDao.getTrackersInfo(conditions));
		return trackerBean;
	}
	public LogicBean getStatusInfo() throws SoftbankException {
		LogicBean statusBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		if ("".equals(context.getParam().get("status_id"))){
			conditions.put("id", 0);
		}else{
			conditions.put("id", Integer.parseInt(context.getParam().get("status_id")));
		}
		statusBean.setData(customFieldListDao.getStatusInfo(conditions));
		return statusBean;
	}
	
	public void upCustomFieldSort() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("custom_field_type", context.getParam().get("flg"));
		List<Map<String, Object>> customFieldList = customFieldListDao.getCustomFieldListInfo(conditions);
		String str_end_position = String.valueOf(customFieldList.get(Integer.parseInt(context.getParam().get("end_pos"))).get("position"));
		
		conditions.put("custom_field_id", Integer.parseInt(context.getParam().get("custom_field_id")));
		List<Map<String, Object>> customFieldIdList = customFieldListDao.getCustomFieldIdInfo(conditions);
		if (Integer.parseInt(str_end_position) > Integer.parseInt(String.valueOf(customFieldIdList.get(0).get("position")))){
			conditions.put("end_pos", Integer.parseInt(str_end_position));
			conditions.put("start_pos", Integer.parseInt(String.valueOf(customFieldIdList.get(0).get("position"))));
			customFieldListDao.upCommonMSort(conditions);
		}else{
			conditions.put("end_pos", Integer.parseInt(String.valueOf(customFieldIdList.get(0).get("position"))));
			conditions.put("start_pos", Integer.parseInt(str_end_position));
			customFieldListDao.upCommonPSort(conditions);
		}
		Map<String, Object> conditionSort = Maps.newHashMap();
		conditionSort.put("custom_field_id", Integer.parseInt(context.getParam().get("custom_field_id")));
		conditionSort.put("end_pos", Integer.parseInt(str_end_position));
		customFieldListDao.upCommonSort(conditionSort);

	}
	public void saveCustomField() throws SoftbankException {
		String type = context.getParam().get("type");
		String name = context.getParam().get("custom_field_name");
		String field_format = context.getParam().get("custom_field_field_format");
		String possible_values = context.getParam().get("custom_field_possible_values");
		String regexp = context.getParam().get("custom_field_regexp");
		String min_length = context.getParam().get("custom_field_min_length");
		String max_length = context.getParam().get("custom_field_max_length");
		String is_required = context.getParam().get("custom_field_is_required");
		String is_for_all = context.getParam().get("custom_field_is_for_all");
		String is_filter = context.getParam().get("custom_field_is_filter");
		String searchable = context.getParam().get("custom_field_searchable");
		String default_value = context.getParam().get("custom_field_default_value");
		String editable = context.getParam().get("custom_field_editable");
		String visible = context.getParam().get("custom_field_visible");
		String check_default_value = context.getParam().get("check_custom_field_default_value");
		
		String[] issueStatusIds = context.getParam().getList("i_issue_status_ids_");
		List<String> permissionsList = Lists.newArrayList(); 
		if (issueStatusIds != null){
			for (int p = 0; p < issueStatusIds.length; p++) {
				String strPermission = issueStatusIds[p];
				permissionsList.add(strPermission);
			}
		}

		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("type", type);
		conditions.put("name", name);
		conditions.put("field_format", field_format);
		if (possible_values.equals("undefined")) possible_values = "";
		conditions.put("possible_values", Yaml.dump(possible_values));
		if (regexp.equals("undefined")) regexp = "";
		conditions.put("regexp", regexp);
		if ("string".equals(field_format) || "text".equals(field_format) 
				|| "int".equals(field_format) || "float".equals(field_format)){
			conditions.put("min_length", StringUtils.isEmpty(min_length) ? 0 : Integer.parseInt(min_length));
			conditions.put("max_length", StringUtils.isEmpty(max_length) ? 0 : Integer.parseInt(max_length));
		}else{
			conditions.put("min_length", 0);
			conditions.put("max_length", 0);
		}
		conditions.put("is_required","true".equals(is_required) ? true : false );
		conditions.put("is_for_all", "true".equals(is_for_all) ? true : false);
		conditions.put("is_filter", "true".equals(is_filter) ? true : false);
		conditions.put("searchable", "true".equals(searchable) ? true : false);
		
		if ("bool".equals(field_format)){
			if (check_default_value.equals("undefined")) check_default_value = "";
			conditions.put("default_value", check_default_value);
		}else{
			if (default_value.equals("undefined")) default_value = "";
			conditions.put("default_value", default_value);
		}
		conditions.put("editable", "true".equals(editable) ? true : false);
		conditions.put("visible", "true".equals(visible) ? true : false);
		conditions.put("required_issue_status_ids", Yaml.dump(permissionsList));
		
		String flg = context.getParam().get("flg");
		int customFieldId = 0;
		if("insert".equals(flg)){
			customFieldListDao.insertCustomFields(conditions);
			customFieldId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		}else{
			customFieldId = Integer.parseInt(context.getParam().get("custom_field_id"));
			conditions.put("custom_field_id", customFieldId);
			customFieldListDao.updataCustomFields(conditions);
			customFieldListDao.deleteCustomFieldsTrackers(conditions);
		}
		
		String[] issueCustomFieldIds = context.getParam().getList("i_issue_custom_field_ids_");
		if (issueCustomFieldIds != null){
			Map<String, Object> customFieldsTrackers = Maps.newHashMap();
			customFieldsTrackers.put("custom_field_id", customFieldId);
			for (int i = 0; i < issueCustomFieldIds.length; i++) {
				customFieldsTrackers.put("tracker_id", Integer.parseInt(issueCustomFieldIds[i]));	
				customFieldListDao.insertCustomFieldsTrackers(customFieldsTrackers);
			}
		}
	}
	
	public LogicBean getEditIssueCustomField() throws SoftbankException {
		LogicBean statusBean = new LogicBean();
		String id = context.getParam().get("id");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", Integer.parseInt(id));
		statusBean.setData(customFieldListDao.getEditIssueCustomField(conditions));
		return statusBean;
	}
}
