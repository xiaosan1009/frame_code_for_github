package co.jp.softbank.qqmx.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import co.jp.softbank.qqmx.dao.common.IDbExecute;

public interface IBeanValidator extends Validator {
	
	void setDao(IDbExecute dao);
	
	void validate(Object obj, Object param, Errors errors);

}
