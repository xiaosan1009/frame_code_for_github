package co.jp.softbank.qqmx.logic.application.reform;


import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class TuChartListLogic extends TuLogicBase {
	
	private static List<Map<String, Object>> all_tu_data;
	private static List<Map<String, Object>> all_tu_data_redLine;
	private static Map<String, Object> max_min_date;
	
	public LogicBean getChartInfo() throws SoftbankException, Exception {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> data = new HashMap<String, Object>();
		
		logicBean.setData(data);
		return logicBean;
	}
	
	/**
	 * 検索種類ボタン(年・月・週・日)変更、画面再表示
	 * @throws SoftbankException 
	 * @throws Exception 
	 **/
	@SuppressWarnings("unchecked")
	public LogicBean getKindChartInfo() throws SoftbankException, Exception {
		
		String kind = context.getParam().getParamerterMap().get("kind");
		
		// 統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 全従業員/社員/業託
		String dispartch = null;
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		// 新規/既存
		String category = null;
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		// 人工数/金額/施策数
		String status = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		//保存履歴
		String study = null;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);
		
		String budget_artificial_flag = status;
		String artificial_unit = null;
		if ("金額".equals(budget_artificial_flag)) {
			budget_artificial_flag = "BUDGET";
		} else if ("".equals(budget_artificial_flag) || budget_artificial_flag == null || "人工数".equals(budget_artificial_flag)) {
			budget_artificial_flag = "ARTIFICIAL";
			artificial_unit = "人工";
		} else {
			budget_artificial_flag = "RECORD_NUM";
		}
		conditions.put("artificial_unit", artificial_unit);
		
		// Not RedLine
		all_tu_data = db.querys("tuChart.selectAllDateFromView", conditions);
		// RedLine
		all_tu_data_redLine = db.querys("tuChart.selectAllDateFromViewForRedLine", conditions);
		if (all_tu_data.size() == 0) {
			LogicBean logicBeanNull = new LogicBean();
			Map<String, Object> data = new HashMap<String, Object>();
			
			data.put("SELECT_KIND", kind);
			data.put("MAX_HEIGHT_LINE", 0);
			data.put("BUDGET_ARTIFICIAL_FLAG", budget_artificial_flag);
			data.put("AXIS_X", Lists.newArrayList());
			data.put("LEVEL1_LIST", Lists.newArrayList());
			data.put("LEVEL2_LIST", Lists.newArrayList());
			data.put("LEVEL3_LIST", Lists.newArrayList());
			data.put("LEVEL4_LIST", Lists.newArrayList());
			
			logicBeanNull.setData(data);
			return logicBeanNull;
		}
		
		String dateStart = StringUtils.toString(context.getParam().get("dateStart"));
		String dateEnd = StringUtils.toString(context.getParam().get("dateEnd"));
		
		dateStart = dateStart.replace("/", "-");
		dateEnd = dateEnd.replace("/", "-");
		
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
		// Axis-x 作成
		List<String> axis_x = Lists.newArrayList();
		List<String> axis_x_for_compare = Lists.newArrayList();
		max_min_date = db.query("tuChart.selectMaxAndMinDate", conditions);
		// 最大の期日
		Date max_date = (Date) max_min_date.get("max_date");
		// 最小の開始日
		Date min_date = (Date) max_min_date.get("min_date");
		
		if ("".equals(dateStart)) {
			dateStart = "2016-12-01";
		}
		if ("".equals(dateEnd)) {
			dateEnd = "2020-01-01";
		}
		Date dateStart_dateType = dateformat.parse(dateStart);
		Date dateEnd_dateType = dateformat.parse(dateEnd);
		
		int res_start = 	dateStart_dateType.compareTo(min_date);
		int res_start_end = dateStart_dateType.compareTo(max_date);
		int res_end = dateEnd_dateType.compareTo(max_date);
		int res_end_start = dateEnd_dateType.compareTo(min_date);
		
		if (res_start > 0 && res_start_end <= 0) {
			min_date = dateStart_dateType;
		}
		
		if (res_end <= 0 && res_end_start >= 0) {
			max_date = dateEnd_dateType;
		}
		
		if ("YEAR".equals(kind)) {
			// 年差取得
			long min_year = Long.valueOf(dateformat.format(min_date).substring(0,4));
			long max_year = Long.valueOf(dateformat.format(max_date).substring(0,4));
			
			Long max_abs_min_year_num = max_year - min_year;
			
			for (long i = 0; i <= max_abs_min_year_num; i++) {
				String year_axis_x = String.valueOf(min_year + i);
				axis_x.add(year_axis_x);
			}
		} else if ("MONTH".equals(kind)) {
			Calendar startDate = Calendar.getInstance(); 
			Calendar endDate = Calendar.getInstance(); 
			
			startDate.setTime(min_date);  
			endDate.setTime(max_date);  
			int result = (endDate.get(Calendar.YEAR) - startDate.get(Calendar.YEAR)) * 12 + endDate.get(Calendar.MONTH) - startDate.get(Calendar.MONTH);  
			int month_num = result == 0 ? 1 : Math.abs(result);
			
			for (int i = 0; i <= month_num; i++) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(min_date);
				int year = cal.get(Calendar.YEAR); 
				int month = cal.get(Calendar.MONTH);
				if (month == 12) {
					year = year + 1;
					cal.set(Calendar.YEAR, year);
				} else {
					// 処理なし
				}
				cal.add(Calendar.MONTH, i); 
				cal.set(Calendar.YEAR, cal.get(Calendar.YEAR));
				Date date = cal.getTime();
				String month_axis_x = dateformat.format(date);
				axis_x.add(month_axis_x);
			}
		} else if ("WEEK".equals(kind)) {
			SimpleDateFormat sdf_week = new SimpleDateFormat("EEEE");
			String week_min = sdf_week.format(min_date);
			String week_max = sdf_week.format(max_date);
			String new_min_date = getWeekday(week_min, min_date, dateformat);
			String new_max_date = getWeekday(week_max, max_date, dateformat);
			
			// 最小の開始日追加
			axis_x.add(new_min_date);
			// 期日 - 開始日
			Long date_between = this.dateBetween(dateformat.parse(new_min_date), dateformat.parse(new_max_date));
			// 週単位として
			Long weekNum = date_between / 7;
			String newDate = new_min_date;
			for (long i = 0; i < weekNum; i++) {
				newDate = addDate(newDate, 7);
				axis_x.add(newDate);
			}
			
			for (String date_x : axis_x) {
				axis_x_for_compare.add(addDate(date_x, -1));
			}
			
			List<String> axis_x_temp = Lists.newArrayList();
			for (String date_x_for_show : axis_x) {
				axis_x_temp.add(addDate(date_x_for_show, -7));
			}
			axis_x = axis_x_temp;
//			// 最大の期日追加
//			axis_x.add(new_max_date);
		} else if ("DAY".equals(kind)) {
			// 最小の開始日追加
			axis_x.add(dateformat.format(min_date));
			// 期日 - 開始日
			Long date_between = this.dateBetween(min_date, max_date);
			// 日単位として
			String newDate = dateformat.format(min_date);
			for (long i = 1; i < date_between; i++) {
				newDate = addDate(newDate, 1);
				axis_x.add(newDate);
			}
			// 最大の期日追加
			axis_x.add(dateformat.format(max_date));
		}
		
		Map<String, Object> levelMap = Maps.newHashMap();
		Map<String, Object> levelMap_redLine = Maps.newHashMap();
		if ("YEAR".equals(kind)) {
			List<String> year_axis_x = Lists.newArrayList();
			for (String x : axis_x) {
				if ("2017".equals(x)) {
					year_axis_x.add("2017-12-31");
				} else if ("2018".equals(x)) {
					year_axis_x.add("2018-12-31");
				} else if ("2019".equals(x)) {
					year_axis_x.add("2019-12-31");
				}
			}
			// RedLine
			levelMap_redLine = this.getLevelList(year_axis_x, dateformat, budget_artificial_flag, true);
			// Not RedLine
			levelMap = this.getLevelList(year_axis_x, dateformat, budget_artificial_flag, false);
		} else if ("MONTH".equals(kind)) {
			List<String> month_axis_x = Lists.newArrayList();
			for (String x : axis_x) {
				
				month_axis_x.add(x.substring(0, 8) + getMaxDayOfMonth(x));
			}
			// RedLine
			levelMap_redLine = this.getLevelList(month_axis_x, dateformat, budget_artificial_flag, true);
			// Not RedLine
			levelMap = this.getLevelList(month_axis_x, dateformat, budget_artificial_flag, false);
		} else if ("WEEK".equals(kind)) {
			// RedLine
			levelMap_redLine = this.getLevelList(axis_x_for_compare, dateformat, budget_artificial_flag, true);
			// Not RedLine
			levelMap = this.getLevelList(axis_x_for_compare, dateformat, budget_artificial_flag, false);
		} else if ("DAY".equals(kind)) {
			// RedLine
			levelMap_redLine = this.getLevelList(axis_x, dateformat, budget_artificial_flag, true);
			// Not RedLine
			levelMap = this.getLevelList(axis_x, dateformat, budget_artificial_flag, false);
		}
		
		BigDecimal level1_0 = ((List<BigDecimal>)levelMap.get("LEVEL1_LIST")).get(0);
		BigDecimal level2_0 = ((List<BigDecimal>)levelMap.get("LEVEL2_LIST")).get(0);
		BigDecimal level3_0 = ((List<BigDecimal>)levelMap.get("LEVEL3_LIST")).get(0);
		BigDecimal level4_0 = ((List<BigDecimal>)levelMap.get("LEVEL4_LIST")).get(0);
		BigDecimal max_height_line = level1_0.add(level2_0).add(level3_0).add(level4_0);
		
		LogicBean logicBean = new LogicBean();
		Map<String, Object> data = new HashMap<String, Object>();
		
		data.put("SELECT_KIND", kind);
		data.put("MAX_HEIGHT_LINE", max_height_line);
		data.put("BUDGET_ARTIFICIAL_FLAG", budget_artificial_flag);
		data.put("AXIS_X", axis_x);
		data.put("LEVEL1_LIST", levelMap.get("LEVEL1_LIST"));
		data.put("LEVEL2_LIST", levelMap.get("LEVEL2_LIST"));
		data.put("LEVEL3_LIST", levelMap.get("LEVEL3_LIST"));
		data.put("LEVEL4_LIST", levelMap.get("LEVEL4_LIST"));
		
		List<BigDecimal> level_3_redLine = Lists.newArrayList();
		level_3_redLine = (List<BigDecimal>) levelMap_redLine.get("LEVEL3_LIST");
		List<BigDecimal> level_4_redLine = Lists.newArrayList();
		level_4_redLine = (List<BigDecimal>) levelMap_redLine.get("LEVEL4_LIST");
		
		List<BigDecimal> redLineData = Lists.newArrayList();
		for (int i = 0; i < level_3_redLine.size(); i++) {
			redLineData.add(level_3_redLine.get(i).add(level_4_redLine.get(i)));
		}
		data.put("RED_LINE", redLineData);
		
		logicBean.setData(data);
		return logicBean;
	}
	
	/**
	 * 各レベルリスト算出
	 * @throws Exception 
	 **/
	private Map<String, Object> getLevelList(List<String> axis_x, SimpleDateFormat dateformat, String budget_artificial_flag, boolean isRedLine) throws Exception {
		
		List<Map<String, Object>> allRecords = Lists.newArrayList();
		if (isRedLine) {
			allRecords = all_tu_data_redLine;
		} else {
			allRecords = all_tu_data;
		}
		
		
		String kind = context.getParam().getParamerterMap().get("kind");
		boolean monthFlag = false;
		if ("MONTH".equals(kind)) {
			monthFlag = true;
		} else {
			// 処理なし
		}
		
		Date today = new Date();
		String today_string_08 = dateformat.format(today).substring(0, 8);
		
		Map<String, Object> levelListMap = Maps.newHashMap();
		
		List<BigDecimal> level1_list = Lists.newArrayList();
		List<BigDecimal> level2_list = Lists.newArrayList();
		List<BigDecimal> level3_list = Lists.newArrayList();
		List<BigDecimal> level4_list = Lists.newArrayList();
		for (String x_date_string : axis_x) {
			BigDecimal level1 = BigDecimal.ZERO;
			BigDecimal level2 = BigDecimal.ZERO;
			BigDecimal level3 = BigDecimal.ZERO;
			BigDecimal level4 = BigDecimal.ZERO;
			
			Date x_date_date = dateformat.parse(x_date_string);
			
			String x_date_string_08 = x_date_string.substring(0, 8);
			if (monthFlag && today_string_08.equals(x_date_string_08)) {
				x_date_date = today;
			}
			int res = today.compareTo(x_date_date);

			if (res >= 0) {
				// 過去日の場合
				for (Map<String, Object> tu_data : allRecords) {
					int dateCompareRes4 = 1;
					int dateCompareRes3 = 1;
					int dateCompareRes2 = 1;
					if (tu_data.get("lv4_end_date") != null && !"".equals(tu_data.get("lv4_end_date"))) {
						dateCompareRes4 = ((Date) tu_data.get("lv4_end_date")).compareTo(x_date_date);
					}
					if (tu_data.get("lv3_end_date") != null && !"".equals(tu_data.get("lv3_end_date"))) {
						dateCompareRes3 = ((Date) tu_data.get("lv3_end_date")).compareTo(x_date_date);
					}
					if (tu_data.get("lv2_end_date") != null && !"".equals(tu_data.get("lv2_end_date"))) {
						dateCompareRes2 = ((Date) tu_data.get("lv2_end_date")).compareTo(x_date_date);
					}
					if (dateCompareRes4 <= 0) {
						// レベル4
						BigDecimal level4_17_minus_19 = BigDecimal.ZERO;
						if ("BUDGET".equals(budget_artificial_flag)) {
							// 金額の場合
							level4_17_minus_19 = (BigDecimal) tu_data.get("plan_budget_effect1719");
						} else if ("ARTIFICIAL".equals(budget_artificial_flag)) {
							// 人工の場合
							level4_17_minus_19 = (BigDecimal) tu_data.get("plan_artificial_effect1719");
						} else {
							// 施策の場合
							level4_17_minus_19 = BigDecimal.valueOf(1);
						}
						level4 = level4.add(level4_17_minus_19);
					} else if (dateCompareRes3 <= 0) {
						// レベル3
						BigDecimal level3_17_minus_19 = BigDecimal.ZERO;
						if ("BUDGET".equals(budget_artificial_flag)) {
							// 金額の場合
							level3_17_minus_19 = (BigDecimal) tu_data.get("plan_budget_effect1719");
						} else if ("ARTIFICIAL".equals(budget_artificial_flag)) {
							// 人工の場合
							level3_17_minus_19 = (BigDecimal) tu_data.get("plan_artificial_effect1719");
						} else {
							// 施策の場合
							level3_17_minus_19 = BigDecimal.valueOf(1);
						}
						level3 = level3.add(level3_17_minus_19);
					} else if (dateCompareRes2 <= 0) {
						// レベル2
						BigDecimal level2_17_minus_19 = BigDecimal.ZERO;
						if ("BUDGET".equals(budget_artificial_flag)) {
							// 金額の場合
							level2_17_minus_19 = (BigDecimal) tu_data.get("plan_budget_effect1719");
						} else if ("ARTIFICIAL".equals(budget_artificial_flag)) {
							// 人工の場合
							level2_17_minus_19 = (BigDecimal) tu_data.get("plan_artificial_effect1719");
						} else {
							// 施策の場合
							level2_17_minus_19 = BigDecimal.valueOf(1);
						}
						level2 = level2.add(level2_17_minus_19);
					} else {
						// レベル1
						BigDecimal level1_17_minus_19 = BigDecimal.ZERO;
						if ("BUDGET".equals(budget_artificial_flag)) {
							// 金額の場合
							level1_17_minus_19 = (BigDecimal) tu_data.get("plan_budget_effect1719");
						} else if ("ARTIFICIAL".equals(budget_artificial_flag)) {
							// 人工の場合
							level1_17_minus_19 = (BigDecimal) tu_data.get("plan_artificial_effect1719");
						} else {
							// 施策の場合
							level1_17_minus_19 = BigDecimal.valueOf(1);
						}
						level1 = level1.add(level1_17_minus_19);
					}
				}
			} else {
				// 未来日の場合
				for (Map<String, Object> tu_data : allRecords) {
					
					int dateCompareRes4 = 1;
					int dateCompareRes3 = 1;
					int dateCompareRes2 = 1;
					if (tu_data.get("lv4_due_date") != null && !"".equals(tu_data.get("lv4_due_date"))) {
						dateCompareRes4 = ((Date) tu_data.get("lv4_due_date")).compareTo(x_date_date);
					}
					if (tu_data.get("lv3_due_date") != null && !"".equals(tu_data.get("lv3_due_date"))) {
						dateCompareRes3 = ((Date)  tu_data.get("lv3_due_date")).compareTo(x_date_date);
					}
					if (tu_data.get("lv2_due_date") != null && !"".equals(tu_data.get("lv2_due_date"))) {
						dateCompareRes2 = ((Date) tu_data.get("lv2_due_date")).compareTo(x_date_date);
					}
					
					if (dateCompareRes4 <= 0) {
						// レベル4
						BigDecimal level4_17_minus_19 = BigDecimal.ZERO;
						if ("BUDGET".equals(budget_artificial_flag)) {
							// 金額の場合
							level4_17_minus_19 = (BigDecimal) tu_data.get("plan_budget_effect1719");
						} else if ("ARTIFICIAL".equals(budget_artificial_flag)) {
							// 人工の場合
							level4_17_minus_19 = (BigDecimal) tu_data.get("plan_artificial_effect1719");
						} else {
							// 施策の場合
							level4_17_minus_19 = BigDecimal.valueOf(1);
						}
						level4 = level4.add(level4_17_minus_19);
					} else if (dateCompareRes3 <= 0) {
						// レベル3
						BigDecimal level3_17_minus_19 = BigDecimal.ZERO;
						if ("BUDGET".equals(budget_artificial_flag)) {
							// 金額の場合
							level3_17_minus_19 = (BigDecimal) tu_data.get("plan_budget_effect1719");
						} else if ("ARTIFICIAL".equals(budget_artificial_flag)) {
							// 人工の場合
							level3_17_minus_19 = (BigDecimal) tu_data.get("plan_artificial_effect1719");
						} else {
							// 施策の場合
							level3_17_minus_19 = BigDecimal.valueOf(1);
						}
						level3 = level3.add(level3_17_minus_19);
					} else if (dateCompareRes2 <= 0) {
						// レベル2
						BigDecimal level2_17_minus_19 = BigDecimal.ZERO;
						if ("BUDGET".equals(budget_artificial_flag)) {
							// 金額の場合
							level2_17_minus_19 = (BigDecimal) tu_data.get("plan_budget_effect1719");
						} else if ("ARTIFICIAL".equals(budget_artificial_flag)) {
							// 人工の場合
							level2_17_minus_19 = (BigDecimal) tu_data.get("plan_artificial_effect1719");
						} else {
							// 施策の場合
							level2_17_minus_19 = BigDecimal.valueOf(1);
						}
						level2 = level2.add(level2_17_minus_19);
					} else {
						// レベル1
						BigDecimal level1_17_minus_19 = BigDecimal.ZERO;
						if ("BUDGET".equals(budget_artificial_flag)) {
							// 金額の場合
							level1_17_minus_19 = (BigDecimal) tu_data.get("plan_budget_effect1719");
						} else if ("ARTIFICIAL".equals(budget_artificial_flag)) {
							// 人工の場合
							level1_17_minus_19 = (BigDecimal) tu_data.get("plan_artificial_effect1719");
						} else {
							// 施策の場合
							level1_17_minus_19 = BigDecimal.valueOf(1);
						}
						level1 = level1.add(level1_17_minus_19);
					}
				}
			}
			
			level1_list.add(level1);
			level2_list.add(level2);
			level3_list.add(level3);
			level4_list.add(level4);
			
			levelListMap.put("LEVEL1_LIST", level1_list);
			levelListMap.put("LEVEL2_LIST", level2_list);
			levelListMap.put("LEVEL3_LIST", level3_list);
			levelListMap.put("LEVEL4_LIST", level4_list);
		}
		
		return levelListMap;
	}
	
	/**
	 * 日付差算出
	 **/
	private long dateBetween(Date begin, Date end) {
		long diff = end.getTime() - begin.getTime();
		return diff/(1000 * 60 * 60 * 24);
	}
	
	/**
	 * 日単位として足し算（週はプラス7）
	 **/
	private String addDate(String dateTime, int n) throws ParseException {
		//日期格式 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date parseStringToDate = dateFormat.parse(dateTime);
		String date = dateFormat.format(new Date(parseStringToDate.getTime() + n * 24 * 60 * 60 * 1000L)); // 指定日期
		return date; 
	}
	
	private String getWeekday(String date, Date min_date, SimpleDateFormat dateformat) throws Exception {
		String new_date = "";
		if ("月曜日".equals(date)) {
			new_date = addDate(dateformat.format(min_date), 7);
		} else if ("火曜日".equals(date)) {
			new_date = addDate(dateformat.format(min_date), 6);
		} else if ("水曜日".equals(date)) {
			new_date = addDate(dateformat.format(min_date), 5);
		} else if ("木曜日".equals(date)) {
			new_date = addDate(dateformat.format(min_date), 4);
		} else if ("金曜日".equals(date)) {
			new_date = addDate(dateformat.format(min_date), 3);
		} else if ("土曜日".equals(date)) {
			new_date = addDate(dateformat.format(min_date), 2);
		} else if ("日曜日".equals(date)) {
			new_date = addDate(dateformat.format(min_date), 1);
		}
		
		return new_date;
	}
	private String getMaxDayOfMonth(String day) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = sdf.parse(day) ;
		
		Calendar xCalTemp  = Calendar.getInstance() ;
		xCalTemp.setTime(date);
		
		return String.valueOf(xCalTemp.getActualMaximum(Calendar.DATE));
	} 
}
