package co.jp.softbank.qqmx.handle.impl;

import co.jp.softbank.qqmx.handle.AbstractScriptUtilHandler;

public class ScriptUtilhandlerImpl extends AbstractScriptUtilHandler {

}
