package co.jp.softbank.qqmx.controller;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import co.jp.softbank.qqmx.server.face.IQqmxServletFace;

public class CommonController extends AbstractController {
	
	private IQqmxServletFace qqmxService;
	
	@Override
	protected void initServletContext(ServletContext servletContext) {
		super.initServletContext(servletContext);
		try {
			qqmxService.init(servletContext);
		} catch (ServletException e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		qqmxService.doPost(arg0, arg1);
		return null;
	}
	
	public void setQqmxService(IQqmxServletFace qqmxService) {
		this.qqmxService = qqmxService;
	}

}
