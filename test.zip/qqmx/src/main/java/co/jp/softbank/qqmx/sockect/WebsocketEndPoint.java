package co.jp.softbank.qqmx.sockect;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.sockect.bean.WebSocketClientInfo;
import co.jp.softbank.qqmx.sockect.face.IWebSocketLogic;

import com.google.common.collect.Lists;

public class WebsocketEndPoint extends TextWebSocketHandler {
	
	protected final Logger log = LoggerFactory.getLogger(getClass());
    
    private List<IWebSocketLogic> socketList;

    @Override  
    protected void handleTextMessage(WebSocketSession session,  
            TextMessage message) throws Exception {  
        super.handleTextMessage(session, message); 
        WebSocketClientInfo clientInfo = new WebSocketClientInfo(session);
        JSONObject messageObject = JSONObject.fromObject(message.getPayload());
        for (int i = 0; i < socketList.size(); i++) {
        	socketList.get(i).recieve(clientInfo, messageObject);
		}
    }  
    
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
    	log.info("afterConnectionEstablished start!!!");
        super.afterConnectionEstablished(session);
        WebSocketClientInfo clientInfo = WebSocketClientManager.getInstance().addSession(session);
        try {
        	for (int i = 0; i < socketList.size(); i++) {
            	socketList.get(i).connect(clientInfo);
    		}
		} catch (SoftbankException e) {
			log.error(e.getErrorMsg(), e);
			JSONObject result = new JSONObject();
			List<String> userMessages = Lists.newArrayList(e.getErrorMsg());
	        JSONArray resultArr = JSONArray.fromObject(userMessages);
	        result.put("type", "error");
	        result.put("data", resultArr);
	        WebSocketClientManager.getInstance().send(session, result.toString());
		}
        log.info("afterConnectionEstablished end!!!");
    }
    
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status)
            throws Exception {
    	log.info("afterConnectionClosed start!!!");
        super.afterConnectionClosed(session, status);
        WebSocketClientInfo clientInfo = WebSocketClientManager.getInstance().addSession(session);
        try {
        	for (int i = 0; i < socketList.size(); i++) {
            	socketList.get(i).closed(clientInfo);
    		}
		} catch (SoftbankException e) {
			log.error(e.getErrorMsg(), e);
			JSONObject result = new JSONObject();
			List<String> userMessages = Lists.newArrayList(e.getErrorMsg());
	        JSONArray resultArr = JSONArray.fromObject(userMessages);
	        result.put("type", "error");
	        result.put("data", resultArr);
	        WebSocketClientManager.getInstance().send(session, result.toString());
		}
        log.info("afterConnectionClosed end!!!");
    }

	public void setSocketList(List<IWebSocketLogic> socketList) {
		this.socketList = socketList;
	}
    
}
