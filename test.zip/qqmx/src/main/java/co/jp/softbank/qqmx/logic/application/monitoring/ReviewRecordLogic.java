package co.jp.softbank.qqmx.logic.application.monitoring;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ReviewRecordLogic extends AbstractBaseLogic {

	public void getReviewRecord() throws SoftbankException, ParseException {
		Map<String, Object> conditions = select();
		
		List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
		if (!"".equals(conditions.get("documentId")) && conditions.get("documentId") != null) {
			info = db.querys("deliverables.getDeliverablesList", conditions);
		}
		
		if (info.size() != 0 ) {
			info = infoEdit(info);
		} else {
			info = infoEditNull(info);
		}

		context.getResultBean().setData(info);
	}
	
	public void submitBatchPost() throws SoftbankException, ParseException {
		String documentId = context.getParam().get("documentId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issues_id", Integer.parseInt(documentId));
		List<Map<String, Object>> issuesInfo = db.querys("reviewRecord.getCheckFlg", conditions);
		if (issuesInfo.size() < 1 ){
			return;
		}
		String issue_value = String.valueOf(issuesInfo.get(0).get("value"));
		if (StringUtils.isEmpty(issue_value)){
			conditions.put("issues_id", Integer.parseInt(documentId));
			List<Map<String, Object>> fileDate = db.querys("reviewRecord.getFileDate", conditions);
			String createdData = String.valueOf(fileDate.get(0).get("filecreate_date"));
			externalHttpServer.getStrUrl("http://10.216.80.167:8080/qqrp/qqrp.mx?dispCode=900006&cmdCode=1&issueId=" + documentId + "&gitFlg=0&createdData=" + createdData); //本番環境 誤字脱字
			externalHttpServer.getStrUrl("http://10.216.80.167:8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + documentId); //本番環境 コメント
//			externalHttpServer.getStrUrl("http://localhost:8080/qqrp/qqrp.mx?dispCode=900006&cmdCode=1&issueId=" + documentId + "&gitFlg=0&createdData=" + createdData); //230環境 コメント
//			externalHttpServer.getStrUrl("http://localhost:8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + documentId); //230環境 コメント
		} else {
			externalHttpServer.getStrUrl("http://10.216.80.167:8080/qqrp/qqrp.mx?dispCode=900006&cmdCode=1&issueId=" + documentId); //本番環境 誤字脱字
			externalHttpServer.getStrUrl("http://10.216.80.167:8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + documentId); //本番環境 コメント
//			externalHttpServer.getStrUrl("http://10.157.30.230:8080/qqrp/qqrp.mx?dispCode=900006&cmdCode=1&issueId=" + documentId); //230環境 誤字脱字
//			externalHttpServer.getStrUrl("http://10.157.30.230:8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + documentId); //230環境 コメント
		}
	}

	public void getReviewRecordDetailed() throws SoftbankException {
		
		Map<String, Object> conditions = select();
		if ("".equals(conditions.get("projectId")) || conditions.get("projectId") == null ||
				"".equals(conditions.get("documentId")) || conditions.get("documentId") == null) {
/*			List<Map<String, Object>> reviewRecordInfoList = null;
			context.getResultBean().setData(reviewRecordInfoList);*/
			conditions.put("issue_id", 0);
		} else {
			conditions.put("issue_id", conditions.get("documentId"));
		}
		
		PageListBean pageListBean = pageList("reviewRecord.getReviewRecord", conditions);
		
		context.getResultBean().setData(pageListBean);
	}
	
	public void getSystemList() throws SoftbankException{
		Map<String, Object> conditions = select();
		
		List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
		if (!"".equals(conditions.get("documentId")) && conditions.get("documentId") != null) {
			info = db.querys("deliverables.getDeliverablesList", conditions);
		}

		if (info.size() != 0 ) {
			info = infoEdit(info);
		} else {
			info = infoEditNull(info);
		}

		List<Map<String, Object>> systemList = db.querys("deliverables.getSystemList", conditions);
		
		List<Map<String, Object>> versionList = db.querys("deliverables.getVersionList", conditions);
		
		List<Map<String, Object>> authorList = db.querys("deliverables.getAuthorList", conditions);
		
		List<Map<String, Object>> documentList = db.querys("deliverables.getDocumentList", conditions);
		
//		for(int j = 0;j < documentList.size();j++){
//			// filename
//			String filename = documentList.get(j).get("filename").toString();
//			filename = filename.substring(filename.lastIndexOf("\\")+1, filename.length());
//			documentList.get(j).put("filename", filename);
//		}
		
		Map<String, Object> listMap = Maps.newHashMap();
		listMap.put("systemList", systemList);
		listMap.put("versionList", versionList);
		listMap.put("authorList", authorList);
		listMap.put("documentList", documentList);
		listMap.put("info", info);
		
		context.getResultBean().setData(listMap);
	}
	
	public Map<String, Object> select(){
		
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		String systemId = context.getParam().get("systemId");
		String versionId = context.getParam().get("versionId");
		String authorId = context.getParam().get("authorId");
		String documentId = context.getParam().get("documentId");
		if(!"".equals(versionId)){
			conditions.put("versionId", Integer.parseInt(versionId));
		}
		if(!"".equals(authorId)){
			conditions.put("authorId", Integer.parseInt(authorId));
		}
		if(!"".equals(systemId)){
			conditions.put("systemId", Integer.parseInt(systemId));
			conditions.put("systemId", systemId);
		}
		if (!"".equals(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
		}
		if (!"".equals(documentId)){
			conditions.put("documentId", Integer.parseInt(documentId));
		}
		
		return conditions;
	}
	
	public String isNull(Object info){
		String vaule = "";
		if (info != null) {
			vaule = info.toString();
		} 
		
		return vaule;
	}
	
	public List<Map<String, Object>> infoEdit(List<Map<String, Object>> info) throws SoftbankException{
		
		String orderDateS = isNull(info.get(0).get("start_date"));
		String orderDateE = isNull(info.get(0).get("due_date"));
		String executiveDateS = isNull(info.get(0).get("create_date"));
		String executiveDateE = isNull(info.get(0).get("end_date"));
		String pages = isNull(info.get(0).get("pages"));
		
		// レビュー時間(h)
		String reviewTime = "0";
		if(info.get(0).get("hours") != null){
			reviewTime = info.get(0).get("hours").toString();
		}
		// レビュー時間(str)
		String reviewTimeStr = "0h 0min";
		if(info.get(0).get("review_date") != null){
			reviewTimeStr = info.get(0).get("review_date").toString();
		}

		Map<String, Object> conditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		if (!"".equals(documentId)){
			conditions.put("issue_id", Integer.parseInt(documentId));
		}
		List<Map<String, Object>> statusList = db.querys("reviewRecord.getStatus", conditions);
		
		String done_ratio = "";
		double statusCount_sum = 0.00;
		if (statusList.size() == 0) {
			done_ratio = "100%";
		} else {
			double statusCount_0 = 0.00;
			for (int i = 0; i < statusList.size(); i++) {
				if ("0".equals(statusList.get(i).get("comment_status").toString())) {
					statusCount_0 = Double.parseDouble(statusList.get(i).get("count").toString());
				}
				statusCount_sum = statusCount_sum + Double.parseDouble(statusList.get(i).get("count").toString());
			}
			
			int ratioVal = (int) Math.round((statusCount_0/statusCount_sum) * 100);
			
			done_ratio = ratioVal + "%";
		}
		
		String total = String.valueOf((int)statusCount_sum);

		if (!"".equals(executiveDateS) && executiveDateS.length() != 5) {
			executiveDateS = executiveDateS.substring(5, 10);
			executiveDateS = executiveDateS.replace("-", "/");
		}
		
		if (!"".equals(executiveDateE) && executiveDateE.length() != 5) {
			executiveDateE = executiveDateE.substring(5, 10);
			executiveDateE = executiveDateE.replace("-", "/");
		}

		String orderDate = orderDateS + "～" + orderDateE + "　";
		String executiveDate = "";
		if (!"".equals(executiveDateS)) {
			executiveDate = executiveDateS + "～" + executiveDateE + "　";
		}
		
		DecimalFormat df = new DecimalFormat("0.00");
		String reviewDensity = "0.00";
		String reviewEfficiency = "0.00";
		if (!"".equals(isNull(info.get(0).get("review_density")))) {
			reviewDensity = isNull(info.get(0).get("review_density"));
		}
		if (!"".equals(pages) && total != "" && !"0".equals(pages)) {
			reviewEfficiency = df.format(Double.parseDouble(reviewTime) / Double.parseDouble(pages));
		}
		
		info.get(0).put("orderDate", orderDate);
		info.get(0).put("executiveDate", executiveDate);
		info.get(0).put("reviewTime", reviewTime);
		info.get(0).put("reviewTimeStr", reviewTimeStr);
		info.get(0).put("reviewDensity", reviewDensity);
		info.get(0).put("reviewEfficiency", reviewEfficiency);
		info.get(0).put("done_ratio", done_ratio);
		info.get(0).put("total", total);

		return info;
	}
	
	public List<Map<String, Object>> infoEditNull(List<Map<String, Object>> info){
		Map<String, Object> infoNull =  Maps.newHashMap();

		infoNull.put("pages", "0");
		infoNull.put("username", "");
		infoNull.put("orderDate", "");
		infoNull.put("executiveDate", "");
		infoNull.put("total", "0");
		infoNull.put("reviewTime", "0");
		infoNull.put("reviewTimeStr", "0時 0分");
		infoNull.put("reviewDensity", "0.00");
		infoNull.put("reviewEfficiency", "0.00");
		infoNull.put("done_ratio", "0%");
		
		info.add(infoNull);

		return info;
	}
	
	// レビュー開始、終了時間　DB登録
	public void setReviewTime() throws SoftbankException {

		String documentId = context.getParam().get("documentId");
		String startDate = context.getParam().get("startTime");
		String endDate = context.getParam().get("endTime");
		String authorId = context.getParam().get("authorId");
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", Integer.parseInt(documentId));
		conditions.put("start_date", startDate);
		conditions.put("end_date", endDate);
		if(!"".equals(authorId) && authorId != null){
			conditions.put("login_id", Integer.parseInt(authorId));
		}

		db.insert("reviewRecord.insertReviewTime", conditions);
	}
	
	// レビュー時間取得
	public void getReviewTime() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		if (!"".equals(documentId)){
			conditions.put("issue_id", Integer.parseInt(documentId));
		}
		
		List<Map<String, Object>> list = db.querys("reviewRecord.getReviewTime", conditions);

		context.getResultBean().setData(list);
	}
	
	// 既存選択したルール取得
	public void getCheckedRule() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		if (!"".equals(documentId)){
			conditions.put("issue_id", Integer.parseInt(documentId));
		}
		
		List<Map<String, Object>> list = db.querys("reviewRecord.getCheckedRuleList", conditions);
		// 既存ルールなし　デフォルトルール取得
		if(list.size() == 0){
			conditions.put("issue_id", 999999);
			list = db.querys("reviewRecord.getCheckedRuleList", conditions);
		}
		context.getResultBean().setData(list);
		
	}
	
	// チェックルールDB保存
	public void submitCheckRuleInfo() throws SoftbankException {
		// 当documentIdに関するデータクリア
		Map<String, Object> clearConditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		if (!"".equals(documentId)){
			clearConditions.put("issue_id", Integer.parseInt(documentId));
		}
		db.delete("reviewRecord.clearCheckRuleList", clearConditions);
		
		// チェックルールDB保存
		List<Map<String, Object>> ruleList = Lists.newArrayList();
		ruleList =  db.querys("reviewRecord.getRuleList");
		for (int i = 0; i < ruleList.size(); i++) {
			Map<String, Object> ruleData = ruleList.get(i);
			String ruleId = StringUtils.toString(ruleData.get("id"));
			
			String isChecked = "false";
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issue_id", Integer.parseInt(documentId));
			conditions.put("rules_id", Integer.parseInt(ruleId));
			// ルールchecked
			if (StringUtils.isNotEmpty(context.getParam().get(ruleId))) {
				isChecked = "true";
			}
			conditions.put("ischecked", isChecked);
			// ruletype=3　enter_rule　の場合
			String input_value = context.getParam().get(ruleId + "_value");
			if (input_value != null && input_value !="") {
				conditions.put("input_value", Integer.parseInt(input_value));
			}
			db.insert("reviewRecord.insertCheckRuleList", conditions);
		}
	}
	
		// 対応内容登録
		public void setComments() throws SoftbankException {

			String file_Id = context.getParam().get("file_Id");
			String comment_Id = context.getParam().get("comment_Id");
			String comment_contents = context.getParam().get("comment_contents");
			
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("comment_contents", comment_contents);
			if (!"".equals(file_Id) && !"".equals(comment_Id)){
				conditions.put("file_Id", Integer.parseInt(file_Id));
				conditions.put("comment_Id", Integer.parseInt(comment_Id));
				
				List<Map<String, Object>> list = db.querys("reviewRecord.getComments", conditions);

				if(list.size() == 0){
					// 対応内容追加
					db.insert("reviewRecord.insertComments", conditions);
				}
				else{
					// 対応内容更新
					db.update("reviewRecord.updateComments", conditions);
				}
			}
		}
		
		// コメントステータス設定
		public void setCommentStatus() throws SoftbankException {

			String file_Id = context.getParam().get("file_Id");
			String comment_Id = context.getParam().get("comment_Id");
			String comment_status = context.getParam().get("comment_status");
			
			Map<String, Object> conditions = Maps.newHashMap();
			if (!"".equals(file_Id) && !"".equals(comment_Id) && !"".equals(comment_status)){
				conditions.put("file_Id", Integer.parseInt(file_Id));
				conditions.put("comment_Id", Integer.parseInt(comment_Id));
				conditions.put("comment_status", Integer.parseInt(comment_status));
				
				List<Map<String, Object>> list = db.querys("reviewRecord.getCommentFileDatas", conditions);

				if(list.size() == 0){
					// 処理なし
					return;
				}
				else{
					// 対応内容更新
					String comment_count = list.get(0).get("comment_count").toString();
					String type = list.get(0).get("type").toString();
					String status_count = "1";
					String status_total = "1";
					if(type.equals("xlsx")){
						//excel
						db.update("reviewRecord.updateComment_excel_Datas", conditions);
						List<Map<String, Object>> statusCount = db.querys("reviewRecord.excelStatusCount", conditions);
						status_count = statusCount.get(0).get("unsolved").toString();
						status_total = statusCount.get(0).get("total").toString();
						if(!comment_count.equals(status_count)){
							conditions.put("comment_count", Integer.parseInt(status_count));
							db.update("reviewRecord.updateCommentCount", conditions);
						}
					}else if(type.equals("pptx")){
						//ppt
						db.update("reviewRecord.updateComment_ppt_Datas", conditions);
						List<Map<String, Object>> statusCount = db.querys("reviewRecord.pptStatusCount", conditions);
						status_count = statusCount.get(0).get("unsolved").toString();
						status_total = statusCount.get(0).get("total").toString();
						if(!comment_count.equals(status_count)){
							conditions.put("comment_count", Integer.parseInt(status_count));
							db.update("reviewRecord.updateCommentCount", conditions);
						}
					}else if(type.equals("docx")){
						//doc
						db.update("reviewRecord.updateComment_doc_Datas", conditions);
						List<Map<String, Object>> statusCount = db.querys("reviewRecord.docStatusCount", conditions);
						status_count = statusCount.get(0).get("unsolved").toString();
						status_total = statusCount.get(0).get("total").toString();
						if(!comment_count.equals(status_count)){
							conditions.put("comment_count", Integer.parseInt(status_count));
							db.update("reviewRecord.updateCommentCount", conditions);
						}
					}
					int temp = Integer.parseInt(status_total)-Integer.parseInt(status_count);
					context.getResultBean().setData(temp);
				}
			}
		}
		
		public void fileCopy() throws SoftbankException, ParseException {
			String documentId = context.getParam().get("document_id");
			externalHttpServer.getStrUrl("http://10.216.80.167:8080/qqrp/qqrp.mx?dispCode=900007&cmdCode=1&issueId=" + documentId); //fileCopy
//			externalHttpServer.getStrUrl("http://localhost:8080/qqrp/qqrp.mx?dispCode=900007&cmdCode=1&issueId=" + documentId); //fileCopy
		}
}
