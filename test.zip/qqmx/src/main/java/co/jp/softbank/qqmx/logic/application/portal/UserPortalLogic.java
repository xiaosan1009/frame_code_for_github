package co.jp.softbank.qqmx.logic.application.portal;

import java.util.Date;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.issues.IssuesDao;
import co.jp.softbank.qqmx.dao.issues.bean.IssuesBean;
import co.jp.softbank.qqmx.dao.issues.bean.IssuesPersonBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.application.project.TicketBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class UserPortalLogic extends TicketBaseLogic {
	
	@Autowired
	private IssuesDao issues;
	
	public LogicBean getUserIssues() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		Map<String, Object> conditionsMap = Maps.newHashMap();
		conditionsMap.put("userId", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditionsMap.put("startDate", context.getParam().get("startDate"));
		conditionsMap.put("endDate", context.getParam().get("endDate"));
		
		List<IssuesBean> userIssuesBeans = issues.selectNotFinishedIssuesForUser(conditionsMap);
		
		Map<String, Float> startTimeMap = Maps.newHashMap();
		
		for (int i = 0; i < userIssuesBeans.size(); i++) {
			IssuesBean issuesBean = userIssuesBeans.get(i);
			calcWorkPassDay(issuesBean);
			if (issuesBean.isIs_closed()) {
				continue;
			}
			conditionsMap.put("issuesId", issuesBean.getId());
			List<IssuesPersonBean> userPersonBeans = issues.selectIssuesPersonInfoByIssuesId(conditionsMap);
			if (userPersonBeans == null || userPersonBeans.size() == 0) {
				createIssuesPersonInfo(issuesBean, startTimeMap);
			}
		}
		
		List<IssuesPersonBean> userPersonBeans = issues.selectIssuesPersonInfoByUser(conditionsMap);
		
		Map<String, Object> resultData = Maps.newHashMap();
		resultData.put("issues", userIssuesBeans);
		resultData.put("persons", userPersonBeans);
		resultData.put("enabledScmInfos", ControlDbMemory.getInstance().getEnabledScmInfos());
		
		logicBean.setData(resultData);
		
		return logicBean;
	}
	
	public void saveUserIssues() throws SoftbankException {
		String dataString = this.context.getParam().get("datas");
		JSONObject dataJson = JSONObject.fromObject(dataString);
		JSONArray ticketDatas = dataJson.getJSONArray("ticketDatas");
		JSONArray personDatas = dataJson.getJSONArray("personDatas");
		Map<Integer, Map<String, Object>> updateTicketMap = Maps.newHashMap();
		List<Map<String, Object>> conflicts = updateTicketInfo(ticketDatas, updateTicketMap);
		Map<String, Integer> idMap = Maps.newHashMap();
		Map<Integer, Integer> updateMap = Maps.newHashMap();
		updatePersonInfos(personDatas, idMap, updateMap);
		
		Map<String, Object> resultMap = Maps.newHashMap();
		
		if (conflicts != null && conflicts.size() > 0) {
			resultMap.put("conflicts", conflicts);
		}
		resultMap.put("idMap", idMap);
		resultMap.put("updateMap", updateMap);
		resultMap.put("updateTicketMap", updateTicketMap);
		context.getResultBean().setData(resultMap);
	}

	private void updatePersonInfos(JSONArray personDatas, Map<String, Integer> idMap, Map<Integer, Integer> updateMap) throws SoftbankException {
		for (int i = 0; i < personDatas.size(); i++) {
			IssuesPersonBean personBean = new IssuesPersonBean();
			JSONObject personData = personDatas.getJSONObject(i);
			if (!personData.containsKey("isUpdate")) {
				continue;
			}
			if (personData.containsKey("time_entries_id")) {
				personBean.setTime_entries_id(personData.getInt("time_entries_id"));
			}
			if (personData.containsKey("isDelete") && "1".equals(personData.getString("isDelete"))) {
				deletePersonData(personBean, personData);
			} else {
				String oldId = personData.getString("id");
				updatePersonData(personBean, personData);
				if (oldId.startsWith("n")) {
					idMap.put(oldId, personBean.getId());
				}
				if (personBean.isUpdate()) {
					updateMap.put(personBean.getId(), personBean.getTime_entries_id());
				}
			}
		}
	}

	private List<Map<String, Object>> updateTicketInfo(JSONArray ticketDatas, Map<Integer, Map<String, Object>> updateTicketMap) throws SoftbankException {
		List<Map<String, Object>> issueDatas = Lists.newArrayList();
		for (int i = 0; i < ticketDatas.size(); i++) {
			Map<String, Object> data = Maps.newHashMap();
			Map<String, Object> reMap = Maps.newHashMap();
			JSONObject issuesData = ticketDatas.getJSONObject(i);
			int issueId = issuesData.getInt("id");
			data.put(IssueKey.ISSUE_ID.KEY, issueId);
			data.put(IssueKey.ROOT_ID.KEY, issuesData.getString(IssueKey.ROOT_ID.KEY));
			data.put(IssueKey.SUBJECT.KEY, issuesData.getString(IssueKey.SUBJECT.KEY));
			data.put(IssueKey.DONE_RATIO.KEY, issuesData.getInt(IssueKey.DONE_RATIO.KEY));
			data.put(IssueKey.LOCK_VERSION.KEY, issuesData.getInt(IssueKey.LOCK_VERSION.KEY));
			reMap.put(IssueKey.LOCK_VERSION.KEY, issuesData.getInt(IssueKey.LOCK_VERSION.KEY) + 1);
			updateTicketMap.put(issueId, reMap);
			issueDatas.add(data);
		}
		return updateIssueWithParent(issueDatas, true);
	}

	private void deletePersonData(IssuesPersonBean personBean, JSONObject personData) throws SoftbankException {
		if (personData.containsKey("id") && !personData.getString("id").startsWith("n")) {
			personBean.setId(personData.getInt("id"));
			issues.deleteIssuesPersonInfo(personBean);
			if (personBean.getTime_entries_id() != 0) {
				db.update("time_entries.deleteTimeEntriesById", personBean);
			}
		}
	}

	private void updatePersonData(IssuesPersonBean personBean, JSONObject personData)
			throws SoftbankException {
		int done_ratio = personData.getInt("done_ratio");
		personBean.setDue_date(personData.getString("due_date"));
		personBean.setDuring(personData.getDouble("during"));
		personBean.setEnd_time(personData.getString("end_time"));
		personBean.setStart_time(personData.getString("start_time"));
		personBean.setIssues_ratio(personData.getInt("issues_ratio"));
		personBean.setIssues_id(personData.getInt("issues_id"));
		personBean.setProject_id(personData.getInt("project_id"));
		if (personData.containsKey("activity_id") && !personData.isNullObject() && !"null".equals(personData.getString("activity_id"))) {
			personBean.setActivity_id(personData.getInt("activity_id"));
		} else {
			personBean.setActivity_id(StringUtils.toInt(ControlDbMemory.getInstance().getEnabledScmInfos().get(0).get("id")));
		}
		personBean.setAuthor_id(((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		if (personData.containsKey("description")) {
			personBean.setDescription(personData.getString("description"));
		}
		personBean.setDone_ratio(done_ratio);
		
		if (!personData.getString("id").startsWith("n")) {
			personBean.setId(personData.getInt("id"));
			if (personBean.getTime_entries_id() != 0) {
				if (done_ratio == 100) {
					db.update("time_entries.updateTimeEntriesById", personBean);
				} else {
					db.update("time_entries.deleteTimeEntriesById", personBean);
					personBean.setTime_entries_id(0);
					personBean.setUpdate(true);
				}
			} else {
				if (done_ratio == 100) {
					db.insert("time_entries.addTimeEntriesInfo", personBean);
					personBean.setUpdate(true);
				}
			}
			issues.updateIssuesPersonInfo(personBean);
		} else {
			if (done_ratio == 100) {
				db.insert("time_entries.addTimeEntriesInfo", personBean);
				personBean.setUpdate(true);
			}
			issues.insertIssuesPersonInfo(personBean);
		}
	}
	
	public void getHolidays() throws SoftbankException {
		context.getResultBean().setData(ControlDbMemory.getInstance().getHolidaysMap());
	}
	
	public void getTicketInfo() throws SoftbankException {
		String issueId = context.getParam().get("issueId");
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		List<Map<String, Object>> customFields = db.querys("issues.getCustomFieldsForIssues", conditions);
		conditions.put("customFields", customFields);
		resultMap.put("parentInfos", db.querys("issues.getTicketParentInfo", conditions));
		resultMap.put("issueInfo", db.query("issues.getTicketAllInfoByIdForPortal", conditions));
		resultMap.put("customFields", db.querys("issues.getCustomFieldsByIssueId", conditions));
		context.getResultBean().setData(resultMap);
	}
	
	private void calcWorkPassDay(IssuesBean issuesBean) throws SoftbankException {
		String startDateString = issuesBean.getStart_date();
		String endDateString = issuesBean.getDue_date();
		Date startDate = DateUtils.formatToDate(startDateString, DateUtils.FORMAT_YYYYMMDD_DASH);
		Date endDate = DateUtils.formatToDate(endDateString, DateUtils.FORMAT_YYYYMMDD_DASH);
		String todayString = DateUtils.getNow(DateUtils.FORMAT_YYYYMMDD_DASH);
		Date today = DateUtils.formatToDate(todayString, DateUtils.FORMAT_YYYYMMDD_DASH);
		int workDay = calcBetween(startDate, DateUtils.daysBetween(startDate, endDate));
		issuesBean.setWorkDay(workDay);
		int passDay = calcBetween(startDate, DateUtils.daysBetween(startDate, today) - 1);
		if (passDay < 0) {
			passDay = 0;
		}
		if (passDay > workDay) {
			passDay = workDay;
		}
		issuesBean.setPassDay(passDay);
	}
	
	private void createIssuesPersonInfo(IssuesBean issuesBean, Map<String, Float> startTimeMap) throws SoftbankException {
		String startDateString = issuesBean.getStart_date();
		Date startDate = DateUtils.formatToDate(startDateString, DateUtils.FORMAT_YYYYMMDD_DASH);
		String endDateString = issuesBean.getDue_date();
		Date endDate = DateUtils.formatToDate(endDateString, DateUtils.FORMAT_YYYYMMDD_DASH);
		int between = calcBetween(startDate, DateUtils.daysBetween(startDate, endDate));
		if (between <= 0) {
			return;
		}
		float hours = (float)issuesBean.getEstimated_hours();
		float perHours = (float)Math.ceil(hours / between);
		if (perHours <= 1) {
			perHours = 1;
		}
		between = DateUtils.daysBetween(startDate, endDate);
		List<IssuesPersonBean> addPersonInfos = Lists.newArrayList();
		for (int i = 0; i < between; i++) {
			if (hours <= 0) {
				break;
			}
			Date duringDate = DateUtils.calcDateForDate(startDate, i);
			String duringDateStr = DateUtils.makeFormat(duringDate, DateUtils.FORMAT_YYYYMMDD_DASH);
			if (hours < perHours) {
				perHours = hours;
			} else if (i == (between - 1)) {
				perHours = hours;
			}
			float startTime = 9;
			if (startTimeMap.containsKey(duringDateStr)) {
				startTime = startTimeMap.get(duringDateStr);
			}
			float endTime = startTime + perHours;
			float newEndTime = endTime;
			if (DateUtils.getWeek(duringDate) == 1 || DateUtils.getWeek(duringDate) == 7 || ControlDbMemory.getInstance().isHoliday(duringDate)) {
//				if (i == (between - 1)) {
//					perHours += addPersonInfos.get(addPersonInfos.size() - 1).getDuring();
//					endTime += addPersonInfos.get(addPersonInfos.size() - 1).getDuring();
//					addPersonInfos.get(addPersonInfos.size() - 1).setDuring(perHours);
//					addPersonInfos.get(addPersonInfos.size() - 1).setEnd_time(String.format("%02d", endTime) + ":00");
//				}
				continue;
			}
			do {
				boolean isMorning = false;
				boolean isOver = false;
				if (startTime < 12) {
					isMorning = true;
					if (endTime > 12) {
						newEndTime = 12;
					} else {
						newEndTime = endTime;
					}
				} else if (startTime >= 12) {
					if (startTime == 12) {
						startTime += 1;
						endTime += 1;
					}
					newEndTime = endTime;
					if (endTime > 22) {
						newEndTime = 22;
						isOver = true;
					}
				}
				addPersonBean(issuesBean, addPersonInfos, duringDateStr, startTime, newEndTime);
				startTime = newEndTime;
				if (isMorning) {
					startTime = 12;
				}
				if (isOver || startTime == 22) {
					startTime = 9;
					endTime = startTime + endTime - newEndTime;
				}
			} while (startTime < endTime);
			startTimeMap.put(duringDateStr, endTime);
			hours -= perHours;
		}
		Map<String, Object> conditionsMap = Maps.newHashMap();
		conditionsMap.put("infos", addPersonInfos);
		issues.insertIssuesPersonInfos(conditionsMap);
	}

	private void addPersonBean(IssuesBean issuesBean,
			List<IssuesPersonBean> addPersonInfos, String duringDateStr,
			float startTime, float newEndTime) throws SoftbankException {
		IssuesPersonBean personBean = createPersonBean(issuesBean, duringDateStr);
		int s_h = (int)startTime;
		int s_m = (int)((startTime - s_h) * 60);
		int e_h = (int)newEndTime;
		int e_m = (int)((newEndTime - e_h) * 60);
		personBean.setStart_time(String.format("%02d", s_h) + ":" + String.format("%02d", s_m));
		personBean.setEnd_time(String.format("%02d", e_h) + ":" + String.format("%02d", e_m));
		personBean.setDuring((newEndTime - startTime));
		addPersonInfos.add(personBean);
	}

	private IssuesPersonBean createPersonBean(IssuesBean issuesBean, String duringDateStr) throws SoftbankException {
		IssuesPersonBean personBean = new IssuesPersonBean();
		personBean.setIssues_id(issuesBean.getId());
		personBean.setAuthor_id(issuesBean.getAssigned_to_id());
		personBean.setDue_date(duringDateStr);
		return personBean;
	}

	private int calcBetween(Date starDate, int between) throws SoftbankException {
		int length = between;
		for (int i = 0; i < length; i++) {
			Date duringDate = DateUtils.calcDateForDate(starDate, i);
			if (DateUtils.getWeek(duringDate) == 1 || DateUtils.getWeek(duringDate) == 7 || ControlDbMemory.getInstance().isHoliday(duringDate)) {
				between--;
			}
		}
		return between;
	}

}
