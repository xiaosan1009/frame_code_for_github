package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.RoleListDao;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ForumNewLogic extends AbstractBaseLogic {
	
	//編集：表示
	public void getBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		conditions.put("id", context.getParam().get("id"));
		Map<String, Object> attachments = db.query("boards.getBoardsInfo", conditions);
		context.getResultBean().setData(attachments);
	}
	
	// 編集：作成
	public void saveBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		conditions.put("project_id", context.getParam().projectId);
		conditions.put("name", context.getParam().get("forum_name"));
		conditions.put("description", context.getParam().get("froum_description"));
		conditions.put("topics_count", 0);
		conditions.put("messages_count", 0);
		
		db.insert("boards.addBoardsInfo", conditions);	
	}
	
	// 編集：保存
	public void updateBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", context.getParam().get("boards_id"));
		conditions.put("name", context.getParam().get("forum_name"));
		conditions.put("description", context.getParam().get("froum_description"));
		
		db.update("boards.updateBoardsInfo", conditions);		
	}
	
	
}
