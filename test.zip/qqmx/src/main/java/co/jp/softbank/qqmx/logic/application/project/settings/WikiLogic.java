package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.ProjectWikiDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;

import com.google.common.collect.Maps;

public class WikiLogic extends AbstractBaseLogic {
	
	@Autowired
	private ProjectWikiDao projectWikiDao;
	
	public LogicBean getProjectWiki() throws SoftbankException {
		LogicBean wikiBean = new LogicBean();
		String projectIdString = context.getParam().get("proId");
		log.info("projectIdString = " + projectIdString);
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		wikiBean.setData(projectWikiDao.getProjectWikiInfo(conditions));
		return wikiBean;
	}
	
	public void saveProjectWiki() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		String projectIdString = context.getParam().get("proId");
		String start_page = context.getParam().get("start_page");
		String data_start_page = context.getParam().get("data_start_page");
		conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		conditions.put("start_page", start_page);
		
		if (data_start_page != ""){
			projectWikiDao.updateWikisInfos(conditions);
		}else{
			projectWikiDao.insertWikisInfos(conditions);
		}
	}
	
	public void deleteProjectWiki() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		String projectIdString = context.getParam().get("proId");
		conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		
		projectWikiDao.deleteWikisInfos(conditions);
	}

}
