package co.jp.softbank.qqmx.logic.application.mail;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.StringUtils;

public class MailRelease {

	 private static final String SMTP_HOST = "internal-smtp.bb.local";
	 private static final String SMTP_PORT = "25";
	 private static final String MAIL_FROM = "sbbgrp-qqmx@g.softbank.co.jp";
	 private static final String MAIL_TO = "gyougi.o@g.softbank.co.jp";
	 private static final String MAIL_CC = "";
	 private static final String MAIL_SUBJECT = "QQM-X v1.3.5リリースのご案内";
//	 private static final String MAIL_TEXT = "本文\n\r";
	 
	/**
	 * メール送信
	 * 
	 * @param args
	 * @throws IOException 
	 * @throws MessagingException 
	 * @throws AddressException 
	 */
	public static void main(String[] args) throws IOException {

		File dir = new File("/tmp/mail/mail_test.csv");
		byte[] b = new byte[(int) dir.length()];
		FileInputStream fi = new FileInputStream(dir);
		fi.read(b);
		String s = new String(b);
		s = s.replaceAll("\r", "");
		String[] strrec = s.split("\n");
		
		for (int i = 0; i<strrec.length; i++){
			mailPost(strrec[i]);
			try {
				Thread.currentThread().sleep(200);
				System.out.println("実行時間=" + new Date());
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
		fi.close();
	}
	
	public static void mailPost(String bcc) {
		
		Properties props = new Properties();
		props.setProperty("mail.debug", "true");  
		props.setProperty("mail.host", SMTP_HOST);
		props.setProperty("mail.transport.protocol", SMTP_PORT);
		
		Session session = Session.getInstance(props);
		Message msg = new MimeMessage(session);  

		try {
			msg.setSubject(MAIL_SUBJECT);  
			String mail_text = 
				"各位\n" +
				"\n" +
				"本日、QQM-X v1.3.5をリリース致しました。\n" +
				"V1.3.5は新ガントチャートにおける右クリックの対応メニュー及び、マイルストーン設定機能の２つの機能追加です。\n" +
				"\n" +
				"１．右クリック追加メニューは\n" +
				" ・編集メニューの表示・選択機能\n" +
				" ・複数行・複数セルのコピー及び、貼り付け機能\n" +
				" ・セルの文字色及び背景色の変更及び、保存機能\n" +
				"\n" +
				"２．マイルストーン設定機能にて、マイルストーンの登録・修正が可能です。\n" +
				"\n" +
				"不明点、不具合、要望などありましたら、下記URLのヘルプサイト新規FAQ登録よりお問い合わせください。\n" +
				"http://10.216.80.167/qqmx/qqmx.mx?dispCode=300013&cmdCode=0\n" +
				"\n" +
				"\n" +
				"今後ともQQM-Xをよろしくお願い致します。";
			msg.setText(mail_text);
			// FROM設定
			if (!StringUtils.isEmpty(MAIL_FROM)) {
				msg.setFrom(new InternetAddress(MAIL_FROM));
			}
			
			Transport transport = session.getTransport("smtp");
			transport.connect(SMTP_HOST, MAIL_FROM);
			transport.sendMessage(msg, new Address[] {new InternetAddress(bcc)});  
			transport.close();  
		} catch (MessagingException e) {
			// TODO 自動生成された catch ブロック
			System.out.println(e.getMessage());
			System.out.println(bcc);
			e.printStackTrace();
		}  
	}
	
}
