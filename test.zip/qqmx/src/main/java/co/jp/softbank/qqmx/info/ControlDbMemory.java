package co.jp.softbank.qqmx.info;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.dao.common.CommonDao;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.dao.common.bean.HolidaysBean;
import co.jp.softbank.qqmx.dao.common.bean.PluginInfoBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlSettingMap.SettingKey;
import co.jp.softbank.qqmx.info.bean.DbMemoryBean;
import co.jp.softbank.qqmx.info.bean.ProjectTicketInfoBean;
import co.jp.softbank.qqmx.info.bean.TuInfoBean;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.sockect.WebSocketClientManager;
import co.jp.softbank.qqmx.sockect.impl.AbstractSocketLogic;
import co.jp.softbank.qqmx.sockect.impl.AbstractSocketLogic.SocketMessageType;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ControlDbMemory {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	private static ControlDbMemory me;
	
	private DbMemoryBean dbMemoryBean;
	
	private static CommonDao commonDao;
	
	private static IDbExecute db;
	
	private TuInfoBean tuInfoBean;
	
	private ControlDbMemory() throws SoftbankException {
		super();
		dbMemoryBean = new DbMemoryBean();
		dbMemoryBean.setHolidaysBeans(commonDao.selectHolidaysInfo());
		dbMemoryBean.setPluginInfoBeans(commonDao.selectPluginInfo());
		dbMemoryBean.setRolesBaseBeans(commonDao.selectAllRolesBaseInfo());
		dbMemoryBean.setEnabledScmInfos(commonDao.getEnabledScmInfos());
	}
	
	public static ControlDbMemory getInstance() throws SoftbankException {
		synchronized (ControlRequestMap.class) {
			if (me == null) {
				me = new ControlDbMemory();
			}
		}
		return me;
	}
	
	public List<HolidaysBean> getHolidaysBeans() {
		return dbMemoryBean.getHolidaysBeans();
	}
	
	public Map<String, HolidaysBean> getHolidaysMap() {
		return dbMemoryBean.getHolidaysMap();
	}
	
	public List<Map<String, Object>> getEnabledScmInfos() {
		return dbMemoryBean.getEnabledScmInfos();
	}
	
	public List<PluginInfoBean> getPluginInfoBeans() {
		return dbMemoryBean.getPluginInfoBeans();
	}
	
	public boolean isHoliday(Date date) {
		return dbMemoryBean.isHoliday(date);
	}
	
	public boolean isHoliday(String date) {
		return dbMemoryBean.isHoliday(date);
	}
	
	public long getRootToken(int rootId) {
		return dbMemoryBean.getRootToken(rootId);
	}
	
	public void setRootToken(int rootId, long token) {
		dbMemoryBean.setRootToken(rootId, token);
	}
	
	public ProjectTicketInfoBean getProjectTicketInfosForWatchable(int projectId) throws SoftbankException {
		ProjectTicketInfoBean ticketInfoBean = new ProjectTicketInfoBean();
		List<Map<String, Object>> result = Lists.newArrayList();
		
		if (dbMemoryBean.getTicketsWatchableMap().containsKey(projectId)) {
			result = dbMemoryBean.getTicketsWatchableMap().get(projectId);
			ticketInfoBean.setDatas(result);
			for (int i = 0; i < result.size(); i++) {
				Map<String, Object> data = result.get(i);
				// 最小開始日設定
				ticketInfoBean.setMinStartDate(StringUtils.toString(data.get(IssueKey.START_DATE.KEY_JSON)));
				// 最大期日設定
				ticketInfoBean.setMaxEndDate(StringUtils.toString(data.get(IssueKey.DUE_DATE.KEY_JSON)));
			}
			return ticketInfoBean;
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> projectInfos = db.querysC("ticketList.getProjectInfos", conditions);
		if (projectInfos == null || projectInfos.size() == 0) {
			return ticketInfoBean;
		}
		String rootId = getProjectId(projectInfos.get(0).get("id"));
		if (projectInfos.size() == 1) {
			result = getProjectInfoForWatchable(projectInfos.get(0), rootId, ticketInfoBean);
		} else {
			for (int i = 0; i < projectInfos.size(); i++) {
				Map<String, Object> projectInfo = projectInfos.get(i);
				List<Map<String, Object>> datas = getProjectInfoForWatchable(projectInfo, rootId, ticketInfoBean);
				if (datas != null) {
					result.addAll(datas);
				}
			}
		}
		dbMemoryBean.getTicketsWatchableMap().put(projectId, result);
		dbMemoryBean.getTimestampWatchableMap().put(projectId, new Date());
		ticketInfoBean.setDatas(result);
		return ticketInfoBean;
	}
	
	public List<Map<String, Object>> getCustomListMap(int projectId) throws SoftbankException {
		if (dbMemoryBean.getCustomListMap().containsKey(projectId)) {
			return dbMemoryBean.getCustomListMap().get(projectId);
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> customList = db.querysC("custom_fields.getCustomFieldsForCheck", conditions);
		dbMemoryBean.getCustomListMap().put(projectId, customList);
		return customList;
	}
	
	public Map<Integer, Integer> getCustomFieldTrackerMap(int trackerId) throws SoftbankException {
		if (dbMemoryBean.getCustomFieldTrackerMap().containsKey(trackerId)) {
			return dbMemoryBean.getCustomFieldTrackerMap().get(trackerId);
		}
		
		List<Map<String, Object>> customList = db.querysC("custom_fields.getCustomFieldsByTracker");
		for (int i = 0; i < customList.size(); i++) {
			int tracker_id = StringUtils.toInt(customList.get(i).get("tracker_id"));
			int custom_field_id = StringUtils.toInt(customList.get(i).get("custom_field_id"));
			if (!dbMemoryBean.getCustomFieldTrackerMap().containsKey(tracker_id)) {
				Map<Integer, Integer> mapping = Maps.newHashMap();
				dbMemoryBean.getCustomFieldTrackerMap().put(tracker_id, mapping);
			}
			dbMemoryBean.getCustomFieldTrackerMap().get(tracker_id).put(custom_field_id, custom_field_id);
		}
		return dbMemoryBean.getCustomFieldTrackerMap().get(trackerId);
	}
	
	public ProjectTicketInfoBean getProjectTicketInfos(int projectId) throws SoftbankException {
		ProjectTicketInfoBean ticketInfoBean = new ProjectTicketInfoBean();
		List<Map<String, Object>> result = Lists.newArrayList();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> projectInfos = db.querysC("ticketList.getProjectInfos", conditions);
		if (projectInfos == null || projectInfos.size() == 0) {
			return ticketInfoBean;
		}
		ticketInfoBean.setProjectList(projectInfos);
		Map<String, Object> projectMap = projectInfos.get(0);
		String rootId = getProjectId(projectMap.get("id"));
		if (projectInfos.size() == 1) {
			if (StringUtils.isNotEmpty(projectMap.get("parent_id"))) {
				conditions.put("project_id", projectMap.get("parent_id"));
				Map<String, Object> parentProjectInfo = db.queryC("projects.getProjectInfo", conditions);
				parentProjectInfo.put("floorId", getProjectId(projectMap.get("parent_id")));
				rootId = getProjectId(projectMap.get("parent_id"));
				setProjectInfo(parentProjectInfo, rootId);
				result.add(parentProjectInfo);
				projectMap.put("floorId", getProjectId(projectMap.get("parent_id")) + " " + projectMap.get("floorId"));
			}
			result.addAll(getProjectInfo(projectMap, rootId, ticketInfoBean));
			ticketInfoBean.setDatas(result);
			return ticketInfoBean;
		} else {
			for (int i = 0; i < projectInfos.size(); i++) {
				Map<String, Object> projectInfo = projectInfos.get(i);
				result.addAll(getProjectInfo(projectInfo, rootId, ticketInfoBean));
			}
		}
		ticketInfoBean.setDatas(result);
		return ticketInfoBean;
	}
	
	public List<Map<String, Object>> getProjectInfo(Map<String, Object> projectInfo, String rootId, ProjectTicketInfoBean projectTicketInfoBean) throws SoftbankException {
		List<Map<String, Object>> result = Lists.newArrayList();
		setProjectInfo(projectInfo, rootId);
		result.add(projectInfo);
		ProjectTicketInfoBean ticketInfoBean = getTickets(projectInfo);
		result.addAll(ticketInfoBean.getDatas());
		projectTicketInfoBean.setMinStartDate(ticketInfoBean.getMinStartDate());
		projectTicketInfoBean.setMaxEndDate(ticketInfoBean.getMaxEndDate());
		projectTicketInfoBean.createIssueMapping(ticketInfoBean);
		return result;
	}
	
	public void setProjectInfo(Map<String, Object> projectInfo, String rootId) {
		projectInfo.put(IssueKey.PROCESS.ISPROJECT, true);
		projectInfo.put(IssueKey.ISSUE_ID.KEY_JSON, getProjectId(projectInfo.get("id")));
		projectInfo.put(IssueKey.TREE_ID.KEY_JSON, projectInfo.get("floorId"));
		projectInfo.put(IssueKey.ROOT_ID.KEY_JSON, rootId);
	}
	
	public List<Map<String, Object>> getProjectInfoForWatchable(Map<String, Object> projectInfo, String rootId, ProjectTicketInfoBean ticketInfoBean) throws SoftbankException {
		List<Map<String, Object>> result = Lists.newArrayList();
		String tid = getProjectId(projectInfo.get("id"));
		projectInfo.put(IssueKey.PROCESS.ISPROJECT, true);
		projectInfo.put(IssueKey.ISSUE_ID.KEY_JSON, tid);
		projectInfo.put(IssueKey.TREE_ID.KEY_JSON, projectInfo.get("floorId"));
		projectInfo.put(IssueKey.ROOT_ID.KEY_JSON, rootId);
		List<Map<String, Object>> datas = getTicketsForWatchable(projectInfo, ticketInfoBean);
		if (datas == null || datas.size() == 0) {
			if (rootId.equals(tid)) {
				result.add(projectInfo);
			}
			return result;
		}
		result.add(projectInfo);
		result.addAll(datas);
		return result;
	}
	
	public ProjectTicketInfoBean getTickets(Map<String, Object> projectInfo) throws SoftbankException {
		int projectId = StringUtils.toInt(projectInfo.get("id"));
		log.info("getTickets start! projectId = {}", projectId);
		if (dbMemoryBean.getTicketsMap().containsKey(projectId)) {
			return dbMemoryBean.getTicketsMap().get(projectId);
		}
		dbMemoryBean.getTimestampMap().put(projectId, new Date());
		ProjectTicketInfoBean ticketInfoBean = new ProjectTicketInfoBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> customFields = db.querysC("issues.getCustomFieldsForIssues", conditions);
		conditions.put("customFields", customFields);
		List<Map<String, Object>> datas = db.querysC("issues.getTickets", conditions);
		ticketInfoBean.setDatas(datas);
		anilizeTicketDatas(ticketInfoBean, projectInfo);
		dbMemoryBean.getTicketsMap().put(projectId, ticketInfoBean);
		log.info("getTickets end!");
		return ticketInfoBean;
	}
	
	public void refreshProjects(int projectId, int userId) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> projectInfos = db.querysC("ticketList.getProjectInfos", conditions);
		if (projectInfos == null || projectInfos.size() == 0) {
			return;
		}
		
		String rootId = getProjectId(projectInfos.get(0).get("id"));
//		if (projectInfos.size() == 1) {
//		}
		Map<String, Object> projectInfo = projectInfos.get(0);
		String floorId = getProjectId(projectId);
		if (StringUtils.isNotEmpty(projectInfo.get("parent_id"))) {
			String parentRootId = getProjectId(StringUtils.toInt(projectInfo.get("parent_id")));
			floorId = parentRootId + " " + floorId;
			rootId = parentRootId;
			projectInfo.put("floorId", floorId);
		}
		setProjectInfo(projectInfo, rootId);
		refreshTickets(projectInfo, -1);
//		else {
//			for (int i = 0; i < projectInfos.size(); i++) {
//				Map<String, Object> projectInfo = projectInfos.get(i);
//				setProjectInfo(projectInfo, rootId);
//				refreshTickets(projectInfo, -1);
//			}
//		}
		if (userId > 0 ) {
			WebSocketClientManager.getInstance().sendAll((new AbstractSocketLogic()).getResultData(SocketMessageType.ISSUES_DATA_REFRESH, projectId), userId);
		} else if (userId != -1) {
			WebSocketClientManager.getInstance().sendAll((new AbstractSocketLogic()).getResultData(SocketMessageType.ISSUES_DATA_REFRESH, projectId));
		}
	}
	
	public void refreshAllTicketsForParentProject(int projectId) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> projectInfos = db.querysC("ticketList.getProjectInfos", conditions);
		for (int i = 0; i < projectInfos.size(); i++) {
			Map<String, Object> projectInfo = projectInfos.get(i);
			refreshTickets(StringUtils.toInt(projectInfo.get("id")));
		}
	}
	
	public void refreshTickets(int projectId) throws SoftbankException {
		refreshTickets(projectId, 0);
	}
	
	private void refreshTickets(int projectId, int userId) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		Map<String, Object> projectInfo = db.queryC("projects.getProjectInfo", conditions);
		String floorId = getProjectId(projectId);
		String rootId = getProjectId(projectId);
		if (StringUtils.isNotEmpty(projectInfo.get("parent_id"))) {
			String parentRootId = getProjectId(StringUtils.toInt(projectInfo.get("parent_id")));
			floorId = parentRootId + " " + floorId;
			rootId = parentRootId;
		}
		projectInfo.put("floorId", floorId);
		setProjectInfo(projectInfo, rootId);
		refreshTickets(projectInfo, userId);
	}
	
	public void refreshTickets(Map<String, Object> projectInfo) throws SoftbankException {
		refreshTickets(projectInfo, 0);
	}
	
	public void refreshTickets(Map<String, Object> projectInfo, int userId) throws SoftbankException {
		log.debug("refreshTickets start!");
		int projectId = StringUtils.toInt(projectInfo.get("id"));
		log.debug("projectId = {}", projectId);
		ProjectTicketInfoBean ticketInfoBean = new ProjectTicketInfoBean();
		dbMemoryBean.getTimestampMap().put(projectId, new Date());
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> customFields = db.querysC("issues.getCustomFieldsForIssues", conditions);
		conditions.put("customFields", customFields);
		List<Map<String, Object>> datas = db.querysC("issues.getTickets", conditions);
		ticketInfoBean.setDatas(datas);
		anilizeTicketDatas(ticketInfoBean, projectInfo);
		dbMemoryBean.getTicketsMap().put(projectId, ticketInfoBean);
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.USE_WEBSOCKET)) {
			if (userId > 0 ) {
				WebSocketClientManager.getInstance().sendAll((new AbstractSocketLogic()).getResultData(SocketMessageType.ISSUES_DATA_REFRESH, projectId), userId);
			} else if (userId != -1) {
				WebSocketClientManager.getInstance().sendAll((new AbstractSocketLogic()).getResultData(SocketMessageType.ISSUES_DATA_REFRESH, projectId));
			}
		}
		log.debug("refreshTickets end!");
	}
	
	public void refreshTicketsForWatchable(int projectId) throws SoftbankException {
		log.info("projectId = {}", projectId);
		dbMemoryBean.getTimestampWatchableMap().put(projectId, new Date());
		List<Map<String, Object>> result = Lists.newArrayList();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> projectInfos = db.querysC("ticketList.getProjectInfos", conditions);
		if (projectInfos == null || projectInfos.size() == 0) {
			return;
		}
		ProjectTicketInfoBean ticketInfoBean = new ProjectTicketInfoBean();
		String rootId = getProjectId(projectInfos.get(0).get("id"));
		if (projectInfos.size() == 1) {
			result = getProjectInfoForWatchable(projectInfos.get(0), rootId, ticketInfoBean);
		} else {
			for (int i = 0; i < projectInfos.size(); i++) {
				Map<String, Object> projectInfo = projectInfos.get(i);
				List<Map<String, Object>> datas = getProjectInfoForWatchable(projectInfo, rootId, ticketInfoBean);
				if (datas != null) {
					result.addAll(datas);
				}
			}
		}
		dbMemoryBean.getTicketsWatchableMap().put(projectId, result);
	}
	
	public List<Map<String, Object>> getTicketsForWatchable(Map<String, Object> projectInfo, ProjectTicketInfoBean projectTicketInfoBean) throws SoftbankException {
		int projectId = StringUtils.toInt(projectInfo.get("id"));
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		ProjectTicketInfoBean ticketInfoBean = new ProjectTicketInfoBean();
		List<Map<String, Object>> datas = db.querysC("issues.getWatchableTickets", conditions);
		ticketInfoBean.setDatas(datas);
		anilizeTicketDatas(ticketInfoBean, projectInfo);
		projectTicketInfoBean.setMinStartDate(ticketInfoBean.getMinStartDate());
		projectTicketInfoBean.setMaxEndDate(ticketInfoBean.getMaxEndDate());
		return ticketInfoBean.getDatas();
	}
	
	private Map<Integer, Integer> getNotFinishedMap(Map<String, Object> projectInfo) throws SoftbankException {
		Map<Integer, Integer> result = Maps.newHashMap();
		
		int projectId = StringUtils.toInt(projectInfo.get("id"));
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> datas = db.querysC("issues.selectNotFinishedIssue", conditions);
		for (int i = 0; i < datas.size(); i++) {
			Map<String, Object> data = datas.get(i);
			if (StringUtils.toInt(data.get("isp")) != 0) {
				continue;
			}
			String parentId = StringUtils.toString(data.get("parentId"));
			String[] pds = parentId.split(" ");
			for (int j = 0; j < pds.length; j++) {
				int pid = Integer.parseInt(pds[j]);
				if (result.containsKey(pid)) {
					result.put(pid, result.get(pid) + 1);
				} else {
					result.put(pid, 1);
				}
			}
		}
		return result;
	}
	
	public void anilizeTicketDatas(ProjectTicketInfoBean ticketInfoBean, Map<String, Object> projectInfo) throws SoftbankException {
		//　完了ないチケットMap
		Map<Integer, Integer> notFinishedMap = getNotFinishedMap(projectInfo);
		//　完了ないチケットMap
		Map<Integer, String> floorIdMap = Maps.newHashMap();
		//　前のバージョンID
		String prevVersionId = "";
		//　階層ID
		String floorId = StringUtils.toString(projectInfo.get("floorId"));
		//　チケットデータ
		List<Map<String, Object>> datas = ticketInfoBean.getDatas();
		for (int i = 0; i < datas.size(); i++) {
			Map<String, Object> data = datas.get(i);
			// チケットID
			int issuesId = StringUtils.toInt(data.get(IssueKey.ISSUE_ID.KEY_JSON));
			int parentId = StringUtils.toInt(data.get(IssueKey.PARENT_ID.KEY_JSON));
			// バージョンID
			String versionID = StringUtils.toString(data.get(IssueKey.FIXED_VERSION_ID.KEY_JSON));
			// 最小開始日設定
			ticketInfoBean.setMinStartDate(StringUtils.toString(data.get(IssueKey.START_DATE.KEY_JSON)));
			// 最大期日設定
			ticketInfoBean.setMaxEndDate(StringUtils.toString(data.get(IssueKey.DUE_DATE.KEY_JSON)));
			
			if (StringUtils.isNotEmpty(versionID) && !prevVersionId.equals(versionID)) {
				//　新しいバージョン
				prevVersionId = versionID;
				//　創建バージョン情報
				Map<String, Object> versionMap = Maps.newHashMap();
				String newVersionId = getVersionId(StringUtils.toString(projectInfo.get("floorId")).replaceAll(" ", ""), prevVersionId);
				floorId = StringUtils.toString(projectInfo.get("floorId")) + " " + newVersionId;
				versionMap.put(IssueKey.PROCESS.ISVERSION, true);
				versionMap.put(IssueKey.ISSUE_ID.KEY_JSON, newVersionId);
				versionMap.put(IssueKey.TREE_ID.KEY_JSON, floorId);
				versionMap.put(IssueKey.ROOT_ID.KEY_JSON, projectInfo.get("rootId"));
				versionMap.put("name", data.get(IssueKey.FIXED_VERSION_NAME.KEY_JSON));
				datas.add(i++, versionMap);
			}
			if (i != datas.size() - 1) {
				int nextParentId = StringUtils.toInt(datas.get(i + 1).get(IssueKey.PARENT_ID.KEY_JSON));
				if (issuesId == nextParentId) {
					data.put(IssueKey.PROCESS.ISPARENT, true);
				}
			}
			
			createParentId(floorIdMap, data, issuesId, parentId);
			
			data.put(IssueKey.TREE_ID.KEY_JSON, (floorId + " " + StringUtils.toString(data.get("t0_parent_id"))));
			data.put(IssueKey.ROOT_ID.KEY_JSON, projectInfo.get("rootId"));
			int delayCount = 0;
			if (notFinishedMap.containsKey(issuesId)) {
				delayCount = notFinishedMap.get(issuesId);
			}
			data.put("delayCount", delayCount);
			data.put("project", projectInfo.get("name"));
		}
	}

	private void createParentId(Map<Integer, String> floorIdMap, Map<String, Object> data, int issuesId, int parentId) {
		if (!data.containsKey("t0_parent_id")) {
			String parentFloorId = StringUtils.toString(issuesId);
			if (floorIdMap.containsKey(parentId)) {
				parentFloorId = floorIdMap.get(parentId) + " " + parentFloorId;
			}
			data.put("t0_parent_id", parentFloorId);
			floorIdMap.put(issuesId, parentFloorId);
			if (!data.containsKey(IssueKey.FLOOR.KEY_JSON)) {
				data.put(IssueKey.FLOOR.KEY_JSON, parentFloorId.split(" ").length - 1);
			}
		}
	}
	
	public String getProjectId(Object id) {
		return "p" + id;
	}
	
	private String getVersionId(Object parentId, Object id) {
		return parentId + "_v" + id;
	}
	
	public Map<Integer, Date> getTimestampMap() {
		return dbMemoryBean.getTimestampMap();
	}
	
	public Map<Integer, Date> getTimestampWatchableMap() {
		return dbMemoryBean.getTimestampWatchableMap();
	}

	public static void setCommonDao(CommonDao commonDao) {
		ControlDbMemory.commonDao = commonDao;
	}
	
	public static void setDb(IDbExecute db) {
		ControlDbMemory.db = db;
	}

	public TuInfoBean getTuInfoBean() {
		return tuInfoBean;
	}

	public void setTuInfoBean(TuInfoBean tuInfoBean) {
		this.tuInfoBean = tuInfoBean;
	}
	
	public String getTuNewDate() {
		if (tuInfoBean == null) {
			return null;
		}
		return tuInfoBean.getNewDate();
	}
	
	public void setTuNewDate(String newDate) {
		if (tuInfoBean == null) {
			tuInfoBean = new TuInfoBean();
		}
		tuInfoBean.setNewDate(newDate);
	}

}
