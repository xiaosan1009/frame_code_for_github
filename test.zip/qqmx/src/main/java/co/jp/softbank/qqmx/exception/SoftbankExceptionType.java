package co.jp.softbank.qqmx.exception;

public enum SoftbankExceptionType {
	
	IOException("E100001", "サーバー異常"),
	
	CloneNotSupportedException("E100002", "サーバー異常"),
	
	NoSuchMethodException("E100003", "サーバー異常"),
	
	SecurityException("E100004", "サーバー異常"),
	
	IllegalAccessException("E100005", "サーバー異常"),
	
	IllegalArgumentException("E100006", "サーバー異常"),
	
	InvocationTargetException("E100007", "データの取得に失敗しました。"),
	
	SessionTimeout("E100008", "サーバー異常"),
	
	InputError("E100009", "入力内容に誤りがありますので、変更内容が保存されませんでした。"),
	
	FileNotFoundException("E100010", "サーバー異常"),
	
	UnsupportedEncodingException("E100011", "サーバー異常"),
	
	SQLException("E100012", "DB異常"),
	
	NoHttpResponseException("E100013", "ログインサーバーエラー"),
	
	RequestParamterError("E100014", "サーバー異常"),
	
	InputCheckError("E100015", "検証異常"),
	
	TaskHasNoInputType("E100016", "The task has no input type!"),
	
	ScriptException("E100017", "サーバー異常"),
	
	NumberFormatException("E100018", "サーバー異常"),
	
	InvalidFormatException("E100019", "サーバー異常"),
	
	InvalidOperationException("E100020", "サーバー異常"),
	
	SAXException("E100021", "サーバー異常"),
	
	OpenXML4JException("E100022", "サーバー異常"),
	
	ParserConfigurationException("E100023", "サーバー異常"),
	
	RolesException("E100024", "このページにアクセスするには認証が必要です。"),
	
	SystemException("E100000", "サーバー異常");
	
	private String errCode;
	
	private String errMsg;
	
	private SoftbankExceptionType(String errCode, String errMsg) {
		this.errCode = errCode;
		this.errMsg = errMsg;
	}

	public String getErrCode() {
		return errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

}
