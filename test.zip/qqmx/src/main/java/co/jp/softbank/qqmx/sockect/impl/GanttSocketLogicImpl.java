
package co.jp.softbank.qqmx.sockect.impl;

import net.sf.json.JSONObject;

import org.springframework.web.socket.WebSocketSession;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.sockect.WebSocketClientManager;
import co.jp.softbank.qqmx.sockect.bean.WebSocketClientInfo;
import co.jp.softbank.qqmx.sockect.face.IWebSocketLogic;

public class GanttSocketLogicImpl extends AbstractSocketLogic implements IWebSocketLogic {

    @Override
    public void recieve(WebSocketClientInfo clientInfo, JSONObject message) throws SoftbankException {
        String type = message.getString("type");
        if (SocketMessageType.GANTT_SHOW.equals(type)) {
        	WebSocketClientManager.getInstance().addGanttUserInfoMap(message);
        	WebSocketClientManager.getInstance().sendAll(message.toString());
        } else if (SocketMessageType.GANTT_OPERATOR.equals(type)) {
        	WebSocketClientManager.getInstance().addGanttMoveInfoMap(message);
        	WebSocketClientManager.getInstance().sendAll(message.toString());
		}
    }

    @Override
    public void connect(WebSocketClientInfo clientInfo) throws SoftbankException {
        executeUserMessage(clientInfo);
    }
    
    private void executeUserMessage(WebSocketClientInfo clientInfo) throws SoftbankException {
        WebSocketClientManager.getInstance().send(clientInfo.getSession(),
                getResultData(SocketMessageType.USER_CONNECT, WebSocketClientManager.getInstance().getGanttUserInfos()));
    }

    private void sendAllConnUserToActive(WebSocketSession session) throws SoftbankException {
        WebSocketClientManager.getInstance().sendAll("");

    }

    @Override
    public void closed(WebSocketClientInfo clientInfo) throws SoftbankException {
    	UserInfoData userInfoData = clientInfo.getUserInfoData();
    	WebSocketClientManager.getInstance().removeGanttUserAllInfoMap(userInfoData);
    	WebSocketClientManager.getInstance().removeGanttMoveInfoMap(userInfoData);
    	WebSocketClientManager.getInstance().sendAll(getResultData(SocketMessageType.USER_CLOSED, userInfoData.toJson()));
    }

}
