package co.jp.softbank.qqmx.logic;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.fileupload.FileItem;
import org.slf4j.Logger;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.SqlHelper;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.exception.SoftbankInputResult;
import co.jp.softbank.qqmx.exception.bean.InputErrorBean;
import co.jp.softbank.qqmx.handle.face.ITaskScriptFace;
import co.jp.softbank.qqmx.handle.face.IScriptUtilFace;
import co.jp.softbank.qqmx.info.ControlRequestMap;
import co.jp.softbank.qqmx.info.bean.DbRequestData;
import co.jp.softbank.qqmx.info.bean.DbRequestData.DbRequestDataType;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.logic.bean.UploadFileInfo;
import co.jp.softbank.qqmx.message.IMessageAccessor;
import co.jp.softbank.qqmx.server.ExternalHttpServer;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;
import co.jp.softbank.qqmx.validator.IBeanValidator;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public abstract class AbstractBaseLogic {
	
	private static final long UPLOAD_IMAGE_FILE_MAX_SIZE = 100000000;
	
	protected HttpContext context;
	
	protected ExternalHttpServer externalHttpServer;
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	protected IBeanValidator validator;
	
	protected IMessageAccessor messageAccessor;
	
	protected Map<String, String> extMap;
	
	protected IDbExecute db;
	
	protected IScriptUtilFace scriptUtil;
	
	public interface UploadFileName {
		String getFileName(String fileName, String newFileName);
	}
	
	protected interface UploadType {
		String image = "image";
		String flash = "flash";
		String media = "media";
		String file = "file";
		String all = "all";
		String csv = "csv";
		String excel = "excel";
	}
	
	public void applicationInit(HttpContext context) throws SoftbankException {
		this.context = context;
		externalHttpServer = new ExternalHttpServer(context);
		this.db.setContext(context);
		if (scriptUtil != null) {
			scriptUtil.setHandlerMethod(context);
		}
		initExtMap();
		
		paramInit();
	}
	
	protected void paramInit() {
		
	}

	private void initExtMap() {
		extMap = Maps.newHashMap();
		extMap.put(UploadType.image, "gif,jpg,jpeg,png,bmp");
		extMap.put(UploadType.flash, "swf,flv");
		extMap.put(UploadType.media, "swf,flv,mp3,wav,wma,wmv,mid,avi,mpg,asf,rm,rmvb");
		extMap.put(UploadType.file, "doc,docx,xls,xlsx,ppt,htm,html,txt,zip,rar,gz,bz2");
		extMap.put(UploadType.csv, "csv");
		extMap.put(UploadType.excel, "xls, xlsx");
		extMap.put(UploadType.all, "*");
	}
	
	public void doValidate() throws SoftbankException {
		if (validator == null || !ControlRequestMap.getInstance().isCheck(context.getParam())) {
			return;
		}
		List<InputErrorBean> errorInfos = doValidatep(null);
		
		if (errorInfos.size() > 0) {
			throw new SoftbankException(SoftbankExceptionType.InputError, errorInfos);
		}
		
	}
	
	public void doValidate(Map<String, Object> param) throws SoftbankException {
		if (validator == null) {
			return;
		}
		List<InputErrorBean> errorInfos = doValidatep(param);
		
		if (errorInfos.size() > 0) {
			throw new SoftbankException(SoftbankExceptionType.InputError, errorInfos);
		}
		
	}
	
	public void doValidateMap(List<Map<String, Object>> params) throws SoftbankException {
		if (validator == null) {
			return;
		}
		Map<String, List<InputErrorBean>> results = Maps.newHashMap();
		for (int i = 0; i < params.size(); i++) {
			Map<String, Object> param = params.get(i);
			List<InputErrorBean> errorInfos = doValidatep(param);
			String issueId = StringUtils.toString(param.get(IssueKey.ISSUE_ID.KEY));
			if (errorInfos.size() > 0) {
				results.put(issueId, errorInfos);
			}
		}
		
		if (results.size() > 0) {
			throw new SoftbankException(SoftbankExceptionType.InputError, results);
		}
		
	}

	private List<InputErrorBean> doValidatep(Map<String, Object> param) throws SoftbankException {
		List<InputErrorBean> errorInfos = Lists.newArrayList();
		try {
			Errors errors = validate(param);
			if (errors.hasErrors()) {
				List<ObjectError> errorList = errors.getAllErrors();
				for (int i = 0; i < errorList.size(); i++) {
					InputErrorBean errorBean = new InputErrorBean();
					FieldError error = (FieldError)errorList.get(i);
					log.info(error.getObjectName());
					log.info(messageAccessor.getMessage(error.getCode(), error.getArguments(), context));
					log.info(error.getDefaultMessage());
					log.info(error.getField());
					errorBean.setTargetId(error.getField());
					errorBean.setMessage(messageAccessor.getMessage(error.getCode(), error.getArguments(), context));
					
					errorInfos.add(errorBean);
				}
			}
			
			doValidate(errorInfos);
		} catch (Exception e) {
			throw new SoftbankException(SoftbankExceptionType.InputCheckError, e);
		}
		return errorInfos;
	}
	
	public void init() throws SoftbankException {
		
	}
	
	public void doValidate(List<InputErrorBean> errorInfos) throws SoftbankException {
		
	}
	
	public void execute() throws SoftbankException {
		List<DbRequestData> dbExecuteList = ControlRequestMap.getInstance().getDbExecuteList(context.getParam());
		if (context.isEngineTest()) {
			log.info("dbExecuteList.size = {}", dbExecuteList.size());
		}
		if (dbExecuteList != null && dbExecuteList.size() > 0) {
			Map<String, Object> responseMap = Maps.newHashMap();
			for (int i = 0; i < dbExecuteList.size(); i++) {
				DbRequestData dbe = dbExecuteList.get(i);
				if (context.isEngineTest()) {
					log.info("dbe.getKey = {}, dbe.getSql = {}", dbe.getKey(), dbe.getSql());
				}
				if (StringUtils.isNotEmpty(dbe.getSql())) {
					switch (dbe.getType()) {
					case item:
						Map<String, Object> data = db.query(dbe.getSql(), context.getParam().getParamerterMap());
						if (StringUtils.isNotEmpty(dbe.getKey())) {
							responseMap.put(dbe.getKey(), data);
						} else {
							context.getResultBean().setData(data);
							return;
						}
						break;
					case list:
						List<Map<String, Object>> datas = db.querys(dbe.getSql(), context.getParam().getParamerterMap());
						if (StringUtils.isNotEmpty(dbe.getKey())) {
							responseMap.put(dbe.getKey(), datas);
						} else {
							context.getResultBean().setData(datas);
							return;
						}
						break;
					case insert:
						db.insert(dbe.getSql(), context.getParam().getParamerterMap());
						break;
					case update:
						db.update(dbe.getSql(), context.getParam().getParamerterMap());
						break;
					case delete:
						db.delete(dbe.getSql(), context.getParam().getParamerterMap());
						break;

					default:
						break;
					}
				}
			}
			context.getResultBean().setData(responseMap);
		}
	}

	public void setValidator(IBeanValidator validator) {
		this.validator = validator;
	}

	public void setMessageAccessor(IMessageAccessor messageAccessor) {
		this.messageAccessor = messageAccessor;
	}
	
	protected String getMessage(String code) {
		return messageAccessor.getMessage(code, null, context);
	}
	
	protected String getMessage(String code, Object[] args) {
		return messageAccessor.getMessage(code, args, context);
	}

	protected Errors validate() {
        return validate(null);
    }
	
	protected Errors validate(Map<String, Object> param) {
		Errors errors = new BindException(new SoftbankInputResult(context));
		validator.setDao(db);
		if (param == null) {
			validator.validate(context, errors);
		} else {
			validator.validate(context, param, errors);
		}
		
		return errors;
	}
	
	protected IDaoInterface getDao() {
		return null;
	}
	
	protected UploadFileInfo doUpload(FileItem item, String filePath, String fileType) {
		return doUpload(item, filePath, fileType, null);
	}
	
	protected UploadFileInfo doUpload(FileItem item, String filePath, String fileType, UploadFileName uploadFileName) {
		UploadFileInfo fileInfo = new UploadFileInfo();
		String fileName = item.getName();
		log.debug("fileName = " + fileName);
		if (StringUtils.isEmpty(fileName)) {
			return null;
		}
		String uploadPath = context.getContext().getRealPath(File.separator) + ConstantsUtil.Frame.UPLOAD_PATH + filePath;
		log.debug("uploadPath = " + uploadPath);
		if(item.getSize() > UPLOAD_IMAGE_FILE_MAX_SIZE){
			return null;
		}
		
		String fileExt = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
		log.debug("fileExt = " + fileExt);
		if (!Arrays.<String> asList(extMap.get(fileType).split(",")).contains(fileExt) && !UploadType.all.equals(fileType)) {
			return null;
		}
		
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		String newFileName = df.format(new Date()) + "_" + new Random().nextInt(1000);
		if (uploadFileName != null) {
			newFileName = uploadFileName.getFileName(fileName, newFileName);
		}
		newFileName += ConstantsUtil.Str.DOT + fileExt;
		String requestUrl = context.getRequest().getRequestURL().toString();
		requestUrl = requestUrl.substring(0, requestUrl.lastIndexOf("/") + 1);
		String urlPath = requestUrl + ConstantsUtil.Frame.UPLOAD_PATH + filePath + newFileName;
		log.debug("urlPath = " + urlPath);
		try {
			File dir = new File(uploadPath);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			File uploadedFile = new File(uploadPath, newFileName);
			item.write(uploadedFile);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		fileInfo.setRealPath(uploadPath);
		fileInfo.setUrlPath(urlPath);
		fileInfo.setFileName(fileName);
		fileInfo.setNewFileName(newFileName);
		return fileInfo;
	}
	
	protected PageListBean pageList(IDaoInterface dao, String methodStr) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		return pageList(dao, methodStr, conditions);
	}
	
	protected PageListBean pageList(String methodStr) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		return pageList(null, methodStr, conditions);
	}
	
	protected PageListBean pageList(IDaoInterface dao, String methodStr, Map<String, Object> conditions) throws SoftbankException {
		try {
			int currentPage = Integer.parseInt(context.getParam().currentPage);
			int pageRowNumber = Integer.parseInt(context.getParam().pageRowNumber);
			int startPageRow = pageRowNumber * (currentPage - 1);
			String sql = "";
			if (dao == null) {
				sql = SqlHelper.getNamespaceSql(db.getQuerySession(), methodStr, conditions);
			} else {
				sql = SqlHelper.getMapperSql(dao, methodStr, conditions);
			}
			conditions.put("sqlContent", sql);
			conditions.put("pageRowNumber", pageRowNumber);
			conditions.put("startPageRow", startPageRow);
			List<Map<String, Object>> datas = db.querys("co.jp.softbank.qqmx.dao.common.CommonDao.executeSqlForPage", conditions);
			long pageInfo = db.query("co.jp.softbank.qqmx.dao.common.CommonDao.executeSqlForPageCount", conditions, Long.class);
			
			long allRows = pageInfo;
			return getPageListInfo(datas, allRows);
		} catch (SecurityException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SecurityException, e);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IllegalArgumentException, e);
		}
	}

	protected PageListBean getPageListInfo(List<Map<String, Object>> datas, long allRows) {
		int currentPage = Integer.parseInt(context.getParam().currentPage);
		int pageRowNumber = Integer.parseInt(context.getParam().pageRowNumber);
		long allPage = allRows / pageRowNumber;
		if (allRows % pageRowNumber != 0) {
			allPage++;
		}
		if (datas.size() > pageRowNumber) {
			int startPageRow = pageRowNumber * (currentPage - 1);
			if (startPageRow >= datas.size()) {
				datas = Lists.newArrayList();
			} else {
				int endPageRow = startPageRow + pageRowNumber;
				if (endPageRow > datas.size()) {
					endPageRow = datas.size();
				}
				datas = datas.subList(startPageRow, endPageRow);
			}
		}
		PageListBean pageListBean = new PageListBean();
		pageListBean.setDatas(datas);
		pageListBean.setCurrentPage(currentPage);
		pageListBean.setPageRowNumber(pageRowNumber);
		pageListBean.setAllRows(allRows);
		pageListBean.setAllPage(allPage);
		return pageListBean;
	}
	
	protected PageListBean pageList(String methodStr, Map<String, Object> conditions) throws SoftbankException {
		return pageList(null, methodStr, conditions);
	}
	
	protected UserInfoData getUserInfos() {
		return (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
	}

	public void setDb(IDbExecute db) {
		this.db = db;
	}

	public void setScriptUtil(IScriptUtilFace scriptUtil) {
		this.scriptUtil = scriptUtil;
	}

}
