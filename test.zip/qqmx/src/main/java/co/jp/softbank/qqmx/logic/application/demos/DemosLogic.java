package co.jp.softbank.qqmx.logic.application.demos;

import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.SqlHelper;
import co.jp.softbank.qqmx.dao.demos.DemosDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class DemosLogic extends AbstractBaseLogic {
	
	@Autowired
	private DemosDao demosDao;
	
	public void getDemosInfo() throws SoftbankException {
		context.getResultBean().setData(pageList(demosDao, "getDemosList"));
	}

}
