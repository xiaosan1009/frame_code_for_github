package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.RoleListDao;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ForumResponseListLogic extends AbstractBaseLogic {
/*
	public void getMessageList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(pageList("forumList.getMessageList", conditions));
	}*/

	
}
