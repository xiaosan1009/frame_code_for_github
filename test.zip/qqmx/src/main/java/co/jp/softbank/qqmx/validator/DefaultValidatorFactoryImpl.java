package co.jp.softbank.qqmx.validator;

import org.apache.commons.validator.Validator;
import org.springframework.validation.Errors;
import org.springmodules.validation.commons.DefaultValidatorFactory;
public class DefaultValidatorFactoryImpl extends DefaultValidatorFactory {

    public static final String SOFTBANK_ERRORS_KEY = "co.jp.softbank.qqmx.validator.IValidationErrors";
    
    @Override
    public Validator getValidator(String beanName, Object bean, Errors errors) {
        Validator validator = 
            new CommonsValidatorImpl(getValidatorResources(), beanName);
        
        SpringValidationErrors commonErrors = createSpringValidationErrors();
        commonErrors.setErrors(errors);
        validator.setParameter(SOFTBANK_ERRORS_KEY, commonErrors);
        
        validator.setParameter(Validator.BEAN_PARAM, bean);
        return validator;
    }
    
    protected SpringValidationErrors createSpringValidationErrors() {
        return new SpringValidationErrors();
    }
}
