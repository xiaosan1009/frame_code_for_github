package co.jp.softbank.qqmx.dao.dasmain;

import java.util.List;
import java.util.Map;

public interface DasmainDao {
	
	List<Map<String, Object>> getProjectInfos();
	List<Map<String, Object>> getUserTaskInfoById(Map<String, Object> conditions);
	List<Map<String, Object>> getUserNewsInfoById(Map<String, Object> conditions);
	Map<String, Object> getUserMonthInfoById(Map<String, Object> conditions);
	Map<String, Object> getUserDelayInfoById(Map<String, Object> conditions);
	
	List<Map<String, Object>> getUserInformationById(Map<String, Object> conditions);
	List<Map<String, Object>> getUserInformation1ById(Map<String, Object> conditions);
	List<Map<String, Object>> getUserInformation2ById(Map<String, Object> conditions);
	List<Map<String, Object>> getUserTicketPlanById(Map<String, Object> conditions);
}
