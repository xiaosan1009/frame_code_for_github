/**
 *   <Quantitative project management tool.>
 *   Copyright (C) 2012 IPA, Japan.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package co.jp.softbank.qqmx.logic.application.batch;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

/**
 * 版管理ツールからソースファイルを取得してソース規模データ収集を行う抽象クラス。
 * 
 */
public abstract class SourceScaleCount extends AbstractBaseLogic {
    
    /** ロガー名 */
    public final static String LOGGER_NAME = "SourceScaleLogger";
    
    /** ロガー */
    protected static Logger log = Logger.getLogger(LOGGER_NAME);
    
    /** SQL STATE - キー重複 */
    public final static String SQL_STATE_KEY_DUPLICATE = "23505";
    
    /** デフォルトステップカウンタ */
    protected static IpfSourceScaleCounter defaultSourceScaleCounter;
    
    /** カスタムステップカウンタ登録用マップ */
    protected static Map<String, IpfSourceScaleCounter> customSourceScaleCounterMap = 
            new HashMap<String, IpfSourceScaleCounter>();
    
    // 設定ファイルのPath
    protected static final String PATH = "SourceScaleCount.dicon";
    

    
    /**
     * ソース規模を収集し結果を返す。
     * 
     * @param oldFile 変更前ファイル
     * @param newFile 変更後ファイル
     * @return ソース規模収集結果
     */
    public static SourceScaleResult count(File oldFile, File newFile) {
        
        String filename = null;
        if (newFile != null) {
            filename = newFile.getName();
        }
        if (oldFile != null) {
            filename = oldFile.getName();
        }
        
        String ext = FilenameUtils.getExtension(filename);
        String regExt = getRegExt(ext);
        
        if (checkCountable(regExt)) {
        	return IpfSourceScaleCounter.count(oldFile, newFile);
        } else {
        	return new SourceScaleResult();
        }
    }
    
    public static boolean checkCountable(String filename) {
    	
    	boolean isCountable = false;
    	
        List<String> regExtslist = new ArrayList<String>();
        regExtslist.add("java");
        regExtslist.add("scala");
        regExtslist.add("cpp");
        regExtslist.add("c");
        regExtslist.add("pc");
        regExtslist.add("h");
        regExtslist.add("cs");
        regExtslist.add("drl");
        regExtslist.add("jsp");
        regExtslist.add("php");
        regExtslist.add("php3");
        regExtslist.add("asp");
        regExtslist.add("asa");
        regExtslist.add("html");
        regExtslist.add("htm");
        regExtslist.add("tmpl");
        regExtslist.add("arkhtml");
        regExtslist.add("xhtml");
        regExtslist.add("js");
        regExtslist.add("vbs");
        regExtslist.add("bas");
        regExtslist.add("frm");
        regExtslist.add("cls");
        regExtslist.add("vb");
        regExtslist.add("pl");
        regExtslist.add("pm");
        regExtslist.add("py");
        regExtslist.add("rb");
        regExtslist.add("tcl");
        regExtslist.add("env");
        regExtslist.add("sh");
        regExtslist.add("csh");
        regExtslist.add("ksh");
        regExtslist.add("spec");
        regExtslist.add("sql");
        regExtslist.add("prc");
        regExtslist.add("ctl");
        regExtslist.add("cfm");
        regExtslist.add("properties");
        regExtslist.add("list");
        regExtslist.add("xml");
        regExtslist.add("dicon");
        regExtslist.add("tld");
        regExtslist.add("xsd");
        regExtslist.add("xaml");
        regExtslist.add("datasource");
        regExtslist.add("map");
        regExtslist.add("wprx");
        regExtslist.add("ndf");
        regExtslist.add("idf");
        regExtslist.add("rel");
        regExtslist.add("v3");
        regExtslist.add("bat");
        regExtslist.add("css");
        regExtslist.add("l");
        regExtslist.add("el");
        regExtslist.add("cl");
        regExtslist.add("clj");
        regExtslist.add("scm");
        regExtslist.add("st");
        regExtslist.add("vm");
        regExtslist.add("vsl");
        regExtslist.add("ini");
        regExtslist.add("lua");
        regExtslist.add("hs");
        regExtslist.add("csv");
        regExtslist.add("tpl");
        regExtslist.add("iot");
        regExtslist.add("ldr");
        regExtslist.add("scl");
        regExtslist.add("balptab");
        regExtslist.add("bpm");
        regExtslist.add("trn");
        regExtslist.add("json");
        regExtslist.add("txt");
        
        if (regExtslist.contains(filename)) {
        	isCountable = true;
        } else {
        	isCountable = false;
        }
        return isCountable;
	}
    
    /**
     * ソース規模収集可能なファイルの種類かチェックする。
     * 
     * @param file カウント対象ファイル名
     * @return 収集可 true、収集不可 false
     */
    protected static boolean isCountable(String filename) {
    	
        
        String ext = FilenameUtils.getExtension(filename);
        String regExt = getRegExt(ext);
        
        if (checkCountable(regExt)) {
        	// 収集可能
        	return true;
        } else {
        	// 収集不可
            return false;
        }
        
        
//        IpfSourceScaleCounter sc = getSourceScaleCounter(filename);
//        if(sc.isCountable(filename)) {
//            // 収集可能
//            return true;
//        }
//        // 収集不可
//        return false;
    }
    
    
//    /**
//     * ファイルの拡張子に対応するステップカウンターを取得する。
//     * 
//     * @param file カウント対象ファイル名
//     * @return 拡張子に対応するステップカウンター
//     */
//    protected static IpfSourceScaleCounter getSourceScaleCounter(String filename) {
//        
//        // 拡張子を取得
//        String ext = FilenameUtils.getExtension(filename);
//        String regExt = getRegExt(ext);
//
//        try {
//            S2Container container = S2ContainerFactory.create(PATH);
//            container.init();
//            
//            // カスタムステップカウンターを取得してマップに登録
//            // カスタムステップカウンタークラスはパッケージ jp.go.ipa.sourcescale.counter.custom 配下に、
//            // IpfStepCounter クラスを継承して作成する。
//            for (int i = 0; i < container.getComponentDefSize(); i++) {
//                
//                Object component = container.getComponentDef(i).getComponent();
//                if (component instanceof IpfSourceScaleCounter) {
//                    // カスタムステップカウンタークラスの場合
//                    IpfSourceScaleCounter sourceScaleCounter = (IpfSourceScaleCounter) component;
//                    
//                    for (String exts : sourceScaleCounter.getFileExtList()) {
//                        String regExts = getRegExt(exts);
//                        if (regExts != null) {
//                            // 対応する拡張子をキーにしてマップに登録
//                            customSourceScaleCounterMap.put(regExts, sourceScaleCounter);
//                            log.debug(String.format("Custom Counter Loaded : [.%s] : %s",
//                                    regExt, sourceScaleCounter.getClass().getName()));
//                        }
//                    }
//                }
//            }
//        } catch (Exception e) {
//        }
//        
//        // デフォルトのステップカウンタークラス(DefaultIpfStepCounterImpl)を取得
//        defaultSourceScaleCounter = new IpfDefaultSourceScaleCounterImpl();
//    
//        
//        // 拡張子に対応するカスタムステップカウンタが存在するかチェック
//        if (customSourceScaleCounterMap.containsKey(regExt)) {
//            // カスタムステップカウンターを使用
//            return customSourceScaleCounterMap.get(regExt);
//        } else {
//            // デフォルトのステップカウンターを使用
//            return defaultSourceScaleCounter;
//        }
//    }
    
    /**
     * 拡張子をカスタムステップカウンタマップ登録時に使用するキー値
     * （小文字、ドット(.)なし）に変換する。
     * 
     * @param ext 拡張子
     * @return マップ登録時のキー値
     */
    protected static String getRegExt(String ext) {
        String regExt = null;
        if (ext != null && ext.length() > 0) {
            regExt = ext.toLowerCase().replaceAll("\\.", "");
        }
        return regExt;
    }
    
    /**
     * 版管理ツールから取得したファイルを作成する一時ディレクトリを作成する。
     * @param prefix 一時ディレクトリ名の接頭辞
     * @param suffix 一時ディレクトリ名の接尾辞
     * @return 作成した一時ディレクトリを返す（ディレクトリ名：[prefix]yyyyMMddHHmmssSSS[suffix]）
     */
    protected static File createTempDirectory(String prefix, String suffix) {
        StringBuilder dirName = new StringBuilder();
        if (prefix != null && prefix.length() > 0) {
            dirName.append(prefix);
        }
        String timestamp = DateFormatUtils.format(new Date(), "yyyyMMddHHmmssSSS");
        dirName.append(timestamp);
        if (suffix != null && suffix.length() > 0) {
            dirName.append(suffix);
        }

        File dir = new File("/opt/ipftools/monitoring-board-sample.git/tempFile" + "/" + dirName.toString());
//        File dir = new File("C:\\Users\\dev6840202x3\\Desktop\\diff" + "\\" + dirName.toString()); //ローカル
        if (! dir.exists()) {
            dir.mkdirs();
            log.debug("tmpdir:" + dir.getPath());
        }
        return dir;
    }

    /**
     * ソース規模データをDBに登録する。
     * 
     * @param conn DBコネクション
     * @param pstmt ソース規模データ登録用プリペアド・ステートメント
     * @param projectId プロジェクトID
     * @param result ソース規模データ格納オブジェクト
     * @throws Exception 
     */
    protected void insertSourceScale(
            Integer project_id,
            String repoPath,
            String branch,
            SourceScaleResult result) throws Exception {
        
        // 収集結果ログ出力
        log.debug(result.getResultDetailString());
        
        // 更新日時
        Timestamp changeDate = new Timestamp(
                DateUtils.toCalendar(result.getUpdDate()).getTimeInMillis()); // Date 型 → Timestamp 型変換
        
        // チケットID（コミットログから取得）
        Set<Long> ticketIdSet = getTicketIdFromCommitLog(result.getMessage());

        // リモート連携対応
        if (ticketIdSet == null || ticketIdSet.size() == 0) {
            ticketIdSet.add(0L);
        }
        log.debug("Related Ticket Id:" + ticketIdSet);
        
        int ticketId = 0;
        
        // チケットID分繰り返し
		for (Long lTicketId : ticketIdSet) {
		    ticketId = lTicketId.intValue();
		    Map<String, Object> conditions = Maps.newHashMap();
		    
		    conditions.put("project_id", project_id);
		    conditions.put("repository", repoPath);
		    conditions.put("branch", branch);
		    conditions.put("ticket_id", ticketId);
		    conditions.put("revision", result.getRevision());
		    conditions.put("file_name", result.getFileName());
		    conditions.put("file_type", result.getFileType());
		    conditions.put("file_path", result.getFilePath());
		    conditions.put("change_date", changeDate);
		    conditions.put("file_size", (int) result.getFileSize());
		    conditions.put("source_lines", (int) result.getSourceLine());
		    conditions.put("source_lines2", (int) result.getSourceLine2());
		    conditions.put("increase_source_lines", (int) result.getIncreaseLine());
		    conditions.put("increase_source_lines2", (int) result.getIncreaseLine2());
		    conditions.put("add_source_lines", (int) result.getAddLine());
		    conditions.put("add_source_lines2", (int) result.getAddLine2());
		    conditions.put("change_source_lines", (int) result.getModLine());
		    conditions.put("change_source_lines2", (int) result.getModLine2());
		    conditions.put("delete_source_lines", (int) result.getDelLine2());
		    conditions.put("delete_source_lines2", (int) result.getDelLine2());
		    conditions.put("change_user_id", null);
		    conditions.put("change_user", result.getAuthor());

		    db.insert("sourceScale.insertSourceScale", conditions);
		    
		}
    }

    /**
     * ソース規模データをDBに登録する。
     * 
     * @param conn DBコネクション
     * @param pstmt ソース規模データ登録用プリペアド・ステートメント
     * @param projectId プロジェクトID
     * @param version バージョン
     * @param result ソース規模データ格納オブジェクト
     * @throws Exception 
     */
    protected static void insertSourceScale(
            Connection conn,
            PreparedStatement pstmt,
            String projectId,
            String version,
            SourceScaleResult result) throws Exception {
        
        // 収集結果ログ出力
        log.debug(result.getResultDetailString());
        
        // 更新日時
        Timestamp changeDate = new Timestamp(
                DateUtils.toCalendar(result.getUpdDate()).getTimeInMillis()); // Date 型 → Timestamp 型変換
        
        // チケットID（コミットログから取得）
        Set<Long> ticketIdSet = getTicketIdFromCommitLog(result.getMessage());

        // リモート連携対応
        if (ticketIdSet == null || ticketIdSet.size() == 0) {
            ticketIdSet.add(0L);
        }
        log.debug("Related Ticket Id:" + ticketIdSet);
        
        int ticketId = 0;
        
        try {
            // チケットID分繰り返し
            for (Long lTicketId : ticketIdSet) {
                ticketId = lTicketId.intValue();
                
                pstmt.clearParameters();
                int i = 1;
                pstmt.setString(i++, projectId);                    // project_id
                pstmt.setString(i++, version);                      // version_name
                pstmt.setString(i++, result.getRevision());         // revision
                pstmt.setInt(i++, ticketId);                        // ticket_id
                pstmt.setString(i++, result.getFileName());         // file_name
                pstmt.setString(i++, result.getFileType());         // file_type
                pstmt.setString(i++, result.getFilePath());         // file_path
                pstmt.setString(i++, result.getAuthor());           // change_user_id
                pstmt.setTimestamp(i++, changeDate);                // change_date
                pstmt.setInt(i++, (int) result.getFileSize());      // file_size
                pstmt.setInt(i++, (int) result.getSourceLine());    // source_lines
                pstmt.setInt(i++, (int) result.getSourceLine2());   // source_lines2
                pstmt.setInt(i++, (int) result.getIncreaseLine());  // increase_source_lines
                pstmt.setInt(i++, (int) result.getIncreaseLine2()); // increase_source_lines2
                pstmt.setInt(i++, (int) result.getChangeLine());    // change_source_lines
                pstmt.setInt(i++, (int) result.getChangeLine2());   // change_source_lines2
                pstmt.executeUpdate();
            }
        } catch (SQLException sqle) {
            String sqlState = sqle.getSQLState();
            if (StringUtils.equals(sqlState, SQL_STATE_KEY_DUPLICATE)) {
                
                // ロールバック用にカスタマイズした例外をスローする
                throw new IpfSQLNormalException(sqle);
            } else {
                throw sqle;
            }
        }
    }
    
    protected void insertSourceDiff(
            String projectId,
            String version,
            String repoPath,
            SourceScaleResult result) throws Exception {
    	
    	   // 収集結果ログ出力
        log.debug(result.getResultDetailString());
        
	    Integer project_id = 0;
	    if (projectId != null && projectId != "") {
	    	project_id = Integer.parseInt(projectId);
	    }
        
        // 更新日時
//        Timestamp changeDate = new Timestamp(
//                DateUtils.toCalendar(result.getUpdDate()).getTimeInMillis()); // Date 型 → Timestamp 型変換
        
        // チケットID（コミットログから取得）
//        Set<Long> ticketIdSet = getTicketIdFromCommitLog(result.getMessage());
//
//        // リモート連携対応
//        if (ticketIdSet == null || ticketIdSet.size() == 0) {
//            ticketIdSet.add(0L);
//        }
//        log.debug("Related Ticket Id:" + ticketIdSet);
        
        int ticketId = 0;
        
        // チケットID分繰り返し
//	    ticketId = lTicketId.intValue();
	    Map<String, Object> conditions = Maps.newHashMap();
	    
	    conditions.put("project_id", project_id);
	    conditions.put("repository", repoPath);
//	    conditions.put("branch", branch);
	    conditions.put("ticket_id", ticketId);
	    conditions.put("revision", result.getRevision());
	    conditions.put("file_name", result.getFileName());
	    conditions.put("file_type", result.getFileType());
	    conditions.put("file_path", result.getFilePath());
//	    conditions.put("change_date", changeDate);
	    conditions.put("file_size", (int) result.getFileSize());
	    conditions.put("source_lines", (int) result.getSourceLine());
	    conditions.put("source_lines2", (int) result.getSourceLine2());
	    conditions.put("increase_source_lines", (int) result.getIncreaseLine());
	    conditions.put("increase_source_lines2", (int) result.getIncreaseLine2());
	    conditions.put("add_source_lines", (int) result.getAddLine());
	    conditions.put("add_source_lines2", (int) result.getAddLine2());
	    conditions.put("change_source_lines", (int) result.getModLine());
	    conditions.put("change_source_lines2", (int) result.getModLine2());
	    conditions.put("delete_source_lines", (int) result.getDelLine2());
	    conditions.put("delete_source_lines2", (int) result.getDelLine2());
	    conditions.put("change_user_id", null);
	    conditions.put("change_user", result.getAuthor());

	    db.insert("sourceScale.insertSourceDiff", conditions);
		    

        
        // 収集結果ログ出力
//        log.debug(result.getResultDetailString());
//        
//        pstmt.clearParameters();
//        int i = 1;
//        pstmt.setString(i++, projectId);                    // project_id
//        pstmt.setString(i++, version);                      // version_name
//        pstmt.setString(i++, result.getFileName());         // file_name
//        pstmt.setString(i++, result.getFileType());         // file_type
//        pstmt.setString(i++, result.getFilePath());         // file_path
//        pstmt.setInt(i++, (int) result.getSourceLine());    // source_lines
//        pstmt.setInt(i++, (int) result.getSourceLine2());   // source_lines2
//        pstmt.setInt(i++, (int) result.getIncreaseLine());  // increase_source_lines
//        pstmt.setInt(i++, (int) result.getIncreaseLine2()); // increase_source_lines2
//        pstmt.setInt(i++, (int) result.getChangeLine());    // change_source_lines
//        pstmt.setInt(i++, (int) result.getChangeLine2());   // change_source_lines2
//        pstmt.setInt(i++, (int) result.getAddLine());       // add_line
//        pstmt.setInt(i++, (int) result.getAddLine2());      // add_line2
//        pstmt.setInt(i++, (int) result.getDelLine());       // del_line
//        pstmt.setInt(i++, (int) result.getDelLine2());      // del_line2
//        pstmt.setInt(i++, (int) result.getModLine());       // mod_line
//        pstmt.setInt(i++, (int) result.getModLine2());      // mod_line2
//        pstmt.executeUpdate();
    }
    
    protected static void deleteSourceDiff(
            String projectId,
            String version) throws Exception {
        
        // SQL
        String sql = 
                "DELETE FROM source_diff " +
                " WHERE project_id = ? and version_name = ?";
        
//        PreparedStatement pstmt = conn.prepareStatement(sql);
        int i = 1;
//        pstmt.setString(i++, projectId);
//        pstmt.setString(i++, version);
//        pstmt.executeUpdate();
    }
    
    /**
     * コミットログから関連するチケットIDを抽出してセットに格納して返す。
     * 
     * @param commitLog コミットログ
     * @return 関連するチケットIDのセット
     */
    protected static Set<Long> getTicketIdFromCommitLog(String commitLog) {
        
        Set<Long> ticketIdSet = new HashSet<Long>();
        
        // コミットログから関連するチケットIDを抽出（Trac）
        ticketIdSet.addAll(getTicketIdFromCommitLogForTrac(commitLog));
        // コミットログから関連するチケットIDを抽出（Redmine）
        ticketIdSet.addAll(getTicketIdFromCommitLogForRedmine(commitLog));
        
        return ticketIdSet;
    }
    
    /**
     * コミットログから関連するチケットIDを抽出してセットに格納して返す。
     * （Trac 版）
     * 
     * @param commitLog コミットログ
     * @return 関連するチケットIDのセット
     */
    protected static Set<Long> getTicketIdFromCommitLogForTrac(String commitLog) {
        Set<Long> ticketIdSet = new HashSet<Long>();
        
        // コミットログからチケットIDを抽出するための正規表現
        String regexp = 
            "(?:close|closed|closes|fix|fixed|fixes|addresses|references|refs|re|see|[\\s,&]+|[\\s]*and)[\\s]*" + 
            "(?:ticket\\:|issue\\:|bug\\:|#)([0-9]+)";
        
        Pattern p = Pattern.compile(regexp, Pattern.MULTILINE);
        Matcher m = p.matcher(commitLog.toLowerCase());
        while(m.find()){
            if (m.groupCount() > 0) {
                String ticketId = m.group(1);
                log.debug("[Trac] ticketId:" + ticketId);
                ticketIdSet.add(NumberUtils.toLong(ticketId));
            }
        }
        return ticketIdSet;
    }
    
    /**
     * コミットログから関連するチケットIDを抽出してセットに格納して返す。
     * （Redmine 版）
     * 
     * @param commitLog コミットログ
     * @return 関連するチケットIDのセット
     */
    protected static Set<Long> getTicketIdFromCommitLogForRedmine(String commitLog) {
        Set<Long> ticketIdSet = new HashSet<Long>();
        
        // コミットログからチケットIDを抽出するための正規表現
        String regexp = "";
        
        Pattern p = Pattern.compile(regexp, Pattern.MULTILINE);
        Matcher m = p.matcher(commitLog.toLowerCase());
        while(m.find()){
            if (m.groupCount() > 0) {
                String ticketId = m.group(1);
                log.debug("[Redmine] ticketId:" + ticketId);
                ticketIdSet.add(NumberUtils.toLong(ticketId));
            }
        }
        return ticketIdSet;
    }
}
