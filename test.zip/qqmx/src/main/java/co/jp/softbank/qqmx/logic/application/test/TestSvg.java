package co.jp.softbank.qqmx.logic.application.test;

import java.io.File;

import org.springframework.stereotype.Component;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.FileUtils;

public class TestSvg extends AbstractBaseLogic {
	
	private static final String DATA_FILE_FOLDER = "data" + File.separator + "test-svg";

	public void getDatas() throws SoftbankException {
		File file = new File(context.getRealPath() + DATA_FILE_FOLDER + File.separator + "datas.txt");
		context.getResultBean().setData(FileUtils.getFileDataString(file));
	}
	
}
