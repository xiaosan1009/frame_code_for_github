package co.jp.softbank.qqmx.info;

import java.io.File;
import java.util.Map;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlSettingMap.SettingKey;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.FileUtils;
import co.jp.softbank.qqmx.util.LogUtil;

import com.google.common.collect.Maps;

public class ControlScriptHandler {
	
	private static final String DISP_SCRIPT_KEY = "DISP_SCRIPT_KEY";
	
	private static final String FORMAT_SCRIPT_KEY = "FORMAT_SCRIPT_KEY";
	
	private static final String SCRIPT_UTIL_KEY = "SCRIPT_UTIL_KEY";
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	/**
     * 自身对象
     */
    private static ControlScriptHandler sMe;
    
    private Map<String, Map<String, String>> mScriptMap;
    
    private Map<String, Map<String, String>> mScriptPathMap;
    
    /**
     * 自身对象的取得.
     * @return ControlBaConfig 自身对象
     * @throws SoftbankException SoftbankException
     */
    public static ControlScriptHandler getInstance() {
        
        synchronized (ControlScriptHandler.class) {
            if (sMe == null) {
                sMe = new ControlScriptHandler();
            }
        }
        
        return sMe;
    }
    
    public void initScript(File folder) throws SoftbankException {
    	log.info(ConstantsUtil.Log.START_SIGN);
    	log.info("folder = " + folder);
    	if (folder == null || !folder.isDirectory()) {
			return;
		}
    	
    	if (mScriptMap == null) {
    		mScriptMap = Maps.newHashMap();
    		mScriptPathMap = Maps.newHashMap();
		}
    	initMapInfo(folder, DISP_SCRIPT_KEY);
    	log.info(ConstantsUtil.Log.END_SIGN);
    }

	private void initMapInfo(File folder, String key) throws SoftbankException {
		Map<String, String> actionMap = Maps.newHashMap();
		Map<String, String> actionPathMap = Maps.newHashMap();
    	analyzingScriptFile(folder, actionMap, actionPathMap);
    	mScriptMap.put(key, actionMap);
    	mScriptPathMap.put(key, actionPathMap);
	}
    
    public void initFormatScript(File folder) throws SoftbankException {
    	log.info(ConstantsUtil.Log.START_SIGN);
    	log.info("folder = " + folder);
    	if (folder == null || !folder.isDirectory()) {
    		return;
    	}
    	
    	log.info("mScriptMap = " + mScriptMap);
    	if (mScriptMap == null) {
    		mScriptMap = Maps.newHashMap();
    		mScriptPathMap = Maps.newHashMap();
    	}
    	initMapInfo(folder, FORMAT_SCRIPT_KEY);
    	log.info(ConstantsUtil.Log.END_SIGN);
    }
    
    public void initScriptUtil(File folder) throws SoftbankException {
    	log.info(ConstantsUtil.Log.START_SIGN);
    	log.info("folder = " + folder);
    	if (folder == null || !folder.isDirectory()) {
    		return;
    	}
    	
    	if (mScriptMap == null) {
    		mScriptMap = Maps.newHashMap();
    		mScriptPathMap = Maps.newHashMap();
    	}
    	initMapInfo(folder, SCRIPT_UTIL_KEY);
    	log.info(ConstantsUtil.Log.END_SIGN);
    }

	private void analyzingScriptFile(File folder, Map<String, String> actionMap, Map<String, String> actionPathMap) throws SoftbankException {
		log.info(ConstantsUtil.Log.START_SIGN);
		File[] files = folder.listFiles();
		
		log.info("files.length = " + files.length);
    	for (int i = 0; i < files.length; i++) {
			File file = files[i];
			String fileName = file.getName();
			
			if (file.isDirectory()) {
				analyzingScriptFile(file, actionMap, actionPathMap);
				continue;
			}
			
			if (fileName.indexOf(ConstantsUtil.Str.DOT) == -1) {
				continue;
			}
			fileName = fileName.substring(0, fileName.indexOf(ConstantsUtil.Str.DOT));
			actionMap.put(fileName, FileUtils.getFileDataString(file));
			actionPathMap.put(fileName, file.getAbsolutePath());
		}
    	
    	log.info(ConstantsUtil.Log.END_SIGN);
	}
    
    public String getScript(String dispCode) throws SoftbankException {
    	return getScript(DISP_SCRIPT_KEY, dispCode);
    }
    
    public String getFormatScript(String method) throws SoftbankException {
    	return getScript(FORMAT_SCRIPT_KEY, method);
    }
    
    public String getScriptUtil(String method) throws SoftbankException {
    	return getScript(SCRIPT_UTIL_KEY, method);
    }
    
    public boolean containsFormatMethod(String method) {
    	return mScriptMap.get(FORMAT_SCRIPT_KEY).containsKey(method);
    }
    
    public boolean containsScriptUtilMethod(String method) {
    	return mScriptMap.get(SCRIPT_UTIL_KEY).containsKey(method);
    }
    
    private String getScript(String mode, String dispCode) throws SoftbankException {
    	log.debug(ConstantsUtil.Log.START_SIGN);
    	final boolean immediately = ControlSettingMap.getInstance().getBoolean(SettingKey.SCRIPT_IMMEDIATELY);
    	log.debug("immediately = {}", immediately);
    	if (immediately) {
    		if (mScriptPathMap != null && mScriptPathMap.get(mode).containsKey(dispCode)) {
    			File file = new File(mScriptPathMap.get(mode).get(dispCode));
    			log.debug("getScript", "", "file = " + file);
    			return FileUtils.getFileDataString(file);
    		}
    	}
    	if (mScriptMap == null || !mScriptMap.get(mode).containsKey(dispCode)) {
    		return null;
    	}
    	log.debug(ConstantsUtil.Log.END_SIGN);
    	return mScriptMap.get(mode).get(dispCode);
    }

}
