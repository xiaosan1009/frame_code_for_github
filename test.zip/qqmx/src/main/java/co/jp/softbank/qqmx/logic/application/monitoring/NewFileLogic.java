package co.jp.softbank.qqmx.logic.application.monitoring;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;

public class NewFileLogic extends AbstractBaseLogic {
// TODO *******************************************************************************20170824 王暁義 qqmxからqqrpまで移動しました。このCLASS廃棄する。
	public void newFile() throws SoftbankException, ParseException, IOException {
		Map<String, Object> conditions = Maps.newHashMap();
		String issuesId = context.getParam().get("issues_id");
		conditions.put("issues_id", Integer.parseInt(issuesId));
		List<Map<String, Object>> issuesInfo = db.querys("newFile.getissuesInfo", conditions);
		if (issuesInfo.size() < 1 ){
			return;
		}
		String issue_value = String.valueOf(issuesInfo.get(0).get("value"));
		String pass = issue_value.replaceAll("\\\\","/");
		String fileName = issue_value.split("\\\\")[issue_value.split("\\\\").length-1];
		String pathOut = "smb:" + pass;
		String pathInputFile = messageAccessor.getMessage("FILE_CHECK_PATH") + "/documents/" +issuesInfo.get(0).get("project_id")+ "/" +issuesId+ "/" + fileName;
		String pathInputPass = messageAccessor.getMessage("FILE_CHECK_PATH") + "/documents/" +issuesInfo.get(0).get("project_id")+ "/" +issuesId+ "/";
		
//		String pathInputFile = "C:/A平日使用/file/" +issuesInfo.get(0).get("project_id")+ "/" +issuesId+ "/" + fileName;
//		String pathInputPass = "C:/A平日使用/file/" +issuesInfo.get(0).get("project_id")+ "/" +issuesId+ "/";
		
        //ここからファイル書き出しサンプル
		File newPass = new File(pathInputPass);
		File newfile = new File(pathInputFile);
		
		delete(newPass);
		newPass.mkdirs();
		newfile.createNewFile();
        
		NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", "user", "Qualitypass@1");
		SmbFile outFile =  new SmbFile(pathOut, auth);
		InputStream out = outFile.getInputStream();
		
        try {
            BufferedInputStream input = new BufferedInputStream(out);
            BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(newfile));
            byte buf[] = new byte[256];
            int len;
            while ((len = input.read(buf)) != -1) {
                output.write(buf, 0, len);
            }
            output.flush();
            output.close();
            input.close();
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	/*
     * ファイルおよびディレクトリを削除する
     */
    private static void delete(File f)
    {
        /*
         * ファイルまたはディレクトリが存在しない場合は何もしない
         */
        if(f.exists() == false) {
            return;
        }

        if(f.isFile()) {
            /*
             * ファイルの場合は削除する
             */
            f.delete();

        } else if(f.isDirectory()){
            /*
             * ディレクトリの場合は、すべてのファイルを削除する
             */

            /*
             * 対象ディレクトリ内のファイルおよびディレクトリの一覧を取得
             */
            File[] files = f.listFiles();

            /*
             * ファイルおよびディレクトリをすべて削除
             */
            for(int i=0; i<files.length; i++) {
                /*
                 * 自身をコールし、再帰的に削除する
                 */
                delete( files[i] );
            }
            /*
             * 自ディレクトリを削除する
             */
            f.delete();
        }
    }
}
