package co.jp.softbank.qqmx.util;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;
import java.util.StringTokenizer;

import org.apache.commons.validator.GenericTypeValidator;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.UrlValidator;

public class ValidationUtil {
	
	protected static String hankakuKanaList =
	        "ｱｲｳｴｵｧｨｩｪｫｶｷｸｹｺｻｼｽｾｿﾀﾁﾂｯﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖｬｭｮﾗﾘﾙﾚﾛﾜｦﾝﾟﾞｰ･､｡｢｣";
	
	protected static String zenkakuKanaList =
	        "アイウヴエオァィゥェォカキクケコヵヶガギグゲゴサシスセソ"
	            + "ザジズゼゾタチツテトダヂヅデドナニヌネノハヒフヘホ"
	            + "バビブベボパピプペポマミムメモヤユヨャュョラリルレロ"
	            + "ワヮヰヱヲッンー";
	
	protected static final String ZENKAKU_BEGIN_U00_LIST = "＼¢£§¨¬°±´¶×÷";
	
	public static Date toDate(String value, String datePattern) {

        return toDate(value, datePattern, null);
    }
	
	public static Date toDate(String value, String datePattern, String datePatternStrict) {
		
		if (StringUtils.isEmpty(value)) {
			return null;
		}
		
		Date result = null;
		
		// 桁数チェックなしの変換
		if (datePattern != null && datePattern.length() > 0) {
			result = GenericTypeValidator.formatDate(value,
					datePattern, false);
			
			// 桁数チェックありの変換
		} else if (datePatternStrict != null
				&& datePatternStrict.length() > 0) {
			result = GenericTypeValidator.formatDate(value,
					datePatternStrict, true);
			
			// 日付パターンが設定されていない
		} else {
			throw new IllegalArgumentException(
					"datePattern or datePatternStrict must be specified.");
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		System.out.println(toDate("2017-07-4", null, DateUtils.FORMAT_YMD2));
	}
	
	public static boolean isAlphaNumericString(String value) {
        return matchRegexp(value, "^([0-9]|[a-z]|[A-Z])*$");
    }
	
	public static boolean isUpperAlphaNumericString(String value) {
        return matchRegexp(value, "^([0-9]|[A-Z])*$");
    }
	
	public static boolean isHankakuString(String value) {

        // 検証値がnullまたは空文字の時、true返却
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        char[] chars = value.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (!isHankakuChar(chars[i])) {
                return false;
            }
        }
        return true;
    }
	
	protected static boolean isHankakuChar(char c) {
        return (c <= '\u00ff' && ZENKAKU_BEGIN_U00_LIST.indexOf(c) < 0)
                || isHankakuKanaChar(c);
    }
	
	protected static boolean isHankakuKanaChar(char c) {
        return hankakuKanaList.indexOf(c) >= 0;
    }
	
	public static boolean isNumber(
            BigDecimal value, int integerLength, boolean isAccordedInteger,
            int scaleLength, boolean isAccordedScale) {

        // 検証値がnullの時、true返却
        if (value == null) {
            return true;
        }

        // 整数部チェックを行う
        // 整数部絶対値のみ抽出
        BigInteger bi = value.toBigInteger().abs();
        // 整数桁数
        int length = bi.toString().length();
        if (!checkNumberFigures(length, integerLength, isAccordedInteger)) {
            return false;
        }

        // 小数部チェックを行う
        int scale = value.scale();
        if (!checkNumberFigures(scale, scaleLength, isAccordedScale)) {
            return false;
        }

        return true;
    }
	
	public static boolean isHankakuKanaString(String value) {

        // 検証値がnullまたは空文字の時、true返却
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        char[] chars = value.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (!isHankakuKanaChar(chars[i])) {
                return false;
            }
        }
        return true;

    }
	
	public static boolean isZenkakuString(String value) {

        // 検証値がnullまたは空文字の時、true返却
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        char[] chars = value.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (!isZenkakuChar(chars[i])) {
                return false;
            }
        }
        return true;

    }
	
	public static boolean isZenkakuKanaString(String value) {

        // 検証値がnullまたは空文字の時、true返却
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        char[] chars = value.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (!isZenkakuKanaChar(chars[i])) {
                return false;
            }
        }
        return true;

    }
	
	public static boolean hasNotProhibitedChar(
            String value, String prohibitedChars) {

        // 検証値がnullまたは空文字の時、true返却
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        char[] chars = value.toCharArray();

        // 入力禁止文字列が未設定の場合、チェックを行わない
        if (prohibitedChars == null || "".equals(prohibitedChars)) {
            return true;
        }

        // 検証
        for (int i = 0; i < chars.length; i++) {
            if (prohibitedChars.indexOf(chars[i]) >= 0) {
                return false;
            }
        }
        return true;
    }
	
	public static boolean isArrayInRange(Object obj, int min, int max) {

        // 検証値の配列長
        int targetLength = 0;
        if (obj == null) {
            targetLength = 0;
        } else if (obj instanceof Collection) {
            targetLength = ((Collection) obj).size();
        } else if (obj.getClass().isArray()) {
            targetLength = Array.getLength(obj);
        } else {
            // 検証値が配列型ではない場合、IllegalArgumentExceptionをスロー
            throw new IllegalArgumentException(obj.getClass().getName() +
                    " is neither Array nor Collection.");
        }

        // 入力された要素数が指定範囲以外ならばfalseを返却
        if (!GenericValidator.isInRange(targetLength, min, max)) {
            return false;
        }
        return true;
    }
	
	public static boolean isUrl(
            String value, boolean allowallschemes, boolean allow2slashes,
            boolean nofragments, String schemesVar) {

        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // オプションの設定
        int options = 0;
        if (allowallschemes) {
            options += UrlValidator.ALLOW_ALL_SCHEMES ;
        }
        if (allow2slashes) {
            options += UrlValidator.ALLOW_2_SLASHES;
        }
        if (nofragments) {
            options += UrlValidator.NO_FRAGMENTS;
        }

        // オプションがない場合はデフォルトのGenericValidatorを使用
        if (options == 0 && schemesVar == null) {
            if (GenericValidator.isUrl(value)) {
                return true;
            }
            return false;
        }

        // スキームをString[]に変換
        String[] schemes = null;
        if (schemesVar != null) {

            StringTokenizer st = new StringTokenizer(schemesVar, ",");
            schemes = new String[st.countTokens()];

            int i = 0;
            while (st.hasMoreTokens()) {
                schemes[i++] = st.nextToken().trim();
            }
        }

        // オプションありの場合はUrlValidatorを使用
        UrlValidator urlValidator = new UrlValidator(schemes, options);
        if (urlValidator.isValid(value)) {
            return true;
        }
        return false;
    }
	
	public static boolean isByteInRange(
            String value, String encoding, int min, int max) {

        // 検証値がnullまたは空文字の時、true返却
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 指定エンコーディングでバイト長を取得
        int bytesLength = 0;
        try {
            bytesLength = StringUtils.getByteLength(value, encoding);
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException(e.getMessage());
        }

        // バイト数チェック
        if (!GenericValidator.isInRange(bytesLength, min, max)) {
            return false;
        }
        return true;
    }
	
	public static boolean isNumericString(String value) {
        return matchRegexp(value, "^([0-9])*$");
    }
	
	public static boolean isDateInRange(
            String value, String startDateStr, String endDateStr,
            String datePattern, String datePatternStrict) {

        // 検証値がnullまたは空文字の時、true返却
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 入力日付の妥当性チェック
        Date result = toDate(value, datePattern, datePatternStrict);
        if (result == null) {
            return false;
        }

        if (GenericValidator.isBlankOrNull(startDateStr)
                && GenericValidator.isBlankOrNull(endDateStr)) {
            // 日付範囲が指定されていない場合は正常とみなす
            return true;
        }

        // 開始日付以降かどうかチェック
        if (!GenericValidator.isBlankOrNull(startDateStr)) {
            Date startDate =
                toDate(startDateStr, datePattern, datePatternStrict);

            if (startDate == null) {
                throw new IllegalArgumentException("startDate is unparseable["
                    + startDateStr + "]");
            }

            if (result.before(startDate)) {
                return false;
            }
        }

        // 終了日付以前かどうかチェック
        if (!GenericValidator.isBlankOrNull(endDateStr)) {
            Date endDate = toDate(endDateStr, datePattern, datePatternStrict);

            if (endDate == null) {
                throw new IllegalArgumentException("endDate is unparseable["
                    + endDateStr + "]");
            }

            if (result.after(endDate)) {
                return false;
            }
        }

        return true;
    }
	
	protected static boolean isZenkakuKanaChar(char c) {
        return zenkakuKanaList.indexOf(c) >= 0;
    }
	
	protected static boolean isZenkakuChar(char c) {
        return !isHankakuChar(c);
    }
	
	protected static boolean checkNumberFigures(
            int length, int checkLength, boolean isAccorded) {
        // 桁数オーバ時は、falseを返却
        if (length > checkLength) {
            return false;
        }

        // 一致指定されているとき
        if (isAccorded) {
            // 桁数不一致は、falseを返却
            if (length != checkLength) {
                return false;
            }
        }
        return true;
    }
	
	public static boolean matchRegexp(String value, String mask) {
        if (!StringUtils.isEmpty(value)
                && !GenericValidator.matchRegexp(value, mask)) {
            return false;
        }
        return true;
    }
	
}
