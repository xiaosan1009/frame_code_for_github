package co.jp.softbank.qqmx.logic.application.project.settings;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.LogCommand;
import org.eclipse.jgit.lib.AnyObjectId;
import org.eclipse.jgit.lib.Constants;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevObject;
import org.eclipse.jgit.revwalk.RevSort;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.treewalk.EmptyTreeIterator;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.TreeFilter;
import org.mozilla.universalchardet.UniversalDetector;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNLogEntry;
import org.tmatesoft.svn.core.SVNLogEntryPath;
import org.tmatesoft.svn.core.SVNNodeKind;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.BasicAuthenticationManager;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.fs.FSRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class ProjectRepositoryLogic extends AbstractBaseLogic {
	
	public void insertProjectRepositoryInfo() throws SVNException, SoftbankException, ParseException, IOException, Exception{
		
		String project_id = context.getParam().get("proId");
		//　プロジェクト基本情報取得する。
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(project_id));
		List<Map<String, Object>> getProjectRepository = db.querys("projectRepository.getProjectRepositoryInfo", conditions);
		
		for ( int m=0; m<getProjectRepository.size(); m++ ) {
			
			Map<String, Object> getMapProjectRepository = getProjectRepository.get(m);
			
			if ("Git".equals(getMapProjectRepository.get("type"))) {
		        // コマンド引数取得
		        String repoPath    = String.valueOf(getMapProjectRepository.get("url"));
		        // Git コミットログ取得
		        FileRepositoryBuilder builder = new FileRepositoryBuilder();
		        Repository repository = builder.setGitDir(new File(repoPath + Constants.DOT_GIT)).readEnvironment().findGitDir().build();
		        if (!(repository == null || repository.getAllRefs().isEmpty())) {
		            
		            Git gitBranch = new Git(repository);
		            List<Ref> callBranch = gitBranch.branchList().call();
		            int repositoryId = Integer.parseInt(String.valueOf(getMapProjectRepository.get("id")));
		            
		            Map<String, Object> repositorieInfos = Maps.newHashMap();
		            repositorieInfos.put("repository_id", repositoryId);
		            repositorieInfos.put("type", "g");
		            LogCommand gitLog = gitBranch.log();
		            
		            for ( Ref refBranch : callBranch ) {
	                    repositorieInfos.put("url", refBranch.getName());

	                    List<Map<String, Object>> getRepositorieInfos = db.querys("projectRepository.getRepositorieInfos", repositorieInfos);
	                    String repositorieInfoId = "";
	                    if (getRepositorieInfos.size() > 0){
	                    	repositorieInfoId = String.valueOf(getRepositorieInfos.get(0).get("last_scmid"));
	                    	repositorieInfos.put("last_scmid", refBranch.getObjectId().getName());
	                    	db.update("projectRepository.updateRepositorieInfos", repositorieInfos);
	                    } else {
	                    	repositorieInfos.put("last_scmid", refBranch.getObjectId().getName());
	                    	db.insert("projectRepository.insertRepositorieInfos", repositorieInfos);
	                    }
	                    
		            	
		            	Ref peeledRef = repository.peel(refBranch);
	                    if(peeledRef.getPeeledObjectId() != null) {
	                    	gitLog.add(peeledRef.getPeeledObjectId());
	                    } else {
	                    	gitLog.add(refBranch.getObjectId());
	                    }
	                    
	        			Iterable<RevCommit> logs = gitLog.call();
	        			for (RevCommit rev : logs) {
	        				if ("".equals(repositorieInfoId) || !refBranch.getObjectId().getName().equals(repositorieInfoId)){
	        				insertChangesets(rev, getMapProjectRepository, repository);
	        					System.out.println("rev.getName()" + rev.getName());
	        				}else{
	        					System.out.println("break");
	        					break;
	        				}
	        			}
		            }
		            
//		            Git gitTag = new Git(repository);
//		            List<Ref> callTag = gitTag.tagList().call();
//		            LogCommand tagLog = gitTag.log();
//		            
//		            for ( Ref refTag : callTag ) {
//
//	                    repositorieInfos.put("url", refTag.getName());
//	                    List<Map<String, Object>> getRepositorieInfos = db.querys("projectRepository.getRepositorieInfos", repositorieInfos);
//	                    
//	                    String repositorieInfoId = "";
//	                    
//	                    if (getRepositorieInfos.size() > 0){
//	                    	repositorieInfoId = String.valueOf(getRepositorieInfos.get(0).get("last_scmid"));
//	                    	repositorieInfos.put("last_scmid", refTag.getObjectId().getName());
//	                    	db.update("projectRepository.updateRepositorieInfos", repositorieInfos);
//	                    } else {
//	                    	repositorieInfos.put("last_scmid", refTag.getObjectId().getName());
//	                    	db.insert("projectRepository.insertRepositorieInfos", repositorieInfos);
//	                    }
//		            	
//		            	Ref peeledRef = repository.peel(refTag);
//		            	if(peeledRef.getPeeledObjectId() != null) {
//		            		tagLog.add(peeledRef.getPeeledObjectId());
//		            	} else {
//		            		tagLog.add(refTag.getObjectId());
//		            	}
//		            	
//		            	Iterable<RevCommit> logs = tagLog.call();
//		            	for (RevCommit rev : logs) {
//	        				if ("".equals(repositorieInfoId) || !refTag.getObjectId().getName().equals(repositorieInfoId)){
//	        					insertChangesets(rev, getMapProjectRepository, repository);
//	        				}else{
//	        					break;
//	        				}
//		            	}
//		            }
		        }
			}else if ("Subversion".equals(getMapProjectRepository.get("type"))) {
				//　データ初期化
				SVNURL url = null ;
				String user = "";
				String password = "";
				String reposUrl = "";
				int startRevision = 0;
				int endRevision = -1;
				int repositoryId = 0;
				
				user = String.valueOf(getMapProjectRepository.get("login"));
				password = String.valueOf(getMapProjectRepository.get("password"));
				reposUrl = String.valueOf(getMapProjectRepository.get("url"));
				Map<String, Object> conditionChangesets = Maps.newHashMap();
				repositoryId = Integer.parseInt(String.valueOf(getMapProjectRepository.get("id")));
				conditionChangesets.put("repository_id", repositoryId);
				// 開始リビジョンを取得する。
				List<Map<String, Object>> getChangesets = db.querys("projectRepository.getChangesetsInfo", conditionChangesets);
				if (getChangesets.get(0) != null){
					startRevision = Integer.parseInt(String.valueOf(getChangesets.get(0).get("revision"))) + 1;
				}
				
				try {
					// url の プロトコルが http, https, svn, svn+ssh, file の場合
					url = SVNURL.parseURIDecoded(reposUrl);
				} catch (SVNException svne) {
					try {
						// ファイルパスを直接指定した場合(例 C://svn/repos/)
						url = SVNURL.fromFile(new File(reposUrl));
					} catch (SVNException e) {
						throw svne;
					}
				}
				// プロトコルに応じたライブラリの初期化処理を行う
				String protocol = url.getProtocol();
				
				if (protocol.startsWith("http")) {
					DAVRepositoryFactory.setup();
				} else if (protocol.startsWith("svn")) {
					SVNRepositoryFactoryImpl.setup();
				} else if (protocol.startsWith("file")) {
					FSRepositoryFactory.setup();
				}
				
				SVNRepository repository = SVNRepositoryFactory.create(url);
				
				// リモート連携対応
				// 認証情報設定
				ISVNAuthenticationManager authManager = null;
				
				if (protocol.startsWith("http") || protocol.startsWith("svn")) {
					authManager = new BasicAuthenticationManager(user, password);
				}
				
				if (authManager != null) {
					repository.setAuthenticationManager(authManager);
				}
				
				Collection logEntries = null;
				logEntries = repository.log( new String[] {}, null, startRevision, endRevision, true, true);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				for (Iterator i = logEntries.iterator(); i.hasNext();) {
					SVNLogEntry logEntry = (SVNLogEntry) i.next();
					// changesets登録
					Map<String, Object> insertChangesets = Maps.newHashMap();
					insertChangesets.put("repository_id", repositoryId);
					insertChangesets.put("revision", logEntry.getRevision());
					insertChangesets.put("committer", logEntry.getAuthor());
					Timestamp time = new Timestamp(logEntry.getDate().getTime());
					insertChangesets.put("committed_on", time);
					insertChangesets.put("comments", logEntry.getMessage());
					insertChangesets.put("commit_date", sdf.parse(sdf.format(logEntry.getDate())));
					insertChangesets.put("scmid", "");
					Map<String, Object> conditionUsers = Maps.newHashMap();
					conditionUsers.put("login", logEntry.getAuthor());
					List<Map<String, Object>> getUserId = db.querys("projectRepository.getUserId", conditionUsers);
					if (getUserId.size() > 0 && getUserId.get(0) != null) {
						insertChangesets.put("user_id", Integer.parseInt(String.valueOf(getUserId.get(0).get("id"))));
					}else{
						insertChangesets.put("user_id", null);
					}
					db.insert("projectRepository.insertChangesetsInfo", insertChangesets);
					
					final int changesetId = Integer.parseInt(StringUtils.toString(insertChangesets.get("id")));
					
					if (logEntry.getChangedPaths().size() > 0) {
						Set changedPathsSet = logEntry.getChangedPaths().keySet();
						// ソースファイル数分繰り返し
						for (Iterator changedPaths = changedPathsSet.iterator(); changedPaths.hasNext();) {
							SVNLogEntryPath entryPath = (SVNLogEntryPath) logEntry.getChangedPaths().get(changedPaths.next());
							if (entryPath.getKind() == SVNNodeKind.FILE || entryPath.getKind() == SVNNodeKind.UNKNOWN) {
								// changes登録
								Map<String, Object> insertChanges = Maps.newHashMap();
								insertChanges.put("changeset_id", changesetId);
								insertChanges.put("action", entryPath.getType());
								insertChanges.put("path", entryPath.getPath());
								insertChanges.put("from_path", "");
								insertChanges.put("from_revision", "");
								insertChanges.put("revision", "");
								insertChanges.put("branch", "");
								db.insert("projectRepository.insertChangesInfo", insertChanges);
							}
						}
					}
				}
			}
		}
	}
	
	
	public void getProjectRepositoryInfo() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		String project_id = context.getParam().get("proId");
		conditions.put("project_id", Integer.parseInt(project_id));
		context.getResultBean().setData(db.querys("projectRepository.getRepositoryInfo" , conditions));
	}
	
	
	
    /**
     * 全リビジョンの RevCommit のリストを返す。
     * 
     * @param repository リポジトリ
     * @return RevCommit のリスト
     * @throws Exception 
     */
    public static Iterator<RevCommit> getRevList(Repository repository) throws Exception {
        
        Git git = new Git(repository);
        Iterable<RevCommit> irc = git.log().call();
        
        return irc.iterator();
    }
    
    /**
     * 全リビジョンの RevCommit のリストを返す。
     * 
     * @param repository リポジトリ
     * @return RevCommit のリスト
     * @throws Exception 
     */
    public void insertChangesets(RevCommit logEntry, Map<String, Object> getMapProjectRepository, Repository repository) throws Exception {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// changesets登録
		Map<String, Object> insertChangesets = Maps.newHashMap();
		insertChangesets.put("repository_id", getMapProjectRepository.get("id"));
		insertChangesets.put("revision", logEntry.getName());
		insertChangesets.put("committer", logEntry.getCommitterIdent().getName() + " <" + logEntry.getCommitterIdent().getEmailAddress() + ">");
//		Timestamp time = new Timestamp();
		insertChangesets.put("committed_on", new Date(logEntry.getCommitTime() * 1000L));
		insertChangesets.put("comments", logEntry.getFullMessage());
		insertChangesets.put("commit_date", sdf.parse(sdf.format(new Date(logEntry.getCommitTime() * 1000L))));
		insertChangesets.put("scmid", logEntry.getName());
		Map<String, Object> conditionUsers = Maps.newHashMap();
		conditionUsers.put("login", logEntry.getCommitterIdent().getName());
		List<Map<String, Object>> getUserId = db.querys("projectRepository.getUserId", conditionUsers);
		if (getUserId.size() > 0 && getUserId.get(0) != null) {
			insertChangesets.put("user_id", Integer.parseInt(String.valueOf(getUserId.get(0).get("id"))));
		}else{
			insertChangesets.put("user_id", null);
		}
		db.insert("projectRepository.insertChangesetsInfo", insertChangesets);
		final int changesetId = Integer.parseInt(StringUtils.toString(insertChangesets.get("id")));
		insertChanges(logEntry, repository, changesetId);
    }
    
    /**
     * 全リビジョンの RevCommit のリストを返す。
     * 
     * @param repository リポジトリ
     * @return RevCommit のリスト
     * @throws Exception 
     */
    public void insertChanges(RevCommit logEntry, Repository repository, int changesetId) throws Exception {
		TreeWalk twalk = null;
		RevWalk rwalk = null;
        // リビジョンリストを取得
        rwalk = getAllRevWalk(repository);
		twalk = getTreeWalk(repository, logEntry, rwalk);
        // ソースファイル数分繰り返し
        while (twalk.next()) {
            // ソースファイル取得、ソース規模情報取得、DB登録
            byte[] filePathBytes = twalk.getRawPath();                          // ファイルフルパス（ファイル名含む） バイト配列
            String filePath      = getDecodeStr(filePathBytes);    // ファイルフルパス（ファイル名含む）
            AnyObjectId[] objectIds = new AnyObjectId[2];
            char chg            = getChangeType(twalk, objectIds);   // 変更種別
			// changes登録
			Map<String, Object> insertChanges = Maps.newHashMap();
			insertChanges.put("changeset_id", changesetId);
			insertChanges.put("action", chg);
			insertChanges.put("path", filePath);
			insertChanges.put("from_path", "");
			insertChanges.put("from_revision", "");
			insertChanges.put("revision", "");
			insertChanges.put("branch", "");
			db.insert("projectRepository.insertChangesInfo", insertChanges);
            
        }
    }
    
    /**
     * 指定したリビジョンの RevCommit のリストを返す。
     * 
     * @param repository リポジトリ
     * @param oldRev 旧リビジョン
     * @return RevCommit のリスト
     * @throws Exception 
     */
    public static Iterator<RevCommit> getRevList(Repository repository,
            String oldRev) throws Exception {
        
        // 旧リビジョン
        ObjectId oldObjId = repository.resolve(oldRev);

        Git git = new Git(repository);
        Iterable<RevCommit> irc = null;
        if (oldObjId.equals(RevObject.zeroId())) {
            // リビジョンが ALL 0 の場合
            irc = git.log().call();
        } else {
            irc = git.log().not(oldObjId).call();
        }
        
        return irc.iterator();
    }
    
    /**
     * 指定したリビジョンの RevCommit のリストを返す。
     * 
     * @param repository リポジトリ
     * @param oldRev 旧リビジョン
     * @param newRev 新リビジョン
     * @return RevCommit のリスト
     * @throws Exception 
     */
    public static Iterator<RevCommit> getRevList(Repository repository,
            String oldRev, String newRev) throws Exception {
        
        // 旧リビジョン
        ObjectId oldObjId = repository.resolve(oldRev);
        // 新リビジョン
        ObjectId newObjId = repository.resolve(newRev);
        
        Git git = new Git(repository);
        Iterable<RevCommit> irc = null;
        if (oldObjId.equals(RevObject.zeroId())) {
            // リビジョンが ALL 0 の場合
            irc = git.log().add(newObjId).call();
        } else {
            irc = git.log().addRange(oldObjId, newObjId).call();
        }
        return irc.iterator();
    }
    
    /**
     * 変更種別、変更前・変更後のオブジェクトIDを返す。
     * 
     * @param tWalk TreeWalk
     * @param objectIds 変更前、変更後のオブジェクトIDをセットして返す。
     *                  インデックス 0 : 変更前オブジェクトID
     *                  インデックス 1 : 変更後オブジェクトID
     * @return 変更種別(A:新規追加, M:変更, D:削除)
     */
    public static char getChangeType(TreeWalk tWalk, AnyObjectId[] objectIds) {
        
        char chg = 'M';
        int nTree = tWalk.getTreeCount();
        if (nTree == 1) {
            int m0 = tWalk.getRawMode(0); // new
            if (m0 != 0) {
                chg = 'A';
                objectIds[0] = tWalk.getObjectId(0); // new
            }
        } else if (nTree == 2) {
            int m0 = tWalk.getRawMode(0); // old
            int m1 = tWalk.getRawMode(1); // new
            if (m0 == 0 && m1 != 0) {
                chg = 'A';
            } else if (m0 != 0 && m1 == 0) {
                chg = 'D';
            } else if (m0 != m1 && tWalk.idEqual(0, 1)) {
                chg = 'T';
            }
            if (m0 != 0) {
                objectIds[0] = tWalk.getObjectId(0); // old
            }
            if (m1 != 0) {
                objectIds[1] = tWalk.getObjectId(1); // new
            }
        }
        
        return chg;
    }
    
    /**
     * バイト配列を文字列に変換して返す。
     * 
     * @param バイト配列
     * @return 文字列
     */
    public static String getDecodeStr(byte[] bytes) {
        
        String encoding = getEncoding(bytes);
        
        String decodeStr = null;
        try {
            if ("UTF-8".equals(encoding) ||
            		"EUC-JP".equals(encoding)) {
                // encoding
                decodeStr = new String(bytes, encoding);
            } else if ("SHIFT_JIS".equals(encoding)) {
                // MS932
                decodeStr = new String(bytes, "MS932");
            } else {
                // JISAutoDetect
                decodeStr = new String(bytes, "JISAutoDetect");
            }
        } catch (UnsupportedEncodingException e) {
            //
        }
        
        return decodeStr;
    }

    /**
     * バイト配列の文字コードを判別して返す。
     * 
     * @param バイト配列
     * @return 文字コード
     */
    public static String getEncoding (byte[] bytes) {
        
        String encoding = null;
        
        /** 文字コード判定用クラス */
        UniversalDetector detector = new UniversalDetector(null);
        
        ByteArrayInputStream bis = null;
        try {
            bis = new ByteArrayInputStream(bytes);
            byte[] buf = new byte[4096];
            int nread;
            while ((nread = bis.read(buf)) > 0 && !detector.isDone()) {
                detector.handleData(buf, 0, nread);
            }
            detector.dataEnd();
            
            if (detector.getDetectedCharset() != null) {
                encoding = detector.getDetectedCharset();
            }
            
        } catch (Exception e) {
            //
        } finally {
            IOUtils.closeQuietly(bis);
            detector.reset();
        }
        return encoding;
    }
    
    /**
     * 変更前、変更後ファイル比較用の TreeWalk を返す。
     * 
     * @param repository リポジトリ
     * @param commit 指定リビジョンの RevCommit
     * @param rwalk RevWalk
     * @return 変更前、変更後ファイル比較用の TreeWalk
     * @throws Exception 
     */
    public static TreeWalk getTreeWalk(
            Repository repository, 
            RevCommit commit, 
            RevWalk rwalk) throws Exception {
        
        TreeWalk twalk = new TreeWalk(repository);
        
        if (commit.getParentCount() > 0) {
            RevCommit parent = commit.getParent(0);
            if (parent.getTree() == null) {
                // リビジョン指定で実行した場合、親リビジョンの RevTree が取得できないので、
                // RevWalk から親リビジョンを取得してから RevTree を取得する。
                parent = rwalk.parseCommit(parent.getId());
            }
            twalk.addTree(parent.getTree());
            twalk.addTree(commit.getTree());
        } else {
            twalk.addTree(new EmptyTreeIterator());
            twalk.addTree(commit.getTree());
        }
        twalk.setRecursive(true);
        twalk.setFilter(TreeFilter.ANY_DIFF);
        return twalk;
    }
    
    /**
     * 全てのブランチを含むの RevWalk を返す。
     * 
     * @param repository リポジトリ
     * @param oldRev 旧リビジョン
     * @param newRev 新リビション
     * @return 全てのブランチを含むの RevWalk
     * @throws Exception 
     */
    public static RevWalk getAllRevWalk(Repository repository) 
            throws Exception {
        
        RevWalk rwalk = new RevWalk(repository);
        
        Map<String, Ref> map = repository.getAllRefs();
        Collection<RevCommit> list = new ArrayList<RevCommit>();
        for (Entry<String, Ref> entry : map.entrySet()) {
            String  name = entry.getKey();
            Ref     ref  = entry.getValue();
            RevCommit revCommit = rwalk.parseCommit(ref.getObjectId());
            list.add(revCommit);
        }
        rwalk.markStart(list);
        rwalk.sort(RevSort.REVERSE);
        return rwalk;
    }
}
