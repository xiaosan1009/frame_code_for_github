package co.jp.softbank.qqmx.task.bean;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.io.FileUtils;

import co.jp.softbank.qqmx.util.ConstantsUtil;

public class FileBean {
	
	private String abstractPath;
	
	private String projectId;
	
	private String projectName;
	
	private String resourceId;
	
	private String resourceName;
	
	private String fileName;
	
	private String fileSuffix;
	
	private String[] classPath;
	
	private String[] sourcePath;

	public String getAbstractPath() {
		return abstractPath;
	}

	public void setAbstractPath(String abstractPath) {
		this.abstractPath = abstractPath;
	}

	public String[] getClassPath() {
		return classPath;
	}

	public void setClassPath(String[] classPath) {
		this.classPath = classPath;
	}

	public String[] getSourcePath() {
		return sourcePath;
	}

	public void setSourcePath(String[] sourcePath) {
		this.sourcePath = sourcePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
		fileSuffix = fileName.substring(fileName.lastIndexOf(ConstantsUtil.Str.DOT) + 1);
	}

	public String getFileSuffix() {
		return fileSuffix;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public void setFileSuffix(String fileSuffix) {
		this.fileSuffix = fileSuffix;
	}

}
