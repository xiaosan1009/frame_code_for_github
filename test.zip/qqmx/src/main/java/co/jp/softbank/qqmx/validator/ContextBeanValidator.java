package co.jp.softbank.qqmx.validator;

import java.util.Map;

import org.apache.commons.validator.ValidatorException;
import org.springframework.validation.Errors;
import org.springmodules.validation.commons.ValidatorFactory;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class ContextBeanValidator implements IBeanValidator {
	
	public static final String SOFTBANK_VALIDATOR_DAO_KEY = "co.jp.softbank.qqmx.dao.common.IDbExecute";
	
	public static final String SOFTBANK_VALIDATOR_PARAM_KEY = "java.util.Map";
	
	private ValidatorFactory validatorFactory;
	
	private Object dao;
	
	public void validate(Object obj, Errors errors) {
        org.apache.commons.validator.Validator commonsValidator = getValidator(obj, errors);
        try {
        	if (dao != null) {
				commonsValidator.setParameter(SOFTBANK_VALIDATOR_DAO_KEY, dao);
			}
        	commonsValidator.setParameter(SOFTBANK_VALIDATOR_PARAM_KEY, null);
            commonsValidator.validate();
        } catch (ValidatorException e) {
        } finally {
            cleanupValidator(commonsValidator);
        }
    }
	
	public void validate(Object obj, Object param, Errors errors) {
		org.apache.commons.validator.Validator commonsValidator = getValidator(obj, errors);
		try {
			if (dao != null) {
				commonsValidator.setParameter(SOFTBANK_VALIDATOR_DAO_KEY, dao);
			}
			commonsValidator.setParameter(SOFTBANK_VALIDATOR_PARAM_KEY, param);
			commonsValidator.validate();
		} catch (ValidatorException e) {
		} finally {
			cleanupValidator(commonsValidator);
		}
	}
	
	public void setValidatorFactory(ValidatorFactory validatorFactory) {
        this.validatorFactory = validatorFactory;
    }
	
	protected void cleanupValidator(org.apache.commons.validator.Validator validator) {
    }
	
	private org.apache.commons.validator.Validator getValidator(Object obj, Errors errors) {
		String dispcode = null;
		String cmdCode = null;
		if (obj instanceof HttpContext) {
			dispcode = ((HttpContext)obj).getParam().dispCode;
			cmdCode = ((HttpContext)obj).getParam().cmdCode;
		} else if (obj instanceof Map) {
			dispcode = StringUtils.toString(((Map)obj).get("dispCode"));
			cmdCode = StringUtils.toString(((Map)obj).get("cmdCode"));
		} else {
			return null;
		}
		if (StringUtils.isEmpty(dispcode) || StringUtils.isEmpty(cmdCode)) {
			return null;
		}
		dispcode += ConstantsUtil.Str.UNDERLINE + cmdCode;
        return this.validatorFactory.getValidator(dispcode, obj, errors);
    }

	@Override
	public boolean supports(Class<?> arg0) {
		return true;
	}

	@Override
	public void setDao(IDbExecute dao) {
		this.dao = dao;
	}
}
