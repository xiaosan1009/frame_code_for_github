package co.jp.softbank.qqmx.handle;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.ControlScriptHandler;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.EngineScriptUtil;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.ScriptEngineUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class AbstractScriptEngineHandler extends AbstractBaseLogic {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	protected ScriptEngine scriptEngine;
    
    public AbstractScriptEngineHandler() {
    	ScriptEngineManager manager = new ScriptEngineManager();
    	scriptEngine = manager.getEngineByName("js");
	}
    
    @Override
    public void applicationInit(HttpContext httpContext) throws SoftbankException {
    	super.applicationInit(httpContext);
    	if (scriptEngine == null || httpContext.getParam() == null) {
			return;
		}
    	
    	ControlScriptHandler scriptHandler = ControlScriptHandler.getInstance();
    	String script = scriptHandler.getScript(httpContext.getParam().dispCode);
    	if (StringUtils.isEmpty(script)) {
			return;
		}
    	
    	try {
    		script = ScriptEngineUtil.createScriptImport() + script;
			scriptEngine.eval(script);
			setHandlerMethod(httpContext);
			
		} catch (ScriptException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.ScriptException, e);
		}
    	log.debug(ConstantsUtil.Log.END_SIGN);
    }
	
	private void setHandlerMethod(HttpContext httpContext) {
		scriptEngine.put("_log", log);
		scriptEngine.put("_util", new EngineScriptUtil(httpContext));
		scriptEngine.put("_context", httpContext);
		scriptEngine.put("_request", httpContext.getParam());
		scriptEngine.put("_session", httpContext.getSessionData());
		scriptEngine.put("_application", httpContext.getContext());
		scriptEngine.put("_result", httpContext.getResultBean());
		scriptEngine.put("_db", db);
//		scriptEngine.put("_format", handlerMethod.getFormat());
//		scriptEngine.put("_external", handlerMethod.getExternal());
//		scriptEngine.put("_sutil", handlerMethod.getScriptUtil());
//		scriptEngine.put("_dataSource", handlerMethod.getDataSource());
	}

	public void execute(String method) throws SoftbankException {
		Invocable inv = (Invocable) scriptEngine;
		try {
			inv.invokeFunction(method);
		} catch (NoSuchMethodException e) {
			throw new SoftbankException(SoftbankExceptionType.NoSuchMethodException, e);
		} catch (ScriptException e) {
			throw new SoftbankException(SoftbankExceptionType.ScriptException, e);
		}
	}
    
}
