package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.RoleListDao;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class RoleListLogic extends AbstractBaseLogic {

	@Autowired
	private RoleListDao roleListDao;

	public void getRoleListInfo() throws SoftbankException {
/*		List<Map<String, Object>> RoleList = roleListDao.getRoleListInfo();
		context.getResultBean().setData(RoleList);*/
		PageListBean pageListBean = pageList(roleListDao, "getRoleListInfo");
		context.getResultBean().setData(pageListBean);
	}
	
	public void deleteRoleInfo() throws SoftbankException {
		int role_id = Integer.valueOf(context.getParam().get("role_id"));
		Map<String, Object> roleMap = Maps.newHashMap();
		
		roleMap.put("role_id", role_id);
		
		roleListDao.updateRoleInfo(roleMap);
		roleListDao.deleteRoleInfo(roleMap);
		roleListDao.deleteWorkflowsInfo(roleMap);
	}
	
	public void editRoleList() throws SoftbankException {
		
		List<Map<String, Object>> getRoleListInfo = roleListDao.getRoleListInfo();
		for (int n = 0; n < getRoleListInfo.size(); n++){
			Map<String, Object> roleMap = Maps.newHashMap();
			String[] permissions = context.getParam().getList(String.valueOf(getRoleListInfo.get(n).get("name")));
			roleMap.put("name", String.valueOf(getRoleListInfo.get(n).get("name")));
			List<String> permissionsList = Lists.newArrayList(); 
			for (int p = 0; p < permissions.length; p++) {
				permissionsList.add(":" + permissions[p]);
			}
			roleMap.put("permissions", Yaml.dump(permissionsList));
			roleListDao.updateRoleListInfo(roleMap);
		}

	}
	
	public LogicBean getReportList() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		Map<String, Object> roleMap = Maps.newHashMap();
		List<Map<String, Object>> roledataListMap = Lists.newArrayList();
		Map<String, Object> roleDataMap = Maps.newHashMap();

		List<Map<String, Object>> getRoleListInfo = roleListDao.getRoleListInfo();
		NewRoleBean roleListBean = new NewRoleBean();
		List<String> roleList = Lists.newArrayList();
		for (int n = 0; n < getRoleListInfo.size(); n++){
			roleList.add(String.valueOf(getRoleListInfo.get(n).get("name")));
		}
		roleListBean.setNewRoleMap(roleList);
		
		List<NewRoleBean> resultBean = Lists.newArrayList();
		List<Map<String, Object>> rolesBaseSubList = roleListDao.getRolesBaseSubList();
		
		for (int j = 0; j < rolesBaseSubList.size(); j++) {
			NewRoleBean newRoleBean = new NewRoleBean();
			Map<String, Object> rolesBaseSubData = rolesBaseSubList.get(j);
			
			newRoleBean.setId(Integer.valueOf(String.valueOf(rolesBaseSubData.get("id"))));
			newRoleBean.setName(String.valueOf(rolesBaseSubData.get("name")));
			newRoleBean.setValue(String.valueOf(rolesBaseSubData.get("value")));
			
			List<String> roleFlagList = Lists.newArrayList();
			if (rolesBaseSubData.get("value") != null){
				Map<String, Object> rolesCheck = Maps.newHashMap();
				rolesCheck.put("value", rolesBaseSubData.get("value"));
				List<Map<String, Object>> rolesCheckFlg = roleListDao.getRolesCheckFlg(rolesCheck);
				for (int m = 0; m < rolesCheckFlg.size(); m++){
					String flg = "f";
					if (rolesCheckFlg.get(m).get("value_id") != null) flg = "t";
					roleFlagList.add(flg);
				}
			}
			newRoleBean.setRoleFlagMap(roleFlagList);
			
			resultBean.add(newRoleBean);	
		}

		roleDataMap.put("data", resultBean);
		roleDataMap.put("roleHeadList", roleListBean);
		roledataListMap.add(roleDataMap);
			
		roleMap.put("roleList", roledataListMap);
		logicBean.setData(roleMap);
		return logicBean;
	}
	
	public void upRoleSort() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		List<Map<String, Object>> roleListEndIdList = roleListDao.getRoleListInfo();
		String str_end_position = String.valueOf(roleListEndIdList.get(Integer.parseInt(context.getParam().get("end_pos"))).get("position"));
		
		conditions.put("role_id", Integer.parseInt(context.getParam().get("role_id")));
		List<Map<String, Object>> roleListIdList = roleListDao.getRoleSortIdInfo(conditions);
		if (Integer.parseInt(str_end_position) > Integer.parseInt(String.valueOf(roleListIdList.get(0).get("position")))){
			conditions.put("end_pos", Integer.parseInt(str_end_position));
			conditions.put("start_pos", Integer.parseInt(String.valueOf(roleListIdList.get(0).get("position"))));
			roleListDao.upCommonMSort(conditions);
		}else{
			conditions.put("end_pos", Integer.parseInt(String.valueOf(roleListIdList.get(0).get("position"))));
			conditions.put("start_pos", Integer.parseInt(str_end_position));
			roleListDao.upCommonPSort(conditions);
		}
		Map<String, Object> conditionSort = Maps.newHashMap();
		conditionSort.put("role_id", Integer.parseInt(context.getParam().get("role_id")));
		conditionSort.put("end_pos", Integer.parseInt(str_end_position));
		roleListDao.upCommonSort(conditionSort);

	}
}
