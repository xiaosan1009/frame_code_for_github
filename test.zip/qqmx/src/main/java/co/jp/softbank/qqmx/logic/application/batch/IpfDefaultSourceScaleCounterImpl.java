/**
 *   <Quantitative project management tool.>
 *   Copyright (C) 2012 IPA, Japan.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package co.jp.softbank.qqmx.logic.application.batch;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.mozilla.universalchardet.UniversalDetector;

import tk.stepcounter.StepCounter;
import tk.stepcounter.StepCounterFactory;

/**
 * ソースステップ数カウント用デフォルトクラス
 * 
 */
/**
 * @author sugawara.norikazu
 *
 */
public class IpfDefaultSourceScaleCounterImpl extends IpfSourceScaleCounter {
    
    /** ロガー */
    protected static Logger log = Logger.getLogger(SourceScaleCount.LOGGER_NAME);
    
    /** 文字コード判定用クラス */
    protected static UniversalDetector detector = new UniversalDetector(null);
    
    /**
     * ファイルの文字コードを判別して返す。
     * 
     * @param file ファイル
     * @return 文字コード
     */
    private static String getEncoding(File file) {
        
        String encoding = System.getProperty("file.encoding");
        
        FileInputStream fis = null;
        try {
            byte[] buf = new byte[4096];
            fis = FileUtils.openInputStream(file);
            int nread;
            while ((nread = fis.read(buf)) > 0 && !detector.isDone()) {
                detector.handleData(buf, 0, nread);
            }
            detector.dataEnd();
            
            if (detector.getDetectedCharset() != null) {
                encoding = detector.getDetectedCharset();
            }
            
        } catch (Exception e) {
            //
        } finally {
            IOUtils.closeQuietly(fis);
            detector.reset();
        }
        log.debug(String.format("Encodeing : %s (%s).", file, encoding));
        return encoding;
    }
    
    
    /* (非 Javadoc)
     * @see jp.go.ipa.ipf.sourcescale.counter.IpfSourceScaleCounter#setFileExt(java.util.List)
     */
    @Override
	public void setFileExt(List<String> fileExtList) {
		// デフォルトクラスのため全ての拡張子に対応
	}

	/* (非 Javadoc)
	 * @see jp.go.ipa.ipf.sourcescale.counter.IpfSourceScaleCounter#isCountable(java.lang.String)
	 */
	public boolean isCountable(String filename) {
	    
        // ファイルタイプに応じたカッターが存在するかチェックする
        StepCounter counter = StepCounterFactory.getCounter(filename);
        if (counter != null) {
            return true;
        }
	    return false;
	}

}
