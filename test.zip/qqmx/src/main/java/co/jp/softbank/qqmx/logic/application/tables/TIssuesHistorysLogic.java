package co.jp.softbank.qqmx.logic.application.tables;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class TIssuesHistorysLogic extends AbstractBaseLogic {
	
	public void selectIssuesTimeline() throws SoftbankException {
		context.getResultBean().setData(db.querys("issues_historys.selectIssuesTimeline"));
	}
}
