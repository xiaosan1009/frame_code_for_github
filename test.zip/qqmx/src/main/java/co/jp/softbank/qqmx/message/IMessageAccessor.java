package co.jp.softbank.qqmx.message;

import java.util.Locale;

import co.jp.softbank.qqmx.application.bean.HttpContext;

public interface IMessageAccessor {
	
	public String getMessage(String code);
	
	public String getMessage(String code, Object[] args);
	
	public String getMessage(String code, Object[] args, Locale locale);
	
	public String getMessage(String code, Object[] args, HttpContext context);
	
	public String getMessage(String code, Object[] args, String defaultMessage, HttpContext context);

}
