package co.jp.softbank.qqmx.server.impl;

import java.io.IOException;

import javax.websocket.Session;

import net.sf.json.JSONObject;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.server.bean.SocketClientChatInfo;
import co.jp.softbank.qqmx.server.bean.SocketClientInfo;
import co.jp.softbank.qqmx.server.face.ISocketLogicInterface;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.SocketClientManager;

public class UserChatLogicImpl extends AbstractSocketLogic implements ISocketLogicInterface {

	@Override
	public void recieve(Session sendSession, JSONObject message) throws SoftbankException {
		String action = message.getString("action");
		try {
			if ("loadUser".equals(action)) {
				final String allUserInfos = getResultData("open", manager.getAllUserInfo());
				sendSession.getBasicRemote().sendText(allUserInfos);
			} else if ("closed".equals(action)) {
				sendAllConnUserToActive();
			} else if ("conn".equals(action)) {
				final String myInfo = getResultData("conn", manager.getSocketClientBySession(sendSession).toJsonObj());
				sendSession.getBasicRemote().sendText(myInfo);
			} else if ("sendMsg".equals(action)) {
				SocketClientInfo clientInfo = manager.getSocketClientBySession(sendSession);
				SocketClientChatInfo chatInfo = new SocketClientChatInfo(clientInfo);
				chatInfo.setChatTime(DateUtils.getNow(DateUtils.FORMAT_YYYYMMDDHHMMSS_DASH));
				chatInfo.setChatMsg(message.getString("msg"));
				chatInfo.setTo(message.getString("to"));
				JSONObject msgJson = new JSONObject();
				msgJson.put("from", chatInfo.toJsonObj());
				String sendMsg = getResultData("receive", msgJson);
				manager.sendToUser(message.getString("to"), sendMsg);
				sendSession.getBasicRemote().sendText(sendMsg);
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException);
		}
	}

	@Override
	public void connect(Session connSession) throws SoftbankException {
		sendAllConnUserToActive();
	}
	
	private void sendAllConnUserToActive() {
		final String allUserInfos = getResultData("open", manager.getAllUserInfo());
		manager.execute(new SocketClientManager.ExecuteLisener() {
			
			@Override
			public void execute(SocketClientInfo clientInfo) {
				try {
					clientInfo.getSession().getBasicRemote().sendText(allUserInfos);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	@Override
	public void closed(Session connSession) {
		sendAllConnUserToActive();
	}

}
