package co.jp.softbank.qqmx.task.info;

import java.io.Closeable;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import co.jp.softbank.qqmx.exception.SoftbankCollectorException;
import co.jp.softbank.qqmx.exception.SoftbankSystemException;
import co.jp.softbank.qqmx.task.bean.DataObjectBean;
import co.jp.softbank.qqmx.task.face.ICollector;
import co.jp.softbank.qqmx.task.face.ICollectorExceptionHandler;
import co.jp.softbank.qqmx.task.face.ICollectorStatus;

public abstract class AbstractCollector<P> implements ICollector<P>, Closeable, Callable<Integer>, Cloneable {
	
	protected static final int DEFAULT_SLEEP_WAIT = 1;
	
	protected int sleepWait = DEFAULT_SLEEP_WAIT;
	
	protected static final int CURRENT_QUEUE_CHECK_SIZE = 1;

    protected static final int PREVIOUS_QUEUE_CHECK_SIZE = 2;
	
	protected BlockingQueue<DataObjectBean> queue;
	
	protected Queue<DataObjectBean> currentQueue = null;

    protected Queue<DataObjectBean> previousQueue = null;
	
	protected volatile Future<?> fo = null;
	
	protected volatile boolean start;
	
	protected AbstractCollector<?> child = null;
	
	protected ICollectorExceptionHandler exceptionHandler = null;
	
	protected AtomicLong acquireDataCount = new AtomicLong(0);
	
	protected volatile boolean finish = false;
	
	protected void execute() {
        if (this.start) {
            return;
        }
        synchronized (this) {
            if (!this.start) {
                try {
                    beforeExecute();

                    if (this.queue == null) {
                        this.queue = createQueue();
                    }

                    if (this.fo == null) {
                        Callable<Integer> callable = null;
                        try {
                            callable = (Callable<Integer>) this.clone();
                        } catch (CloneNotSupportedException e) {
                        	SoftbankSystemException exception = new SoftbankSystemException(e, "The clone cannot be made.");
                            throw exception;
                        }

                        if (callable instanceof AbstractCollector) {
                            this.child = (AbstractCollector) callable;
                        }

                        ExecutorService ex = getExecutor();

                        try {
                            this.fo = ex.submit(callable);
                        } catch (Throwable e) {
                        	SoftbankSystemException exception = new SoftbankSystemException(e, "The thread cannot be started.");
                            throw exception;
                        } finally {
                            ex.shutdown();
                        }
                    }
                } finally {
                    afterExecute();
                }

                this.start = true;
            }
        }
    }
	
	protected BlockingQueue<DataObjectBean> createQueue() {
		if (this.currentQueue == null) {
            this.currentQueue = createCurrentQueue();
        }
        if (this.previousQueue == null) {
            this.previousQueue = createPreviousQueue();
        }
        return new LinkedBlockingDeque<DataObjectBean>();
    }
	
	protected Queue<DataObjectBean> createCurrentQueue() {
        return new ConcurrentLinkedQueue<DataObjectBean>();
    }
	
	protected Queue<DataObjectBean> createPreviousQueue() {
        return new ConcurrentLinkedQueue<DataObjectBean>();
    }
	
	protected ExceptionHandlerStatus handleException(DataObjectBean data) {
		ExceptionHandlerStatus result = data.getExceptionStatus();
        if (result != null) {
            return result;
        }

        if (this.exceptionHandler != null) {
            result = this.exceptionHandler.handleException(data);
            data.setExceptionStatus(result);
        }
        return result;
    }
	
	protected ExecutorService getExecutor() {
        return Executors.newSingleThreadExecutor(createThreadFactory());
    }

    protected ThreadFactory createThreadFactory() {
        return new CollectorThreadFactory();
    }
	
	protected void beforeExecute() {
    }
	
	protected void afterExecute() {
    }

	@Override
	public boolean hasNext() {
        execute();

        while (true) {
            if (this.queue != null && !this.queue.isEmpty()) {
            	DataObjectBean value = null;
                value = this.queue.peek();

                if (value != null && value.getThrowable() != null
                        && this.exceptionHandler != null) {
                	ExceptionHandlerStatus es = null;
                    try {
                        es = handleException(value);
                    } catch (Throwable e) {
                    }
                    if (ExceptionHandlerStatus.SKIP.equals(es)) {
                        acquireDataCount.incrementAndGet();
                        value = null;
                        this.queue.poll();
                        continue;
                    } else if (ExceptionHandlerStatus.END.equals(es)) {
                        this.queue.poll();
                        break;
                    }
                }

                // コレクタステータスを取得
                if (value != null && value.getCollectorStatus() != null) {

                    this.queue.poll();
                    ICollectorStatus collectorStatus = value.getCollectorStatus();
                    if (ICollectorStatus.END.equals(collectorStatus)) {
                        setFinish(true);
                        if (!this.queue.isEmpty()) {
                            continue;
                        }
                        break;
                    }
                }
                return true;
            }

            if (isFinish() && this.queue.isEmpty()) {
                break;
            }

            try {
                Thread.sleep(this.sleepWait);

            } catch (InterruptedException e) {
                break;
            }
        }

        return false;
    }
	
	protected void addQueue(DataObjectBean dataValueObject) throws InterruptedException {
		addQueue(dataValueObject, false);
	}
	
	protected void addQueue(DataObjectBean dataValueObject, boolean force) throws InterruptedException {
		if (force && this.queue != null) {
			this.queue.offer(dataValueObject);
			return;
		}

		boolean finish = isFinish();

		if (!finish) {
			this.queue.put(dataValueObject);
		} else {
			throw new InterruptedException("The stop demand of the thread is carried out.");
		}
	}
	
	protected void setFinish() {
        setFinish(true);

        try {
            addQueue(new DataObjectBean(ICollectorStatus.END), true);
        } catch (InterruptedException ie) {
        }
    }
	
	protected void setFinish(boolean finish) {
        this.finish = finish;
    }
	
	protected boolean isFinish() {
        boolean finish = this.finish;
        AbstractCollector<?> localChild = this.child;
        Future<?> future = this.fo;

        if (future != null) {
            boolean done = future.isDone();

            if (localChild != null) {
                if (localChild.isFinish()) {
                    finish = localChild.isFinish();
                }
            }
            return finish || done;
        }

        if (localChild != null) {
            if (localChild.isFinish()) {
                finish = localChild.isFinish();
            }
        }
        return finish;
    }
	
	@Override
	public P next() {
		execute();

        P pn = getNext();
        
        if (pn != null) {
            if (this.previousQueue != null) {
                while (this.previousQueue.size() > PREVIOUS_QUEUE_CHECK_SIZE) {
                    this.previousQueue.remove();
                }
                this.previousQueue.add(new DataObjectBean(pn));
            }
            if (this.currentQueue != null) {
                while (this.currentQueue.size() > CURRENT_QUEUE_CHECK_SIZE) {
                    this.currentQueue.remove();
                }
                this.currentQueue.add(new DataObjectBean(pn));
            }
        }

        DataObjectBean value = null;
        ExceptionHandlerStatus es = null;
        do {
            try {
                value = this.queue.poll(this.sleepWait, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                break;
            }

            if (isFinish() && this.queue.isEmpty()) {
                break;
            }

            if (value != null) {
                if (value.getThrowable() != null
                        && this.exceptionHandler != null) {
                    try {
                        es = handleException(value);
                    } catch (Throwable e) {
                    }
                    if (ExceptionHandlerStatus.SKIP.equals(es)) {
                        acquireDataCount.incrementAndGet();
                        es = null;
                        value = null;
                        continue;
                    }
                }
            }
        } while (value == null);

        if (value == null) {
            throw new NoSuchElementException();
        } else if (value.getCollectorStatus() != null) {
        	ICollectorStatus collectorStatus = value.getCollectorStatus();
            if (ICollectorStatus.END.equals(collectorStatus)) {
                setFinish(true);
            }
            throw new NoSuchElementException();
        } else if (value.getValue() == null) {
            acquireDataCount.incrementAndGet();
            if (value.getThrowable() != null) {
                Throwable throwable = value.getThrowable();

                if (es == null
                        || ExceptionHandlerStatus.THROW.equals(es)) {
                    if (throwable instanceof RuntimeException) {
                        throw (RuntimeException) throwable;
                    } else {
                        throw new SoftbankSystemException(throwable);
                    }
                } else if (ExceptionHandlerStatus.END.equals(es)) {
                    this.close();
                }
            }
            throw new NoSuchElementException();
        }

        if (value != null) {
            long dtcnt = acquireDataCount.incrementAndGet();
            if (dtcnt != value.getIndex()) {
                StringBuilder sb = new StringBuilder();
                sb.append("dtcnt:");
                sb.append(dtcnt);
                sb.append(" DataObjectBean dataCount:");
                sb.append(value.getIndex());

                DataObjectBean next = this.queue.peek();
                if (next != null) {
                    sb.append(" getNext() dataCount:");
                    sb.append(next.getIndex());
                }

                DataObjectBean previous = this.previousQueue.peek();
                if (previous != null) {
                    sb.append(" getPrevious dataCount:");
                    sb.append(previous.getIndex());
                }

                DataObjectBean current = this.currentQueue.peek();
                if (current != null) {
                    sb.append(" getCurrent dataCount:");
                    sb.append(current.getIndex());
                }
                throw new SoftbankCollectorException(sb.toString());
            }
        }

        return (P) value.getValue();
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public Iterator<P> iterator() {
		return this;
	}
	
	@Override
	public void close() {
        if (!isFinish()) {
            if (this.fo != null) {
                this.fo.cancel(true);
            }
        }
    }

	@Override
	public P getPrevious() {
		execute();

        if (this.previousQueue != null && this.previousQueue.size() > 1) {
            while (this.previousQueue.size() > PREVIOUS_QUEUE_CHECK_SIZE) {
                this.previousQueue.remove();
            }
            DataObjectBean dvo = this.previousQueue.peek();

            if (dvo != null) {
                return (P) dvo.getValue();
            }
        }
        return null;
	}

	@Override
	public P getCurrent() {
		execute();

        if (this.currentQueue != null && this.currentQueue.size() > 0) {
            while (this.currentQueue.size() > CURRENT_QUEUE_CHECK_SIZE) {
                this.currentQueue.remove();
            }
            DataObjectBean dvo = this.currentQueue.peek();

            if (dvo != null) {
                return (P) dvo.getValue();
            }
        }
        return null;
	}

	@Override
	public P getNext() {
		execute();

		DataObjectBean value = null;
        do {
            if (this.queue != null) {
                value = this.queue.peek();
            }

            if (isFinish() && this.queue.isEmpty()) {
                break;
            }

            if (value == null) {
                try {
                    Thread.sleep(this.sleepWait);
                } catch (InterruptedException e) {
                    break;
                }
            }
        } while (value == null);

        if (value == null) {
            return null;
        } else if (value.getCollectorStatus() != null) {
        	ICollectorStatus collectorStatus = value.getCollectorStatus();
            if (ICollectorStatus.END.equals(collectorStatus)) {
                setFinish(true);
            }
            return null;
        } else if (value.getValue() == null) {
            return null;
        }

        return (P) value.getValue();
	}
	
	@Override
	public int size() {
		execute();
		return this.queue.size();
	}

}
