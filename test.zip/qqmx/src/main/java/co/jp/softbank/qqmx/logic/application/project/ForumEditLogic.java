package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

import co.jp.softbank.qqmx.dao.project.settings.RoleListDao;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ForumEditLogic extends AbstractBaseLogic {
	
	public void getNewsListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		conditions.put("id", context.getParam().get("id"));
		List<Map<String, Object>> attachments = db.querys("messages.getMessagesInfo", conditions);
		context.getResultBean().setData(attachments);
	}
	
	public void saveNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		conditions.put("board_id", StringUtils.toInt(context.getParam().get("board_id")));
		conditions.put("parent_id", null);
		conditions.put("subject", context.getParam().get("messages_subject"));
		conditions.put("content", context.getParam().get("messages_content"));
		conditions.put("user_id", context.getSessionData().getUserInfo().getId());
		conditions.put("last_reply_id", null);
		conditions.put("locked", "1".equals(context.getParam().get("messages_locked")) ? true : false);
		conditions.put("sticky", context.getParam().get("messages_sticky"));
		
		db.insert("messages.addMessagesInfo", conditions);	
	}
	public void updateNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String newsId = context.getParam().get("news_id");
		conditions.put("news_id", newsId);
		
		conditions.put("subject", context.getParam().get("messages_subject"));
		conditions.put("locked", "1".equals(context.getParam().get("messages_locked")) ? true : false);
		conditions.put("sticky", "1".equals(context.getParam().get("messages_sticky")) ? 1 : 0);
		conditions.put("content", context.getParam().get("messages_content"));
		
		db.update("messages.updateMessagesInfo", conditions);		
	}
	public void delNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("messages_id", StringUtils.toInt(context.getParam().get("messages_id")));		
		
		db.update("messages.deleteMessagesById", conditions);
		db.update("messages.deleteMessagesByParentId", conditions);
	}
}
