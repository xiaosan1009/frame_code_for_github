package co.jp.softbank.qqmx.task.bean;

import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;

import co.jp.softbank.qqmx.task.face.IKey;
import co.jp.softbank.qqmx.task.face.ITask;
import co.jp.softbank.qqmx.task.face.ITaskContext;

public class Worker implements Callable<Worker> {
	
	private ITaskContext ctx;
    private ITask<Object> task;
    private IKey key;
    private Object value;
    private AtomicInteger lines;

    public Worker(ITaskContext context, ITask<Object> task, AtomicInteger lines) throws Exception {
        this.ctx = context;
        this.lines = lines;
        this.task = task;
        this.task.setLines(lines);
    }
    
    public void cleanup() throws Exception {
        task.cleanup(ctx);
    }
    public ITaskContext getContext() {
        return ctx;
    }
    
    public void setKeyValue(IKey key, Object value) {
        this.key = key;
        this.value = value;
    }

	@Override
	public Worker call() throws Exception {
		if (value == null) {
            return this;
        }
        try {
            if (task.isMultiline()) {
                lines.addAndGet(((Collection<?>) value).size());
                task.execute(ctx, key, value);
            } else {
                if (value instanceof Iterable) {
                    for (Object o : ((Iterable<?>) value)) {
                        lines.incrementAndGet();
                        task.execute(ctx, key, o);
                    }
                } else {
                    lines.incrementAndGet();
                    task.execute(ctx, key, value);
                }
            }
        } catch (Exception e) {
        	e.printStackTrace();
        } finally {
            key = null;
            value = null;
        }
        return this;
	}

}
