package co.jp.softbank.qqmx.logic.application.tables;

import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

import com.google.common.collect.Maps;

public class TQueriesLogic extends AbstractBaseLogic {
	
	public void selectQueriesInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("user_id", getUserInfos().getId());
		conditions.put("project_id", context.getParam().projectId);
		context.getResultBean().setData(db.querys("queries.selectQueriesInfo", conditions));
	}
}
